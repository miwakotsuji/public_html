#!/bin/sh

# NB 1: OmniRPC must be set up on the remote PC
# NB 2: OmniRPC binaries must be in the user PATH
# NB 3: the remote machines must have the user's public key (the user who is running the YML scheduler)

#
# PLEASE, fill the 4 following variables
#
REMOTE_MACHINE_NAMES="toto.rech-info.net titi.ast.fr"
USER_NAME="dupont"
LOCAL_STUB_PATH="/usr/local/bin/"
REMOTE_STUB_PATH="~/"

#
# Don't change anything below
#
COMMAND_CONNECT="ssh -x -l $USER_NAME"
COMMAND_REGISTER="omrpc-register -register  ${REMOTE_STUB_PATH}/yml_worker_omnirpc.rex 1>/dev/null; exit;" 

rm -f register_trace.txt;
touch register_trace.txt;

for i in $REMOTE_MACHINE_NAMES 
  do
  # we transfer the stub
  echo `scp ${LOCAL_STUB_PATH}/yml_worker_omnirpc.rex ${USER_NAME}@${i}:${REMOTE_STUB_PATH}/.` 1>/dev/null
  # we register the stub
  `${COMMAND_CONNECT} $i ${COMMAND_REGISTER}`
  if  [ "$?" != "0" ]; then      
      echo "$i: the stub could not be registered"  1>> register_trace.txt   
  else     
      echo "$i: OK"  1>> register_trace.txt  
  fi 
done
