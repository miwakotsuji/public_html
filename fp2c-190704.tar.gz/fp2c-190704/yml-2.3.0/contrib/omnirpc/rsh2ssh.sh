#!/bin/bash
alias rsh="ssh"


