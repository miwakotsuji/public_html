#include <OmniRpc.h>
#include <stdio.h>
#include <math.h>

int main(int argc,char *argv[]){

  int a_int,b_int;
  int c_int;
  double a_double,b_double;
  double c_double;
  int ret;
  int i;
  int tab_c[5];

  OmniRpcRequest req;
  OmniRpcRequest req_bis[5];

  printf ("before init\n");           
  OmniRpcInit(&argc,&argv);
  printf ("after init\n");

  a_int = 2;
  b_int = 3;
  c_int = 0;

  fprintf(stdout,"Test OmniRpcCallAsync et OmniRpcWait - 1 job\n");
  req = OmniRpcCallAsync("plusInt", a_int, b_int, &c_int);
  OmniRpcWait(req);
  fprintf(stdout,"plusInt, c = %d\n",c_int);

  fprintf(stdout,"Test OmniRpcCall\n");
  ret = OmniRpcCall("moinsInt", a_int, b_int, &c_int);
  fprintf(stdout,"plusInt, c = %d\n",c_int);

  fprintf(stdout,"Test OmniRpcCallAsync et OmniRpcWaitAll -  5 job\n");
  for(i=0;i<5;i++){
    req_bis[i] = OmniRpcCallAsync("foisInt", a_int, b_int, &tab_c[i]);
  }
  OmniRpcWaitAll(5, req_bis);
  for(i=0;i<5;i++){
    fprintf(stdout,"foisInt, tab_c[%d] = %d\n",i,tab_c[i]);
  }

  fprintf(stdout,"Another test OmniRpcCallAsync et OmniRpcWaitAll -  5 job\n");
  for(i=0;i<5;i++){
    req_bis[i] = OmniRpcCallAsync("doNothing", 1000000);
  }
  OmniRpcWaitAll(5, req_bis);

  printf ("before finalize\n"); 
  OmniRpcFinalize();
  printf ("after finalize\n");
  
  return 0;
}
