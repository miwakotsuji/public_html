#!/bin/bash
#
###### A) Please, enter the 3 following informations
#
USER_NAME_BACKEND="choy"; 
MACHINE_NAME_BACKEND="pelevoue"; # fully qualified domain name
YML_INSTALL_DIR="/home/choy/THESE/OLD_WORK_YML/"; # full path of the YML install dir
#
###### B) Please, check the format of the omnirpc platform desciption
#
# Server <name server> <number of nodes>
# User <user name>
# /@/Install <dir of install - bin, lib, include...>
# /@/Files <dir of omni files - hosts.xml, nodes, stub...>
# <name node1>
# <name node2>
# <name node3>
#... 
# Server <name server> <number of nodes>
# User <user name>
# /@/Install <dir of install - bin, lib, include...>
# /@/Files <dir of omni files - hosts.xml, nodes, stub...>
# <name node1>
# ...
# 
# NB 1: all machine names MUST BE fully qualified domain names
# NB 2: /@/ is just a token allows recognizing  the mark "/@/Files" and
#       a possible token "Files" in the path of the omnirpc file dir
# NB 3: same remark for /@/Install
##### Please, do not change the following instructions

rm serversFile.txt;
rm nodesFile.txt;
touch serversFile.txt;
touch nodesFile.txt;

rm hosts.xml;
touch hosts.xml;
echo "<?xml version="1.0" ?>" >> hosts.xml
echo "<OmniRpcConfig>" >> hosts.xml


NB_NODES="";
NODES_NAME="";
SERVER_NAME="";
USER_NAMES="";
OMNI_INSTALL_DIR="";
OMNI_FILE_DIR="";
OMNI_FILE_DIR_BACKEND="";

OMNIBACKEND_CONFIG_FILE="$YML_INSTALL_DIR/omnirpc.xcf";
if [ -e "$OMNIBACKEND_CONFIG_FILE" ]; then
    OMNI_FILE_DIR_BACKEND=$"`grep "hostfileDir" $OMNIBACKEND_CONFIG_FILE | awk '{print $3}' | sed 's/value=//g' | sed 's/\"//g' `"
else
    echo "$YML_INSTALL_DIR/omnirpc.xcf not found!"
    exit;
fi


if [ -e "omniPlatform.txt" ]; then
    

    echo "### CONFIG SUMMARY ###"
    SERVER_NAME=$"`awk '/Server/ {print $2}' omniPlatform.txt`"
    echo "All servers:"
    echo "$SERVER_NAME"

    NB_NODES=$"`awk '/Server/ {print $3}' omniPlatform.txt`"
    echo "Numbers of workers per server:"
    echo "$NB_NODES"
 
    NODES_NAME=$"`grep -v "Server\|User\|\/@\/Install\|\/@\/Files"  omniPlatform.txt`"
    echo "All workers:"
    echo "$NODES_NAME"
    
    USER_NAMES=$"`awk '/User/ {print $2}' omniPlatform.txt`"
    echo "User name on server machines:"
    echo "$USER_NAMES"

    OMNI_INSTALL_DIR=$"`awk '/\/@\/Install/ {print $2}' omniPlatform.txt`"
    echo "OmniRPC install directory on servers:"
    echo "$OMNI_INSTALL_DIR" 

    OMNI_FILE_DIR=$"`awk '/\/@\/Files/ {print $2}' omniPlatform.txt`"
    echo "OmniRPC file directory on servers:" 
    echo "$OMNI_FILE_DIR  " 
    echo "### END SUMMARY ###"
    echo ""

    l=0
    for name in $SERVER_NAME
      do
      SERVER_NAME_TAB[$l]=$name;
      l=$((l+1));
    done    
    
    l=0
    for name in $NODES_NAME
      do
      NODES_NAME_TAB[$l]=$name;
      l=$((l+1));
    done
    
    l=0
    for nb in $NB_NODES
      do
      NB_NODES_TAB[$l]=$nb;
      l=$((l+1));
    done

    l=0
    for name in $USER_NAMES
      do
      USER_NAMES_TAB[$l]=$name;
      l=$((l+1));
    done
    
    l=0
    for name in $OMNI_INSTALL_DIR
      do
      OMNI_INSTALL_DIR_TAB[$l]=$name;
      l=$((l+1));
    done    
   
    l=0
    for name in $OMNI_FILE_DIR
      do
      OMNI_FILE_DIR_TAB[$l]=$name;
      l=$((l+1));
    done 
 
    l=0
    RANK_NODES_TO_LOAD=0
    for i in $SERVER_NAME
      do
      
      echo "<Host name=\"$i\"  user=\"${USER_NAMES_TAB[$l]}\" arch=\"i386\" os=\"linux\">" >> hosts.xml
      echo "<Agent invoker=\"ssh\" mxio=\"on\" path=\"${OMNI_INSTALL_DIR_TAB[$l]}\"/>"  >> hosts.xml 
      echo "<JobScheduler type=\"rr\" maxjob=\"${NB_NODES_TAB[$l]}\" />"  >> hosts.xml 
      echo "<Registry path=\"${OMNI_FILE_DIR_TAB[$l]}\" />"  >> hosts.xml 
      echo "</Host>"  >> hosts.xml 
      
      rm nodes
      touch nodes
      
      NB_NODES_MUST_LOAD=${NB_NODES_TAB[$l]}  
      RINF=RANK_NODES_TO_LOAD
      RSUP=RANK_NODES_TO_LOAD+NB_NODES_MUST_LOAD-1
      CURR=RINF
      STOP=0
      CONTINUE=1
      while (($STOP!=$CONTINUE));do 
	echo "${NODES_NAME_TAB[$CURR]} ssh" >> nodes
	CURR=$((CURR+1))
	if (($CURR>$RSUP ));then
	    STOP=1
	fi
      done
      echo "Copy node file: scp nodes ${USER_NAMES_TAB[$l]}@$i:${OMNI_FILE_DIR_TAB[$l]}/."
      `scp nodes ${USER_NAMES_TAB[$l]}@$i:${OMNI_FILE_DIR_TAB[$l]}/.`
      RANK_NODES_TO_LOAD=$((CURR))
      
      l=$((l+1));
    done
    echo "</OmniRpcConfig>" >> hosts.xml

    echo "Copy host file: scp hosts.xml $USER_NAME_BACKEND@$MACHINE_NAME_BACKEND:$OMNI_FILE_DIR_BACKEND/."
    `scp hosts.xml $USER_NAME_BACKEND@$MACHINE_NAME_BACKEND:$OMNI_FILE_DIR_BACKEND/.`
else
    echo "The file omniPlatform.txt is not found"
fi



##############################################################


