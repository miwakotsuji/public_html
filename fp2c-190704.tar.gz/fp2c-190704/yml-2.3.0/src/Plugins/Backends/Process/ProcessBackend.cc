/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/

/**
 * @file
 * @brief Class ProcessBackend function definition 
 *
 * 2005-07-02
 * Olivier Delannoy
 */
#include "ProcessBackend.hh" 


#include <Dir.hh>
#include <Process.hh>
#include <UID.hh>
#include <MD5.hh>
#include <RuntimeEnvironment.hh>
#include <LoggerFactory.hh>
#include <ConfigFactory.hh>
#include <Pack.hh>
#include <File.hh>
#include <Dir.hh>
#include <DirHandler.hh> 
#include <fstream> 

namespace ProcessBackend
{

// Finished 
ProcessBackend::ProcessBackend()
{
}
 
// Finished
ProcessBackend::~ProcessBackend()
{
}

// Finished 
void ProcessBackend::initImpl(const Yml::Core::string& initData)
{ 
    Util::Config* config = Util::ConfigFactory::getSingleton().create(initData);
    mRunDir = config->get("path", "runtime", "");
    if (mRunDir.empty())
    {
        // No runtime directory set in the configuration file
        UTIL_FATAL("default", "No runtime directory configuration");
    }
}


// To be finished 
Yml::Core::SchedulerTask* ProcessBackend::retrieveImpl()
{
    TaskList::iterator iter = mTasks.begin();
    for(iter ; iter != mTasks.end() ; ++iter)
    {
        if ((*iter)->mTerminate)
        {
            Yml::Core::SchedulerTask* res = (*iter)->mTask;
            delete *iter;
            mTasks.erase(iter);
            return res;
        }
    }
    iter = mTasks.begin();
    for(iter ; iter != mTasks.end() ; ++iter)
    {
        if (!(*iter)->mTerminate) 
        {
            if ((*iter)->mProcess.state() == Util::PROCESS_FINISHED)
            {
                
                UTIL_INFO("default", "Task " << (*iter)->mTask->index() << " finished its execution");
                UTIL_INFO("default", "Packing admin data for task " << (*iter)->mTask->index());
                Util::Pack pack((*iter)->mTask->packAdmin());
                pack.add("trace.txt", (*iter)->mDir + "trace.txt");
                pack.add("status.txt", (*iter)->mDir + "status.txt");
                
                UTIL_INFO("default", "Packing output data of task " << (*iter)->mTask->index());
                
                Util::Pack packOut((*iter)->mTask->packOutput());
                std::ifstream outList(((*iter)->mDir + "output.txt").c_str());
                while(outList)
                {
                    Yml::Core::string tmp;
                    outList >> tmp;
                    if (!outList)
                        break;
                    UTIL_DEBUG("default", "Packing: " << tmp << "->" << (*iter)->mDir + tmp);
                    packOut.add(tmp, (*iter)->mDir + tmp);

                }
                outList.close();
                UTIL_DEBUG("default", "End Packing results");
                
                Util::Dir::rmdir((*iter)->mDir);
                (*iter)->mTerminate = true;
            }
        }
    }
    iter = mTasks.begin();
    for(iter ; iter != mTasks.end() ; ++iter)
    {
        if ((*iter)->mTerminate)
        {
            Yml::Core::SchedulerTask* res = (*iter)->mTask;
            delete *iter;
            mTasks.erase(iter);
            return res;
        }
    }
    return 0;
}

class FileList_dirHandler : public Util::DirHandler
{
public:
    FileList_dirHandler(Util::StringList& list)
        : mList(list) 
    {
    }
    
    void onFile(const Util::String& dirName, const Util::String& fileName)
    {
        Util::String tmp(fileName);
        tmp += " ";
        tmp += Util::MD5::fileToString(dirName + Util::RuntimeEnvironment::PATH_SEPARATOR + fileName);
        mList << tmp;
    }
private:
    Util::StringList& mList;
};

    

// Finished 
bool ProcessBackend::executeImpl(Yml::Core::SchedulerTask* task)
{
    // Retrieve the implementation component name to use 
    Yml::Core::string bin = Yml::Core::PluginManager::getSingleton().getExecutionCatalog().selectComponent(task);
    if (bin.empty())
    {
        UTIL_ERROR("default", "No binary available for abstract component: " << task->component());
        return false;
    }
    UTIL_INFO("default", "Abstract component: " << task->component() << " instancied using " << bin);
    // Create a Dir for the execution of the task 
    Yml::Core::string mDir = mRunDir + Util::UID::createUID() + Util::RuntimeEnvironment::PATH_SEPARATOR;
    Util::Dir::mkdir(mDir);
    UTIL_INFO("default", "Execution in directory: " << mRunDir);
    mTasks.push_back(new ProcessHandler(mDir, task));
    //Unpack
    Util::Pack pack(task->packInput());
    UTIL_INFO("default", "Unpacking data from: " << task->packInput());
    pack.extractAll(mDir);
    //Prepare the command line 
    Util::StringList params;
    for(Yml::Core::uint32 i = 0 ; i < task->parameters() ; ++i)
    {
        Yml::Core::string prm = task->parameter(i);
        params << prm;
    }
    
    // Update this to use Util::DirHandler 
    FileList_dirHandler handler(mTasks.back()->mFiles);
    // Creer la liste des fichiers sous forme d'une chaine nom md5sum 
    Util::Dir::visit(handler, mDir, false);
    //Execute
    mTasks.back()->mStartTime = Util::RuntimeEnvironment::unixTime();
    UTIL_INFO("default", "Starting task " << task->index());
    return mTasks.back()->mProcess.start(mBinDir + Util::RuntimeEnvironment::PATH_SEPARATOR + bin, params, mDir);
}

}

/*! 
    Plugin access function 
 */ 
extern "C" ProcessBackend::ProcessBackend* create(void)
{
    return new ProcessBackend::ProcessBackend;
}

/*! 
    Plugin instance deallocator function 
 */
extern "C" void destroy(ProcessBackend::ProcessBackend* object)
{
    delete object;
}

