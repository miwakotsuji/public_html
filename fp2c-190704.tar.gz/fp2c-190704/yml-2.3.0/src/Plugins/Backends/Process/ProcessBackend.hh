/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/

/**
 * @file
 * @brief Class ProcessBackend declaration
 *  
 * 2005-07-02
 * Olivier Delannoy
 *
 *
 */
#ifndef PROCESSBACKEND_HH
#define PROCESSBACKEND_HH 1
#include <Yml/Core/Backend.hh>
#include <Yml/Core/SchedulerTask.hh>
#include <Yml/Core/ExecutionCatalog.hh>
#include <Yml/Core/PluginManager.hh>
#include <Process.hh>
#include <StringList.hh> 
#include <list>
namespace ProcessBackend
{
/*! 
  \brief 
  Store an active component while it is running.
  
  Store an active component while it is running.

  \internal 
*/
struct ProcessHandler 
{
    Yml::Core::uint32 mStartTime;
    bool mTerminate;
    Util::Process mProcess;
    Yml::Core::string mDir;
    Yml::Core::SchedulerTask* mTask;
    Util::StringList mFiles;
    
    ProcessHandler(const Yml::Core::string& dirname, Yml::Core::SchedulerTask* task)
        :  mStartTime(0), mTerminate(false), mDir(dirname), mTask(task)
    {
    }
};
/*! 
  \brief 
  Process based backend.

  Process based backend. This backend is usefull to test an
  application on a single host. Everything is made so that an
  application running on this backend works exactly the same as on a
  distributed platform using one of the other backend available 
*/
class ProcessBackend : public Yml::Core::Backend
{
    typedef std::list<ProcessHandler*> TaskList;
    
public:
    ProcessBackend();
    ~ProcessBackend();
protected:        
    void initImpl(const Yml::Core::string& initData);
    bool executeImpl(Yml::Core::SchedulerTask* task);
    Yml::Core::SchedulerTask* retrieveImpl(void);
    
private:
    /** Store tasks in the list */
    TaskList mTasks;
    /** Store the path to the runtime dir */
    Yml::Core::string mRunDir;
    /** Store the path to the binary data */
    Yml::Core::string mBinDir;
};
}
#endif

