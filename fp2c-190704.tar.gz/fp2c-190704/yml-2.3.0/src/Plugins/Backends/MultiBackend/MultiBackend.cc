/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/

/**
 * @file
 * @brief Class MultiBackendBackend function definition 
 *
 * 2007-09-22
 * Olivier Delannoy
 */
#include <map>
#include <deque>
#include <Yml/Core/Backend.hh>
#include <Yml/Core/SchedulerTask.hh>
#include <Yml/Core/ExecutionCatalog.hh>
#include <Yml/Core/PluginManager.hh>
#include <Yml/UDP/UDP.hh>
#include <LoggerFactory.hh>
#include <ConfigFactory.hh>




namespace MultiBackendBackend
{
/*! 
  \brief 
  MultiBackend based backend.

  MultiBackend based backend. This is a special backend used to
  delegate the execution of a set of tasks to one or several 
  backend. 
*/
class MultiBackendBackend : public Yml::Core::Backend, public enet::SignalBindable
{
    typedef std::deque<Yml::Core::SchedulerTask*> TaskQueue;
    typedef std::map<Yml::Core::uint32, Yml::Core::SchedulerTask*> TaskList;

public:
    MultiBackendBackend();
    ~MultiBackendBackend();
protected:        

    void initImpl(const Yml::Core::string& initData);
    void cleanupImpl();

    bool executeImpl(Yml::Core::SchedulerTask* task);
    Yml::Core::SchedulerTask* retrieveImpl(void);
    void cancelImpl(Yml::Core::uint32 task);
private:
    void doConnect(Yml::UDP::Peer& peer);
    void doDisconnect(Yml::UDP::Peer& peer);
    void doReceive(Yml::UDP::Peer& peer, Yml::UDP::Message* message);
    
    /** Check if some tasks are finished */
    void pollActiveTasks();
    
    /** Store tasks in the list */
    TaskList mActive;
    /** Store finished tasks */
    TaskQueue mFinished;
    Yml::Core::string mBMHost;
    Yml::Core::uint32 mBMPort;
    Yml::UDP::UDP mUDPLibrary;
    Yml::UDP::Host mHost;
    bool mConnected;
    
};

MultiBackendBackend::MultiBackendBackend()
{
    mHost.onPeerConnect.connect(*this, &MultiBackendBackend::doConnect);
    mHost.onPeerDisconnect.connect(*this, &MultiBackendBackend::doDisconnect);
    mHost.onMessageReceived.connect(*this, &MultiBackendBackend::doReceive);
    mConnected = false;
}
MultiBackendBackend::~MultiBackendBackend(){}

// Signal Handlers 
void MultiBackendBackend::doConnect(Yml::UDP::Peer& peer)
{
    UTIL_INFO("default", "Connected to the back-end manager");
    mConnected = true;
    Yml::UDP::MSGApplicationStart msg;
    peer.send(&msg, 0);
    mHost.flush();
}

void MultiBackendBackend::doDisconnect(Yml::UDP::Peer& peer)
{
    // It's bad 
    UTIL_FATAL("default", "We have been disconnected from the back-end manager");
}

void MultiBackendBackend::doReceive(Yml::UDP::Peer& peer, Yml::UDP::Message* message)
{
    switch(message->type())
    {
    case Yml::UDP::MSG_TASK_FINISHED:
    {
        // Here is the interesting part 
        Yml::UDP::MSGTaskFinished* finished = static_cast<Yml::UDP::MSGTaskFinished*>(message);
        // Do something
        Yml::Core::uint32 index = finished->task().task_id;
        TaskList::iterator iter = mActive.find(index);
        if (iter != mActive.end())
        {
            iter->second->setStatus((Yml::Core::ExecutionStatus)finished->task().task_status);
            mFinished.push_back(iter->second);
            mActive.erase(iter);
        }
    }
    break;

    default:
        UTIL_ERROR("default", "Incomming message of an unknown type");
    }
}



// Finished 
void MultiBackendBackend::initImpl(const Yml::Core::string& initData)
{ 
    Util::Config* config = Util::ConfigFactory::getSingleton().create(initData);
    mBMHost = config->get("back-end manager", "hostname", "localhost");
    Yml::Core::string port = config->get("back-end manager", "port", "5666");
    mBMPort = atoi(port.c_str());
}

void MultiBackendBackend::cleanupImpl() 
{
    // Send fin application
    Yml::UDP::MSGApplicationEnd msg;
    mHost.broadcast(&msg, 0);
    mHost.flush();
}

Yml::Core::SchedulerTask* MultiBackendBackend::retrieveImpl()
{
    pollActiveTasks();
    if (! mFinished.empty())
    {
        Yml::Core::SchedulerTask* res = mFinished.front();
        mFinished.pop_front();
        return res;
    }
    return 0;
}

void MultiBackendBackend::pollActiveTasks()
{
    mHost.service(1000);
}


bool MultiBackendBackend::executeImpl(Yml::Core::SchedulerTask* task)
{
    mActive[task->index()] = task;
    // Initialization de mComm 
    if (! mConnected)
    {
        UTIL_INFO("default", "Connecting to the back-end manager: " << mBMHost << ":" << mBMPort);
        if (! mHost.connect(mBMHost.c_str(), mBMPort, 1, 5))
        {
            UTIL_FATAL("default", "Unable to connect to the back-end manager");
        }
    }
    
    // Submission of the task
    Yml::UDP::MSGTaskSubmit msg;
    msg.setTask(task);
    mHost.broadcast(&msg, 0);
    return true;
}


void MultiBackendBackend::cancelImpl(Yml::Core::uint32 taskId)
{
    TaskList::iterator iter = mActive.find(taskId);
    if (iter != mActive.end())
    {
        Yml::UDP::MSGTaskCancel msg;
        msg.task().task_id = taskId;
        mHost.broadcast(&msg, 0);
        mActive.erase(iter);
    }
}

}

/*! 
    Plugin access function 
 */ 
extern "C" MultiBackendBackend::MultiBackendBackend* create(void)
{
    return new MultiBackendBackend::MultiBackendBackend;
}

/*! 
    Plugin instance deallocator function 
 */
extern "C" void destroy(MultiBackendBackend::MultiBackendBackend* object)
{
    delete object;
}

