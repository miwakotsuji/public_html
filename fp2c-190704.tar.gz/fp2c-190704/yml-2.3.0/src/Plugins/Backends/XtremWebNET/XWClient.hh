/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/
/**
 * @file
 * @brief Class XtremWebClient declaration
 *  
 * 2006-07-12
 * Olivier Delannoy
 *
 *
 */
#ifndef XTREMWEBCLIENT_HH
#define XTREMWEBCLIENT_HH 1
#include <Yml/Core/core.hh>
#include <cassert>
#include <cstring>
#include <vector>
#include <iostream>
#include <arpa/inet.h>
#include <netinet/in.h>

namespace XtremWebBackendNET
{
/** 
 * @brief List RPC Identifier 
 *
 * This is a partial list not completely supported at the moment
 * Commented value are used at the moment 
 */ 
enum XW_IDRPC
{
    XW_IDRPC_FIRST = 0,
    XW_IDRPC_DISCONNECT = 1, 
    XW_IDRPC_CLOSE = 2, 
    XW_IDRPC_SENDAPP = 3, 
    XW_IDRPC_GETAPPBYNAME = 4, //!< Retrieve application information 
    XW_IDRPC_GETAPPBYUID = 5, 
    XW_IDRPC_LOADAPP = 6, 
    XW_IDRPC_GETAPPS = 7, 
    XW_IDRPC_REMOVEAPP = 8, 
    //
    XW_IDRPC_SUBMITWORK = 46, //!< Submit a work 
    XW_IDRPC_BROADCASTWORK = 47, 
    XW_IDRPC_SENDMOBILEWORK = 48, 
    XW_IDRPC_GETWORK = 49, //! Retrieve work info 
    XW_IDRPC_WORKREQUEST = 50, 
    XW_IDRPC_LOADWORK = 51, 
    XW_IDRPC_GETWORKS = 52, 
    XW_IDRPC_REMOVEWORK = 53, //! Cleanup of work info 
    XW_IDRPC_REMOVEWORKS = 54, 
    XW_IDRPC_GETRESULT = 55, //! Retrieve work result 
    XW_IDRPC_SENDRESULT = 56, //! Send work result 
    
    XW_IDRPC_MAX = 68, 
    
};


class XWComm;
class XWCommTCP;
class XWCommUDP;
class XWMessage;
class XWClient;


/*! 
 * @brief XtremWeb Communication layer. 
 * 
 * This class is an abstract class for communicating with XW. It's only task 
 * is to contact a dispatcher and submit him a query. The same comm layer must handle repeated 
 * client request. Basically the communication layer deals only with two thing 
 * submit an XWMessage and wait for an XWMessage from the DRServer. This might not be as 
 * nice as easy as it looks like. This separation might require some more information from 
 * XWMessage in TCP. (We will see later) 
 */ 
 
class XWComm 
{
public:
    virtual ~XWComm() {}
    
    bool execute(const XWMessage& request, XWMessage& result);
    

protected:
    XWComm(const Yml::Core::string& host, const Yml::Core::string& port);

    virtual bool startComm() = 0;
    virtual bool send(const XWMessage& request) = 0;
    virtual bool recv(XWMessage& result) = 0;
    virtual void endComm() = 0;
    struct sockaddr_in d_dispatcherAddress;
private:

};

    

/**
 * @brief XtremWeb Client packet class. 
 *
 * This class is used to prepare a packet to be sent on the network
 * once created. This is used to prepare all message before emission
 * and thus being able to switch almost freely between TCP / UDP.
 */
class XWMessage
{
public:
    static const Yml::Core::uint32 MESSAGE_SIZE = 20480;
    
    XWMessage()
        : d_offsetRead(0), d_offsetWrite(0)
    {
        memset(d_data, 0, MESSAGE_SIZE);
    }
    
    XWMessage& writeChar(char value)
    {
        //assert (d_offsetWrite < MESSAGE_SIZE);
        d_data[d_offsetWrite] = value;
        ++d_offsetWrite;
        return *this;
    }
    XWMessage& readChar(char& value)
    {
        //assert (d_offsetRead < d_offsetWrite);
        value = d_data[d_offsetRead];
        ++d_offsetRead;
        return *this;
    }
    XWMessage& writeShort(Yml::Core::int16 value)
    {
        //assert (d_offsetWrite + sizeof(value) <  MESSAGE_SIZE);
        Yml::Core::int16 tmp = htons(value);
        memcpy(d_data + d_offsetWrite, (char*)&tmp, sizeof(tmp));
        d_offsetWrite += sizeof(tmp);
        return *this;    
    }
    XWMessage& readShort(Yml::Core::uint16& value)
    {
        //assert (d_offsetRead + sizeof(value) < d_offsetWrite);
        memcpy((char*)&value, d_data + d_offsetRead, sizeof(value));
        value = ntohs(value);
        d_offsetRead += sizeof(value);
        
        return *this;    
    }
    XWMessage& writeInt(Yml::Core::int32 value)
    {
        //assert (d_offsetWrite + sizeof(value) <  MESSAGE_SIZE);
        Yml::Core::int32 tmp = htonl(value);
        memcpy(d_data + d_offsetWrite, (char*)&tmp, sizeof(tmp));
        d_offsetWrite += sizeof(tmp);
        return *this;
    }
    XWMessage& readInt(Yml::Core::int32& value)
    {
        //assert (d_offsetRead + sizeof(value) < d_offsetWrite);
        memcpy((char*)&value, d_data + d_offsetRead, sizeof(value));
        value = ntohl(value);
        d_offsetRead += sizeof(value);
        return *this;    
    }
    XWMessage& writeLong(Yml::Core::int64 value)
    {
        //assert (d_offsetRead + sizeof(value) <  MESSAGE_SIZE);
        Yml::Core::int64 tmp = htonl(value);
        memcpy(d_data + d_offsetWrite, (char*)&tmp, sizeof(tmp));
        d_offsetWrite += sizeof(tmp);
        return *this;    
    }
    XWMessage& readLong(Yml::Core::int64& value)
    {
        //assert (d_offsetRead + sizeof(value) < d_offsetWrite);
        memcpy((char*)&value, d_data + d_offsetRead, sizeof(value));
        value = ntohl(value); // This is probably not going to work... 
        d_offsetRead += sizeof(value);
        return *this;    
    }
    XWMessage& writeString(const Yml::Core::string& value)
    {
        writeShort(value.size());
        memcpy(d_data + d_offsetWrite, value.data(), value.size());
        d_offsetWrite += value.size();
        
        return *this;
    }
    XWMessage& readString(Yml::Core::string& value)
    {
        Yml::Core::uint16 size;
        readShort(size);
        value.assign(d_data + d_offsetRead, size);
        d_offsetRead += size;
        
        return *this; 
    }
    
    // XWMessage& writeArray(const char*, Yml::Core::uint32& size);
    // XWMessage& readArray(char*& ptr, Yml::Core::uint32& size);
    const char* data() const
    {
        return d_data;
    }
    char* data()
    {
        return d_data;
    }
    size_t size() const
    {
        return d_offsetWrite;
    }
    size_t& size() 
    {
        return d_offsetWrite;
    }
    size_t capacity() const
    {
        return MESSAGE_SIZE;
    }
    
private:
    char d_data[MESSAGE_SIZE];
    size_t d_offsetRead;
    size_t d_offsetWrite;
};


class XWCommUDP : public XWComm 
{
public:
    XWCommUDP(const Yml::Core::string& host, const Yml::Core::string& port)
        : XWComm(host, port), d_sock(-1)
    {
        
    }
    ~XWCommUDP()
    {
        if (d_sock != -1) ::close(d_sock);
    }
protected:
    bool startComm();
    bool send(const XWMessage& request);
    bool recv(XWMessage& result);
    void endComm();
    
private:
    int d_sock;
};

   
class XWCommTCP : public XWComm 
{
public:
    XWCommTCP(const Yml::Core::string& host, const Yml::Core::string& port)
        : XWComm(host, port), d_sock(-1)
    {    
    }
    ~XWCommTCP()
    {
        if (d_sock != -1) ::close(d_sock);
    }
    
    
protected:
    bool startComm();
    bool send(const XWMessage& request);
    bool recv(XWMessage& result);
    void endComm();
    
private:
    int d_sock;
};

    

/**
 * @brief XtremWeb Client class. 
 * 
 * This class is used with recent version of XtremWeb. It is the begining of a
 * full featured client for XtremWeb using TCP interface at the moment. 
 * The current solution is far from being perfect because it handles only 
 * partially the interaction with XtremWeb. Direct access to the database 
 * is still needed for monitoring. 
 * @code 
 *
 * int main()
 * {
 *     String ymlWorkerUID(XtremWebClient("192.168.0.100", 4229, "xw_1_7_0", "your pass here").getAppUIDByName("yml"));
 *     String jobId = XtremWebClient("192.168.0.100", 4229, "xw_1_7_0", "your pass here").submit(ymlWorkerUID, "un label", "param1 param2 param3"); 
 *     std::cout << "YML Worker UID: " << ymlWorkerUID << std::endl;
 *     std::cout << "Submit work: " << jobId << std::endl;
 *     return 0;
 * }
 * @endcode 
 */
class XWClient
{
private:

public:  
    /** 
     * Create a new client and connect to the server using TCP 
     */
    XWClient(const Yml::Core::string& version, 
             const Yml::Core::string& protocol, 
             const Yml::Core::string& host, 
             const Yml::Core::string& port, 
             const Yml::Core::string& login, 
             const Yml::Core::string& password);

    /** 
     * Destructor 
     */ 
    ~XWClient();

    bool cacheInformation(const Yml::Core::string& workerName);

    /** 
     * Retrieve the application description (XML element) corresponding to app @em name
     */ 
    Yml::Core::string getAppByName(const Yml::Core::string& name);
    /**
     * Retrieve the application UID required to submit a job 
     */
    Yml::Core::string getAppUIDByName(const Yml::Core::string& name);
    /** 
     * Submit a job 
     */ 
    Yml::Core::string workSubmit(const Yml::Core::string& label, const Yml::Core::string& cmdLine);

    /** 
        Retrieve work description 
    */ 
    Yml::Core::string work(const Yml::Core::string& wid);
    /** 
     * Retrieve a job status 
     */
    Yml::Core::int32 workStatus(const Yml::Core::string& wid);
    /**
     * Queue clean work 
     */
    void clean(const Yml::Core::string& wid);
    /**
     * Do cleanup 
     */ 
    void doCleanup();
    
    bool error() const;    
private:
    /** Wether apps uid has been retrieved or not */
    bool d_cached;
    /** The communication layer used  */ 
    XWComm* d_communicator;
    /** The user ids stored in XML */ 
    Yml::Core::string d_user;
    /** App uid */
    Yml::Core::string d_appUID;
    /** Store pending works for cleanup */
    std::vector<Yml::Core::string> d_pendingClean;    
    
    // Helper functions 
    /** 
     * Create an UID "a la" JAVA 
     * @see java.rmi.server.UID#UID() 
     */
    Yml::Core::string newUID();
    /**
     * convert a value to a Yml::Core::string using an arbitrary base (2-36)
     */
    Yml::Core::string itoa(long long value, int radix);


private:
    // Disabled operation 
    XWClient(XWClient& client);
    XWClient& operator=(XWClient& client);
};

}
#endif
