/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/

/**
 * @file
 * @brief Class XtremWebBackend function definition 
 *
 * 2005-07-02
 * Olivier Delannoy
 */
#include "XtremWebBackendNET.hh"
#include "XWClient.hh" 

#include <UID.hh>
#include <Dir.hh>
#include <File.hh>
#include <RuntimeEnvironment.hh> 
#include <ConfigFactory.hh>
#include <LoggerFactory.hh>
#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm>

namespace XtremWebBackendNET
{

XtremWebBackendNET::XtremWebBackendNET(void) 
    : mAppUID(Util::UID::createUID() + "_"), mClient(0)
{    
}


XtremWebBackendNET::~XtremWebBackendNET(void)
{
    delete mClient;
}

void XtremWebBackendNET::initImpl(const Yml::Core::string& initData)
{
    // Init the rest of the backend 
    Util::Config* config = Util::ConfigFactory::getSingleton().create(initData);
    Util::Config* ymlConfig = Util::ConfigFactory::getSingleton().create("yml");
    // Task descriptor Dir and Group 
    mWorkDescGroup = "work-desc/" ;
    mWorkDescDir = ymlConfig->get("path", "dr-root") + mWorkDescGroup;
    Util::Dir::mkdir(mWorkDescDir);
    // Create the XW Client object

    Yml::Core::string xwVersion      = config->get("general", "version",  "1.8.0");
    Yml::Core::string xwUserLogin    = config->get("general", "user",     "yml");
    Yml::Core::string xwUserPassword = config->get("general", "password", "");
    Yml::Core::string xwServerHost   = config->get("general", "server",   "localhost");
    Yml::Core::string xwServerPort   = config->get("general", "port",     "4325"); // 25 for TCP 
    Yml::Core::string xwProtocol     = config->get("general", "protocol",  "tcp");
    Yml::Core::string xwWorkerName   = config->get("general", "worker",   "yml_xtremweb_worker_net");
    
    // Log the configuration 
    UTIL_INFO("default", "XtremWeb backend configuration");
    UTIL_INFO("default", " - Path configuration");
    UTIL_INFO("default", "   - Work descriptions: " << mWorkDescDir);
    UTIL_INFO("default", " - XtremWeb configuration");    
    UTIL_INFO("default", "   - Version: "          << xwVersion);
    UTIL_INFO("default", "   - Protocol: "         << xwProtocol);
    UTIL_INFO("default", "   - Server Host: "      << xwServerHost);
    UTIL_INFO("default", "   - Server Port: "      << xwServerPort);
    UTIL_INFO("default", "   - User: "             << xwUserLogin);
    UTIL_INFO("default", "   - Worker name: "      << xwWorkerName);
    UTIL_INFO("default", " - Data Repository Server");
    UTIL_INFO("default", "   - Host: "             << mDRHost);
    UTIL_INFO("default", "   - Port: "             << mDRPort);
    UTIL_INFO("default", "   - Work desc group: "  << mWorkDescGroup);
    UTIL_INFO("default", "   - Binary group: "     << mBinGroup);
    UTIL_INFO("default", " - Application UID: "    << mAppUID);
    
    

    mClient = new XWClient(xwVersion, xwProtocol, xwServerHost, xwServerPort, 
                           xwUserLogin, xwUserPassword);
    if (mClient->error())
    {
        UTIL_FATAL("default", "XtremWebBackendNET: unable to connect to the XtremWeb dispatcher");
    }
    mClient->cacheInformation(xwWorkerName);
    UTIL_INFO("default", "XtremWebBackendNET: initialization successfull");
}


bool XtremWebBackendNET::executeImpl(Yml::Core::SchedulerTask* task)
{
    // Creation of the tasks descriptor
    std::ostringstream taskUID;
    taskUID << mAppUID;
    taskUID << task->index();
    Yml::Core::string taskFileName = taskUID.str(); 
    std::ofstream workDescription((mWorkDescDir + taskFileName).c_str());
    workDescription << task->work() << std::endl;
    workDescription.close();
    

    // Prepare the command line 
    std::ostringstream xwCmdLine;
    xwCmdLine << mDRHost << ' ' << mDRPort << " /" << mWorkDescGroup << "/" << taskFileName;
    Yml::Core::string tuid = taskUID.str();

    // Submit and marshall 
    Yml::Core::string wid = mClient->workSubmit(tuid, xwCmdLine.str());
    if (wid.empty())
    {
        UTIL_ERROR("default", "Task '"<< tuid << "' submission failed");
        return false;
    }
    
    UTIL_DEBUG("default", "Task '" << tuid << "' submitted successfully with UID '" << wid << "'");
    mActive.push_back(std::make_pair(wid, task));
    return true;
}


Yml::Core::SchedulerTask* XtremWebBackendNET::retrieveImpl(void)
{
    UTIL_DEBUG("default", "Backend statistics: Current active task:  " << mActive.size() << " Current finished task: " << mFinished.size());
    
    // Try to find a completed task no pooling if some are already available 
    if (! mFinished.empty())
    {
	Yml::Core::SchedulerTask* res = mFinished.front();
        mFinished.pop_front();
        return res;
    }
    else if (!mActive.empty())
    {
        // Try to find a completed tasks by checking for finished tasks 
        pollActiveWorks();   
        if (! mFinished.empty())
        {
            Yml::Core::SchedulerTask* res = mFinished.front();
            mFinished.pop_front();
            return res; 
        }    
    }   
    sleep(4);
    mClient->doCleanup();
    return 0;
}

struct CleanFinishedTask 
{
    bool operator()(std::pair<Yml::Core::string, Yml::Core::SchedulerTask*> const& item)
    {
        //UTIL_DEBUG("default", "UID: " << item.first << " Task address: " << item.second);
        
        return item.second == 0;
    }    
};

void XtremWebBackendNET::pollActiveWorks()
{
    // For each running works do
    TaskList::iterator iter = mActive.begin();
    const TaskList::iterator end = mActive.end();
    for(; iter != end ; ++iter) 
    {
        Yml::Core::int32 status = mClient->workStatus(iter->first);
        if (status != -1)
        {
            // The work is finished
            UTIL_DEBUG("default", "Status for work: " << iter->first << " is " << status);
            if (status != 0)
                iter->second->setStatus(Yml::Core::ExecError);
            // Add the task to finished works 
	    UTIL_DEBUG("default", "Register work: " << iter->first << " for cleanup");
            mClient->clean(iter->first); // Queue cleanup of the work
#ifndef HAVE_DEBUG 
            std::ostringstream taskFile;
            taskFile << mWorkDescDir << mAppUID << iter->second->index();
            Util::File::remove(taskFile.str());
#endif
	    UTIL_DEBUG("default", "Add task to finished task list"); 
            mFinished.push_back(iter->second);
            iter->second = 0;
        }
    }
    UTIL_DEBUG("default", "Cleanup active works");
    TaskList::iterator new_beg = std::remove_if(mActive.begin(), mActive.end(), CleanFinishedTask());
    mActive.erase(new_beg, mActive.end());
}


} // end of namespace 


extern "C" XtremWebBackendNET::XtremWebBackendNET* create(void)
{
    return new XtremWebBackendNET::XtremWebBackendNET();
}

extern "C" void destroy(Yml::Core::Backend* obj)
{
    delete static_cast<XtremWebBackendNET::XtremWebBackendNET*>(obj);
}

