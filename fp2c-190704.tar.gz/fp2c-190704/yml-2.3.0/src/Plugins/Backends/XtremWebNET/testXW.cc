/** 
 * Test program for XW that try to submit a job and wait for its execution 
 */
#include "XWClient.hh" 
#include <unistd.h>
#include <iostream>




int main()
{
  std::cout << "Initialize XWClient" << std::endl;
  XtremWebBackendNET::XWClient client("1.8.0", "tcp", "192.168.0.100", "4325", "xw2", "fa75c61b2144868c8cbd928d1");
  //XtremWebBackendNET::XWClient client("1.8.0", "udp", "192.168.0.100", "4328", "xw2", "fa75c61b2144868c8cbd928d1");
  std::cout << "Application UID: " << client.getAppUIDByName("ls") << std::endl;
  std::cout << "Caching data" << std::endl;
  
  if (client.cacheInformation("ls"))  {
    Yml::Core::string wid = client.workSubmit("essaie", "-lh");
    int workStatus = -1;  
    while(workStatus < 0) {
      workStatus = client.workStatus(wid);
      std::cout << "WorkStatus: " << wid << ": " << workStatus << std::endl;
      usleep(1000);
    }
    client.clean(wid);
  }
  
  client.doCleanup();
  
  return 0;
}
