/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/
/**
 * @file
 * @brief Class XtremWebClient definition 
 *  
 * This file is introduce for XtremWeb version 1.7.0 and later 
 * 
 * 2005-07-02
 * Olivier Delannoy
 */
#include "XWClient.hh"
#include <sstream> 
#include <iostream>
#include <climits>
#include <LoggerFactory.hh> 

#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <cstdlib>



namespace XtremWebBackendNET
{

XWComm::XWComm(const Yml::Core::string& host, const Yml::Core::string& port)
{
    memset((char*)&d_dispatcherAddress, 0, sizeof(d_dispatcherAddress));
    
    std::istringstream finPort(port);
    unsigned short sport;
    finPort >> sport;
    if (!finPort) 
    {
        UTIL_FATAL("debug", "port does not contains a port number");
    }
    // Initialize the address
    d_dispatcherAddress.sin_family = AF_INET;
    d_dispatcherAddress.sin_port = htons(sport);
    struct hostent* hostent; 
    if ((hostent = ::gethostbyname(host.c_str())) == 0)
    {
        UTIL_FATAL("debug", "host: unable to retrieve host information");
    }
    d_dispatcherAddress.sin_addr.s_addr = ((struct in_addr *)(hostent->h_addr))->s_addr;
    
}



bool XWComm::execute(const XWMessage& request, XWMessage& result)
{
    if (! startComm())
        return false;
    if (! send(request))
    {
        endComm();
        return false;
    }
    //std::cout << "Before result" << std::endl;
    if (! recv(result))
    {
        endComm();
        return false;
    }
    //std::cout << "After result" << std::endl;
    endComm();
    return true;
}


bool XWCommUDP::startComm()
{
    // We only need to connect the first time 
    if (d_sock == -1)
    {
        // Do the connect    
        d_sock = ::socket(PF_INET, SOCK_DGRAM, 0);
        if (d_sock == -1)
            return false;
        int status = ::connect(d_sock, (struct sockaddr*)&d_dispatcherAddress, 
                               sizeof(d_dispatcherAddress));
        if (status == -1)
        {
            ::close(d_sock);
            d_sock = -1;
            return false;
        }
    }
    return true;
}

bool XWCommUDP::send(const XWMessage& request)
{
    assert(d_sock >= 0);
    //std::cout << "Request size: " << request.size() << std::endl;
    
    int status = sendto(d_sock, request.data(), request.size(), 0, NULL, 0);
    
    if (status == -1)
        return false;
    return true;
}


bool XWCommUDP::recv(XWMessage& result)
{
    assert(d_sock >= 0);
    int status = recvfrom(d_sock, result.data(), result.capacity(), 0, NULL, 0);
    if (status == -1)
        return false;
    result.size() = status;
    return false;
}


void XWCommUDP::endComm()
{
    // Nothting to do in UDP
}

bool XWCommTCP::startComm()
{
    assert(d_sock == -1);
    // connect 
    d_sock = ::socket(PF_INET, SOCK_STREAM, 0);
    if (d_sock == -1)
        return false;
    int status = ::connect(d_sock, (struct sockaddr*)&d_dispatcherAddress, sizeof(d_dispatcherAddress));
    if (status == -1)
    {
        ::close(d_sock);
        d_sock = -1;
        return false;
    }
    return true;
}

bool XWCommTCP::send(const XWMessage& request)
{
    assert(d_sock >= 0);
    //std::cout << "Request size: " << request.size() << std::endl;
    int status = sendto(d_sock, request.data(), request.size(), 0, NULL, 0);
    if (status == -1)
        return false;
    return true;
}


bool XWCommTCP::recv(XWMessage& result)
{
    assert(d_sock >= 0);
    int status = recvfrom(d_sock, result.data(), result.capacity(), 0, NULL, 0);
    //std::cout << "Recv status: " << status << std::endl;
    if (status == -1)
        return false;
    result.size() = status;
    //std::cout << "Result size: " << result.size() << std::endl;
    
    return true;
}


void XWCommTCP::endComm()
{
    assert(d_sock >= 0);
    ::close(d_sock);
    d_sock = -1;
}

struct XWException 
{
};

    

XWClient::XWClient(const Yml::Core::string& version, 
                   const Yml::Core::string& protocol, 
                   const Yml::Core::string& host, 
                   const Yml::Core::string& port, 
                   const Yml::Core::string& login,
                   const Yml::Core::string& password)
    : d_cached(false), d_communicator(0)
{
    if (protocol == "udp")
        d_communicator = new XWCommUDP(host, port);
    else if (protocol == "tcp")
        d_communicator = new XWCommTCP(host, port);
    else 
        // Error
        throw XWException();
    
        ;
    
    std::ostringstream user;
    user << "<USER UID=\"NULL\" USERGROUP=\"NULL\" LOGIN=\"" 
         << login << "\" PASSWORD=\"" << password 
         << "\" EMAIL=\"NULL\" FNAME=\"NULL\" LNAME=\"NULL\" TEAM=\"NULL\" COUNTRY=\"NULL\" NBJOBS=\"NULL\" RIGHTS=\"5\" />";
    d_user = user.str();
}



XWClient::~XWClient() 
{
    // Do all cleanup 
    doCleanup();
    
    delete d_communicator;
}

Yml::Core::string XWClient::getAppByName(const Yml::Core::string& name)
{
    Yml::Core::string res;
    XWMessage request;
    XWMessage result;
    request.writeInt(XW_IDRPC_GETAPPBYNAME)
        .writeString(d_user)
        .writeString(name);    
    if (d_communicator->execute(request, result))
    {
        result.readString(res);
    }
    return res;
}

Yml::Core::string XWClient::getAppUIDByName(const Yml::Core::string& name)
{
    // Better extraction of information 
    Yml::Core::string tmp = getAppByName(name);
    size_t uid_start = 1 +  tmp.find_first_of('\"');
    size_t uid_end  = tmp.find_first_of('\"', uid_start + 1);
    return tmp.substr(uid_start, uid_end - uid_start);
}

bool XWClient::cacheInformation(const Yml::Core::string& appName)
{
    d_appUID = getAppUIDByName(appName);
    d_cached = true;
    return ! d_appUID.empty();
}

Yml::Core::string XWClient::workSubmit(const Yml::Core::string& label, const Yml::Core::string& cmdLine)
{
    XWMessage request;
    XWMessage result;
    Yml::Core::string uid = newUID();
    if (uid.empty())
    {
        return uid;
    }
    
    
    std::ostringstream out;
    out << "<MOBILEWORK NATIF=\"false\" ISSERVICE=\"NULL\"><WORK UID=\"" << uid
        << "\" SESSION=\"NULL\" GRP=\"NULL\" EXPECTEDHOST=\"NULL\" ISSERVICE=\"NULL\" "
        << "LABEL=\"" << label << "\" APP=\"" << d_appUID << "\" USER=\"NULL\" STATUS=\"LONGFILE\" RESULTSTATUS=\"NULL\" RETURNCODE=\"NULL\" SERVER=\"NULL\" " 
        << "CMDLINE=\" " << cmdLine << " \" STDINNAME=\"NULL\" DIRINNAME=\"NULL\" STDOUTNAME=\"NULL\" DIROUTNAME=\"NULL\" ARRIVALDATE=\"NULL\" " 
        << "COMPLETEDDATE=\"NULL\" RESULTDATE=\"NULL\" ERROR_MSG=\"NULL\" SENDTOCLIENT=\"NULL\" LOCAL=\"NULL\" ACTIVE=\"NULL\" WORKREPLICATED=\"NULL\" " 
        << "MAXRETRY=\"NULL\" RESULTREPLICATED=\"NULL\" /></MOBILEWORK>";
   
    request.writeInt(XW_IDRPC_SUBMITWORK)
        .writeString(d_user)
        .writeString(out.str())
        .writeInt(0)
        .writeInt(0);
    d_communicator->execute(request, result);
    return uid;
    
}


Yml::Core::string XWClient::work(const Yml::Core::string& wid)
{
    XWMessage request;
    XWMessage result;
    request.writeInt(XW_IDRPC_GETWORK)
        .writeString(d_user)
        .writeString(wid);
    d_communicator->execute(request, result);
    Yml::Core::string tmp;
    result.readString(tmp);
    return tmp;
}


Yml::Core::int32 XWClient::workStatus(const Yml::Core::string& wid) 
{
    Yml::Core::int32 ret = -1;
    Yml::Core::string res = work(wid);
    //std::cout << "Work: " << res << std::endl;
    size_t pos = res.find("RETURNCODE");
    size_t beg = 1 + res.find_first_of('\"', pos);
    size_t end = res.find_first_of('\"', beg + 1);
    Yml::Core::string returnCode = res.substr(beg, end - beg);
    //std::cout << "ReturnCode: " << returnCode << std::endl;
    if (returnCode != "NULL")
    {
        std::istringstream in(returnCode);
        if (in)
        {
            in >> ret;
            if (!in)
                ret = -1;
        }
    }
    return ret;
}


void XWClient::clean(const Yml::Core::string& wid)
{
    d_pendingClean.push_back(wid);
}

void XWClient::doCleanup() 
{
    std::vector<Yml::Core::string>::const_iterator iter =  d_pendingClean.begin();
    const std::vector<Yml::Core::string>::const_iterator end = d_pendingClean.end();
    for (; iter != end ; ++iter) 
    {
        XWMessage request;
        XWMessage result;
        request.writeInt(XW_IDRPC_REMOVEWORK)
            .writeString(d_user)
            .writeString(*iter);
        d_communicator->execute(request, result);
    }
    d_pendingClean.clear();
}



bool XWClient::error() const
{
    return false;
}

Yml::Core::string XWClient::newUID()
{
    //short count = SHRT_MIN;
    long time = 0;
    struct timeval tm;
    int status = gettimeofday(&tm, NULL);
    if (status == -1)
    {
        return "";
    }
    time = tm.tv_sec * 1000 + tm.tv_usec;
    long int unique = (long int)&time ^ gethostid() ^ time;
    int max = 16;
    // Translate into object count, counting from 0.
    short lc = (random() + SHRT_MAX) & 0xFFFF;
    return itoa(time, max) + ":" + 
           itoa(unique, max) + ":" + 
           itoa(lc, max);
}

Yml::Core::string XWClient::itoa(long long value, int radix)
{
    const char * digits = "0123456789abcdefghijklmnopqrstuvwxyz";
    if (radix > 36 || radix < 2)
    {
        radix = 10;
    }
    char buffer[65];
    int i = 65;
    bool isNeg = false;
    if (value < 0)
    {
        isNeg = true;
        value = -value;
        if (value < 0)
        {
            buffer[--i] = digits[(int) (-value + radix) % radix];
            value = -(value / radix);
        }
    }
    do 
    {
        buffer[--i] = digits[(int) (value % radix)]; 
        value /= radix; 
    } 
    while(value > 0);
    if (isNeg)
        buffer[--i] = '-';
    return Yml::Core::string(buffer + i, 65 - i);
}

/*
void XWClient::close()
{
    writeCode(XW_IDRPC_DISCONNECT);
    mClient.shutdown();
}



void XWClient::writeCode(XW_IDRPC code)
{
    writeInt(code);
    writeString(mUser);
}
*/


}
