#ifndef MYSQLWRAPPED_H
#define MYSQLWRAPPED_H
#include <mysql/mysql.h>
#include  "Database.h"
#include  "IError.h"
#include  "Query.h"
#include  "StderrLog.h"
#include  "SysLog.h"
#include  "enum_t.h"
#include  "set_t.h"
#endif 
