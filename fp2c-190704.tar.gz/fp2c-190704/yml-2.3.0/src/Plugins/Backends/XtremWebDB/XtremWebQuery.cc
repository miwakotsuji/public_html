/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/

/**
 * @file
 * @brief Class XtremWebQuery function definition 
 *
 * 2005-10-28
 * Olivier Delannoy
 */
#include "XtremWebQuery.hh"
#include <sstream> 

namespace XtremWebBackendDB 
{


XtremWebQuery::XtremWebQuery(const Yml::Core::string& version)
    : mVersion(0)
{
    if (version == "1.3.11")
        mVersion=1;
    else if (version == "1.4.0")
        mVersion=2;
    else 
        mVersion=0;
}


XtremWebQuery::~XtremWebQuery(void)
{
    
}

Yml::Core::string XtremWebQuery::getUserId(const Yml::Core::string& name) const
{
    std::ostringstream query;
    query << "SELECT uid FROM users WHERE login='" << name << "' LIMIT 1";
    return query.str();
}

Yml::Core::string XtremWebQuery::getAppId(const Yml::Core::string& name) const
{
    std::ostringstream query;
    query << "SELECT uid FROM apps WHERE name='" << name << "' LIMIT 1";
    return query.str();
}

Yml::Core::string XtremWebQuery::getCompletedWorks(const Yml::Core::string& uid) const
{
    std::ostringstream query;
    switch(mVersion)
    {
      case 0:
          break;
      case 1:
      case 2:
          query << "SELECT  uid, status, returnCode FROM works WHERE uid LIKE '" 
                << uid << "%' and completedDate IS NOT NULL";
          break;
    }
    return query.str();
}

Yml::Core::string XtremWebQuery::deleteCompletedWorks(const Yml::Core::string& uid) const
{
    std::ostringstream query;
    query << "DELETE FROM works WHERE uid = '" << uid << "'";
    return query.str();
}

Yml::Core::string XtremWebQuery::insertWork(const Yml::Core::string& uid, 
                                                             const Yml::Core::string& userid, 
                                                             const Yml::Core::string& appid, 
                                                             const Yml::Core::string& cmdLine, 
                                                             const Yml::Core::string& server) const
{
    std::ostringstream query;
    switch(mVersion)
    {
    case 0: // Unsupported 
        break;
    case 1: // XW 1.3.11
        query << "INSERT INTO works VALUES (NULL, '"  << uid << "', NULL, NULL, NULL, '" << appid 
	      << "', '" << userid << "', 'WAITING', 'UNAVAILABLE', NULL, '" << server << "', '" 
              << cmdLine << "', NULL, NULL, NULL, NULL, NOW(), NULL, NULL, NULL, 'false', 'true', 'true', 'false', 'false')";
        break;
    case 2:  // XW 1.4.0
        query << "INSERT INTO works VALUES ('" << uid << "', NULL, NULL, NULL, NULL, '" << appid << "', '" << userid 
	      << "', 'WAITING', 'UNAVAILABLE', 10, NULL, '" << server << "', '"  << cmdLine 
	      << "', NULL, NULL, NULL, NULL, NOW(), NULL, NULL, NULL, 'false', 'true', 'true', 'false', 'false', 'false')";
    }
    return query.str();
}

                                                             
}









