/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/

/**
 * @file
 * @brief Class XtremWebBackend function definition 
 *
 * 2005-07-02
 * Olivier Delannoy
 */
#include "XtremWebBackendDB.hh"
#include "XtremWebQuery.hh"


#include <UID.hh>
#include <Dir.hh>
#include <File.hh>
#include <RuntimeEnvironment.hh> 
#include <ConfigFactory.hh>
#include <LoggerFactory.hh>
#include <iostream>
#include <fstream>
#include <sstream> 
#include <libmysqlwrapped.h> 

namespace XtremWebBackendDB
{

XtremWebBackendDB::XtremWebBackendDB(void)
    : mDatabase(0), mQueryFactory(0)
{   
}

XtremWebBackendDB::~XtremWebBackendDB(void)
{
    delete mDatabase;
    delete mQueryFactory;
}

void XtremWebBackendDB::initImpl(const Yml::Core::string& initData)
{
    mTaskGroup = "tasks/";
    Util::Config* config  = Util::ConfigFactory::getSingleton().create("yml");
    
    mTaskDir = config->get("path", "dr-root") + mTaskGroup;
    Util::Dir::mkdir(mTaskDir);    
    mXWVersion                       = config->get("general", "version",  "1.3.11");
    Yml::Core::string mXWUserLogin   = config->get("general", "user",     "yml");
    mXWServerHost                    = config->get("general", "server",   "");
    Yml::Core::string xwWorkerName   = config->get("general", "worker",   "yml_xtremweb_workerdb");
    Yml::Core::string xwDBHost       = config->get("database", "host", "localhost");
    Yml::Core::string xwDBUser       = config->get("database", "user");
    Yml::Core::string xwDBPass       = config->get("database", "password");
    Yml::Core::string xwDBName       = config->get("database", "name", "xtremweb");
    // Define a unique id for this application 
    mAppUID = "yml_" + Util::UID::createUID() + "_";
    
    // Log the configuration 
    UTIL_INFO("default", "XtremWeb backend configuration");
    UTIL_INFO("default", " - Binary group: " << mBinGroup);
    UTIL_INFO("default", " - Task path: " << mTaskDir);
    UTIL_INFO("default", " - Task group: " << mTaskGroup);
    UTIL_INFO("default", " - XtremWeb configuration");    
    UTIL_INFO("default", "   - Database");
    UTIL_INFO("default", "     - Host: " << xwDBHost);
    UTIL_INFO("default", "     - User: " << xwDBUser);
    UTIL_INFO("default", "     - Name: " << xwDBName);
    UTIL_INFO("default", "   - Version: "          << mXWVersion);
    UTIL_INFO("default", "   - Server Host: "      << mXWServerHost);
    UTIL_INFO("default", "   - XW User: "          << mXWUserLogin);
    UTIL_INFO("default", "   - XW YML Worker: "    << xwWorkerName);
    UTIL_INFO("default", " - Data Repository Server");
    UTIL_INFO("default", "   - Host: " << mDRHost);
    UTIL_INFO("default", "   - Port: " << mDRPort);
    UTIL_INFO("default", " - Application UID: " << mAppUID);

    // Connect to the database
    mDatabase = new Database(xwDBHost, xwDBUser, xwDBPass, xwDBName);
    UTIL_FATAL_ASSERT("default", mDatabase, "Database object allocation failed");
    if (! mDatabase->Connected())
    {	
        UTIL_FATAL("default", "XtremWebBackendDB: Unable to connect to the database");
    }
    // Select the User uid 
    // Initialize the query factory object 

    mQueryFactory = new XtremWebQuery(mXWVersion);
    UTIL_FATAL_ASSERT("default", mQueryFactory, "XtremWebQuery object allocation failed");
    Query query(*mDatabase);
    // Retrieve the user uid
    query.get_result(mQueryFactory->getUserId(mXWUserLogin));
    if (query.fetch_row())
    {
        mXWUserUID =  query.getstr();
        query.free_result();
    }
    else 
    {
        UTIL_DEBUG("default", "Query [" << query.GetLastQuery() << "] failed");
        query.free_result();
        UTIL_FATAL("default", "Unable to find the XW user account named " << mXWUserLogin);
    }
    UTIL_INFO("default", " - XW User UID: " << mXWUserUID);
    // Retrieve the Worker app uid
    query.get_result(mQueryFactory->getAppId(xwWorkerName));
    if (query.fetch_row())
    {
        mXWWorkerUID = query.getstr();
        query.free_result();
    }
    else 
    {
        query.free_result();
        UTIL_FATAL("default", "Unable to find the XW YmlWorker application named " <<  xwWorkerName);
    }
    UTIL_INFO("default", " - YML Worker UID: " << mXWWorkerUID);
    UTIL_INFO("default", "XtremWeb backend initialization successfull");
}

bool XtremWebBackendDB::executeImpl(Yml::Core::SchedulerTask* task)
{
    std::ostringstream taskUID;
    taskUID << mAppUID;
    taskUID << task->index();
    Yml::Core::string taskFileName = taskUID.str(); 
    std::ofstream workDescription((mTaskDir + taskFileName).c_str());
    workDescription << task->work() << std::endl;
    workDescription.close();
    
    std::ostringstream xwCmdLine;
    xwCmdLine << mDRHost << ' ' << mDRPort << " /" << mTaskGroup << "/" << taskFileName;
    Query insert(*mDatabase);
    
    // Insert a job request inside of the database and launch the job. 
    Yml::Core::string query = mQueryFactory->insertWork(taskUID.str(), mXWUserUID, mXWWorkerUID,  xwCmdLine.str(), mXWServerHost);
    UTIL_DEBUG("default", "Query: " << query);
    if (insert.execute(query))
    {
        UTIL_DEBUG("default", "Task '" << taskUID.str() << "' submitted successfully");
        mRuning.insert(std::pair<Yml::Core::string, Yml::Core::SchedulerTask*>(taskUID.str(), task));
        return true;
    }
    UTIL_ERROR("default", "Insert query failed: " << insert.GetError());
    return false;
}

Yml::Core::SchedulerTask* XtremWebBackendDB::retrieveImpl(void)
{
    Yml::Core::SchedulerTask* res = 0;
    Query query(*mDatabase);
    Yml::Core::string select = mQueryFactory->getCompletedWorks(mAppUID);
    query.get_result(select);
    UTIL_DEBUG("default", "Query: " <<   select);
    while(query.fetch_row())
    {
        // uid, status,  
        Yml::Core::string uid = query.getstr();
        Yml::Core::string status = query.getstr();
        Yml::Core::uint32 returnCode = query.getval();
        if (status == "COMPLETED" || status == "RUNNING")
        {
            // What to do with those information ? ? ? 
            TaskList::iterator iter = mRuning.find(uid);
            if (iter != mRuning.end())
            {
                // Report error to the scheduler 
                iter->second->setStatus(returnCode ? Yml::Core::ExecError : Yml::Core::ExecSuccess);
                mFinished.push_back(iter->second);
                // Cleaning  XW database 
                Query queryD(*mDatabase);
                queryD.execute(mQueryFactory->deleteCompletedWorks(uid));
                Util::File::remove(mTaskDir + iter->first);
                mRuning.erase(iter);
            }
            else 
            {
                UTIL_ERROR("default", "Detecting the terminaison of a tasks not manage by the backend");
            }
        }
        else
        {
            // TODO Should be an error for Yml not a fatal event ...
            UTIL_FATAL("default", "XtremWeb was unable to execute task " << uid << ": " << status);
        }
    } 
    if (! mFinished.empty())
    {
        res = mFinished.front();
        mFinished.pop_front();
    }
    return res;   
}


} // end of namespace 

extern "C" XtremWebBackendDB::XtremWebBackendDB* create(void)
{
    return new XtremWebBackendDB::XtremWebBackendDB();
}

extern "C" void destroy(Yml::Core::Backend* obj)
{
    delete static_cast<XtremWebBackendDB::XtremWebBackendDB*>(obj);
}
