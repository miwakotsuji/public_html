/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/

/**
 * @file
 * @brief Class XtremWebBackend declaration
 *  
 * 2005-07-02
 * Olivier Delannoy
 *
 *
 */
#ifndef XTREMWEBBACKEND_HH
#define XTREMWEBBACKEND_HH 1
#include <Yml/Core/Backend.hh>
#include <Yml/Core/SchedulerTask.hh>
#include <Yml/Core/PluginManager.hh>
#include <Yml/Core/ExecutionCatalog.hh>
#include <map>
#include <list>
// Backward declaration 
class Database;

/** 
 * @brief This namespace agregate all features related to XtremWeb 
 * backend.
 * This namespace provides all the features related to the XtremWeb
 * backend.
 * */
namespace XtremWebBackendDB {

class XtremWebQuery;
/** 
 * @brief The XtremWeb backend class for Yml 
 *
 * This class implement the Backend interface for the 
 * YML Framework 
 */ 
class XtremWebBackendDB : public Yml::Core::Backend
{
public:
    /** 
     * Default Constructor 
     */
    XtremWebBackendDB(void);
    /** 
     * Destructor 
     */
    ~XtremWebBackendDB(void);
protected:
    /* Inherited doc */
    void initImpl(const Yml::Core::string& initData);
    /* Inherited doc */
    bool executeImpl(Yml::Core::SchedulerTask* task);
    /* Inherited doc */
    Yml::Core::SchedulerTask* retrieveImpl(void);      
private:
    typedef std::map<Yml::Core::string, Yml::Core::SchedulerTask*> TaskList;
    typedef std::list<Yml::Core::SchedulerTask*> TaskStack;
        
    
    /** Store the dir for tasks */
    Yml::Core::string mTaskDir;
    /** Store task information */
    Yml::Core::string mTaskGroup;
    /** Store the version of XtremWeb used */ 
    Yml::Core::string mXWVersion;
    /** Store the user uid */
    Yml::Core::string mXWUserUID;
    /** Store the Worker uid */
    Yml::Core::string mXWWorkerUID;
    /** Store the Server hostname */
    Yml::Core::string mXWServerHost;
    /** Store a pointer to the database object */
    Database *mDatabase;
    /** Store the XtremWeb Query generator object pointer */
    XtremWebQuery* mQueryFactory;
    /** Store a common prefix to all task of this application */
    Yml::Core::string mAppUID;
    /** Store all finished Task */
    TaskStack mFinished;
    /** Store all runing tasks */
    TaskList mRuning;
};
}
#endif

