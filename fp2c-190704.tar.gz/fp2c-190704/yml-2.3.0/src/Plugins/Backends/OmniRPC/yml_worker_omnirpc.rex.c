/* This file '/home/tsuji/test_dir/bin/omrpc-gen' was created by omrpc-gen. Don't edit */

#include "ninf_stub_info.h"
#include "omrpc_stub_lib.h"

short omrpc_stub_version_major = 3;
short omrpc_stub_version_minor = 1;
short omrpc_stub_init = 0;

/* name of module */
char *omrpc_module_name ="yml";

/* number of entry */
short omrpc_n_entry=1;

static char yml_worker_omnirpc_stub_description[] = "YML Worker execution";
static struct ninf_param_desc yml_worker_omnirpc_param_desc[] = {
	{ DT_INT, MODE_IN, 0,},
	{ DT_CHAR, MODE_IN, 1,{
		{ VALUE_IN_ARG, 0, 
			{
			  {VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,},
			  {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,}
			},
		  VALUE_NONE, 0, 
			{
			  {VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,},
			  {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,}
			},
		  VALUE_NONE, 0, 
			{
			  {VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,},
			  {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,}
			},
		  VALUE_NONE, 0, 
			{
			  {VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,},
			  {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,}
			},
		},
		}},
	{ DT_INT, MODE_OUT, 1,{
		{ VALUE_CONST, 1, 
			{
			  {VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,},
			  {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,}
			},
		  VALUE_NONE, 0, 
			{
			  {VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,},
			  {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,}
			},
		  VALUE_NONE, 0, 
			{
			  {VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,},
			  {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,}
			},
		  VALUE_NONE, 0, 
			{
			  {VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,},
			  {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,}
			},
		},
		}},
};
static NINF_STUB_INFO yml_worker_omnirpc_stub_info = {
3,1,0,	"yml","yml_worker_omnirpc",3,
yml_worker_omnirpc_param_desc, 
	0, 
			{
			  {VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,VALUE_NONE,},
			  {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,}
			},
	yml_worker_omnirpc_stub_description, 
	0, /* boolean: specify server side shrink */
	0,
	0
};

/* entry name table */
static char *omrpc_entry_name_table[1]={
"yml_worker_omnirpc"
};

NINF_STUB_INFO *omrpc_stub_info_table[1]={
&yml_worker_omnirpc_stub_info
};

/* Globals */

#include <Yml/Worker/worker.h>


/* Stub Main program */
int main(int argc, char ** argv){
	int __tmp;

	omrpc_stub_INIT(argc,argv);
	while(1){
	  __tmp = omrpc_stub_REQ();
	  switch(__tmp){
	  default: goto exit;
	  case 0: /* yml_worker_omnirpc */
{
	int dataSize;
	char *data;
	int *status;
		omrpc_stub_SET_ARG(&dataSize,0);
		omrpc_stub_SET_ARG(&data,1);
		omrpc_stub_SET_ARG(&status,2);
		omrpc_stub_BEGIN();
{
    status[0] = worker(data, dataSize, 0);
}
		omrpc_stub_END();
}
	  break; 
	   }
	}
exit:
	omrpc_stub_EXIT();
 return 0; }
 /* END OF Stub Main */
