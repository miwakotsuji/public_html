/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/

/**
 * @file
 * @brief Class OmniRPCBackend body
 *  
 * 2005-07-02
 * Choy Laurent
 * Olivier Delannoy
 *
 *
 */

#include "OmniRPCBackend.hh"
#include <iostream>
#include <fstream>
#include <RuntimeEnvironment.hh> 
#include <ConfigFactory.hh>
#include <LoggerFactory.hh>
#include <Dir.hh>
#include <UID.hh>
#include <sched.h>
/**
 * Constructor
 */
namespace OmniRPCBackend
{        

OmniRPCBackend::OmniRPCBackend(void) 
    : mMustInit(true), req(0), flagReq(0), taskStatus(0), taskReq(0), mEnableDebug(false)
{       
}
void OmniRPCBackend::initImpl(const Yml::Core::string &initData)
{
    UTIL_DEBUG("default","OmniRPCBackend::init -  begin");
    Util::Config* config = Util::ConfigFactory::getSingleton().create(initData);   
    Util::Config* ymlConfig = Util::ConfigFactory::getSingleton().create("yml");

    mEnableDebug = config->get("general", "verbose", "yes") == "yes";
        
    mOmniVersion = config->get("general", "version", "1.0");
    mHostFileDir = config->get("general", "hostfileDir", "");
    Yml::Core::string sizeArray = config->get("general", "maxNumberRequest", "200");  
    std::istringstream is(sizeArray);
    is >> MAX_NUMBER_REQUEST;
    
    mPackInDir = ymlConfig->get("path", "packin");
    if (mPackInDir[mPackInDir.size() -1] != Util::RuntimeEnvironment::PATH_SEPARATOR)
        mPackInDir += Util::RuntimeEnvironment::PATH_SEPARATOR;
    Util::Dir::mkdir(mPackInDir);


    mPackOutDir = ymlConfig->get("path", "packout");
    if (mPackOutDir[mPackOutDir.size() -1] != Util::RuntimeEnvironment::PATH_SEPARATOR)
        mPackOutDir += Util::RuntimeEnvironment::PATH_SEPARATOR;
    Util::Dir::mkdir(mPackOutDir);
    


    UTIL_DEBUG("default","OmniRPCBackend::init - end");
}

bool OmniRPCBackend::initializeOmniRPC()
{
    UTIL_DEBUG("default","OmniRPCBackend::initializeOmniRPC - begin");
    // This should use STL vector facilities 
    req = new OmniRpcRequest[MAX_NUMBER_REQUEST];  
    flagReq = new int[MAX_NUMBER_REQUEST];
    taskReq = new Yml::Core::SchedulerTask*[MAX_NUMBER_REQUEST];
    taskStatus = new int[MAX_NUMBER_REQUEST];
    
    for (int i = 0; i<MAX_NUMBER_REQUEST; i++){
        req[i] = NULL;
        flagReq[i] = 0;
        taskReq[i] = NULL;    
        // flagReq[i]= 0 means that req[i] is free for a request
        // flagReq[i]= 1 means that req[i] is currently used by an asynchroneous request
    }
    
    // We use malloc because OmniRPC is written in C.
    char **args = (char**)malloc(sizeof(char*)*5);
    int nbArgs = 5;
    
    args[0] = strdup("yml_worker_omnirpc");
    args[1] = strdup("--hostfile");
    args[2] = strdup((mHostFileDir + "/hosts.xml").c_str());
    if (mEnableDebug)
    {
        args[3] = strdup("--debug");
        args[4] = NULL;
    }
    else 
    {
        args[3] = NULL;
        args[4] = NULL;
        nbArgs = 4;
    }
    UTIL_DEBUG("default","In OmniRPCBackend:: OmniRpcInit::");
    UTIL_DEBUG("default","In OmniRPCBackend:: nb args = " << nbArgs);
    UTIL_DEBUG("default","In OmniRPCBackend:: arg0 = " <<args[0]);
    UTIL_DEBUG("default","In OmniRPCBackend:: arg1 = " <<args[1]);
    UTIL_DEBUG("default","In OmniRPCBackend:: arg2 = " <<args[2]);
    if(args[3])
        UTIL_DEBUG("default","In OmniRPCBackend:: arg3 = " <<args[3]);

    OmniRpcInit(&nbArgs, &args);

    UTIL_DEBUG("default","OmniRpcInit done");
    mMustInit = false;     
    UTIL_DEBUG("default","OmniRPCBackend::initializeOmniRPC - end");
    return true;
}
void OmniRPCBackend::finalizeOmniRPC()
{
    OmniRpcFinalize();
    if (req)
        delete[] req;
    if (flagReq)
        delete[] flagReq;
    if (taskReq)
        delete[] taskReq;
    if (taskStatus)
        delete[] taskStatus;    
}


bool OmniRPCBackend::executeImpl(Yml::Core::SchedulerTask* task)  
{
    UTIL_DEBUG("default","OmniRPCBackend::executeImpl - begin");
    int i;
    int freeRank = -1;
    bool foundFree;  
    if(mMustInit && ! initializeOmniRPC())
    {
        UTIL_FATAL("default", "OmniRPCBackend::execute: failed to initialize omnirpc");
        return false;
    }
    Yml::Core::uint32 baseNameStart;

    foundFree = false;
    // on commence par un rapide parcours pour voir si un emplacement est libre
    for (i = 0; i<MAX_NUMBER_REQUEST; i++){
        if ( flagReq[i] == 0){
            foundFree = true;  
            freeRank = i;      
            i=MAX_NUMBER_REQUEST; // in order to get out the loop      
        }
    }
    // on a rien vu au premier abord...on teste donc la terminaison et, au pire,  on attend ...plus couteux
    if (foundFree==false){
               
        Yml::Core::SchedulerTask* finishedTask=NULL;
        while(finishedTask==NULL)
        {
            finishedTask=internalRetrieve();            
        }        
        someCompletedTasks.push_back(finishedTask);      
        // on doit chercher le rank car retrieve ne peut le retourner :(
        // grace au lock/unlock, on est certain qu'il n'y a pas d'interf�rence avec un 
        // �ventuel appel de retrieve par le schedduler
        foundFree = false;
        for (i = 0; i<MAX_NUMBER_REQUEST; i++){
            if ( flagReq[i] == 0){
                foundFree = true;  
                freeRank = i;      
                i=MAX_NUMBER_REQUEST; // in order to get out the loop      
            }
        }   
    }
    flagReq[freeRank] = 1;
    taskReq[freeRank] = task;
    UTIL_DEBUG("default", "Work Description: " << std::endl << task->work());
    req[freeRank] = OmniRpcCallAsync("yml_worker_omnirpc",
                                     task->work().size(), 
                                     task->work().c_str(), 
                                     taskStatus + freeRank);
    UTIL_DEBUG("default", "OmniRPCBackend::executeImpl - end");
    return true;   
}

/**
 * It retrieves the result of a finished task             
 */
Yml::Core::SchedulerTask * OmniRPCBackend::retrieveImpl(void)  
{
    UTIL_DEBUG("default","OmniRPCBackend::retrieveImpl - begin ");
    if (! mMustInit) 
    {
        Yml::Core::SchedulerTask* ptrTask = 0;
        int j;    
        j=0;
        for(j = 0; j < MAX_NUMBER_REQUEST; j++){
            if(flagReq[j] == 1)
            {
                if(OmniRpcProbe(req[j]) == 1){
                    
                    req[j]  = NULL;
                    flagReq[j] = 0;                    
                    ptrTask = taskReq[j];                    
                    taskReq[j] = NULL;  
                    UTIL_DEBUG("default","OmniRPCBackend::retrieveImpl, task " << j << " is finished with status " << taskStatus[j]);
                    if (taskStatus[j] != 0)
                        ptrTask->setStatus(Yml::Core::ExecError);
                    return ptrTask;
                }
            }  
        }
        // all tasks (having flagReq[j]=1) are still running
        // if there is one task in the vector of completed tasks (it can be filled just before submitting a task)
        // we pop it and return it.
        if (someCompletedTasks.size() != 0)
        {
            ptrTask = someCompletedTasks.back();
            someCompletedTasks.pop_back();
            UTIL_DEBUG("default","OmniRPCBackend::retrieveImpl - end: some tasks completed");
            return ptrTask;            
        }
    }
    UTIL_DEBUG("default","OmniRPCBackend::retrieve - end: before return null (no task completed)");
    return 0; 
}

Yml::Core::SchedulerTask * OmniRPCBackend::internalRetrieve (void)  
{
    Yml::Core::SchedulerTask* ptrTask = 0;
    int j;    
    UTIL_DEBUG("default","In OmniRPCBackend::internalRetrieve, begin ");
    j=0;   
        
    for(j = 0; j < MAX_NUMBER_REQUEST; j++){
        if(flagReq[j] == 1)
        {
            if(OmniRpcProbe(req[j]) == 1)
            {                
                req[j]  = NULL;
                flagReq[j] = 0;                    
                ptrTask = taskReq[j];                    
                taskReq[j] = NULL;  
                UTIL_DEBUG("default", "In OmniRPCBackend::internalRetrieve, task " << j << " finished with status " << taskStatus[j]);
                return ptrTask;
            }
        }  
    }
    UTIL_DEBUG("default", "In OmniRPCBackend::retrieve, before return null (no task completed)");      
    return ptrTask; 
}

/**
 * Destructor
 */
OmniRPCBackend::~OmniRPCBackend()
{ 
    if (!mMustInit)
    {
        finalizeOmniRPC();
    }
}

}


/*! 
    Plugin access function 
 */ 
extern "C" OmniRPCBackend::OmniRPCBackend* create(void)
{
    return new OmniRPCBackend::OmniRPCBackend();
}

/*! 
    Plugin instance deallocator function 
 */
extern "C" void destroy(Yml::Core::Backend* object)
{
    delete static_cast<OmniRPCBackend::OmniRPCBackend*>(object);
}


