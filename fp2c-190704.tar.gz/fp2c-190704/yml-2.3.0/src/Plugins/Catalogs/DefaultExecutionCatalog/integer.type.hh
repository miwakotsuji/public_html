/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 * @file
 * @brief Integer parameter wrapper 
 *  
 * @todo Extend support for matching the standard interface of longs in C++ 
 * 
 * 2005-09-24
 * Olivier Delannoy
 */
#ifndef INTEGER_TYPE_HH
#define INTEGER_TYPE_HH 1

namespace yml {
typedef int32_t integer;  

// param_import / export are not needed for basic types 
template <>
bool param_import(integer& param, const char* filename)
{
    FileStream in(filename, STREAM_READ_ONLY);
    if (in)
    {
        Serializer reader(in);
        reader.readInt32(param);
        if (in)
            return true;
    }
    return false;
}
template <>
bool param_export(const integer& param, const char* filename)
{
    FileStream out(filename, STREAM_WRITE_ONLY);
    if (out)
    {
        Serializer writer(out);
        writer.writeInt32(param);
        if (out)
            return true;
    }
    return false;
}
}
#endif
