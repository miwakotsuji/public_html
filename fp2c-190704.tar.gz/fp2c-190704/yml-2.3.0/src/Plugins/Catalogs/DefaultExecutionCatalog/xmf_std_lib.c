#include"xmp_header.hh"
#include"yml_xmp_component_base.hh"
#include"vector.xmptype.h"
#include"Matrix.xmptype.h"
#include"integer.xmptype.h"
#include"real.xmptype.h"
#include<mpi.h>
#include<netdb.h>
#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include<time.h>
#include<unistd.h>
#include<sys/time.h>

#define _HOST_NAME_LENGTH MAXPATHLEN  

double etime0, etime1;

void xmf_export_real8vector_(double *a, int *idx, char *fname0, char *mdisc)
{
   char *fname=&(fname0[256*(*idx)]);
   //printf("xmf_export: file=%s disc=%s|||\n",fname,mdisc);
   type_export((void *)a,fname,vector_MPI_Type,vector_export,mdisc);
} /* xmf_export_realvector */

void xmf_import_real8vector_(double *a, int *idx, char *fname0, char *mdisc)
{
   char *fname=&(fname0[256*(*idx)]);
   //printf("xmf_import: file=%s disc=%s|||\n",fname,mdisc);
   type_import((void *)a,fname,vector_MPI_Type,vector_import,mdisc);
} /* xmf_import_realvector */

void xmf_export_real8matrix_(double *a, int *idx, char *fname0, char *mdisc)
{
   char *fname=&(fname0[256*(*idx)]);
   type_export((void *)a,fname,Matrix_MPI_Type,Matrix_export,mdisc);
} /* xmf_export_realmartix */

void xmf_import_real8matrix_(double *a, int *idx, char *fname0, char *mdisc)
{
   char *fname=&(fname0[256*(*idx)]);
   type_import((void *)a,fname,Matrix_MPI_Type,Matrix_import,mdisc);
} /* xmf_import_realmartix */

void xmf_import_integer_(int *a, int *idx, char *fname0)
{
   char *fname=&(fname0[256*(*idx)]);
   integer_import(a,fname);
} /* xmf_import_integer */

void xmf_export_integer_(int *a, int *idx, char *fname0)
{
   char *fname=&(fname0[256*(*idx)]);
   integer_export(a,fname);
} /* xmf_export_integer */

void xmf_import_real8_(double *a, int *idx, char *fname0)
{
   char *fname=&(fname0[256*(*idx)]);
   real_import(a,fname);
} /* xmf_import_real8 */

void xmf_export_real8_(double *a, int *idx, char *fname0)
{
   char *fname=&(fname0[256*(*idx)]);
   real_export(a,fname);
} /* xmf_export_real8 */


void xmf_start_component(int argc, char *argv)
{
  int     i,myrank,nprocs;
  int     pid;
  time_t  timer;
  struct  tm *t_st;
  struct  hostent *host;
  char    path[PATH_MAX];
  int ack;
  MPI_File fh;

  time(&timer);
  t_st   = localtime(&timer);
  etime0 = gettimeofday_sec();

  MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
  MPI_Comm_size(MPI_COMM_WORLD, &nprocs);

  if(myrank==0){
    pid=getpid();

    sprintf(path,"%s/%s\0",&(argv[(argc-1)*256]),"trace.txt");
    fp_trace_txt =fopen(path,"w");
    fprintf(fp_trace_txt,"component   : %s (pid=%d)\n",&(argv[0]),pid);
    fprintf(fp_trace_txt,"start   time: %s              (%f)\n",asctime(t_st),etime0); 
    fprintf(fp_trace_txt,"nprocs = %d\n",nprocs);
/*
    for(i=0;i<nprocs;i++)
      fprintf(fp_trace_txt,"host %d %s %d.%d.%d.%d\n",i,node[i].name,node[i].ip[0],node[i].ip[1],node[i].ip[2],node[i].ip[3]);
*/
    //fclose(fp_trace_txt);  

    sprintf(path,"%s/%s\0",&(argv[(argc-1)*256]),"status.txt");
    fp_status_txt=fopen(path,"w");

    sprintf(path,"%s/%s\0",&(argv[(argc-1)*256]),"output.txt");
    fp_output_txt=fopen(path,"w");
    fclose(fp_output_txt);
  } 

} /* xds_start_component */

void xmf_finish_component()
{
  int    myrank;
  time_t timer;
  struct tm *t_st;
  char   path[PATH_MAX];
  double ctime,gtime;

  MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
  if(myrank!=0) return;

  time(&timer);
  t_st   = localtime(&timer);
  etime1 = gettimeofday_sec();

  //fp_trace_txt =fopen("trace.txt","a");
  //fp_status_txt=fopen("status.txt","w");  
  fprintf(fp_status_txt,"success\n");
  fprintf(fp_trace_txt,"end     time: %s              (%f)\n",asctime(t_st),etime1);
  fprintf(fp_trace_txt,"elasped time: %f\n",etime1-etime0);
  fprintf(fp_trace_txt,"elasped time body: %f\n",_xmp_etime_body);
  fclose(fp_trace_txt);
  fclose(fp_status_txt);
} /* xmf_finish_component */
