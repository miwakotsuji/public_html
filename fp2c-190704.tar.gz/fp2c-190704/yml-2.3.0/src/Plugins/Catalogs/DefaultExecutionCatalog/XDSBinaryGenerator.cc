//* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
/ * Copyright Miwako Tsuji 2014
 *
 *   Miwako Tsuji
 *   miwako.tsuji@riken.jp
 *   AICS,RIKEN
 *   Kobe, Hyogo, JAPAN
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/
/**
 * @file
 * @brief Class XDSBinaryGenerator function definition 
 *
 */
#include "XDSBinaryGenerator.hh"

#ifdef HAVE_CONFIG_H
#include <yml_config.hh>
#endif 
#include <LoggerFactory.hh>
#include <File.hh>
#include <StringList.hh>
#include <Process.hh>
#include <ConfigFactory.hh>
#include <RuntimeEnvironment.hh>
#include <StringHelper.hh>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <Yml/Core/core.hh>
#include <Dir.hh>

#define MAXSIZE 1024

namespace DefaultExecutionCatalog
{
XDSBinaryGenerator::XDSBinaryGenerator(const Yml::Core::string& dataDir)
: BinaryGenerator(dataDir + "XDS" + Util::RuntimeEnvironment::PATH_SEPARATOR)
{
}

bool XDSBinaryGenerator::generate(const Yml::Core::ComponentImpl& impl, const Yml::Core::ParameterList& interface, const Yml::Core::string& dest)
{
  Yml::Core::string fname_c(dest+".c");
  Yml::Core::string fname_idl(dest+".idl");
  if(createSourceCode(impl, interface, fname_c)){
    if(createBinary(impl.getImplLibraries(),dest,fname_c)){
      UTIL_INFO("default", "DefaultExecutionCatalog: Implementation component '" << impl.getName() << "' compilation successfull");
      if(createOmrpcIdl(impl,interface,fname_idl)){
        if(createRex(impl.getImplLibraries(),dest,fname_idl)){
          UTIL_INFO("default", "DefaultExecutionCatalog: Implementation component '" << impl.getName() << "' omnirpc-rex creation successfull");
          return true;
        }
      }else{
        UTIL_ERROR("default", "DefaultExecutionCatalog: Implementation component '" << impl.getName() << "' omnirpc-rex creation failed");
      }
    }else{
      UTIL_ERROR("default", "DefaultExecutionCatalog: Implementation component '" << impl.getName() << "' compilation failed");
    }
  }else{
    UTIL_ERROR("default", "DefaultExecutionCatalog: Implementation component '" << impl.getName() << "' source code generation failed");
  }
  return false;
} /* XDSBinaryGenerator::generate */

bool XDSBinaryGenerator::createOmrpcIdl(const Yml::Core::ComponentImpl& impl, const Yml::Core::ParameterList& interface, const Yml::Core::string& fname_idl)
{
  // Create OmniRPC IDL
  std::ofstream out(fname_idl.c_str());
  if (!out)
    return false;
  out << "Module " << impl.getComponentAbstractName() << ";" << std::endl << std::endl;
  out << "Globals {" << std::endl
      << "#include <worker.h>" << std::endl
      << "#include<limits.h>" << std::endl
      << "#include\"xmp_header.hh\"" << std::endl
      << "struct droperation" << std::endl
      << "{" << std::endl
      << "    char*          mHost;" << std::endl
      << "    unsigned short mPort;" << std::endl
      << "    char*          mUri;" << std::endl
      << "    uint8          mIsPacked;" << std::endl
      << "};" << std::endl
      << "typedef struct droperation droperation_t;" << std::endl
      << "struct worker" << std::endl
      << "{" << std::endl
      << "    drclient_t mClient;" << std::endl
      << "    char mInitialWorkingDir[PATH_MAX];" << std::endl
      << "    char mWorkingDir[PATH_MAX];" << std::endl
      << "    char* mWorkDescription;" << std::endl
      << "    uint32 mWorkDescriptionSize;" << std::endl
      << "    char* mBinaryName;" << std::endl
      << "" << std::endl
      << "    char** mParameters;" << std::endl
      << "    uint32 mParameterCurrent;" << std::endl
      << "    uint32 mParameterCount;" << std::endl
      << "" << std::endl
      << "    droperation_t* mImports;" << std::endl
      << "    uint32 mImportCurrent;" << std::endl
      << "    uint32 mImportCount;" << std::endl
      << "" << std::endl
      << "    droperation_t mExport;" << std::endl
      << "    droperation_t mAdmin;" << std::endl
      << "    uint8 mXmlErrorDetected;" << std::endl
      << "};" << std::endl
      << "typedef struct worker* worker_t;" << std::endl
      << "extern int worker_init(worker_t* context, char* data, uint32 dataSize, drclient_t client);" << std::endl
      << "extern int worker_import_resources(worker_t context);" << std::endl
      << "extern int worker_export_resouces(worker_t context);" << std::endl
      << "extern void main_" << impl.getName() << "(int argc,char **argv);" << std::endl
      << "}" << std::endl;
  out << "Define " << impl.getComponentAbstractName() << "(mode_in int dataSize, mode_in char data[dataSize], mode_out int status[1])" << std::endl
      << "{" << std::endl
      << "  int  i,n,status;" << std::endl
      << "  char **arg;" << std::endl
      << "  char *dir;" << std::endl
      << "  worker_t context;" << std::endl
      << "  drclient_t client=0;" << std::endl
      << "  if(__myrank==0){" << std::endl
      << "    status=worker_init(&context,data,dataSize,0);" << std::endl
      << "    if(status!=0) exit(1);" << std::endl
      << "    status=worker_import_resources(context);" << std::endl
      << "    if(status!=0) exit(1);" << std::endl
      << "    for(n=0;context->mParameters[n];n++);" << std::endl
      << "  }" << std::endl
      << "  MPI_Bcast(&n,1,MPI_INT,0,MPI_COMM_WORLD);" << std::endl
      << "  dir=(char *)malloc(PATH_MAX*sizeof(char));" << std::endl
      << "  arg=(char **)xmp_malloc_matrix(n+1,PATH_MAX,sizeof(char));" << std::endl
      << "  if(__myrank==0){" << std::endl
      << "    for(i=0;i<n;i++){" << std::endl
      << "      strcpy(arg[i],context->mParameters[i]);" << std::endl
      << "    }" << std::endl
      << "    strcpy(arg[n],context->mWorkingDir);" << std::endl
      << "  }" << std::endl
      << "  MPI_Bcast(&(arg[0][0]),(n+1)*PATH_MAX,MPI_CHAR,0,MPI_COMM_WORLD);" << std::endl
      << "  strcpy(dir,arg[n]);" << std::endl
      << "  chdir(dir);" << std::endl
      << "  xmp_start_component(n+1,arg);" << std::endl
      << "  main_" << impl.getName() << "(n+1,arg);" << std::endl
      << "  MPI_Barrier(MPI_COMM_WORLD);" << std::endl
      << "  xmp_free_matrix((void ***)&arg,n+1,PATH_MAX,sizeof(char));" << std::endl
      << "  xmp_finish_component();" << std::endl
      << "  chdir(context->mInitialWorkingDir);" << std::endl
      << "  if(__myrank==0){" << std::endl
      << "    status=worker_export_resources(context);" << std::endl
      << "    chdir(context->mInitialWorkingDir);" << std::endl
      << "  }" << std::endl
      << "}" << std::endl;
  return true;
} /* XDSBinaryGenerator::createOmrpcIdl */

bool XDSBinaryGenerator::createSourceCode(const Yml::Core::ComponentImpl& impl, const Yml::Core::ParameterList& interface, const Yml::Core::string& fname_c)
{
  // hoge.query --> hoge.c
  std::ofstream out(fname_c.c_str());
  if (!out) return false;
  out << "/********************************************** " << std::endl
      << " * This file has been generated automatically * " << std::endl
      << " * by the yml_component program               * " << std::endl
      << " * Please do not edit                         * " << std::endl
      << " **********************************************/" << std::endl
      << "// Parameter type include" << std::endl;
  // include all type definition
  out << "#include \"yml_xmp_component_base.hh\"" << std::endl;
  for(size_t i = 0; i < interface.count(); ++i){
    const Yml::Core::Parameter& p = interface.get(i);
    out << "#include \"" <<p.getType() << ".xmptype.h\"" << std::endl;
  }
  out << std::endl;
  out << "// Typedefs for parameters" << std::endl;
  out << "#pragma xmp nodes _XMP_default_nodes(" << impl.getImplNodesTopology() << ")"<< std::endl << std::endl;
  Util::StringList template_list;
  for(size_t i = 0; i < interface.count(); ++i){
    const Yml::Core::Parameter& p = interface.get(i);
    if(p.getMapping().empty()==false){
      int  dim_node; // sizes for xmp-array(s) and dimension of nodes
      // integration of implementation component extension (TEMPORARY)
      std::vector<int> vSize = p.getSize();
      if(!template_list.contains(p.getTemplateName())){
        template_list << p.getTemplateName();
        out << p.getTemplatePrint() << std::endl;
      }
      // integration of implementation component extension (TEMPORARY END) */

      // generate variable 
      out << "XMP_" << p.getType() << " " << p.getName();
      for(std::vector<int>::iterator iter = vSize.begin(); iter != vSize.end(); iter++)
        out << "[" << *iter << "]" ;
      out << ";" << std::endl;
      /* ----------------------------------- */
      out << "#pragma xmp align " << p.getName() << p.getDataAlign() << " with " << p.getTemplateName() << p.getTemplateAlign() << std::endl;
      out << std::endl;
    }
    else
    {
      out << "typedef " << p.getType() << " " << p.getName() << "_type;" << std::endl;
    }
    /*
    if(p.isCollection()){
      out << "typedef yml::Collection< yml::" << p.getType() << " > " 
      << p.getName() << "_type;" << std::endl;
    }else{
      out << "typedef yml::" << p.getType() << " " << p.getName() << "_type;" 
      << std::endl;
    }
     */
  }
  out << " // user provided header"       << std::endl
      << impl.getImplHeader()             << std::endl
      << "// end of user provided header" << std::endl << std::endl;

  out << "int main_" << impl.getName() << "(int argc, char **argv)" << std::endl
      << "{" << std::endl;

  for(size_t i=0;i<interface.count();++i){
    const Yml::Core::Parameter& p = interface.get(i);
    if(p.getMapping().empty()){
      out << "  " << p.getName() << "_type " << p.getName() << ";" << std::endl;
    }
  }
  out << std::endl;

  /* Import Parameters */
  out << "  {" << std::endl;

  for(size_t i=0;i<interface.count();++i){
    const Yml::Core::Parameter& p = interface.get(i);
    if(p.getIOMode()==Yml::Core::PARAM_IO_IN  || p.getIOMode()==Yml::Core::PARAM_IO_INOUT ){
      if(!p.getMapping().empty()){
        out << "    extern " << "XMP_" << p.getType() << " *_XMP_ADDR_" << p.getName() << ";\n";
        out << "    type_import((void *)_XMP_M_GET_ADDR_0(_XMP_ADDR_" << p.getName() << ")" << ",argv[" << i+1 << "]," << p.getType() << "_MPI_Type," << p.getType() <<"_import,\"";

        std::vector<int> vSize = p.getSize();
        for(std::vector<int>::iterator iter = vSize.begin(); iter != vSize.end(); iter++){
          if(iter !=vSize.begin()) out << ",";
          out << *iter ;
        }
        int istart=p.getNode().find('(');
        int iend=p.getNode().find(')');
        out << ";" << p.getNode().substr(istart+1,iend-istart-1) << ";";
        //out << ";" << impl.getImplNodesTopology() << ";";

        std::vector<Yml::Core::ParameterMapping> vMap = p.getMapping();
        for(std::vector<Yml::Core::ParameterMapping>::iterator iter = vMap.begin(); iter != vMap.end(); iter++){
          if(iter !=vMap.begin()) out << ",";
          out << *iter;
        }

        out << ";";
        out << p.getDataAlign() << ":" << p.getTemplateAlign() << "\");" << std::endl;
      }else{
        out << p.getType() << "_import(&" << p.getName()  << ",argv[" << i+1 << "]);" << std::endl;
      }
    }
  }

  out << "  }" << std::endl;
  out << std::endl;

  // Class body goes here
  out << "{ // ==================== XMP source code : start ====================" << std::endl
      << "  extern double gettimeofday_sec(), _xmp_etime_body;\n"
      << "  double _xmp_t0;" << std::endl
      << "  MPI_Barrier(MPI_COMM_WORLD);" << std::endl
      << "  _xmp_t0 = gettimeofday_sec();" << std::endl
      << impl.getImplSource() << std::endl
      << "  MPI_Barrier(MPI_COMM_WORLD);" << std::endl
      << "  _xmp_etime_body = gettimeofday_sec()-_xmp_t0;" << std::endl
      << "} // ==================== XMP source code :  end  ====================" << std::endl;
  out << std::endl;


  /* Export Parameters */
  out << "  {" << std::endl;
  for(size_t i=0;i<interface.count();++i){
    const Yml::Core::Parameter& p        = interface.get(i);
    if(p.getIOMode()==Yml::Core::PARAM_IO_OUT  || p.getIOMode()==Yml::Core::PARAM_IO_INOUT ){
      if(!p.getMapping().empty()){
        out << "{" << std::endl;
        out << "    extern " << "XMP_" << p.getType()  << " * _XMP_ADDR_" << p.getName() << ";\n";
        out << "    type_export((void *)_XMP_M_GET_ADDR_0(_XMP_ADDR_" << p.getName() << ")" << ",argv[" << i+1 << "]," << p.getType() << "_MPI_Type," << p.getType() << "_export,\"";

        std::vector<int> vSize = p.getSize();
        for(std::vector<int>::iterator iter = vSize.begin(); iter != vSize.end(); iter++){
          if(iter !=vSize.begin()) out << ",";
          out << *iter ;
        }
        //out << ";" << impl.getImplNodesTopology() << ";";
        int istart=p.getNode().find('(');
        int iend=p.getNode().find(')');
        out << ";" << p.getNode().substr(istart+1,iend-istart-1) << ";";
                                
        std::vector<Yml::Core::ParameterMapping> vMap = p.getMapping();
        for(std::vector<Yml::Core::ParameterMapping>::iterator iter = vMap.begin(); iter != vMap.end(); iter++){
          if(iter !=vMap.begin()) out << ",";
          out << *iter;
        }

        out << ";";
        out << p.getDataAlign() << ":" << p.getTemplateAlign() << "\");" << std::endl;
        out << "}" << std::endl;
      }else{
        out << p.getType() << "_export(&" << p.getName() << ",argv[" << i+1 << "]);" << std::endl;
      }
    }
  }

  out << "  }" << std::endl;

  out << std::endl;

  out << "  return EXIT_SUCCESS; "     << std::endl;
  out << "} // end of main component " << std::endl;
  out << "// User provided footer"    << std::endl
      << "#line 1 \"Footer section\""  << std::endl
      << impl.getImplFooter()          << std::endl
      << "/***********************************************/" << std::endl;
  out.close();
  return true;
} /* XDSBinaryGenerator::createSourceCode */

bool XDSBinaryGenerator::createRex(const Yml::Core::string& libraries, const Yml::Core::string& dest, const Yml::Core::string& fname_idl)
{
  bool abort = false;
  Yml::Core::string fname_o       (dest+".o");
  Yml::Core::string fname_rex     (dest+".rex");
  Yml::Core::string fname_rex_c   (dest+".rex.c");
  Yml::Core::string fname_rex_o   (dest+".rex.o");
  Yml::Core::string fname_xmpgpu_o(dest+".xmpgpu.o");
  Yml::Core::string libexpat_a       = EXPAT_LIB;
  Yml::Core::string xmp_lib          = XMP_LIB;
  Yml::Core::string xmp_include      = XMP_INCLUDE;
  Yml::Core::string xds_std_lib      = mDataDir+"lib/libxds_std_lib.a";
  Yml::Core::string workerIncludeDir = YML_WORKER_INCLUDE;
  Yml::Core::string yml_worker_lib   = YML_WORKER_LIB;
  Yml::Core::string cmd_mpl          = MPI_CC; // linker
  Yml::Core::string cmd_mpc          = MPI_CC; // compiler 
  Yml::Core::string cmd_omg          = OMRPC_GEN_XMP;
  Yml::Core::string omrpcIncludeDir  = OMRPC_INCLUDE;
  Yml::Core::string omrpc_lib_stub   = OMRPC_LIB_STUB;
  Yml::Core::string omrpc_lib_io     = OMRPC_LIB_IO;
  Util::Process proc;
  Util::StringList param_omg;
  Util::StringList param_mpc, param_mpl, lflags_mpl;
  Yml::Core::string libInfoDir(mDataDir + "lib" + Util::RuntimeEnvironment::PATH_SEPARATOR);

  // $ ./omrpc-gen-xmp hoge.idl hoge.rex.c 
  param_omg << fname_idl << fname_rex_c;
  proc.start(cmd_omg, param_omg);
  proc.wait();
  UTIL_DEBUG("default", "DefaultExecutionCatalog: Compiler completes with exit status " << proc.exitStatus());

  param_mpc << "-c" << fname_rex_c << "-DXMP_DEV_STARPU" << "-I"+workerIncludeDir << "-I"+omrpcIncludeDir << "-I"+mDataDir+"include" << "-o" << fname_rex_o;
  proc.start(cmd_mpc,param_mpc);
  proc.wait();

  // lflags_mpl << "-static" << "-L" + mDataDir + "lib";
  // Check for includes / libs for all libraries
  if (!libraries.empty())
  {
    std::istringstream libList(libraries);
    while(!libList.eof())
    {
      Yml::Core::string lib;
      libList >> lib;
      UTIL_INFO("default", "DefaultExecutionCatalog: Retrieving information for library '" << lib << "'");
      std::ifstream libdesc((libInfoDir + lib + ".txt").c_str());
      if (!libdesc)
      {
        UTIL_ERROR("default", "Library '" << lib << "' is not available");
        abort = true;
        break;
      }

      Yml::Core::string cflags;
      std::getline(libdesc, cflags);
      /*
      std::istringstream ifl(Util::StringHelper::trim(cflags));
      while(!ifl.eof())
      {
        Yml::Core::string tmp;
        ifl >> tmp;
        // Skip the line
        //if (ifl && ! tmp.empty())  cflagsList << tmp;
      }
      */
      Yml::Core::string libs;
      std::getline(libdesc, libs);
      std::istringstream ili(Util::StringHelper::trim(libs));
      while(!ili.eof())
      {
        Yml::Core::string tmp;
        ili >> tmp;
        if (ili && !tmp.empty()) lflags_mpl << tmp;
      }
    }
  }

  lflags_mpl << xds_std_lib  << omrpc_lib_stub << omrpc_lib_io << xmp_lib << yml_worker_lib << libexpat_a << "-lm";
  param_mpl << fname_rex_o << fname_o << fname_xmpgpu_o << lflags_mpl << "-o" << fname_rex;
  proc.start(cmd_mpl,param_mpl);
  proc.wait();

  UTIL_DEBUG("default", "DefaultExecutionCatalog: Compiler completes with exit status " << proc.exitStatus());

  return proc.exitStatus() == 0;
} /* XDSBinaryGenerator::createRex */

bool XDSBinaryGenerator::createBinary(const Yml::Core::string& libraries, const Yml::Core::string& dest, const Yml::Core::string& fname_c)
{
  // xmpcc -c hoge.c -o hoge.o 
  bool abort = false;
  Yml::Core::string cmd_xmp       =XMP_CC;
  Yml::Core::string cmd_cda       =NVCC;
  Yml::Core::string fname_o       =dest+".o";
  Yml::Core::string fname_cu      =dest+".cu";
  Yml::Core::string fname_xmpgpu_o=dest+".xmpgpu.o";
  Yml::Core::string fname_dir     =dest+"_dir";
  Yml::Core::string omrpc_inc     =OMRPC_INCLUDE;
  Util::Process proc_xmp;
  Util::Process proc_cda;
  Util::StringList param_xmp, cflags_xmp, lflags_xmp;
  Util::StringList param_cda, cflags_cda, lflags_cda;

  Yml::Core::string libInfoDir(mDataDir + "lib" + Util::RuntimeEnvironment::PATH_SEPARATOR);
  cflags_xmp << "-c" << "-O3" << "-I" + mDataDir + "include" << "-I"+omrpc_inc;
  //lflags_xmp << "-static -lm" << "-L" + mDataDir + "lib";
  lflags_xmp << "-lm" << "-L" + mDataDir + "lib";
  // Check for includes / libs for all libraries
  if (!libraries.empty())
  {
    std::istringstream libList(libraries);
    while(!libList.eof())
    {
      Yml::Core::string lib;
      libList >> lib;
      UTIL_INFO("default", "DefaultExecutionCatalog: Retrieving information for library '" << lib << "'");
      std::ifstream libdesc((libInfoDir + lib + ".txt").c_str());
      if (! libdesc)
      {
        UTIL_ERROR("default", "Library '" << lib << "' is not available");
        abort = true;
        break;
      }

      Yml::Core::string cflags;
      std::getline(libdesc, cflags);
      std::istringstream ifl(Util::StringHelper::trim(cflags));
      while(!ifl.eof())
      {
        Yml::Core::string tmp;
        ifl >> tmp;
        if (ifl && ! tmp.empty())
          cflags_xmp << tmp;
      }

      Yml::Core::string libs;
      std::getline(libdesc, libs);
      std::istringstream ili(Util::StringHelper::trim(libs));
      while(!ili.eof())
      {
        Yml::Core::string tmp;
        ili >> tmp;
        //if (ili && !tmp.empty()) lflags_xmp << tmp;
      }
    }
  }

  if (abort)
    return false;

  if(!Util::Dir::exists(fname_dir)) Util::Dir::mkdir(fname_dir);
  param_xmp << cflags_xmp << "-o" << fname_o << fname_c << lflags_xmp << "-enable-gpu" << "--verbose" << "--tempdir" << fname_dir << "--stay-tempdir" << "--fixed-tempdir";
  UTIL_DEBUG("default", "DefaultExecutionCatalog: " << cmd_xmp << " " << param_xmp);
  proc_xmp.start(cmd_xmp, param_xmp);
  proc_xmp.wait();
  UTIL_DEBUG("default", "DefaultExecutionCatalog: Compiler completes with exit status " << proc_xmp.exitStatus());

  cflags_cda << "-arch=sm_20" << "-I"+omrpc_inc  << "-c";
  param_cda << cflags_cda << fname_cu << "-o" << fname_xmpgpu_o;
  proc_cda.start(cmd_cda, param_cda);
  proc_cda.wait();
  UTIL_DEBUG("default", "DefaultExecutionCatalog: Compiler completes with exit status " << proc_cda.exitStatus());

  return (proc_xmp.exitStatus() == 0 && proc_cda.exitStatus() == 0);
} /* XDSBinaryGenerator::createBinary */

}

