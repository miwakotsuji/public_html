/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 * @file
 * @brief Integer parameter wrapper for XMP
 *
 *
 *
 * 2012-01-12
 * Corrected 2013-01-28
 */
#ifndef INTEGER_TYPE_HH
#define INTEGER_TYPE_HH 1

#include <stdint.h>
#include <stdbool.h>
#include <mpi.h>

typedef int32_t integer;

static bool integer_import(integer* param, char* filename)
{
  int ack;
  MPI_File   fh;
  MPI_Status status;
  char       path[256];
  FILE       *fp;

  static int  myrank=-1, nprocs;
  static char dir[256];

  if(myrank==-1){
    MPI_Comm_rank(MPI_COMM_WORLD,&myrank);
    MPI_Comm_size(MPI_COMM_WORLD,&nprocs);

    // Get real file path of NFS from data_dir.txt
    if(myrank==0){
      fp=fopen("data_dir.txt","r");
      fscanf(fp,"%s",dir);
    }
    MPI_Bcast(dir,256,MPI_CHAR,0,MPI_COMM_WORLD);
  }

  if(strncmp("const",filename,5)==0){
    ack = MPI_File_open(MPI_COMM_WORLD,filename,MPI_MODE_RDONLY,MPI_INFO_NULL,&fh);
  }else{
    sprintf(path,"%s%s\0",dir,filename);
    ack=MPI_File_open(MPI_COMM_WORLD,path,MPI_MODE_RDONLY,MPI_INFO_NULL,&fh);
  }
  if (ack!=MPI_ERR_NO_SUCH_FILE){
    MPI_File_read_all(fh,param,1,MPI_INT,&status);
    MPI_File_close(&fh);
    return true;
  }

  MPI_File_close(&fh);

  return false;
} /* integer_import */

static bool integer_export(integer* param, char* filename)
{
  int ack;
  MPI_File   fh;
  MPI_Status status;
  FILE       *fp;
  char        path[256];
  static int  myrank=-1, nprocs;
  static char dir[256];

  if(myrank==-1){
    MPI_Comm_rank(MPI_COMM_WORLD,&myrank);
    MPI_Comm_size(MPI_COMM_WORLD,&nprocs);

    // Get real file path of NFS from data_dir.txt
    if(myrank==0){
      fp=fopen("data_dir.txt","r");
      fscanf(fp,"%s",dir);
    }
    MPI_Bcast(dir,256,MPI_CHAR,0,MPI_COMM_WORLD);
  }

  if(strncmp("const",filename,5)==0){
    ack=MPI_File_open(MPI_COMM_WORLD,filename,MPI_MODE_WRONLY| MPI_MODE_CREATE,MPI_INFO_NULL,&fh);
  }else{
    sprintf(path,"%s%s\0",dir,filename);
    ack=MPI_File_open(MPI_COMM_WORLD,path,MPI_MODE_WRONLY| MPI_MODE_CREATE,MPI_INFO_NULL,&fh);
  }

  if (ack != MPI_ERR_NO_SUCH_FILE)
  {
    MPI_File_write_all(fh,param,1,MPI_INT,&status);
    MPI_File_close(&fh);
    if(myrank==0)
    {
      fp=fopen("output.txt","a");
      if(strncmp("const",filename,5)==0){
        fprintf(fp,"%s\n",filename);
      }else{
        fprintf(fp,"0,%s\n",path);  // put the leading '0' to show this file must not be included in out.pack
      }
      fclose(fp);
    }

    return true;
  }

  MPI_File_close(&fh);

  return false;
} /* integer_export */

#endif
