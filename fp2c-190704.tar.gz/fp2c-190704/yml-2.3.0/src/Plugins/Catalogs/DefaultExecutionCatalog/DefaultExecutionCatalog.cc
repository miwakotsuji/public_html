/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/
/**
 * @file
 * @brief Class DefaultExecutionCatalog function definition 
 *
 * 2007-01-29
 * Olivier Delannoy
 */
#include "DefaultExecutionCatalog.hh"
#include "BinaryGenerator.hh"
#include "CXXBinaryGenerator.hh"
#include "XMPBinaryGenerator.hh"
#include "XDSBinaryGenerator.hh"
#include "XMFBinaryGenerator.hh"
#include <Yml/Core/ComponentImpl.hh>
#include <Yml/Core/ParameterList.hh>
#include <Yml/Core/SchedulerTask.hh>

#ifdef HAVE_CONFIG_H
#include <yml_config.hh>
#endif 

#include <LoggerFactory.hh>
#include <ConfigFactory.hh>
#include <RuntimeEnvironment.hh>
#include <Dir.hh>
#include <FileInfo.hh>
#include <fstream>
namespace DefaultExecutionCatalog
{
DefaultExecutionCatalog::DefaultExecutionCatalog() 
{
        
}
DefaultExecutionCatalog::~DefaultExecutionCatalog()
{
    const std::map<Yml::Core::string, BinaryGenerator*>::iterator end = mGenerators.end();
    std::map<Yml::Core::string, BinaryGenerator*>::iterator iter = mGenerators.begin();
    for(; iter != end ; ++iter)
    {
        UTIL_INFO("default", "DefaultExecutionCatalog: unregister generator (" << iter->first << ")");
        delete iter->second;
        iter->second = 0;
    }
}

void DefaultExecutionCatalog::initImpl(const Yml::Core::string& initData)
{
    UTIL_DEBUG("default", "DefaultExecutionCatalog: Loading configuration from '" << initData << "'");
    
    Util::Config* config = Util::ConfigFactory::getSingleton().create(initData);
    mBinaryDir = config->get("path", "binaries");
    if (mBinaryDir.empty())
        UTIL_FATAL("default", "DefaultExecutionCatalog: Configuration error, no binary path set");
    
    // This should be computed based on the dr config and the mBinaryDir 
    // TODO 
    Yml::Core::string binaryURI = config->get("path", "binaries-uri");
    if (binaryURI.empty())
        UTIL_FATAL("default", "DefaultExecutionCatalog: Configuration error, no binary prefix path set");
    setBinaryURI(binaryURI);



    mGeneratorDir = config->get("path", "generators"); 
    if (mGeneratorDir.empty())
        UTIL_FATAL("default", "DefaultExecutionCatalog: Configuration error, no generator data path set");
    mIndexDir = config->get("path", "indexes");
    if (mIndexDir.empty())
        UTIL_FATAL("default", "DefaultExecutionCatalog: Configuration error, no index path set");
    // extend path now with a leading / if needed 
    if (mBinaryDir[mBinaryDir.size() -1] != Util::RuntimeEnvironment::PATH_SEPARATOR)
        mBinaryDir += Util::RuntimeEnvironment::PATH_SEPARATOR;
    if (mGeneratorDir[mGeneratorDir.size() - 1] != Util::RuntimeEnvironment::PATH_SEPARATOR)
        mGeneratorDir += Util::RuntimeEnvironment::PATH_SEPARATOR;
    if (mIndexDir[mIndexDir.size() -1] != Util::RuntimeEnvironment::PATH_SEPARATOR)
        mIndexDir += Util::RuntimeEnvironment::PATH_SEPARATOR;
    UTIL_DEBUG("default", "DefaultExecutionCatalog: Creating folder '" << mBinaryDir << "' if needed");
    Util::Dir::mkdir(mBinaryDir);
    UTIL_DEBUG("default", "DefaultExecutionCatalog: Creating folder '" << mGeneratorDir << "' if needed");
    Util::Dir::mkdir(mGeneratorDir);
    UTIL_DEBUG("default", "DefaultExecutionCatalog: Creating folder '" << mIndexDir << "' if needed");
    Util::Dir::mkdir(mIndexDir);
    UTIL_FATAL_ASSERT("default", Util::FileInfo(mBinaryDir).isDir(), 
                      "DefaultExecutionCatalog: Initialization error, unable to create '" << mBinaryDir << "'");
    UTIL_FATAL_ASSERT("default", Util::FileInfo(mGeneratorDir).isDir(), 
                      "DefaultExecutionCatalog: Initialization error, unable to create '" << mGeneratorDir << "'");
    UTIL_FATAL_ASSERT("default", Util::FileInfo(mIndexDir).isDir(), 
                      "DefaultExecutionCatalog: Initialization error, unable to create '" << mIndexDir << "'");
    UTIL_INFO("default", "DefaultExecutionCatalog: storing implementations in '" << mBinaryDir << "'");
    UTIL_INFO("default", "DefaultExecutionCatalog: Generators data dir is '" << mGeneratorDir << "'");
    UTIL_INFO("default", "DefaultExecutionCatalog: Generators data dir is '" << mIndexDir << "'");
    
    // Generator registration
    UTIL_INFO("default", "DefaultExecutionCatalog: registering generator (CXX)");
    mGenerators["CXX"] = new CXXBinaryGenerator(mGeneratorDir);
    UTIL_INFO("default", "DefaultExecutionCatalog: registering generator (C++)");
    mGenerators["C++"] = new CXXBinaryGenerator(mGeneratorDir);
    UTIL_INFO("default", "DefaultExecutionCatalog: registering generator (XMP)");
    mGenerators["XMP"] = new XMPBinaryGenerator(mGeneratorDir);
    UTIL_INFO("default", "DefaultExecutionCatalog: registering generator (XDS: Xmp-Dev with Starpu)");
    mGenerators["XDS"] = new XDSBinaryGenerator(mGeneratorDir);
    UTIL_INFO("default", "DefaultExecutionCatalog: registering generator (XMF)");
    mGenerators["XMF"] = new XMFBinaryGenerator(mGeneratorDir);
}

bool DefaultExecutionCatalog::registerImpl(const Yml::Core::ComponentImpl& component, const Yml::Core::ParameterList& interface, bool force)
{
    Yml::Core::string filename(mBinaryDir + component.getName());
    if (force)
        UTIL_WARN("default", "Force overwrite enabled");
    if (! Util::FileInfo(filename).isFile() || force)
    {
        // Do the registration 
        // Check for the availability of a generator 
        std::map<Yml::Core::string, BinaryGenerator*>::iterator iter = mGenerators.find(component.getImplLanguage());
        if (iter != mGenerators.end())
        {
            if (iter->second->generate(component, interface, filename))
            {
                // Register the component to the catalog 
                Yml::Core::string cListFilename(mIndexDir + component.getComponentAbstractName() + ".txt");
                std::ofstream list(cListFilename.c_str(), std::ios_base::out|std::ios_base::app);
                if (list)
                {
                    list << filename << std::endl;
                    list.close();
                    UTIL_INFO("default", "DefaultExecutionCatalog: Implementation component '" << component.getName() << "' registeration successfull");
                    return true;
                }
                
            }
            
        }
    }
    UTIL_ERROR("default", "DefaultExecutionCatalog: Implementation component '" << component.getName() << "' registration failed");
    return false;
}

Yml::Core::string DefaultExecutionCatalog::selectImpl(const Yml::Core::SchedulerTask* task)
{
    Yml::Core::string res(mIndexDir+task->component());
    // Look for a file named task->component() + ".txt"
    Yml::Core::string cListFilename(mIndexDir + task->component() + ".txt");
    if (Util::FileInfo(cListFilename).isFile())
    {
        // Open and look for the last component in the list
        std::ifstream list(cListFilename.c_str());
        if (list)
        {
            Yml::Core::string tmp(mIndexDir+task->component());
            // Yml now search for the last insertion 
            do
            {
                list >> tmp;
                if (! tmp.empty() )
                {
                    res = tmp;
                }
            }
            while(list && !list.eof());
            list.close();
            // Check if the implementation exists 
            Yml::Core::string file(mBinaryDir + res);
            if (Util::FileInfo(file).isFile())
            {
                return res;
            } 
        }
    }
    return res;
}

}


extern "C" DefaultExecutionCatalog::DefaultExecutionCatalog* create()
{
    return new DefaultExecutionCatalog::DefaultExecutionCatalog;
}

extern "C" void destroy(Yml::Core::ExecutionCatalog* catalog)
{
    delete static_cast<DefaultExecutionCatalog::DefaultExecutionCatalog*>(catalog);
}

