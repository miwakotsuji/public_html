/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/
/**
 * @file
 * @brief Class CXXBinaryGenerator function definition 
 *
 * 2007-01-29
 * Olivier Delannoy
 */
#include "CXXBinaryGenerator.hh"

#ifdef HAVE_CONFIG_H
#include <yml_config.hh>
#endif 
#include <LoggerFactory.hh>
#include <File.hh>
#include <StringList.hh>
#include <Process.hh>
#include <ConfigFactory.hh>
#include <RuntimeEnvironment.hh>
#include <StringHelper.hh>
#include <fstream>
#include <sstream>
namespace DefaultExecutionCatalog
{
CXXBinaryGenerator::CXXBinaryGenerator(const Yml::Core::string& dataDir)
    : BinaryGenerator(dataDir + "CXX" + Util::RuntimeEnvironment::PATH_SEPARATOR)
{
}
    


bool CXXBinaryGenerator::generate(const Yml::Core::ComponentImpl& impl, const Yml::Core::ParameterList& interface, const Yml::Core::string& dest)
{
    // Create source file 
    Yml::Core::string src(dest + ".cc");
    if (createSourceCode(impl, interface, src))
    {
        if (createBinary(impl.getImplLibraries(), dest, src))
        {
            UTIL_INFO("default", "DefaultExecutionCatalog: Implementation component '" << impl.getName() << "' compilation successfull");
            return true;
        }
        else
        {
            //Util::File::remove(src);
            UTIL_ERROR("default", "DefaultExecutionCatalog: Implementation component '" << impl.getName() << "' compilation failed");
        }
    }
    else 
    {
        UTIL_ERROR("default", "DefaultExecutionCatalog: Implementation component '" << impl.getName() << "' source code generation failed");
    }
    return false;
    
}


bool CXXBinaryGenerator::createSourceCode(const Yml::Core::ComponentImpl& impl, const Yml::Core::ParameterList& interface, const Yml::Core::string& dest)
{
    // Create the source code
    std::ofstream out(dest.c_str());
    if (!out)
        return false;
    out << "/**********************************************" << std::endl 
        << " * This file has been generated automatically *" << std::endl
        << " * by the yml_component program               *" << std::endl 
        << " * Please do not edit                         *" << std::endl
        << " **********************************************/" << std::endl
        << "#include \"yml_cxx_component_base.hh\"" << std::endl
        << "// Parameter type include" << std::endl;
    // Include all type definition 
    for(size_t i = 0 ; i < interface.count() ; ++i)
        {
            const Yml::Core::Parameter& p = interface.get(i);
            out << "#include \"" << p.getType() << ".type.hh\"" << std::endl;
        }
    out << "// Typedefs for parameters" << std::endl;
    for (size_t i = 0 ; i < interface.count() ; ++i)
        {
            const Yml::Core::Parameter& p = interface.get(i);
            if (p.isCollection())
                {
                    out << "typedef yml::Collection< yml::" << p.getType() << " > " 
                        << p.getName() << "_type;" << std::endl;
                }
            else
                {
                    out << "typedef yml::" << p.getType() << " " << p.getName() << "_type;" 
                        << std::endl;
                }
                        
        }        
    // Import user defined header 
    out << "// user provided header" << std::endl
        //<< "#line 1 \"Header\"" << std::endl
        << impl.getImplHeader() << std::endl
        << "// end of user provided header" << std::endl
        << std::endl
        << "class MyComponent : public yml::Component" << std::endl
        << "{" << std::endl
        << "public:" << std::endl 
        << "    MyComponent(int argc, char** argv)" << std::endl 
        << "       : yml::Component(\"" << impl.getName() << "\", \"" << impl.getComponentAbstractName() << "\", argc, argv) {}" << std::endl 
        << "protected:" << std::endl 
        << "    void executeImpl(int argc, char** argv)" << std::endl 
        << "    {" << std::endl
        << "        if (argc != 1 + " << interface.count() << ")" << std::endl
        << "        {" << std::endl
        << "            logError(\"Wrong component invocation, number of parameter invalid\");" << std::endl
        << "            error();" << std::endl    
        << "        }" << std::endl;
    // Declaration des parametres du composant 
    for (size_t i = 0 ; i < interface.count() ; ++i)
        {
            const Yml::Core::Parameter& p = interface.get(i);
            if (p.isCollection())
                out << "      " << p.getName() << "_type " 
                    << p.getName() << "(argv[" << i + 1<< "]);" << std::endl; 
            else 
            out << "        " << p.getName() << "_type " 
                << p.getName() << ";" << std::endl;
            // Selection of the IO policy 
            Yml::Core::string ioPolicy;
            switch(p.getIOMode())
                {
                case Yml::Core::PARAM_IO_IN:
                    ioPolicy = "IOPolicy_in";
                    break;
                case Yml::Core::PARAM_IO_OUT:
                    ioPolicy = "IOPolicy_out";
                    break;
                case Yml::Core::PARAM_IO_INOUT:
                    ioPolicy = "IOPolicy_inout";
                    break;
                }
            out << "        yml::Parameter< " << p.getName() << "_type, yml::" 
                << ioPolicy << "< " << p.getName() << "_type > > " << p.getName() 
                << "_param(" << p.getName() << ");" << std::endl;
            
        }
    // Chargement des parametres 
    for (size_t i = 0 ; i < interface.count() ; ++i)
        {
            const Yml::Core::Parameter& p = interface.get(i);
            out << "       //Parameter " << p.getName() << " import" << std::endl
                << "       if (! " << p.getName() << "_param.pimport(argv[" 
                << i + 1 << "]))" << std::endl
                << "       {" << std::endl
                << "           logError(\"Unable to import parameter " << p.getName()
                << "\");" << std::endl
                << "           error();" << std::endl 
                << "       }" << std::endl;
        }
    // Class body goes here 
    out << "        // Computation code" << std::endl
        << "# 1 \"Source\" 1 3 4" << std::endl
        << impl.getImplSource() << std::endl 
	<< "# 1 \"Source\" 2 3 4"
        << "        // end of Computation code" << std::endl;
    // Sauvegarde des parametres en sortie 
    for (size_t i = 0 ; i < interface.count() ; ++i)
        {
            const Yml::Core::Parameter& p = interface.get(i);
            out << "       //Parameter " << p.getName() << " export" << std::endl
                << "       if (! " << p.getName() << "_param.pexport(argv[" 
                << i + 1 << "]))" << std::endl
                << "       {" << std::endl
                << "           logError(\"Unable to export parameter " << p.getName()
                << "\");" << std::endl
                << "           error();" << std::endl 
                << "       }" << std::endl;
        }
    // Footer of the component definition 
    out << "    }" << std::endl 
        << "}; // End of MyComponent class definition" << std::endl    
        << std::endl
        << "COMPONENT_CALL(MyComponent)" << std::endl
        << "// User provided footer" << std::endl 
        << "#line 1 \"Footer section\"" << std::endl
        << impl.getImplFooter() << std::endl
        << "/***********************************************/" << std::endl;
    out.close();
    return true;
}

bool CXXBinaryGenerator::createBinary(const Yml::Core::string& libraries, const Yml::Core::string& dest, const Yml::Core::string& src)
{
    // Prepare argument list 
    bool abort = false;
    Yml::Core::string compiler = "/usr/bin/g++";
    Util::StringList paramList;
    Util::StringList cflagsList;
    Util::StringList ldflagsList;
    Yml::Core::string libInfoDir(mDataDir + "lib" + Util::RuntimeEnvironment::PATH_SEPARATOR);
    cflagsList << "-Wall" << "-O2" << "-I" + mDataDir + "include";
    ldflagsList << "-static" << "-L" + mDataDir + "lib";
    // Check for includes / libs for all libraries 
    if (!libraries.empty())
    {
        std::istringstream libList(libraries);
        while(!libList.eof())
        {
            Yml::Core::string lib;
            libList >> lib;
            UTIL_INFO("default", "DefaultExecutionCatalog: Retrieving information for library '" << lib << "'");
            std::ifstream libdesc((libInfoDir + lib + ".txt").c_str());
            if (! libdesc)
            {
                UTIL_ERROR("default", "Library '" << lib << "' is not available");
                abort = true;
                break;
            }
            
            Yml::Core::string cflags;
            std::getline(libdesc, cflags);            
            std::istringstream ifl(Util::StringHelper::trim(cflags));
            while(!ifl.eof())
            {
                Yml::Core::string tmp;
                ifl >> tmp;
                if (ifl && ! tmp.empty())
                    cflagsList << tmp;
            }
            
            Yml::Core::string libs;
            std::getline(libdesc, libs);
            std::istringstream ili(Util::StringHelper::trim(libs));
            while(!ili.eof())
            {
                Yml::Core::string tmp;
                ili >> tmp;
                if (ili && !tmp.empty())
                    ldflagsList << tmp;
            }   
        }
    }
    
    if (abort)
        return false;
    
    paramList << cflagsList << "-o" << dest << src << ldflagsList;
    UTIL_DEBUG("default", "DefaultExecutionCatalog: " << compiler << " " << paramList);
    Util::Process cxx;
    cxx.start(compiler, paramList);
    cxx.wait();
    UTIL_DEBUG("default", "DefaultExecutionCatalog: Compiler completes with exit status " << cxx.exitStatus());
    return cxx.exitStatus() == 0;
}
}

