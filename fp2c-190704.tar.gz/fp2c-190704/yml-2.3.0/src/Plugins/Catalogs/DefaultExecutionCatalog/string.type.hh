/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 * @file
 * @brief String data type parameter wrapper
 * 
 *  
 * 2005-09-24
 * Olivier Delannoy
 */
#ifndef STRING_TYPE_HH
#define STRING_TYPE_HH 1
namespace yml 
{
typedef std::string string;

template <>
bool param_import(string& param, const char* filename)
{
    FileStream in(filename, STREAM_READ_ONLY);
    if (in)
    {
        Serializer reader(in);
        reader.readString(param);
        if (in)
            return true;
    }
    return false;
}
template <> 
bool param_export(const string& param, const char* filename)
{
    FileStream out(filename, STREAM_WRITE_ONLY);
    if (out)
    {
        Serializer writer(out);
        writer.writeString(param);
        if (out)
            return true;
    }
    return false;
}
}
#endif 
