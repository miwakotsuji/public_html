#ifndef _XMP_HEADER_H_
#define _XMP_HEADER_H_
#include <math.h>
#include <mpi.h>
#include <limits.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include"omrpc_mpi_lib.h"

#define TMP_DR_ROOT "/work/xg19i036/x10112/xg19i036/xmpyml/var/yml/dr"
#define TMP_DR_WORK "/work/xg19i036/x10112/xg19i036/xmpyml/var/yml/dr/tmp"



FILE *fp_output_txt;
FILE *fp_trace_txt;
FILE *fp_status_txt;

omrpc_mpi_node_t *node;
MPI_Comm         comm_parent;

void xmp_start_rex(int argc, char **argv);
void xmp_finish_rex();
void xmp_start_component(int argc, char **argv);
void xmp_finish_component();
double _xmp_etime_body;
double gettimeofday_sec();


void **xmp_malloc_matrix(int, int, size_t);
void xmp_free_matrix(void ***, int, int, size_t);
#endif  // _XMP_HEADER_H_
