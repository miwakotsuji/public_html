#include"xmp_header.hh"
#include<mpi.h>
#include<netdb.h>
#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include<time.h>
#include<unistd.h>
#include<sys/time.h>

#define _HOST_NAME_LENGTH MAXPATHLEN  

double etime0, etime1;

double gettimeofday_sec()
{ 
  struct timeval tv; 
  gettimeofday(&tv, NULL); 
  return tv.tv_sec + tv.tv_usec * 1e-6; 
} /* gettimeofday_sec */ 

void copy_file(char *fname_in, char *fname_out)
{
  int  n;
  char buf[128];
  FILE *fp_in, *fp_out;

  fp_in = fopen(fname_in, "rb");
  if(fp_in == NULL){
    fprintf(stderr,"ERROR: cannot open input file\"%s\" \n",fname_in);
    exit(1);
  }
  fp_out = fopen(fname_out, "wb");
  if(fp_out == NULL){
    fprintf(stderr,"ERROR: cannot open output file\"%s\" \n",fname_out);
    exit(1);
  }

  while ((n = fread(buf, 1, 128, fp_in)) > 0)
    fwrite(buf, 1, n, fp_out);

  fclose(fp_out);
  fclose(fp_in );

  return;
} /* copy_file */

int get_matrix_size(char *prog_name, char *fname, int *size1, int *size2)
{
  FILE  *fp;
  int   size=-1;
  int   tmp[2];

  fp=fopen(fname,"rb");
  if(fp==NULL){
    fprintf(stderr,"ERROR[%s]: cannot open file %s (get_matrix_size)\n",prog_name,fname);
    return EXIT_FAILURE;
  }

  size=fread(tmp,sizeof(int),2,fp);
  if(size<=0){
    perror("fread");
    fprintf(stderr,"ERROR[%s]: cannot read file %s (get_matrix_size)\n",prog_name,fname);
    fclose(fp);
    exit(1);
  }
  *size1=tmp[0];
  *size2=tmp[1];

  fclose(fp);

  return EXIT_SUCCESS;
} /* get_matrix_size */

char **xmp_malloc_cmatrix(int n, int m, size_t usize);

void **xmp_malloc_matrix(int n, int m, size_t usize)
{
 return (void **)xmp_malloc_cmatrix(n,m,usize);
}
/*
void **xmp_malloc_matrix(int n, int m, size_t usize)
{
  int    i,size;
  size_t ptr_size;
  void **A;
  void *ptr;

  ptr_size=sizeof(void *);

  size=n*ptr_size;
  A=malloc(size);
  if(A==NULL){
    printf("memory allocation error : size=%d\n",size);
    exit(1);
  }
  size=n*m*usize;
  A[0]=malloc(size);
  if(A[0]==NULL){ 
    printf("memory allocation error : size=%d\n",size);
    exit(1);
  }
  ptr=A[0];
  for(i=0;i<n;i++){
    A[i]=ptr;
    ptr+=m*usize;
  }

  return A;   
}  xmp_malloc_matrix */

void **xmp_malloc_imatrix(int n, int m, size_t usize)
{
  int    i,size;
  size_t ptr_size;
  int **A;

  ptr_size=sizeof(void *);

  size=n*ptr_size;
  A=(int **)malloc(size);
  if(A==NULL){
    printf("memory allocation error : size=%d\n",size);
    exit(1);
  }
  size=n*m*usize;
  A[0]=(int *)malloc(size);
  if(A[0]==NULL){ 
    printf("memory allocation error : size=%d\n",size);
    exit(1);
  }
  for(i=0;i<n;i++){
    A[i]=&(A[0][i*m]);
  }

  return A;   
} /* xmp_malloc_imatrix */

char **xmp_malloc_cmatrix(int n, int m, size_t usize)
{
  int    i,size;
  size_t ptr_size;
  char **A;
  char *ptr;

  ptr_size=sizeof(void *);

  size=n*ptr_size;
  A=(char **)malloc(size);
  if(A==NULL){
    printf("memory allocation error : size=%d\n",size);
    exit(1);
  }
  size=n*m*usize;
  A[0]=(char *)malloc(size);
  if(A[0]==NULL){ 
    printf("memory allocation error : size=%d\n",size);
    exit(1);
  }
  for(i=0;i<n;i++){
    A[i]=&(A[0][i*m]);
  }

  return A;   
} /* xmp_malloc_cmatrix */

void xmp_free_matrix(void ***A, int n, int m, size_t usize)
{
  free((*A)[0]);
  free(*A);
  *A=NULL;

  return;
} /* xmp_free_matrix */

void xmp_start_rex(int argc, char **argv)
{
  int     i,j,myrank,nprocs;
  int     pid,ip;
  int     ipaddr[4];
  int     **ipaddrs;
  char    hostname[_HOST_NAME_LENGTH];
  char    **hostnames, *sched_type = NULL;
  time_t  timer;
  struct  tm *t_st;
  struct  hostent *host;

  time(&timer);
  t_st=localtime(&timer);

  MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
  MPI_Comm_size(MPI_COMM_WORLD, &nprocs);
  MPI_Comm_get_parent(&comm_parent);
  if(comm_parent==NULL){
    fprintf(stderr,"ERROR: noparent\n");
    exit(1);
  }
/*
  hostnames=(char **)xmp_malloc_cmatrix(nprocs, _HOST_NAME_LENGTH, sizeof(char));
  ipaddrs  =(int  **)xmp_malloc_imatrix(nprocs, 4, sizeof(int));

  memset(hostname,0,_HOST_NAME_LENGTH);
  gethostname(hostname,_HOST_NAME_LENGTH);
  if(hostname==NULL){
    fprintf(stderr,"ERROR: gethostname\n");
    exit(1);
  }
  MPI_Gather(&(hostname[0]),    _HOST_NAME_LENGTH,MPI_CHAR,
             &(hostnames[0][0]),_HOST_NAME_LENGTH,MPI_CHAR,0,MPI_COMM_WORLD);

  host=gethostbyname(hostname);
  if(host==NULL){
    fprintf(stderr,"ERROR: gethostbyname %s\n",hostname);
    exit(1);
  }

  ip =*(host->h_addr_list[0]);
  ipaddr[0]=ip&0x000000ff;
  ip = *(host->h_addr_list[0]+1);
  ipaddr[1]=ip&0x000000ff;
  ip = *(host->h_addr_list[0]+2);
  ipaddr[2]=ip&0x000000ff;
  ip = *(host->h_addr_list[0]+3);
  ipaddr[3]=ip&0x000000ff;

  MPI_Gather(&(ipaddr[0]),    4,MPI_INT,
             &(ipaddrs[0][0]),4,MPI_INT,0,MPI_COMM_WORLD);

  for(i=0; i<argc-1; i++){
     if(strcmp(argv[i],"-sched")==0){
       sched_type = argv[i+1];
       break;
     }
  }

  if(myrank==0){
    // set node info
    node=(omrpc_mpi_node_t *)malloc(nprocs*sizeof(omrpc_mpi_node_t));
    for(i=0;i<nprocs;i++){
      node[i].rank=i;
      node[i].ip[0]=ipaddrs[i][0];
      node[i].ip[1]=ipaddrs[i][1];
      node[i].ip[2]=ipaddrs[i][2];
      node[i].ip[3]=ipaddrs[i][3];
      memset(node[i].name,0,_HOST_NAME_LENGTH);
      for(j=0;j<_HOST_NAME_LENGTH;j++){
        if(hostnames[i][j]=='.' || hostnames[i][j]=='\0') break;
        node[i].name[j]=hostnames[i][j];
      }
      //memcpy(node[i].name,&(hostnames[i][0]),_HOST_NAME_LENGTH);
    }
    if(strcmp(sched_type,"mpi")==0)
      omrpc_send_nodelist(nprocs, comm_parent, node);
  }
  xmp_free_matrix((void ***)&hostnames, nprocs, _HOST_NAME_LENGTH, sizeof(char));
  xmp_free_matrix((void ***)&ipaddrs,   nprocs, _HOST_NAME_LENGTH, sizeof(int ));
*/
} /* xmp_start_rex */

void xmp_finish_rex()
{
  //free(node);
} /* xmp_finish_rex */

void xmp_start_component(int argc, char **argv)
{
  int     i,myrank,nprocs;
  int     pid;
  time_t  timer;
  struct  tm *t_st;
  struct  hostent *host;
  char    path[PATH_MAX];
int ack;
MPI_File fh;
  time(&timer);
  t_st   = localtime(&timer);
  etime0 = gettimeofday_sec();

  MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
  MPI_Comm_size(MPI_COMM_WORLD, &nprocs);

  if(myrank==0){
    pid=getpid();

    sprintf(path,"%s/%s\0",argv[argc-1],"trace.txt");
    fp_trace_txt =fopen(path,"w");
    fprintf(fp_trace_txt,"component   : %s (pid=%d)\n",argv[0],pid);
    fprintf(fp_trace_txt,"start   time: %s              (%f)\n",asctime(t_st),etime0); 
    fprintf(fp_trace_txt,"nprocs = %d\n",nprocs);
/*
    for(i=0;i<nprocs;i++)
      fprintf(fp_trace_txt,"host %d %s %d.%d.%d.%d\n",i,node[i].name,node[i].ip[0],node[i].ip[1],node[i].ip[2],node[i].ip[3]);
*/
    //fclose(fp_trace_txt);  

    sprintf(path,"%s/%s\0",argv[argc-1],"status.txt");
    fp_status_txt=fopen(path,"w");

    sprintf(path,"%s/%s\0",argv[argc-1],"output.txt");
    fp_output_txt=fopen(path,"w");
    fclose(fp_output_txt);
  } 


} /* xmp_start_component */

extern void _XMP_starpu_get_gpu_time(double *);
extern void _XMP_starpu_get_cpu_time(double *);

void xmp_finish_component()
{
  int    myrank;
  time_t timer;
  struct tm *t_st;
  char   path[PATH_MAX];
  double ctime,gtime;

  MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
  if(myrank!=0) return;

  time(&timer);
  t_st   = localtime(&timer);
  etime1 = gettimeofday_sec();

  //fp_trace_txt =fopen("trace.txt","a");
  //fp_status_txt=fopen("status.txt","w");  
  fprintf(fp_status_txt,"success\n");
  fprintf(fp_trace_txt,"end     time: %s              (%f)\n",asctime(t_st),etime1);
  fprintf(fp_trace_txt,"elasped time: %f\n",etime1-etime0);
  fprintf(fp_trace_txt,"elasped time body: %f\n",_xmp_etime_body);
  _XMP_starpu_get_gpu_time(&gtime);
  _XMP_starpu_get_cpu_time(&ctime);
  fprintf(fp_trace_txt,"gpu_time = %20.10f cpu_time=%20.10f\n",gtime,ctime);
  fclose(fp_trace_txt);
  fclose(fp_status_txt);
} /* xmp_finish_component */
