/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 * @file
 * @brief Real data type parameter wrapper 
 * 
 * @todo Extend support for matching the standard interface of doubles  in C++ 
 *  
 * 2005-09-24
 * Olivier Delannoy
 */
#ifndef REAL_TYPE_HH
#define REAL_TYPE_HH 1
namespace yml { 
typedef double real;

// param_import / export are not needed for basic types 
template <> bool param_import(real& param, const char* filename)
{
    FileStream in(filename, STREAM_READ_ONLY);
    if (in)
    {
        Serializer reader(in);
        reader.readReal64(param);
        
        if (in)
        {
            return true;
        }
    }
    return false;
}
template <> bool param_export(const real& param, const char* filename)
{
    FileStream out(filename, STREAM_WRITE_ONLY);
    if (out)
    {
        Serializer writer(out);
        writer.writeReal64(param);
        if (out)
            return true;
    }
    return false;
}
}
#endif
