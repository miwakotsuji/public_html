/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
/ * Copyright Miwako Tsuji 2014
 *
 *   Miwako Tsuji
 *   miwako.tsuji@riken.jp
 *   AICS,RIKEN
 *   Kobe, Hyogo, JAPAN
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/
/**
 * @file
 * @brief Class XMPBinaryGenerator function definition 
 *
 */
#include "XMPBinaryGenerator.hh"

#ifdef MYX
 /* please edit the directories by yourself :-p */
#define MUST_MODULE_DIR "-L/work/xg19i036/x10112/xg19i036/myx/MUST-v1.6/modules/"
#define MUST_LIB_DIR "-L//work/xg19i036/x10112/xg19i036/myx/MUST-v1.6//lib/"
#endif

#ifdef HAVE_CONFIG_H
#include <yml_config.hh>
#endif 
#include <LoggerFactory.hh>
#include <File.hh>
#include <StringList.hh>
#include <Process.hh>
#include <ConfigFactory.hh>
#include <RuntimeEnvironment.hh>
#include <StringHelper.hh>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <Yml/Core/core.hh>


#define MAXSIZE 1024

namespace DefaultExecutionCatalog
{
XMPBinaryGenerator::XMPBinaryGenerator(const Yml::Core::string& dataDir)
: BinaryGenerator(dataDir + "XMP" + Util::RuntimeEnvironment::PATH_SEPARATOR)
{
}

bool XMPBinaryGenerator::generate(const Yml::Core::ComponentImpl& impl, const Yml::Core::ParameterList& interface, const Yml::Core::string& dest)
{
  Yml::Core::string fname_c(dest+".c");
  Yml::Core::string fname_idl(dest+".idl");
  Yml::Core::string tmp_fname; // "_2f_home_2f_tsuji_2f_local_ ... _XMPfile.c"
  if(createSourceCode(impl, interface, fname_c)){
    if(createBinary(impl.getImplLibraries(),dest,fname_c)){
      UTIL_INFO("default", "DefaultExecutionCatalog: Implementation component '" << impl.getName() << "' compilation successfull");
      if(createOmrpcIdl(impl, interface, fname_idl, tmp_fname)){
        if(createXMPFinalize(impl, interface, fname_c, tmp_fname)){
          if(createRex(impl.getImplLibraries(), dest, fname_idl)){
            UTIL_INFO("default", "DefaultExecutionCatalog: Implementation component '" << impl.getName() << "' omnirpc-rex creation successfull");
            return true;
          }else{
            UTIL_ERROR("default", "DefaultExecutionCatalog: Implementation component '" << impl.getName() << "' omnirpc-rex creation failed");
          }
        }else{
          UTIL_ERROR("default", "DefaultExecutionCatalog: Implementation component '" << impl.getName() << "' omnirpc-idl creation failed");
        }
      }else{
        UTIL_ERROR("default", "DefaultExecutionCatalog: Implementation component '" << impl.getName() << "' tail-source code generation failed");
      }
    }else{
      UTIL_ERROR("default", "DefaultExecutionCatalog: Implementation component '" << impl.getName() << "' compilation failed");
    }
  }else{
    UTIL_ERROR("default", "DefaultExecutionCatalog: Implementation component '" << impl.getName() << "' source code generation failed");
  }
  return false;
} /* XMPBinaryGenerator::generate */

bool XMPBinaryGenerator::createOmrpcIdl(const Yml::Core::ComponentImpl& impl, const Yml::Core::ParameterList& interface, const Yml::Core::string& fname_idl, Yml::Core::string &tmp_fname)
{
  // Path of Dir
  std::string::size_type pdir = fname_idl.find_last_of('/');
  std::string::size_type pext = fname_idl.find_last_of('.');
  Yml::Core::string str_xmp_traverse_init;
  Yml::Core::string str_xmp_traverse_finz;
  Yml::Core::string dir = fname_idl.substr(0, pdir+1);
  str_xmp_traverse_finz = fname_idl.substr(pdir+1, pext-pdir-1) + "_XMPFinalize();";
  // Create OmniRPC IDL
  std::ofstream out(fname_idl.c_str());
  str_xmp_traverse_init = fname_idl;
  Yml::Core::string from = "_"; 
  Yml::Core::string to = "_5f_";
  Yml::Core::string::size_type pos = str_xmp_traverse_init.find(from);
  while(pos != Yml::Core::string::npos){
    str_xmp_traverse_init.replace(pos, from.size(), to);
    pos = str_xmp_traverse_init.find(from, pos + to.size());
  }
  from = "/"; 
  to = "_2f_"; 
  pos = str_xmp_traverse_init.find(from);
  while(pos != Yml::Core::string::npos){
    str_xmp_traverse_init.replace(pos, from.size(), to);
    pos = str_xmp_traverse_init.find(from, pos + to.size());
  }
  from = ".idl";
  to = "_pp()";
  pos = str_xmp_traverse_init.find(from);
  while(pos != Yml::Core::string::npos){
    str_xmp_traverse_init.replace(pos, from.size(), to);
    pos = str_xmp_traverse_init.find(from, pos + to.size());
  }
  tmp_fname = str_xmp_traverse_init;
  pos = tmp_fname.find("_pp()");
  tmp_fname = tmp_fname.substr(0, pos) + ".c";
  str_xmp_traverse_init = "xmpc_traverse_init_file_" + str_xmp_traverse_init;
  if (!out)
    return false;
  out << "Module " << impl.getComponentAbstractName() << ";" << std::endl << std::endl;
  out << "Globals {" << std::endl
      << "#include <worker.h>" << std::endl
      << "#include<limits.h>" << std::endl
      << "#include\"xmp_header.hh\"" << std::endl
      << "MPI_Comm REX_COMM_WORLD=MPI_COMM_NULL;" << std::endl
      << "struct droperation" << std::endl
      << "{" << std::endl
      << "    char*          mHost;" << std::endl
      << "    unsigned short mPort;" << std::endl
      << "    char*          mUri;" << std::endl
      << "    uint8          mIsPacked;" << std::endl
      << "};" << std::endl
      << "typedef struct droperation droperation_t;" << std::endl
      << "struct worker" << std::endl
      << "{" << std::endl
      << "    drclient_t mClient;" << std::endl
      << "    char mInitialWorkingDir[PATH_MAX];" << std::endl
      << "    char mWorkingDir[PATH_MAX];" << std::endl
      << "    char* mWorkDescription;" << std::endl
      << "    uint32 mWorkDescriptionSize;" << std::endl
      << "    char* mBinaryName;" << std::endl
      << "" << std::endl
      << "    char** mParameters;" << std::endl
      << "    uint32 mParameterCurrent;" << std::endl
      << "    uint32 mParameterCount;" << std::endl
      << "" << std::endl
      << "    droperation_t* mImports;" << std::endl
      << "    uint32 mImportCurrent;" << std::endl
      << "    uint32 mImportCount;" << std::endl
      << "" << std::endl
      << "    droperation_t mExport;" << std::endl
      << "    droperation_t mAdmin;" << std::endl
      << "    uint8 mXmlErrorDetected;" << std::endl
      << "};" << std::endl
      << "typedef struct worker* worker_t;" << std::endl
      << "extern int worker_init(worker_t* context, char* data, uint32 dataSize, drclient_t client);" << std::endl
      << "extern int worker_import_resources(worker_t context);" << std::endl
      << "extern int worker_export_resouces(worker_t context);" << std::endl
      << "extern void main_" << impl.getName() << "(int argc,char **argv);" << std::endl
      << "}" << std::endl;
  out << "Define " << impl.getComponentAbstractName() << "(mode_in int dataSize, mode_in char data[dataSize], mode_out int status[1])" << std::endl
      << "{" << std::endl
      << "  int  i,n,status;" << std::endl
      << "  char **arg;" << std::endl
      << "  char *dir;" << std::endl
      << "  worker_t context;" << std::endl
      << "  drclient_t client=0;" << std::endl
      << "  if(REX_COMM_WORLD==MPI_COMM_NULL){" << std::endl;
#ifdef MYX
  out << "    getMySetComm(&REX_COMM_WORLD);" << std::endl;
#else
  out << "    MPI_Comm_dup(MPI_COMM_WORLD, &REX_COMM_WORLD);" << std::endl;
#endif
  out << "  }" << std::endl;
  out << "  if(__myrank==0){" << std::endl
      << "    status=worker_init(&context,data,dataSize,0);" << std::endl
      << "    if(status!=0) exit(1);" << std::endl
      << "    status=worker_import_resources(context);" << std::endl
      << "    if(status!=0) exit(1);" << std::endl
      << "    for(n=0;context->mParameters[n];n++);" << std::endl
      << "  }" << std::endl
      << "  MPI_Bcast(&n,1,MPI_INT,0,REX_COMM_WORLD);" << std::endl
      << "  dir=(char *)malloc(PATH_MAX*sizeof(char));" << std::endl
      << "  arg=(char **)xmp_malloc_matrix(n+1,PATH_MAX,sizeof(char));" << std::endl
      << "  if(__myrank==0){" << std::endl
      << "    for(i=0;i<n;i++){" << std::endl
      << "      strcpy(arg[i],context->mParameters[i]);" << std::endl
      << "    }" << std::endl
      << "    strcpy(arg[n],context->mWorkingDir);" << std::endl
      << "  }" << std::endl
      << "  MPI_Bcast(&(arg[0][0]),(n+1)*PATH_MAX,MPI_CHAR,0,REX_COMM_WORLD);" << std::endl
      << "  strcpy(dir,arg[n]);" << std::endl
      << "  chdir(dir);" << std::endl
      << "  xmp_start_component(n+1,arg);" << std::endl
      << "  " << str_xmp_traverse_init << ";" << std::endl 
      << "  main_" << impl.getName() << "(n+1,arg);" << std::endl
      << "  MPI_Barrier(REX_COMM_WORLD);" << std::endl
      << "  xmp_free_matrix((void ***)&arg,n+1,PATH_MAX,sizeof(char));" << std::endl
      << "  xmp_finish_component();" << std::endl
      << "    chdir(context->mInitialWorkingDir);" << std::endl
      << "  if(__myrank==0){" << std::endl
      << "    status=worker_export_resources(context);" << std::endl
      << "    chdir(context->mInitialWorkingDir);" << std::endl
      << "  }" << std::endl
      << "  " << str_xmp_traverse_finz << ";" << std::endl
      << "}" << std::endl;
  out.close();
  return true;
} /* XMPBinaryGenerator::createOmrpcIdl */

/*
 * Edit XMP_hoge.c to insert xmp_finalize and 
 * compile XMP_hoge.c again
 * */
bool XMPBinaryGenerator::createXMPFinalize(const Yml::Core::ComponentImpl& impl, const Yml::Core::ParameterList& interface, const Yml::Core::string& fname_c, const Yml::Core::string &tmp_fname)
{
  int iflag, max_line = 256, n_line; 
  std::string::size_type pdir = fname_c.find_last_of('/');
  std::string::size_type pext = fname_c.find_last_of('.');
  Yml::Core::string fname0 = fname_c;          // The name without path and extension
  fname0 = fname0.substr(pdir+1, pext-pdir-1); // The name without path and extension
  Yml::Core::string::size_type pos1, pos2;
  Yml::Core::string stmp, tmp, *l;
  std::ofstream out(fname_c.c_str(), std::ios::app);
  tmp = "__omni_tmp__/" + tmp_fname;
  std::ifstream fin(tmp.c_str());

  iflag = 0; n_line = 0; 
  l = new Yml::Core::string[max_line]; 
  while(getline(fin, stmp)){
    if(iflag==0 && strstr(stmp.c_str(), "xmpc_traverse_init_file") && !strstr(stmp.c_str(),"pp();")){
      iflag = 1; 
      getline(fin, stmp); // "{"
    }else if(iflag==1 && strstr(stmp.c_str(), "}")){
      break; 
    }else if(iflag==1){
      l[n_line] = stmp;
      n_line++; 
    }
  }
  fin.close();

  // print out function calls to finalize this XMP-function
  out << "#include\"xmp_func_decl.h\"" << std::endl;
  out << "void " << fname0 << "_XMPFinalize(){" << std::endl;
  for(int i=n_line-1; i>=0; i--){
    if(l[i].compare(0, 17, "_XMP_alloc_array(")==0){
      // _XMP_alloc_array((void * * )(&(_XMP_ADDR_m)), _XMP_DESC_m, 1, ( ...
      // ---> m 
      pos1 = l[i].find("&(");
      pos2 = l[i].find("),");
      stmp = l[i].substr(pos1+2, pos2-pos1-3);
      stmp = stmp.substr(10, stmp.length()-10); // 10="_XMP_ADDR_".length
      out << "extern void *" << "_XMP_DESC_" << stmp << ";" << std::endl;
      out << "_XMP_dealloc_array((_XMP_DESC_" << stmp << "));" << std::endl;
    }
  }
  for(int i=0; i<n_line; i++){
    if(l[i].compare(0, 21, "_XMP_init_array_desc(")==0){
      pos1 = l[i].find("&(");
      pos2 = l[i].find("),");
      out << "_XMP_finalize_array_desc(" << l[i].substr(pos1+2, pos2-pos1-2) << ");" << std::endl;
    }
  }

  out << "}" << std::endl  
  << std::endl;
  out.close();

  // compile modified *.c to object file
  Yml::Core::string cmd_xmp = XMP_CC;
  Yml::Core::string inc_xmp = XMP_INCLUDE;
  Yml::Core::string fname_o = fname_c; 
  Util::StringList param_xmp;
  Util::Process proc_xmp;
  Yml::Core::string::size_type pos = fname_c.find(".c");
  fname_o.replace(pos, 2, ".o");
  param_xmp << "-c" << "-I"+inc_xmp << "-I" + mDataDir + "include" << fname_c << "-o" << fname_o; 
  UTIL_DEBUG("default", "DefaultExecutionCatalog: " << cmd_xmp << " " << param_xmp);
  proc_xmp.start(cmd_xmp, param_xmp);
  proc_xmp.wait();
  delete [] l;
  return true;
}

bool XMPBinaryGenerator::createSourceCode(const Yml::Core::ComponentImpl& impl, const Yml::Core::ParameterList& interface, const Yml::Core::string& fname_c)
{
  // hoge.query --> hoge.c
  std::ofstream out(fname_c.c_str());
  if (!out) return false;
  out << "/********************************************** " << std::endl
      << " * This file has been generated automatically * " << std::endl
      << " * by the yml_component program               * " << std::endl
      << " * Please do not edit                         * " << std::endl
      << " **********************************************/" << std::endl
      << "// Parameter type include" << std::endl;
  // include all type definition
  out << "#include \"yml_xmp_component_base.hh\"" << std::endl;
  for(size_t i = 0; i < interface.count(); ++i){
    const Yml::Core::Parameter& p = interface.get(i);
    out << "#include \"" <<p.getType() << ".xmptype.h\"" << std::endl;
  }
  out << std::endl;
  out << "// Typedefs for parameters" << std::endl;
  out << "#pragma xmp nodes _XMP_default_nodes(" << impl.getImplNodesTopology() << ")"<< std::endl << std::endl;
  Util::StringList template_list;
  for(size_t i = 0; i < interface.count(); ++i){
    const Yml::Core::Parameter& p = interface.get(i);
    if(p.getMapping().empty()==false){
      int  dim_node; // sizes for xmp-array(s) and dimension of nodes
      // integration of implementation component extension (TEMPORARY)
      std::vector<int> vSize = p.getSize();
      if(!template_list.contains(p.getTemplateName())){
        template_list << p.getTemplateName();
        out << p.getTemplatePrint() << std::endl;
      }
      // integration of implementation component extension (TEMPORARY END) */

      // generate variable 
      out << "XMP_" << p.getType() << " " << p.getName();
      for(std::vector<int>::iterator iter = vSize.begin(); iter != vSize.end(); iter++)
        out << "[" << *iter << "]" ;
      out << ";" << std::endl;
      /* ----------------------------------- */
      out << "#pragma xmp align " << p.getName() << p.getDataAlign() << " with " << p.getTemplateName() << p.getTemplateAlign() << std::endl;
      out << std::endl;
    }
    else
    {
      out << "typedef " << p.getType() << " " << p.getName() << "_type;" << std::endl;
    }
    /*
    if(p.isCollection()){
      out << "typedef yml::Collection< yml::" << p.getType() << " > " 
      << p.getName() << "_type;" << std::endl;
    }else{
      out << "typedef yml::" << p.getType() << " " << p.getName() << "_type;" 
      << std::endl;
    }
     */
  }
  out << " // user provided header"       << std::endl
      << impl.getImplHeader()             << std::endl
      << "// end of user provided header" << std::endl << std::endl;

  out << "int main_" << impl.getName() << "(int argc, char **argv)" << std::endl
      << "{" << std::endl;

  for(size_t i=0;i<interface.count();++i){
    const Yml::Core::Parameter& p = interface.get(i);
    if(p.getMapping().empty()){
      out << "  " << p.getName() << "_type " << p.getName() << ";" << std::endl;
    }
  }
  out << std::endl;

  /* Import Parameters */
  out << "  {" << std::endl;

  for(size_t i=0;i<interface.count();++i){
    const Yml::Core::Parameter& p = interface.get(i);
    if(p.getIOMode()==Yml::Core::PARAM_IO_IN  || p.getIOMode()==Yml::Core::PARAM_IO_INOUT ){
      if(!p.getMapping().empty()){
        out << "    extern " << "XMP_" << p.getType() << " *_XMP_ADDR_" << p.getName() << ";\n";
        out << "    type_import((void *)_XMP_M_GET_ADDR_0(_XMP_ADDR_" << p.getName() << ")" << ",argv[" << i+1 << "]," << p.getType() << "_MPI_Type," << p.getType() <<"_import,\"";

        std::vector<int> vSize = p.getSize();
        for(std::vector<int>::iterator iter = vSize.begin(); iter != vSize.end(); iter++){
          if(iter !=vSize.begin()) out << ",";
          out << *iter ;
        }
        int istart=p.getNode().find('(');
        int iend=p.getNode().find(')');
        out << ";" << p.getNode().substr(istart+1,iend-istart-1) << ";";
        //out << ";" << impl.getImplNodesTopology() << ";";

        std::vector<Yml::Core::ParameterMapping> vMap = p.getMapping();
        for(std::vector<Yml::Core::ParameterMapping>::iterator iter = vMap.begin(); iter != vMap.end(); iter++){
          if(iter !=vMap.begin()) out << ",";
          out << *iter;
        }

        out << ";";
        out << p.getDataAlign() << ":" << p.getTemplateAlign() << "\");" << std::endl;
      }else{
        out << p.getType() << "_import(&" << p.getName()  << ",argv[" << i+1 << "]);" << std::endl;
      }
    }
  }

  out << "  }" << std::endl;
  out << std::endl;

  // Class body goes here
  out << "{ // ==================== XMP source code : start ====================" << std::endl
      << "  extern double gettimeofday_sec(), _xmp_etime_body;" << std::endl
      << "  extern MPI_Comm REX_COMM_WORLD;" << std::endl
      << "  double _xmp_t0;" << std::endl
      << "  MPI_Barrier(REX_COMM_WORLD);" << std::endl
      << "  _xmp_t0 = gettimeofday_sec();" << std::endl
      << impl.getImplSource() << std::endl
      << "  MPI_Barrier(REX_COMM_WORLD);" << std::endl
      << "  _xmp_etime_body = gettimeofday_sec()-_xmp_t0;" << std::endl
      << "} // ==================== XMP source code :  end  ====================" << std::endl;
  out << std::endl;

  /* Export Parameters */
  out << "  {" << std::endl;
  for(size_t i=0;i<interface.count();++i){
    const Yml::Core::Parameter& p        = interface.get(i);
    if(p.getIOMode()==Yml::Core::PARAM_IO_OUT  || p.getIOMode()==Yml::Core::PARAM_IO_INOUT ){
      if(!p.getMapping().empty()){
        out << "{" << std::endl;
      //out << "    extern " << "XMP_" << p.getType()  << " * _XMP_ADDR_" << p.getName() << ";\n";
      //out << "    type_export((void *)_XMP_M_GET_ADDR_0(_XMP_ADDR_" << p.getName() << ")" << ",argv[" << i+1 << "]," << p.getType() << "_MPI_Type," << p.getType() << "_export,\"";
        out << "    type_export(&(" << p.getName() << ")" << ",argv[" << i+1 << "]," << p.getType() << "_MPI_Type," << p.getType() << "_export,\"";

        std::vector<int> vSize = p.getSize();
        for(std::vector<int>::iterator iter = vSize.begin(); iter != vSize.end(); iter++){
          if(iter !=vSize.begin()) out << ",";
          out << *iter ;
        }
        //out << ";" << impl.getImplNodesTopology() << ";";
        int istart=p.getNode().find('(');
        int iend=p.getNode().find(')');
        out << ";" << p.getNode().substr(istart+1,iend-istart-1) << ";";
                                
        std::vector<Yml::Core::ParameterMapping> vMap = p.getMapping();
        for(std::vector<Yml::Core::ParameterMapping>::iterator iter = vMap.begin(); iter != vMap.end(); iter++){
          if(iter !=vMap.begin()) out << ",";
          out << *iter;
        }

        out << ";";
        out << p.getDataAlign() << ":" << p.getTemplateAlign() << "\");" << std::endl;
        out << "}" << std::endl;
      }else{
        out << p.getType() << "_export(&" << p.getName() << ",argv[" << i+1 << "]);" << std::endl;
      }
    }
  }

  out << "  }" << std::endl;

  out << std::endl;

  out << "  return EXIT_SUCCESS; "     << std::endl;
  out << "} // end of main component " << std::endl;
  out << "// User provided footer"    << std::endl
      << "#line 1 \"Footer section\""  << std::endl
      << impl.getImplFooter()          << std::endl
      << "/***********************************************/" << std::endl;
  out.close();
  return true;
} /* XMPBinaryGenerator::createSourceCode */

bool XMPBinaryGenerator::createRex(const Yml::Core::string& libraries, const Yml::Core::string& dest, const Yml::Core::string& fname_idl)
{
  bool abort = false;
  Yml::Core::string fname_o       (dest+".o");
  Yml::Core::string fname_rex     (dest+".rex");
  Yml::Core::string fname_rex_c   (dest+".rex.c");
  Yml::Core::string fname_rex_o   (dest+".rex.o");
  Yml::Core::string libexpat_a       = EXPAT_LIB;
  Yml::Core::string xmp_lib          = XMP_LIB;
  Yml::Core::string xmp_include      = XMP_INCLUDE;
  Yml::Core::string xmp_std_lib      = mDataDir+"lib/libxmp_std_lib.a";
  Yml::Core::string workerIncludeDir = YML_WORKER_INCLUDE;
  Yml::Core::string yml_worker_lib   = YML_WORKER_LIB;
  Yml::Core::string cmd_mpl          = MPI_CC; // linker
  Yml::Core::string cmd_mpc          = MPI_CC; // compiler 
  Yml::Core::string cmd_omg          = OMRPC_GEN_XMP;
  Yml::Core::string omrpcIncludeDir  = OMRPC_INCLUDE;
  Yml::Core::string omrpc_lib_stub   = OMRPC_LIB_STUB;
  Yml::Core::string omrpc_lib_io     = OMRPC_LIB_IO;
  Util::Process proc;
  Util::StringList param_omg;
  Util::StringList param_mpc, param_mpl, lflags_mpl;
  Yml::Core::string libInfoDir(mDataDir + "lib" + Util::RuntimeEnvironment::PATH_SEPARATOR);

  // $ ./omrpc-gen-xmp hoge.idl hoge.rex.c 
  param_omg << fname_idl << fname_rex_c;
  proc.start(cmd_omg, param_omg);
  proc.wait();
  UTIL_DEBUG("default", "DefaultExecutionCatalog: Compiler completes with exit status " << proc.exitStatus());

  param_mpc << "-c" << fname_rex_c << "-I"+workerIncludeDir << "-I"+omrpcIncludeDir << "-I"+mDataDir+"include" << "-o" << fname_rex_o;
  proc.start(cmd_mpc,param_mpc);
  proc.wait();

  // lflags_mpl << "-static" << "-L" + mDataDir + "lib";
  // Check for includes / libs for all libraries
  if (!libraries.empty())
  {
    std::istringstream libList(libraries);
    while(!libList.eof())
    {
      Yml::Core::string lib;
      libList >> lib;
      UTIL_INFO("default", "DefaultExecutionCatalog: Retrieving information for library '" << lib << "'");
      std::ifstream libdesc((libInfoDir + lib + ".txt").c_str());
      if (!libdesc)
      {
        UTIL_ERROR("default", "Library '" << lib << "' is not available");
        abort = true;
        break;
      }

      Yml::Core::string cflags;
      std::getline(libdesc, cflags);
      /*
      std::istringstream ifl(Util::StringHelper::trim(cflags));
      while(!ifl.eof())
      {
        Yml::Core::string tmp;
        ifl >> tmp;
        // Skip the line
        //if (ifl && ! tmp.empty())  cflagsList << tmp;
      }
      */
      Yml::Core::string libs;
      std::getline(libdesc, libs);
      std::istringstream ili(Util::StringHelper::trim(libs));
      while(!ili.eof())
      {
        Yml::Core::string tmp;
        ili >> tmp;
        if (ili && !tmp.empty()) lflags_mpl << tmp;
      }
    }
  }

#ifndef MYX
  lflags_mpl << xmp_std_lib  << omrpc_lib_stub << omrpc_lib_io << xmp_lib << yml_worker_lib << libexpat_a << "-lm" << "-ldl" << "-fopenmp";
#else
  lflags_mpl << xmp_std_lib  << omrpc_lib_stub << omrpc_lib_io << xmp_lib << yml_worker_lib << libexpat_a << 
  MUST_MODULE_DIR << "-lcProtMpiSplitComm" << MUST_LIB_DIR << "-lpnmpi" << 
  "-lm" << "-ldl" << "-fopenmp";
#endif
  param_mpl << fname_rex_o << fname_o <<  lflags_mpl << "-o" << fname_rex;
  proc.start(cmd_mpl,param_mpl);
  proc.wait();


  UTIL_DEBUG("default", "DefaultExecutionCatalog: Compiler completes with exit status " << proc.exitStatus());

  return proc.exitStatus() == 0;
} /* XMPBinaryGenerator::createRex */

bool XMPBinaryGenerator::createBinary(const Yml::Core::string& libraries, const Yml::Core::string& dest, const Yml::Core::string& fname_c)
{
  // xmpcc -c hoge.c -o hoge.o 
  bool abort = false;
  Yml::Core::string cmd_xmp       = XMP_CC;
  Yml::Core::string cmd_cda       ="/opt/CUDA/4.2.9/cuda/bin/nvcc";
  Yml::Core::string fname_o       =dest+".o";
  Yml::Core::string fname_cu      =dest+".cu";
  Yml::Core::string omrpc_inc     =OMRPC_INCLUDE;
  Util::Process proc_xmp;
  Util::StringList param_xmp, cflags_xmp, lflags_xmp;

  Yml::Core::string libInfoDir(mDataDir + "lib" + Util::RuntimeEnvironment::PATH_SEPARATOR);
  //AAAA 
  //cflags_xmp << "-c" << "-O3" << "-I" + mDataDir + "include" << "-I"+omrpc_inc;
  cflags_xmp << "-c" << "-g" << "-I" + mDataDir + "include" << "-I"+omrpc_inc;
  //lflags_xmp << "-static -lm" << "-L" + mDataDir + "lib";
  lflags_xmp << "-lm" << "-L" + mDataDir + "lib";
  // Check for includes / libs for all libraries
  if (!libraries.empty())
  {
    std::istringstream libList(libraries);
    while(!libList.eof())
    {
      Yml::Core::string lib;
      libList >> lib;
      UTIL_INFO("default", "DefaultExecutionCatalog: Retrieving information for library '" << lib << "'");
      std::ifstream libdesc((libInfoDir + lib + ".txt").c_str());
      if (! libdesc)
      {
        UTIL_ERROR("default", "Library '" << lib << "' is not available");
        abort = true;
        break;
      }

      Yml::Core::string cflags;
      std::getline(libdesc, cflags);
      std::istringstream ifl(Util::StringHelper::trim(cflags));
      while(!ifl.eof())
      {
        Yml::Core::string tmp;
        ifl >> tmp;
        if (ifl && ! tmp.empty())
          cflags_xmp << tmp;
      }

      Yml::Core::string libs;
      std::getline(libdesc, libs);
      std::istringstream ili(Util::StringHelper::trim(libs));
      while(!ili.eof())
      {
        Yml::Core::string tmp;
        ili >> tmp;
        //if (ili && !tmp.empty()) lflags_xmp << tmp;
      }
    }
  }

  if (abort)
    return false;

  param_xmp << cflags_xmp << "-o" << fname_o << fname_c << lflags_xmp << "--debug";
  UTIL_DEBUG("default", "DefaultExecutionCatalog: " << cmd_xmp << " " << param_xmp);
  proc_xmp.start(cmd_xmp, param_xmp);
  proc_xmp.wait();
  UTIL_DEBUG("default", "DefaultExecutionCatalog: Compiler completes with exit status " << proc_xmp.exitStatus());

  return (proc_xmp.exitStatus() == 0);
} /* XMPBinaryGenerator::createBinary */

}

