#ifndef YML_TYPE_RAW_HH
#define YML_TYPE_RAW_HH 1
namespace yml 
{
class raw
{
  public:
    RawData(void)
        : mData(0), mLength(0)
    {
    }
    ~RawData(void)
    {
      if (mData)
        free(mData);
    }

    size_t length(void) const
    {
      return mLength;
    }
    void setLength(size_t len)
    {
      mLength = len;
      mData = realloc(mData, len);
    }

    char* getPtr(void)
    {
      return mData;
    }
  protected:
  private:
    char *mData;
    size_t mLength;
};

template <raw>
bool param_import(raw& param, char* filename)
{
  return false;
}

template <raw>
bool param_export(const raw& param, char* filename)
{
  return false;
}

}
#endif 
