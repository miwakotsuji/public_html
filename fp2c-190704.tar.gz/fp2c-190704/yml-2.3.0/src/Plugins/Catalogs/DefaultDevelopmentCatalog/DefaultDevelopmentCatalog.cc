/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/

/**
 * @file
 * @brief Class FileCatalog function definition 
 *
 * 2005-06-14
 * Olivier Delannoy
 */
#include "DefaultDevelopmentCatalog.hh"
#include <Yml/Core/ComponentAbstract.hh>
#include <Yml/Core/ComponentGraph.hh>
#include <Yml/Core/ComponentImpl.hh>
#include <Yml/Core/Parameter.hh>
#include <Yml/Core/Component_xmlHandler.hh>
#ifdef HAVE_CONFIG_H
# include <yml_config.hh>
#endif 

#include <LoggerFactory.hh>
#include <RuntimeEnvironment.hh>
#include <FileInfo.hh> 
#include <Dir.hh>
#include <XMLSerializer.hh> 
#include <XMLParserFactory.hh>
#include <XMLParser.hh>
#include <iostream> 
#include <fstream>

namespace DefaultDevelopmentCatalog
{

DefaultDevelopmentCatalog::DefaultDevelopmentCatalog(void)
{    
}
DefaultDevelopmentCatalog::~DefaultDevelopmentCatalog(void)
{   
}
void DefaultDevelopmentCatalog::init(const Yml::Core::string& initData)
{
    // Initialise the catalog Currently the folders must exists already 
    // Currently only abstract component are stored 
    //Dir::create(initData);
    mAbstractDir = initData + Util::RuntimeEnvironment::PATH_SEPARATOR + "abstract" + Util::RuntimeEnvironment::PATH_SEPARATOR;
    mGraphDir = initData + Util::RuntimeEnvironment::PATH_SEPARATOR + "graph" + Util::RuntimeEnvironment::PATH_SEPARATOR;
    mImplDir = initData + Util::RuntimeEnvironment::PATH_SEPARATOR + "implementation" + Util::RuntimeEnvironment::PATH_SEPARATOR;
    Util::Dir::mkdir(mAbstractDir);
    Util::Dir::mkdir(mGraphDir);
    Util::Dir::mkdir(mImplDir);
    UTIL_FATAL_ASSERT("default", Util::FileInfo(mAbstractDir).isDir(), 
                         "DefaultDevelopmentCatalog: Initialization error, unable to create '" << mAbstractDir << "'");
    UTIL_FATAL_ASSERT("default", Util::FileInfo(mGraphDir).isDir(), 
                         "DefaultDevelopmentCatalog: Initialization error, unable to create '" << mGraphDir << "'");
    UTIL_FATAL_ASSERT("default", Util::FileInfo(mImplDir).isDir(), 
                         "DefaultDevelopmentCatalog: Initialization error, unable to create '" << mImplDir << "'");
    UTIL_INFO("default", "DefaultDevelopmentCatalog: storing abstract component in '" << mAbstractDir << "'");
    UTIL_INFO("default", "DefaultDevelopmentCatalog: storing graph component in '" << mGraphDir << "'");
    UTIL_INFO("default", "DefaultDevelopmentCatalog: storing implementation component in '" << mImplDir << "'");
}



bool DefaultDevelopmentCatalog::registerComponentAbstract(const Yml::Core::ComponentAbstract* component, bool force)
{
    //Create a file for the component 
    Yml::Core::string filename =  mAbstractDir + component->getName() + ".xml";
    if (Util::FileInfo(filename).isFile() && ! force)
    {
        UTIL_INFO("default", "DefaultDevelopmentCatalog: Abstract Component '" << component->getName() << "' already exists'");
        return false;
    }
    
    std::ofstream out(filename.c_str());
    {
        Util::XMLSerializer xmlStream(out);
        component->toXML(xmlStream);
    }
    out.close();
    UTIL_INFO("default", "DefaultDevelopmentCatalog: Abstract Component '" << component->getName() << "' registered successfully");
    return true;
}

bool DefaultDevelopmentCatalog::registerComponentGraph(const Yml::Core::ComponentGraph* component, bool force)
{
    //Create a file for the component 
    Yml::Core::string filename =  mGraphDir + component->getName() + ".xml";
    if (Util::FileInfo(filename).isFile() && ! force)
    {
        UTIL_INFO("default", "DefaultDevelopmentCatalog: Graph Component '" << component->getName() << "' already exists'");
        return false;
    }
    
    std::ofstream out(filename.c_str());
    {
        Util::XMLSerializer xmlStream(out);
        component->toXML(xmlStream);
    }
    out.close();
    UTIL_INFO("default", "DefaultDevelopmentCatalog: Graph Component '" << component->getName() << "' registered successfully");
    return true;
}

bool DefaultDevelopmentCatalog::registerComponentImpl(const Yml::Core::ComponentImpl* component, bool force)
{
    //Create a file for the component 
    Yml::Core::string filename =  mImplDir + component->getName() + ".xml";
    if (Util::FileInfo(filename).isFile() && ! force)
    {
        UTIL_INFO("default", "DefaultDevelopmentCatalog: Implementation Component '" << component->getName() << "' already exists'");
        return false;
    }
    
    std::ofstream out(filename.c_str());
    {
        Util::XMLSerializer xmlStream(out);
        component->toXML(xmlStream);
    }
    out.close();
    UTIL_INFO("default", "DefaultDevelopmentCatalog: Implementation Component '" << component->getName() << "' registered successfully");
    return true;    

}

void DefaultDevelopmentCatalog::releaseComponentAbstract(Yml::Core::ComponentAbstract* component)
{
    delete component;   
}
void DefaultDevelopmentCatalog::releaseComponentGraph(Yml::Core::ComponentGraph* component)
{
    delete component;   
}
void DefaultDevelopmentCatalog::releaseComponentImpl(Yml::Core::ComponentImpl* component)
{
    delete component;   
}

const Yml::Core::ComponentAbstract* DefaultDevelopmentCatalog::retrieveComponentAbstract(const Yml::Core::string& name)
{
    Yml::Core::string filename =  mAbstractDir + name + ".xml";
    if (Util::FileInfo(filename).isFile())
    {
        // Try to load the file 
        Yml::Core::Component_xmlHandler handler;
        Util::XMLParser parser = Util::XMLParserFactory::getSingleton().create();
        parser.parse(handler, filename, "");
        if (handler.getComponentType() != Yml::Core::COMPONENT_TYPE_ABSTRACT)
        {
            UTIL_ERROR("default", "DefaultDevelopmentCatalog: Retrieving abstract component '" <<name << "'failed: xml document does not match an abstract component definition");
            return false;
        }
        else 
        {
            return new Yml::Core::ComponentAbstract(handler.getComponentAbstract());
        }
    }
    return 0;
}

const Yml::Core::ComponentGraph* DefaultDevelopmentCatalog::retrieveComponentGraph(const Yml::Core::string& name)
{
    Yml::Core::string filename =  mGraphDir + name + ".xml";
    if (Util::FileInfo(filename).isFile())
    {
        // Try to load the file 
        Yml::Core::Component_xmlHandler handler;
        Util::XMLParser parser = Util::XMLParserFactory::getSingleton().create();
        parser.parse(handler, filename, "");
        if (handler.getComponentType() != Yml::Core::COMPONENT_TYPE_GRAPH)
        {
            UTIL_ERROR("default", "DefaultDevelopmentCatalog: Retrieving graph component '" <<name << "'failed: xml document does not match an abstract component definition");
            return false;
        }
        else 
        {
            return new Yml::Core::ComponentGraph(handler.getComponentGraph());
        }
    }
    return 0;    
}

const Yml::Core::ComponentImpl* DefaultDevelopmentCatalog::retrieveComponentImpl(const Yml::Core::string& name)
{
    Yml::Core::string filename =  mImplDir + name + ".xml";
    if (Util::FileInfo(filename).isFile())
    {
        // Try to load the file 
        Yml::Core::Component_xmlHandler handler;
        Util::XMLParser parser = Util::XMLParserFactory::getSingleton().create();
        parser.parse(handler, filename, "");
        if (handler.getComponentType() != Yml::Core::COMPONENT_TYPE_IMPL)
        {
            UTIL_ERROR("default", "DefaultDevelopmentCatalog: Retrieving implementation component '" <<name << "'failed: xml document does not match an abstract component definition");
            return false;
        }
        else 
        {
            return new Yml::Core::ComponentImpl(handler.getComponentImpl());
        }
    }
    return 0;    
}



}
/**
 * Create a new instance of a development catalog 
 */
extern "C" Yml::Core::DevelopmentCatalog* create(void)
{
    return new DefaultDevelopmentCatalog::DefaultDevelopmentCatalog();
}
/**
 * Destroy an instance of a development catalog created by this plugin
 */ 
extern "C" void destroy(Yml::Core::DevelopmentCatalog* object)
{
    delete static_cast<DefaultDevelopmentCatalog::DefaultDevelopmentCatalog*>(object);
}

