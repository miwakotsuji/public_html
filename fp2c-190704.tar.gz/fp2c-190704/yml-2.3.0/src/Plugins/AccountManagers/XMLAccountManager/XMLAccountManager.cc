/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/

/**
 * @file
 * @brief Class XMLAccountManager function definition 
 *
 * 2005-06-17
 * Olivier Delannoy
 */
#include "XMLAccountManager.hh"
#include <Yml/Core/Account.hh> 
#include <cassert>
#include <LoggerFactory.hh>
#include <AccountList.hh>
#include <AccountHandler.hh> 
#include <XMLParserFactory.hh>
#include <FileInfo.hh> 
#include <sstream>
#include <fstream>
#include <cstdlib>
XMLAccountManager::XMLAccountManager::XMLAccountManager(void)
{
}

XMLAccountManager::XMLAccountManager::~XMLAccountManager(void)
{
}

bool XMLAccountManager::XMLAccountManager::init(const Yml::Core::string& initData)
{
    UTIL_DEBUG("default", "XMLAccountManager: Initializing plugin");
    UTIL_DEBUG("default", "XMLAccountManager: Using " << initData);
    mFile = initData;
    Util::FileInfo info(mFile);   
    UTIL_ERROR_ASSERT("default", info.isFile() && info.exists(), mFile << ": No such file");
    UTIL_ERROR_ASSERT("default", info.isReadable() && info.isWriteable(), mFile << ": Access denied");
    return info.isReadable() && info.isWriteable();
}


Yml::Core::Account* XMLAccountManager::XMLAccountManager::load(const Yml::Core::string& login, const Yml::Core::string& password)
{
    Yml::Core::Account *account = 0;
    UTIL_INFO("default", "Loading account information for login '" << login << "'");
    AccountHandler handler;
    Util::XMLParser parser = Util::XMLParserFactory::getSingleton().create();
    parser.parse(handler, mFile, "accounts.xsd");
    Account* acc = handler.accounts().find(login);
    if (acc)
    {
        if (acc->mPassword == password)
        {
            account = new Yml::Core::Account;
            UTIL_FATAL_ASSERT("default", account, "Unable to allocate a new Account object");
            account->setLogin(acc->mLogin);        
            account->setPassword(acc->mPassword);
            account->setMail(acc->mEmail);
            account->setRights(atoi(acc->mRights.c_str()));
            account->setFullName(acc->mFullName);
            account->setOrganization(acc->mOrganization);
            UTIL_INFO("default", "Account '" << login << "': loaded successfully");
        }    
        else 
        {
            UTIL_ERROR("default", "Login and password mismatch : access denied");
        }
        
    }
    else 
    {
        UTIL_ERROR("default", "Account does not exists '" << login << "': access denied");
    }
    return account;
}

bool XMLAccountManager::XMLAccountManager::insert(Yml::Core::Account* account)
{
    assert(account);
    UTIL_INFO("default", "Inserting account '" << account->getLogin() << "'");
    AccountHandler handler;
    Util::XMLParser parser = Util::XMLParserFactory::getSingleton().create();
    parser.parse(handler, mFile, "accounts.xsd");
    std::ostringstream rights;
    rights << account->getRights();

    if (handler.accounts().insert(account->getLogin(), account->getPassword(), 
                                  account->getMail(), rights.str(), 
                                  account->getFullName(), account->getOrganization()))
    {
        std::ofstream out(mFile.c_str());
        handler.accounts().toXML(out);
        out.close();
        UTIL_INFO("default", "Account '" << account->getLogin() << "' added successfully");
        return true;
    }
    else 
    {
        UTIL_ERROR("default", "Account '" << account->getLogin() << "' already exists");
        return false;
    }
}

bool XMLAccountManager::XMLAccountManager::remove(const Yml::Core::string& login)
{
    UTIL_INFO("default", "Removing account '" << login << "'");
    AccountHandler handler;
    Util::XMLParser parser = Util::XMLParserFactory::getSingleton().create();
    parser.parse(handler, mFile, "accounts.xsd");
    if (handler.accounts().remove(login))
    {
        std::ofstream out(mFile.c_str());
        handler.accounts().toXML(out);
        out.close();
        UTIL_INFO("default", "Account '" << login << "' removed successfully");
        return true;
    }
    else 
    {
        UTIL_ERROR("default", "Account '" << login << "' does not exists, unable to remove it");
        return false;
    }
}

bool XMLAccountManager::XMLAccountManager::update(Yml::Core::Account* account)
{
    assert(account);
    UTIL_INFO("default", "Updating account  '" << account->getLogin() << "'");
    AccountHandler handler;
    Util::XMLParser parser = Util::XMLParserFactory::getSingleton().create();
    parser.parse(handler, mFile, "accounts.xsd");
    std::ostringstream rights;
    rights << account->getRights();

    if (handler.accounts().update(account->getLogin(), account->getPassword(), 
                                  account->getMail(), rights.str(), 
                                  account->getFullName(), account->getOrganization()))
    {
        std::ofstream out(mFile.c_str());
        handler.accounts().toXML(out);
        out.close();
        UTIL_INFO("default", "Account '" << account->getLogin() << "' updated successfully");
        return true;
    }
    else 
    {
        UTIL_ERROR("default", "Account '" << account->getLogin() << "' update failed");
        return false;
    }
}

extern "C" Yml::Core::AccountManager* create()
{
    return new XMLAccountManager::XMLAccountManager();
}

extern "C" void destroy(Yml::Core::AccountManager* object)
{
    delete object;
}
