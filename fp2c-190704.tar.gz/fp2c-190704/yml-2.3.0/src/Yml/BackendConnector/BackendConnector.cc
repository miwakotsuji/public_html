/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/
/**
 * @file
 * @brief Class BackendConnector function definition 
 *
 * 2007-09-26
 * Olivier Delannoy
 */
#include <Yml/Core/core.hh> 
#include <Yml/Core/PluginManager.hh> 
#include <Yml/Core/Backend.hh> 
#include <Yml/UDP/UDP.hh> 

#include <Application.hh> // Util::Application 
#include <CommandLineOption.hh>
#include <CommandLineParser.hh> 
#include <ConsoleApplicationAdaptor.hh>
#include <ConfigFactory.hh>
#include <LoggerFactory.hh>

#include <locale>
#include <sstream>
#include <sys/time.h> 


namespace Yml
{
namespace BackendConnector
{
using Yml::Core::string;
using Yml::Core::uint32;
using Yml::Core::uint64;
using Yml::Core::SchedulerTask;

class BackendConnector: public Util::Application, public enet::SignalBindable 
{
public:
    BackendConnector(Util::ApplicationAdaptor* adaptor, int argc, char** argv);
    ~BackendConnector();
protected:
    void configureCommandLine();
    string usageQuick() const;
    string usageParameters() const;
    string usageOptions() const;
    string configDir() const;
    string loggerDir() const;
    string pluginDir() const;
    uint32 run();
    
private:
    long long currentTime();

    void doIdle();
    void doConnect(Yml::UDP::Peer& peer);
    void doDisconnect(Yml::UDP::Peer& peer)  { execute = false; }
    void doReceive(Yml::UDP::Peer& peer, Yml::UDP::Message* message);
    bool execute;
    Yml::UDP::Host* mHost;
    Yml::Core::PluginManager mPluginManager;
};


BackendConnector::BackendConnector(Util::ApplicationAdaptor* adaptor, int argc, char** argv) 
    : Util::Application(adaptor, argc, argv) 
{
    std::locale::global(std::locale("C"));
}

BackendConnector::~BackendConnector()
{
}

void BackendConnector::configureCommandLine() 
{
    mCmdLineParser->parameterCount(0);
    mCmdLineParser->addOption(new Util::CommandLineOption("module", "", true, true));
    mCmdLineParser->addOption(new Util::CommandLineOption("init", "", true, true));
    mCmdLineParser->addOption(new Util::CommandLineOption("port", "5666", true));
    mCmdLineParser->addOption(new Util::CommandLineOption("host", "localhost", true));
    mCmdLineParser->addOption(new Util::CommandLineOption("delay", "3000", true));
}

string BackendConnector::usageParameters() const
{
    return "";
}
string BackendConnector::usageQuick() const
{
    return " --module=<module> --init=<init string>";
}

string BackendConnector::usageOptions() const 
{
    return 
      "\n *--module=string ...: The name of the module to use" 
      "\n *--init=string .....: The module initialization string, "
      "\n                       often it is the configuration file "
      "associated" 
      "\n  --host=strting ....: This is the hostname of "
      "the server" 
      "\n  --port=integer ....: This is the port number used "
      "to connect to the server" 
      "\n  --delay=integer ...: The pool delay between two pooling "
      "\n                       operation on the backend";
}
string BackendConnector::configDir() const
{
    return CONFIG_DIR;
}
string BackendConnector::loggerDir() const
{
    return Util::ConfigFactory::getSingleton().create("yml")->get("path", "loggers", ".");
}
string BackendConnector::pluginDir() const
{
    return Util::ConfigFactory::getSingleton().create("yml")->get("path", "plugins", ".");
}

long long BackendConnector::currentTime()
{
    struct timeval tv;
    gettimeofday(&tv, 0);
    return (long long)tv.tv_sec * (long long)1000000 
        + (long long)tv.tv_usec;
}




uint32 BackendConnector::run() 
{
    UTIL_INFO("default", "Starting BackendConnector");
    // Initialization
    ///////////////////////////////////////////////////
    //  Parse command line 
    Util::CommandLineOption* opt;
    opt = option("module");
    Yml::Core::string backendModule = opt->value();    
    opt = option("init");
    Yml::Core::string backendInit = opt->value();
    opt = option("host");
    Yml::Core::string bmHost = opt->value();
    opt = option("port");
    Yml::Core::uint16 bmPort;
    std::istringstream parsePort(opt->value());
    parsePort >> bmPort;
    opt = option("delay");
    std::istringstream parsePollDelay(opt->value());
    Yml::Core::uint32 pollDelay;
    parsePollDelay >> pollDelay;

    ///////////////////////////////////////////////////
    // Print option summary 
    UTIL_INFO("default", "Back-end module .............: " << backendModule);
    UTIL_INFO("default", "Back-end initialization .....: " << backendInit);
    UTIL_INFO("default", "Back-ends manager host ......: " << bmHost);
    UTIL_INFO("default", "Back-ends manager port ......: " << bmPort);
    UTIL_INFO("default", "Poll delay of the Back-ends .: " << pollDelay);
    
    ///////////////////////////////////////////////////
    // Load back-ends 
    mPluginManager.createBackend(backendModule, backendInit);

    ///////////////////////////////////////////////////
    // Connect to the backend-manager
    UTIL_INFO("default", "BackendConnector running");
    Yml::UDP::UDP udpLibrary; // We can use the library from now on
    Yml::UDP::Host host;
    mHost = &host;
    // Setup signals 
    host.onIdle.connect(*this, &BackendConnector::doIdle);
    host.onPeerConnect.connect(*this, &BackendConnector::doConnect);
    host.onPeerDisconnect.connect(*this, &BackendConnector::doDisconnect);
    host.onMessageReceived.connect(*this, &BackendConnector::doReceive);
    
    
    
    // Connect to the backend manager
    if (! host.connect(bmHost.c_str(), bmPort))
    {
        UTIL_FATAL("default", "Unable to connect to the back-end manager");
        return ERROR;
    }
    Yml::UDP::MSGBackendStart start;
    host.broadcast(&start, 0);
    host.flush();
        
    ///////////////////////////////////////////////////
    // Main loop
    execute  = true;
    while(execute) {
        host.service(pollDelay);
    }
    UTIL_INFO("default", "Stoping BackendConnector");    
    return SUCCESS;
}

void BackendConnector::doIdle()
{
    Yml::Core::SchedulerTask* task = 0;
    int count = 0;
    while( (task = mPluginManager.getBackend().retrieve() ) != 0)
    {
        Yml::UDP::MSGTaskFinished finished;
        finished.task().app_id = task->appId();
        finished.task().task_id = task->index();
        finished.task().task_status = task->status();
        UTIL_INFO("default", "Task " << task->appId() << "/" << task->index()
                  << " finished with status " << task->status());
        mHost->broadcast(&finished, 0);
        ++count;
        if (count > 10)
            mHost->service(0);
    }
}
void BackendConnector::doConnect(Yml::UDP::Peer& peer)
{
    UTIL_INFO("default", "Connected to the back-end manager");
}

void BackendConnector::doReceive(Yml::UDP::Peer& peer, Yml::UDP::Message* message)
{
    Yml::Core::SchedulerTask* task;
    
    switch(message->type())
    {
    case Yml::UDP::MSG_TASK_SUBMIT:
        //UTIL_INFO("default", "New incomming task");
        task = static_cast<Yml::UDP::MSGTaskSubmit*>(message)->task();
        assert(task);
        UTIL_INFO("default", "Executing task: " << task->appId() << "/" << task->index());
        //UTIL_INFO("default", "Work: " << task->work());
        //UTIL_INFO("default", "Component: " << task->component());
        //for(Yml::Core::uint32 i = 0 ; i < task->parameters() ; ++i) 
        //   UTIL_INFO("default", "  param "<<i<<": "<<task->parameter(i));
        //UTIL_INFO("default", "UID: " << task->uid());
        mPluginManager.getBackend().execute(task);
        break;
    case Yml::UDP::MSG_TASK_CANCEL:
        UTIL_INFO("debug", "Task canceled");
        mPluginManager.getBackend().cancel(static_cast<Yml::UDP::MSGTaskCancel*>(message)->task().app_id, 
                                           static_cast<Yml::UDP::MSGTaskCancel*>(message)->task().task_id);
        break;
    default:
        UTIL_DEBUG("debug", "Unknown message type: " << message->type());
    }
}

} // end of namespace BackendConnector 
} // end of namesapce Yml



UTIL_APPLICATION(Yml::BackendConnector::BackendConnector, Util::ConsoleApplicationAdaptor())
