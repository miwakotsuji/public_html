/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/

/**
 * @file
 * @brief Class Development Catalog declaration
 *  
 * 2005-06-05
 * Olivier Delannoy
 *
 *
 */
#ifndef YML_CORE_DEVELOPMENTCATALOG_HH
#define YML_CORE_DEVELOPMENTCATALOG_HH 1
#include "core.hh"
#include "DistributeList.hh"
#include <map>
namespace Yml {
namespace Core {
class ParameterList;
class ComponentAbstract;
class ComponentGraph;
class ComponentImpl;
/**
 * \ingroup plugin_interface
 * \brief
 *
 * A catalog store informations concerning component so that
 * the Compiler and the Scheduler can retrieve information
 * concerning registered Component.
 * \todo Add Component browsing facilities to the catalog interface
 */
class DevelopmentCatalog
{
public:
	/** destructor */
	virtual ~DevelopmentCatalog(void);
	/**
	 * Inititialise the Catalog and give him its init string.
	 * The initialisation string format is up to the Catalog
	 * driver in use. Refer to the documentation of the
	 * catalog you are using.
	 */
	virtual void init(const string& initData) = 0;
	/**
	 * Get component IO information from corresponding abstract component
	 */
	const ParameterList* getComponentScheme(const string& name);
	/**
	 * Set the distribution of each parameter
	 */
	void setComponentScheme(const string& name, const DistributeList& distList);
	/**
	 * Register an abstract component
	 * @param component a pointer to a component object.
	 */
	bool registerComponent(const ComponentAbstract* component, bool force = false);
	/**
	 * Register a graph component
	 * @param component a pointer to a component object.
	 */
	bool registerComponent(const ComponentGraph* component, bool force=false);
	/**
	 * Register an implementation component
	 * @param component a pointer to a component object.
	 */
	bool registerComponent(const ComponentImpl* component, bool force = false);

	/**
	 * Get an abstract component by name
	 */
	const ComponentAbstract* getComponentAbstract(const string& name);
	/**
	 * Get a graph component by name
	 */
	const ComponentGraph* getComponentGraph(const string& name);
	/**
	 * Get an implementation component by name
	 */
	const ComponentImpl* getComponentImpl(const string& name);
	/**
	 * Release the component description
	 */
	void release(const ComponentAbstract* component);
	/**
	 * Release the component description
	 */
	void release(const ComponentGraph* component);
	/**
	 * Release the component description
	 */
	void release(const ComponentImpl* component);
        /* get parallel information (# of processes defined in Impl.query */
	int getImplComponentNbNodes(const string& name);


protected:
	/**
	 * Register an abstract component in the catalog
	 */
	virtual bool registerComponentAbstract(const ComponentAbstract* component, bool force) = 0;
	/**
	 * Register a graph component in the catalog
	 */
	virtual bool registerComponentGraph(const ComponentGraph* component, bool force) = 0;

	/**
	 * Register an implementation in the catalog
	 */
	virtual bool registerComponentImpl(const ComponentImpl* component, bool force) = 0;
	/**
	 * Retrieve abstract component
	 */
	virtual const ComponentAbstract* retrieveComponentAbstract(const string& name) = 0;
	/**
	 * Retrieve graph component
	 */
	virtual const ComponentGraph* retrieveComponentGraph(const string& name) = 0;
	/**
	 * Retrieve implementation component
	 */
	virtual const ComponentImpl* retrieveComponentImpl(const string& name) = 0;
	/**
	 * Release the abstract component
	 */
	virtual void releaseComponentAbstract(ComponentAbstract* component) = 0;
	/**
	 * Release the graph component
	 */
	virtual void releaseComponentGraph(ComponentGraph* component) = 0;
	/**
	 * Release the implementation component
	 */
	virtual void releaseComponentImpl(ComponentImpl* component) = 0;

private:
	typedef std::map<string, ParameterList*> Cache;
	Cache mCache;
};
}
}
#ifdef HAVE_INLINE
#include "DevelopmentCatalog.icc"
#endif
#endif

