/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/

/**
 * @file
 * @brief Class Application declaration
 *  
 * 2005-06-07
 * Olivier Delannoy
 */
#ifndef YML_CORE_APPLICATION_HH
#define YML_CORE_APPLICATION_HH 1
#include "core.hh"
#include "ParameterList.hh"
#include "TaskIndex.hh"
#include "SchedulingRule.hh"
#include "SchedulerTask.hh" 
#include "Parameter.hh" 
#include <FixedSizeEntryTable.hh>
//#include <AVLIndex.hh>
#include <Pack.hh>
#ifdef __GNUC__
#include <ext/hash_map>
#else
#include <hash_map> 
#endif
#include <fstream>
#include <list>
#include <vector>
namespace Yml {
namespace Core {

class Task;                     // Forward Declaration 
class PreCondition;             // Forward Declaration
struct hash 
{
    size_t operator()(const string& key) const
    {
        return hasher(key.c_str());
    }
private:
#ifdef __GNUC__
    __gnu_cxx::hash<const char*> hasher;    
#else
    std::hash<const char*> hasher;    
#endif
};

    
        

/**
 * @brief Application management
 *
 * This class interact with the application storage to handle
 * all operation on an application. This class only provide
 * services to create, consult and update application data. 
 */
class Application
{
    /**
     *  Typename for the binary table storing scheduling rules 
     */
    typedef Util::FixedSizeEntryTable<SchedulingRule> RulesTable;
    typedef std::vector<SchedulingRule> RulesTableCache;
    
    /**
     * Typename for Rules index 
     */
#ifdef __GNUC__
    typedef __gnu_cxx::hash_map<string, uint32, hash> RulesIndex;
#else
    typedef std::hash_map<string, uint32, hash> RulesIndex;
#endif
    /** 
     * Typename for the binary table storing task indexes 
     */
    typedef Util::FixedSizeEntryTable<TaskIndex> TasksTable;
    typedef std::vector<TaskIndex> TasksTableCache;
    
    /**
     * Typename for a task queue
     */
    typedef std::list<SchedulerTask*> TasksQueue;
        
public:
    // Pack Entry and working directory layout
    static const string infoVersionFile;      //!< Pack entry name containing the application version (txt) 
    static const string infoNameFile;         //!< Pack entry name containing the name  (txt)
    static const string infoUidFile;          //!< Pack entry name containing the uids  (txt)
    static const string infoDescriptionFile;  //!< Pack entry name containing the description (txt) 
    static const string infoQueryFile;        //!< Pack entry name containing the XML query  (xml)
    static const string infoGraphFile;        //!< Pack entry name containing the Yvette Program of the application (txt) 
    static const string infoParametersFile;   //!< Pack entry name containing the list of parameters (csv)

    static const string dataTasksFile;        //!< Pack entry name containing the list of tasks (txt) 
    static const string dataTasksIndexFile;   //!< Pack entry name containing the index / state of tasks (ft1)
    static const string dataStatusFile;       //!< Pack entry name containing the status of the application (txt)
    static const string dataRulesFile;        //!< Pack entry name containing the rules of scheduling (ft1)

    static const string dataLogFile;          //!< Pack entry name containing the log file (txt)
    static const string dataUidFile;          //!< Pack entry name containing the uid of the execution (txt)
    static const string dataDirectory;        //!< Name of directory containing the application data
    // Application internal format number 
    static const string formatVersion;        //!< Current application format 
    // Application status 
    static const uint32 COMPILING;            //!< Default status
    static const uint32 COMPILED;             //!< Ready for execution 
    static const uint32 EXECUTING;            //!< Application currently running 
    static const uint32 FINISHED;             //!< Application execution finished
    static const uint32 COMP_ERROR;           //!< Invalid application, an error occured during the compilation @deprecated
    static const uint32 ERROR;                //!< The application is in an error state
    
    /**
     * Contstructor
     * 
     * @param appFile full path to the application file 
     * @param workingDir dir used to work with the application if needed  
     */
    Application(const string& appFile, const string& workingDir = "", const string& backendName = "Process");
    
    /**
     * Destructor
     */
    ~Application(void);

    //////////////////////////////////
    // Compilation related interface 
    //////////////////////////////////
    /** 
     * Initialise a new application 
     */
    void initializeCompilation();
    /**
     * Update the current state of the application 
     */
    void finalizeCompilation();
    /** 
     * Set the name of the application 
     */ 
    void setName(const string& name);
    /** 
     * set the XML Query used to create this application 
     */
    void setQuery(const string& xmlQuery);
    /** 
     * Set the application description 
     */
    void setDescription(const string& text);

    /**
     * register a parameter to an application 
     */
    void addParameter(const string& name, const string& type, bool isCollection, ParameterIOMode mode, const string& description);
    /**
     * Register a new task 
     */
    uint32 registerTask(Task* task);  

    ///////////////////////////////
    // Global queriying of the application information    
    ///////////////////////////////
    /**
     * Retrieve the name of the application 
     */
    const string& getName() const;
    /**
     * Retrieve the description of the application 
     */
    const string& getDescription() const;   
    /** 
     * Retrieves parameter information 
     */
    const ParameterList& getParameters() const;
    /**
     * Return the graph of the application 
     */
    const string& getYvetteProgram() const;
     
    // Statistical 
    /** 
     * Get the number of subgraphs 
     */
    uint32 subgraphs(void) const;
    /**
     * Get the number of tasks 
     */
    uint32 tasks(void) const;
    /** 
     * Get the number of events 
     */
    uint32 events(void) const;
    /** 
     * Get the number of exceptions
     */
    uint32 exceptions(void) const;
    /** 
     * Get the current status of the application 
     */
    uint32 status(void) const;

    
    ////////////////////////////////
    // Scheduler interface
    ////////////////////////////////
    /**
     * Extract application data for execution
     */
    void initializeExecution();
    /**
     * Pack results and terminate application execution
     */
    void finalizeExecution();
    
    /** 
     * Import the initial parameters of the application.
     */
    void importParameters(const string& packName);
    /**
     * Export the results of the parameters of the application
     * execution.
     */
    void exportParameters(const string& packName);
    /**
     * Initialize the scheduling of an application
     * 
     */
    void startScheduling();
    /**
     * This function update the rule table if needed 
     */
    void updateSchedulingRules(void);
    /**
     * Return true if the application 
     * execution is finished
     */
    void updateStatus(void);
    /** 
     * Extract the next ready task object 
     */
    SchedulerTask* nextTaskReady(SchedulerTask* last = 0);
    /**
     * Finish a task execution 
     */
    void finishTask(SchedulerTask* task);
    /** 
     * Retrieve rule information 
     */
    void rule(uint32 ruleIndex, SchedulingRule& rule);
    
    /////////////////////////////
    // Application read only interface 
    /////////////////////////////
    /** 
     * Load meta information and parameter list in memory 
     */
    void initializeInfoOnly();

    void backend(const string& name);
    const string& backend(void) const;

private:
    /** 
     * Do the packing of the differents parts composing an application to 
     * a compiled application file 
     */
    void pack();
    /**
     * set an event identified by its index number in the
     * rules table
     */
    void set(uint32 ruleIndex);

    /**
     * Register a new scheduling rule 
     */ 
    uint32 add(SchedulingRule& rule);
    /** 
     * Update rule information 
     */
    void update(uint32 ruleIndex, SchedulingRule& rule);
            
            
    /**
     * Register all Rules into the rule table 
     */
    uint32  addPreCondition(PreCondition* pre);


    // Collection management 
    /**
     * Pack all file of a collection before the execution of a component 
     */
    void packCollection(Util::Pack& pack, const string& dataPrefix);
    /**
     * Remove all file of the collection before extracting the new collection 
     */ 
    void clearCollection(const string& dataPrefix);
    




    /* Store path information */
    string mApplicationFileName;   //!< Store the name of the application file
    string mWorkingDir;            //!< Store the working directory of the application 
    string mDataDir;               //!< Store the data directory of the application 

    /* Store application meta information */
    string mApplicationName;       //!< Store the name of the application 
    string mApplicationDescription;//!< Store the description of the application
    string mApplicationQuery;      //!< Store the XML Query used to create this application
    string mApplicationGraph;      //!< Store the Yvette program of the the application
    string mApplicationFormat;     //!< Store the format used for the application representation 
    string mApplicationUID;        //!< Store the uid of the application 
    string mBackendName;           //!< Store the name of Backend    

    /* Store application statistics */
    uint32 mSubGraphCount;         //!< Store the number of subgraph compiled
    uint32 mComponentCallCount;    //!< Store the number of tasks composing the number of tasks
    uint32 mSignalCount;           //!< Store the number of signal tasks in the application
    uint32 mEventCount;            //!< Store the number of events composing the applications
    uint32 mExceptionCount;        //!< Store the number of exceptions composing the application
    uint32 mConditionCount;        //!< Store the number of condition composing the application
    uint32 mStatus;                //!< Store the status of the application
    uint32 mTaskWaiting;           //!< Store the number of task in status waiting
    uint32 mTaskReady;             //!< Store the number of task in status ready
    uint32 mTaskExecuting;         //!< Store the number of task in status executing
    uint32 mTaskFinished;          //!< Store the number of task in status finished


    /* Application data tables */ 
    ParameterList  mParameters;    //!< Store the parameter list of the application 
    RulesTable*    mRules;         //!< Store all scheduling rules
    RulesIndex     mRulesIndex;    //!< Store an index on the TaskIndex during the compilation process. This field is invalid and ignore at any other stage at the moment     
    RulesTableCache mRulesCache;   //!< Store the list of rules used during the scheduling, this is only available while executing the application.  
    
    std::fstream   mTasks;         //!< Store all tasks description    
    TasksTable*    mTasksIndex;    //!< Store index of tasks as well as the status of the tasks 
    TasksTableCache mTasksCache;   //!< Store the list of tasks index for improving the performance of the scheduling. 
    
    

 
    /* Execution related information */
    string mExecutionUID;          //!< Store the running uid of the application
    bool   mNeedRuleUpdates;       //!< True if it's require to update the rules table     
    bool   mNeedUpdateReadyTasks;  //!< True if we must update the list of ready tasks 
    bool   mStatusChanged;         //!< True if the status of the application should be updated false otherwise
    string mPackIn;                //!< Store tasks input packs prefix 
    string mPackOut;               //!< Store tasks output packs  prefix 
    string mPackAdmin;             //!< Store tasks admin packs prefix 
    string mWorkDir;               //!< Store tasks tmp (working dir) prefix

    /* Execution related queues */ 
    TasksQueue    mReadyTasksQueue;//!< Store tasks ready to be executed tasks
    std::ofstream mExecutionLog;   //!< Store application log stream
    
    friend class Application_xmlHandler;
    

    // Disabled operation
    Application(const Application&);
    Application& operator=(Application&);
};
}
}
#ifdef HAVE_INLINE
#include "YvetteApplication.icc"
#endif
#endif

