/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/

/**
 * @file
 * @brief Class SchedulingRule function definition 
 *
 * 2005-06-05
 * Olivier Delannoy
 */
#include "SchedulingRule.hh"
#ifndef HAVE_INLINE
#define inline
#include "SchedulingRule.icc"
#undef inline
#endif 
#include "YvetteApplication.hh"
#include <MD5.hh>
#include <cassert>
#include <cstring>

namespace Yml
{
namespace Core
{


SchedulingRule::SchedulingRule(void)
    : mFlags(TypeInvalid)
{
    memset((byte*) &mData, 0, sizeof(mData));
}
SchedulingRule::SchedulingRule(SchedulingRule::Type type, const string& name)
{
    assert(type == TypeEvent || type == TypeException);
    mFlags = type;
    Util::MD5 digest;
    digest.init();
    digest.update((byte*)name.c_str(), name.size());
    digest.finalize();
    memcpy((char*) & (mData.name), digest.getDigest(), 16);
}
SchedulingRule::SchedulingRule(SchedulingRule::Type type, uint32 op1, uint32 op2)
{
    assert(type & TypeCondition);
    memset((byte*) &mData, 0, sizeof(mData));
    mFlags = type;
    mData.cond.op1 = op1;
    mData.cond.op2 = op2;
}
SchedulingRule::~SchedulingRule(void)
{
}
void SchedulingRule::reset(void)
{
    if (mFlags & TypeCondition && !(mFlags & FINAL_MASK))
    {
        mFlags &= ERASE_MASK;
    }
}

void SchedulingRule::set(void)
{
    if (! (mFlags & TypeCondition))
    {
        mFlags |= SET_MASK;
        mFlags |= FINAL_MASK;
    }
}
bool SchedulingRule::eval(Application *application)
{
    if (! (mFlags & FINAL_MASK) && (mFlags & TypeCondition))
    {
        SchedulingRule r1;
        SchedulingRule r2;
        mFlags &= ERASE_MASK;
        switch(mFlags & TYPE_MASK)
        {
        case TypeConditionNot:
            application->rule(mData.cond.op1, r1);
            if (! r1.isSet())
                mFlags |= SET_MASK;
            if (r1.isFinal())
                mFlags |= FINAL_MASK;
            break;
        case TypeConditionAnd:
            application->rule(mData.cond.op1, r1);
            application->rule(mData.cond.op2, r2);
            if (r1.isSet() && r2.isSet())
                mFlags |= SET_MASK;
            if (r1.isFinal() && r2.isFinal())
                mFlags |= FINAL_MASK;
            break;
            
        case TypeConditionOr:
            application->rule(mData.cond.op1, r1);
            application->rule(mData.cond.op2, r2);
            if (r1.isSet())
            {
                mFlags |= SET_MASK;
                if (r1.isFinal())
                    mFlags |= FINAL_MASK;
            }
            else if (r2.isSet())
            {
                mFlags |= SET_MASK;
                if (r2.isFinal())
                    mFlags |= FINAL_MASK;
            }
            else if (r1.isFinal() && r2.isFinal())
            {
                mFlags |= FINAL_MASK;
            }
            break;
            
       case TypeConditionXor:
           application->rule(mData.cond.op1, r1);
           application->rule(mData.cond.op2, r2);
           if ((r1.isSet () && ! r2.isSet()) || ( !r1.isSet() && r2.isSet()))
           {
               mFlags |= SET_MASK;
           }
           
           if (r1.isFinal() && r2.isFinal())
           {
               mFlags |= FINAL_MASK;
           }
        default:
            // There is no other kind of rule so it should never append
            assert(0);
        }
    }
    return mFlags & SET_MASK;
}
bool SchedulingRule::operator==(const SchedulingRule& rhs) const
{
    // Meme type 
    uint32 type = mFlags & TYPE_MASK;
    
    if ((type) == (rhs.mFlags & TYPE_MASK))
    {
        switch (type)
        {
        case TypeEvent:
        case TypeException:
            return 0 == memcmp(mData.name, rhs.mData.name, 16);
        default:
            return 
                (mData.cond.op1 == rhs.mData.cond.op1) &&
                (mData.cond.op2 == rhs.mData.cond.op2);
        }
        
    }
    return false;
}

void SchedulingRule::write(Util::LittleEndianStream& out) const
{
    out.write(mFlags);
    if (mFlags & TypeCondition)
    {
        out.write(mData.cond.op1);
        out.write(mData.cond.op2);
        uint32 padding = 0x00000000;
        out.write(padding);
        out.write(padding);
    }
    else 
    {
        for(int i = 0; i < 16 ; ++i)
            out.write(mData.name[i]);
    }
}

void SchedulingRule::read(Util::LittleEndianStream& in)
{
    in.read(mFlags);
    if (mFlags & TypeCondition)
    {
        in.read(mData.cond.op1);
        in.read(mData.cond.op2);
        uint32 padding = 0x00000000;
        in.read(padding);
        in.read(padding);
    }
    else 
    {
        for(int i = 0 ; i < 16 ; ++i)
            in.read(mData.name[i]);
    }
}


string SchedulingRule::createKey() const
{
    if (d_key.empty())
    {
        Util::MD5 digest;
        digest.init();
        digest.update((byte*)&mFlags, sizeof(mFlags));
        digest.update((byte*)&mData, sizeof(mData));
        digest.finalize();
        d_key.assign((const char*)digest.getDigest(), 16);
    }
    return d_key;
}


}

}


