/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/
/**
 * @file
 * @brief Class PluginManager function definition 
 *
 * 2007-01-22
 * Olivier Delannoy
 */
#include "PluginManager.hh"
#include "AccountManager.hh" 
#include "Backend.hh"
#include "DevelopmentCatalog.hh"
#include "ExecutionCatalog.hh" 
#include "SecondLevelScheduler.hh"
#ifndef HAVE_INLINE
#define inline
#include "PluginManager.icc"
#undef inline
#endif 
#ifdef HAVE_CONFIG_H
#include <yml_config.hh>
#endif 
#include <PluginFactory.hh> 
#include <LoggerFactory.hh>
#include <ConfigFactory.hh> 

namespace Yml 
{
namespace Core
{
PluginManager::PluginManager()
    : d_accountManager(0), 
      d_accountManagerPlugin(0), 
      d_createAccountManager(0), 
      d_destroyAccountManager(0), 
      d_backend(0), 
      d_backendPlugin(0), 
      d_createBackend(0), 
      d_destroyBackend(0), 
      d_developmentCatalog(0), 
      d_developmentCatalogPlugin(0), 
      d_createDevelopmentCatalog(0), 
      d_destroyDevelopmentCatalog(0), 
      d_executionCatalog(0), 
      d_executionCatalogPlugin(0), 
      d_createExecutionCatalog(0), 
      d_destroyExecutionCatalog(0), 
      d_secondLevelScheduler(0), 
      d_secondLevelSchedulerPlugin(0), 
      d_createSecondLevelScheduler(0), 
      d_destroySecondLevelScheduler(0)
{
}

PluginManager::~PluginManager()
{
    destroyAccountManager();
    destroyBackend();
    destroyDevelopmentCatalog();
    destroyExecutionCatalog();
    destroySecondLevelScheduler();
}

AccountManager& PluginManager::getAccountManager()
{
    if (! d_accountManager)
        createAccountManager();
    return *d_accountManager;
}

Backend& PluginManager::getBackend()
{
    if (! d_backend)
        createBackend();
    return *d_backend;
}

DevelopmentCatalog& PluginManager::getDevelopmentCatalog()
{
    if (! d_developmentCatalog)
        createDevelopmentCatalog();
    return *d_developmentCatalog;
}

ExecutionCatalog& PluginManager::getExecutionCatalog() 
{
    if (! d_executionCatalog)
        createExecutionCatalog();
    return *d_executionCatalog;
}

SecondLevelScheduler& PluginManager::getSecondLevelScheduler()
{
    if (!d_secondLevelScheduler)
        createSecondLevelScheduler();
    return *d_secondLevelScheduler;
}
void PluginManager::createAccountManager(const string& module, const string& init)
{
    UTIL_DEBUG("default", "Account Manager plugin: Loading");
    UTIL_DEBUG("default", "Account Manager plugin: name '" << module << "'");
    d_accountManagerPlugin = Util::PluginFactory::getSingleton().create(module);
    UTIL_FATAL_ASSERT("default", d_accountManagerPlugin,
                      "Account Manager plugin: unable to load '" << module << "' plugin");
    d_createAccountManager = (AccountManager* (*)())d_accountManagerPlugin->loadSymbol("create");
    d_destroyAccountManager = (void (*)(AccountManager*))d_accountManagerPlugin->loadSymbol("destroy");
    UTIL_FATAL_ASSERT("default", d_createAccountManager && d_destroyAccountManager, 
                      "Account Manager plugin:: malformed plugin ; missing entry point 'create' or 'destroy'");
    d_accountManager = d_createAccountManager();
    UTIL_FATAL_ASSERT("default", d_accountManager, 
                      "Account Manager plugin: instance creation failed");
    d_accountManager->init(init);
    UTIL_DEBUG("default", "Account Manager plugin: loaded successfullly");    
}


void PluginManager::createAccountManager()
{
    Util::Config* yml = Util::ConfigFactory::getSingleton().create("yml");
    string module = yml->get("AccountManager", "module", "XMLAccountManager");
    string init = yml->get("AccountManager", "init", yml->get("path", "data") + "accounts.xml");
    createAccountManager(module, init);
}


void PluginManager::destroyAccountManager()
{
    if (d_accountManager)
        d_destroyAccountManager(d_accountManager);
    d_accountManager = 0;
}

void PluginManager::createBackend(const string& module, const string& init)
{
    UTIL_DEBUG("default", "Backend plugin: loading");
    UTIL_DEBUG("default", "Backend plugin: name '" << module << "'");
    UTIL_INFO("default", "Backend plugin: name '" << module << "'");
    d_backendPlugin = Util::PluginFactory::getSingleton().create(module);
    UTIL_FATAL_ASSERT("default", d_backendPlugin, 
                      "Backend plugin: unable to load '" << module << "' plugin");
    d_createBackend = (Backend*(*)())d_backendPlugin->loadSymbol("create");
    d_destroyBackend = (void(*)(Backend*))d_backendPlugin->loadSymbol("destroy");
    UTIL_FATAL_ASSERT("default", d_createBackend && d_destroyBackend , 
                      "Backend plugin: malformed plugin ; missing entry point 'create' or 'destroy'");
    d_backend = d_createBackend();
    UTIL_FATAL_ASSERT("default", d_backend, 
                      "Backend plugin: instance creation failed");
    d_backend->init(init);
    UTIL_DEBUG("default", "Backend plugin: loaded successfully");    
}

void PluginManager::createBackend()
{
    Util::Config* yml = Util::ConfigFactory::getSingleton().create("yml");
    string name = yml->get("Backend", "module", "ProcessBackend");
    string init = yml->get("Backend", "init", "process");
    createBackend(name, init);
    mBackendName = name;
}

void PluginManager::destroyBackend()
{
    if (d_backend)
        d_destroyBackend(d_backend);
    d_backend = 0;
}

void PluginManager::createDevelopmentCatalog()
{
    Util::Config* yml = Util::ConfigFactory::getSingleton().create("yml");
    string name = yml->get("DevelopmentCatalog", "module", "DefaultDevelopmentCatalog");
    string init = yml->get("DevelopmentCatalog", "init", "");
    createDevelopmentCatalog(name, init);
}
void PluginManager::createDevelopmentCatalog(const string& module, const string& init)
{
    UTIL_DEBUG("default", "Development Catalog plugin: loading");
    UTIL_DEBUG("default", "Development Catalog plugin: name '" << module << "'");
    d_developmentCatalogPlugin = Util::PluginFactory::getSingleton().create(module);
    UTIL_FATAL_ASSERT("default", d_developmentCatalogPlugin, 
                      "Development Catalog plugin: unable to load '" << module << "' plugin");
    d_createDevelopmentCatalog = (DevelopmentCatalog*(*)())d_developmentCatalogPlugin->loadSymbol("create");
    d_destroyDevelopmentCatalog = (void(*)(DevelopmentCatalog*))d_developmentCatalogPlugin->loadSymbol("destroy");
    UTIL_FATAL_ASSERT("default", d_createDevelopmentCatalog && d_destroyDevelopmentCatalog, 
                      "Development Catalog plugin: malformed plugin ; missing entry point 'create' or 'destroy'");
    d_developmentCatalog = d_createDevelopmentCatalog();
    UTIL_FATAL_ASSERT("default", d_developmentCatalog, 
                      "Development Catalog plugin: instance creation failed");
    d_developmentCatalog->init(init);
    UTIL_DEBUG("default", "Development Catalog plugin: loaded successfully");
}

void PluginManager::destroyDevelopmentCatalog()
{
    if (d_developmentCatalog)
        d_destroyDevelopmentCatalog(d_developmentCatalog);
    d_developmentCatalog = 0;
}

void PluginManager::createExecutionCatalog()
{
    Util::Config* yml = Util::ConfigFactory::getSingleton().create("yml");
    string name = yml->get("ExecutionCatalog", "module", "DefaultExecutionCatalog");
    string init = yml->get("ExecutionCatalog", "init", "DefaultExecutionCatalog");
    createExecutionCatalog(name, init);
}
void PluginManager::createExecutionCatalog(const string& module, const string& init)
{
    UTIL_DEBUG("default", "Execution Catalog plugin: name '" << module << "'");
    UTIL_DEBUG("default", "Execution Catalog plugin: initialization '" << init << "'");
    d_executionCatalogPlugin = Util::PluginFactory::getSingleton().create(module);
    UTIL_FATAL_ASSERT("default", d_executionCatalogPlugin, 
                      "Execution Catalog plugin: unable to load '" << module << "' plugin");
    d_createExecutionCatalog = (ExecutionCatalog*(*)())d_executionCatalogPlugin->loadSymbol("create");
    d_destroyExecutionCatalog = (void(*)(ExecutionCatalog*))d_executionCatalogPlugin->loadSymbol("destroy");
    UTIL_FATAL_ASSERT("default", d_createExecutionCatalog && d_destroyExecutionCatalog, 
                      "Execution Catalog plugin: malformed plugin ; missing entry point 'create' or 'destroy'");
    d_executionCatalog = d_createExecutionCatalog();
    UTIL_FATAL_ASSERT("default", d_executionCatalog, 
                      "Execution Catalog plugin: instance creation failed");
    d_executionCatalog->init(init);
    UTIL_DEBUG("default", "Execution Catalog plugin: loaded successfully");
}


void PluginManager::destroyExecutionCatalog()
{
    if (d_executionCatalog)
        d_destroyExecutionCatalog(d_executionCatalog);
    d_executionCatalog = 0;
}

void PluginManager::createSecondLevelScheduler()
{
    Util::Config* yml = Util::ConfigFactory::getSingleton().create("yml");
    string name = yml->get("SecondLevelScheduler", "module", "DefaultScheduler");
    string init = yml->get("SecondLevelScheduler", "init");
    createSecondLevelScheduler(name, init);
}
void PluginManager::createSecondLevelScheduler(const string& module, const string& init)
{
    UTIL_DEBUG("default", "Second Level Scheduler plugin: loading");
    UTIL_DEBUG("default", "Second Level Scheduler plugin: name '" << module << "'");
    d_secondLevelSchedulerPlugin = Util::PluginFactory::getSingleton().create(module);
    UTIL_FATAL_ASSERT("default", d_secondLevelSchedulerPlugin, 
                      "Second Level Scheduler plugin: unable to load '" << module << "' plugin");
    d_createSecondLevelScheduler = (SecondLevelScheduler*(*)())d_secondLevelSchedulerPlugin->loadSymbol("create");
    d_destroySecondLevelScheduler = (void(*)(SecondLevelScheduler*))d_secondLevelSchedulerPlugin->loadSymbol("destroy");
    UTIL_FATAL_ASSERT("default", d_createSecondLevelScheduler && d_destroySecondLevelScheduler, 
                      "Second Level Scheduler plugin: malformed plugin ; missing entry point 'create' or 'destroy'");
    d_secondLevelScheduler = d_createSecondLevelScheduler();
    UTIL_FATAL_ASSERT("default", d_secondLevelScheduler, 
                      "Second Level Scheduler plugin: instance creation failed");
    d_secondLevelScheduler->init(init);
    UTIL_DEBUG("default", "Second Level Scheduler plugin: loaded successfully");    
}

void PluginManager::destroySecondLevelScheduler()
{
    if (d_secondLevelScheduler)
        d_destroySecondLevelScheduler(d_secondLevelScheduler);
    d_secondLevelScheduler = 0;
}
 
const string& PluginManager::backend(void) const
{
    return mBackendName;
}
}
}
