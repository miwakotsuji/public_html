/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/

/**
 * @file
 * @brief Core data declaration
 *  
 * 2005-06-05
 * Olivier Delannoy
 */
#ifndef YML_CORE_CORE_HH
#define YML_CORE_CORE_HH 1
#include <yml_option.hh> 
#include <util_namespace.hh>
namespace Yml {
    namespace Core {
        /** Unsigned integer of 8 bits */
        typedef Util::uint8 uint8;
        /** Signed integer of 8 bits */ 
        typedef Util::int8 int8;    
        /** Unsigned integer of 16 bits */
        typedef Util::uint16 uint16;
        /** Signed integer of 16 bits */
        typedef Util::int16 int16;  
        /** Unsigned integer of 32 bits */
        typedef Util::uint32 uint32; 
        /** Signed integer of 32 bits */
        typedef Util::int32 int32;  
        /** Unsigned integer of 64 bits */ 
        typedef Util::uint64 uint64;
        /** Signed integer of 64 bits */ 
        typedef Util::int64 int64;  
        /** 32 bits Real number */
        typedef Util::real32 real32;
        /** 64 bits Real number */
        typedef Util::real64 real64;
        /** a byte 8 bits long data */
        typedef Util::byte byte;    
        /** a word 16 bits long data */ 
        typedef Util::word word;   
        /** a double word 32 bits long data */  
        typedef Util::dword dword; 
        /** a quad word 64 bits long data */
        typedef Util::qword qword;  
        /** a string of text */
        typedef Util::String string;

        /**
         * Scheduling policies are modifier used within the
         * ParallelScheduling class in order to handle second level
         * scheduling
         */
        enum SchedulingPolicy
        {
            SCHEDULE_COMPUTE, /**< Used for normal task */
            SCHEDULE_MIGRATE, /**< Used for migration and acquisition task */
        };
        /**
         * A component execution can terminate on a success, an error
         * or an exception.
         */
        enum ExecutionStatus
        {
            ExecSuccess   = 0, /**< Used when computation terminate successfully */
            ExecError     = 1, /**< Used when computation terminate with an error */
            ExecException = 2, /**< Used when computation throw an exception */
        };
        /**
         * Store IO mode for parameters 
         */
        enum ParameterIOMode
        {
            PARAM_IO_IN = 1, /**< Used when the parameter is an input */
            PARAM_IO_OUT = 2, /**< Used when the parameter is an output */
            PARAM_IO_INOUT = 3, /**< Used when a parameter is an input and output */
        };
        
        enum ParameterMapping
        {
            PARAM_MAP_BLOCK = 1, /**< Used when the parameter is distributed in a block fashion */
            PARAM_MAP_CYCLIC = 2, /**< Used when the parameter is distributed in a cyclic fashion */

        };

        /**
         * Enumeration of the different component kind 
         */
        enum ComponentType
        {
            COMPONENT_TYPE_ERROR,   /**< Invalid component type */
            COMPONENT_TYPE_ABSTRACT, /**< Abstract component */
            COMPONENT_TYPE_GRAPH,  /**< Graph Component */
            COMPONENT_TYPE_IMPL, /**< Implementation Component */
        };
        /**
         * Enumeration of the different type of message that can
         * occured while compiling an Yvette Program 
         */
        enum CompilerMessageType 
        {
            COMP_MSG_TYPE_INFO, /**< Information message */
            COMP_MSG_TYPE_WARNING, /**< Warning message */
            COMP_MSG_TYPE_ERROR, /**< Error message */
        };
        /** 
         * List all builtin type design within YML 
         */
        enum YvetteObjectType 
        {
            YVETTE_OBJECT_TYPE_INTEGER,    /**< Integers numbers */ 
            YVETTE_OBJECT_TYPE_REAL,       /**< Real numbers */
            YVETTE_OBJECT_TYPE_STRING,     /**< Strings */
            YVETTE_OBJECT_TYPE_EVENT,      /**< Events */
            YVETTE_OBJECT_TYPE_EXCEPTION,  /**< Exceptions */
            YVETTE_OBJECT_TYPE_FUNCTION,   /**< Functions */
        };
        /** 
         * TaskUID are md5 sum computes using Util::MD5 
         * this is a typename 
         */
        typedef byte TaskUID[16];
        /**
         * @brief List all supported query type 
         * 
         * List all supported query 
         */
        enum QueryType
        {
            InvalidQuery, /**< Used when the query contains error */
            UnknownQuery, /**< Used when the type of query type is unknown */
            ApplicationQuery, /**< Used for application query */
            AccountQuery, /**< Used for account query */
            ComponentQuery, /** Used for component query */
            ExecuteQuery, /** Used for application execution start query */
        }; 
#ifdef MAINTAINER_MODE
# define YML_DEBUG(x) std::cerr << x << std::endl;
#else
# define YML_DEBUG(x) 
#endif 
    }
}
#endif

