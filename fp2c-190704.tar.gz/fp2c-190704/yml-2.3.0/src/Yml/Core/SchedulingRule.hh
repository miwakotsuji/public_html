/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/

/**
 * @file
 * @brief Class SchedulingRule declaration
 *  
 * 2005-06-05
 * Olivier Delannoy
 */
#ifndef YML_CORE_SCHEDULINGRULE_HH
#define YML_CORE_SCHEDULINGRULE_HH 1
#include "core.hh"
#include <LittleEndianStream.hh>
namespace Yml {
    namespace Core {
        class Application;
        /**
         * @brief A scheduling rule is used to manage dependencies. 
         * 
         * There is three family of rules in YML. The first rule class
         * corresponds to the event as they appears in the language.
         * The second rule class corresponds to the exception both are
         * handled exactly the same in YML. And finally the last class
         * of rules corresponds to conditions. A condition is composed
         * of a combinaison of rules and an operator. Currently
         * available operators are : 
         * - and (binary)
         * - or  (binary)
         * - xor (binary)
         * - not (unary)
         */
        class SchedulingRule
        {
        public:
            /** 
             * List all existing Scheduling rule type 
             */ 
            enum Type 
            {
                TypeEvent        = 0x01000000, /**< Event type */
                TypeException    = 0x02000000, /**< Exception type */
                TypeCondition    = 0x04000000, /**< Condition type */
                TypeConditionNot = 0x24000000, /**< Not condition type */
                TypeConditionAnd = 0x44000000, /**< And condition type */
                TypeConditionOr  = 0x84000000, /**< Or condition type */
                TypeConditionXor = 0xf4000000, /**< Xor condition type */                 
                TypeInvalid      = 0xff000000, /**< Invalid rule type */
            };
            /**
             * Default Contstructor
             */
            SchedulingRule(void);
            /**
             * Create an event or a exception 
             */
            SchedulingRule(Type op, const string& name);
            /**
             * Create a condition depending on op1Index and op2Index 
             */
            SchedulingRule(Type op, uint32 op1Index, uint32 op2Index = 0);
            /**
             * Destructor
             */
            ~SchedulingRule(void);
            /**
             * Retrieve the type of the rule 
             */
            Type getType(void) const;
            /**
             * Get the left operand index 
             */
            uint32 operand1(void)   const;
            /** 
             * Get the right operand index 
             */
            uint32 operand2(void)   const;
            /**
             * eval the current scheduling rule and update her status
             * @return true if the rule change her state 
             */
            bool eval(Application* application);
            /** 
             * Set the rule only if it's possible (event and exception accept such request) 
             */
            void set(void);
            /** 
             * Do an intelligent reset operation 
             */
            void reset(void);
            /**
             * Test whether the rule is set or not 
             */
            bool isSet(void) const;
            /** 
             * Test wether the rule is final or not 
             */
            bool isFinal(void) const;
            /**
             * Equality operator 
             */ 
            bool operator==(const SchedulingRule& rhs) const;
            /**
             * Write the scheduling rule to a binary stream 
             */
            void write(Util::LittleEndianStream& out) const;
            /**
             * Read the scheduling rule from a binary stream 
             */
            void read(Util::LittleEndianStream& in);

            /** Store the binary size of such an object */
            static const uint32 SIZE = 20;
        
            /** Create the key used to match exactly one rule in the index */ 
            string createKey() const;
            
        private:
            /** Mask for extraction type information only */
            const static uint32 TYPE_MASK  = 0xff000000;
            /** Mask to check whether the rule is set or not */
            const static uint32 SET_MASK   = 0x00010000;
            /** Mask to check wether the rule is final or not */
            const static uint32 FINAL_MASK = 0x00020000;
            /** Mask to erase the state of the rule */ 
            const static uint32 ERASE_MASK = 0xff00ffff;
            /** Store flags */  
            uint32 mFlags;            
            /** Store data */
            union 
            {
                /** Store all information concerning conditions */ 
                struct 
                {
                    uint32 op1; /**< In the case of a condition, the first operand */
                    uint32 op2; /**< In the case of a condition, the second operand */ 
                } cond;
                /** Store id of the event or the exception */ 
                byte name[16];    
            } mData;

            mutable string d_key;       //!< Store the unique key associated to the object. (cached)
            
        };
    }
}
#ifdef HAVE_INLINE
#include "SchedulingRule.icc"
#endif
#endif

