/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/

/**
 * @file
 * @brief Class ComponentImpl function definition 
 *
 * 2005-06-13
 * Olivier Delannoy
 */
#include "ComponentImpl.hh"
#ifndef HAVE_INLINE
#define inline
#include "ComponentImpl.icc"
#undef inline
#endif 
#ifdef HAVE_CONFIG_H
#include <yml_config.hh>
#endif 
#include <sstream>
#include <string>
#include <cstdlib>
namespace Yml
{
namespace Core
{
ComponentImpl::ComponentImpl():mImplNbNodes(0)
{

}
void ComponentImpl::toXML(Util::XMLSerializer& xmlStream) const
{
    xmlStream.openTag("component")
        .attribute("type", "impl")
        .attribute("name", mName)
        .attribute("abstract", mAbstractName)
        .attribute("description", mDescription)
        .openTag("impl")
        .attribute("lang", mImplLang)
        .attribute("libs", mImplLibs)
        .attribute("nodes", mImplNodeType + ":(" + mImplNodesTopology + ")");
        mDistribute.toXML(xmlStream);
        xmlStream.openTag("header")
        .text(mImplHeader)
        .closeTag()
        .openTag("source")
        .text(mImplSource)
        .closeTag()
        .openTag("footer")
        .text(mImplFooter)
        .closeTag()
        .closeTag() // impl
        .closeTag(); // component
}
void ComponentImpl::setImplNodes(const string& nodes)
{
	if(nodes.empty()==false)
	{
		std::istringstream nodeStream(nodes);
		std::string node;

		std::getline(nodeStream,node,':');
		mImplNodeType = node;
		std::getline(nodeStream,node,':');
		mImplNodesTopology = node;

		mImplNodesTopology.erase(mImplNodesTopology.begin(),mImplNodesTopology.begin()+1);
		mImplNodesTopology.erase(mImplNodesTopology.end()-1,mImplNodesTopology.end());
		std::istringstream nbNodeStream(mImplNodesTopology);

                if(strcmp("CPU:(1,1)",nodes.c_str())==0){
                   mImplNbNodes=1;
                }else if(strcmp("CPU:(1)",nodes.c_str())==0){
                   mImplNbNodes=1;
                }else{
		while(std::getline(nbNodeStream,node,','))
		{
			if(strtol(node.c_str(),0,0)==1 || mImplNbNodes==1)
			{
                            mImplNbNodes *= strtol(node.c_str(),0,0);
			}else if(mImplNbNodes == 0){
                            mImplNbNodes = strtol(node.c_str(),0,0);
			}else{
                            mImplNbNodes *= strtol(node.c_str(),0,0);
                       }
		}
                }
	}

}

}
}


