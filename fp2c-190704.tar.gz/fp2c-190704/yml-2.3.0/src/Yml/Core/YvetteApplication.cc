/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/
/**
 * @file
 * @brief Class Application function definition 
 *
 * 2005-07-25
 * Olivier Delannoy
 */ 
#include "YvetteApplication.hh"
#ifdef HAVE_CONFIG_H 
# include "yml_config.hh"
#endif
#ifndef HAVE_INLINE
#define inline
#include "YvetteApplication.icc"
#undef inline
#endif 
#include "Task.hh"
#include "PreCondition.hh"
#include "TaskComputation.hh"
#include "PluginManager.hh" 
#include "DevelopmentCatalog.hh" 
#include "BuiltinManager.hh"

#include <UID.hh>
#include <LoggerFactory.hh>
#include <ConfigFactory.hh> 
#include <RuntimeEnvironment.hh> 

#include <MD5.hh>
#include <Pack.hh> 
#include <CSVSerializer.hh>
#include <CSVParser.hh>
#include <FileInfo.hh> 
#include <Dir.hh>
#include <File.hh>
#include <iomanip>
#include <algorithm> // Find 

#include <sstream>
#include <string>
#include <iostream>

namespace Yml
{    
namespace Core 
{

/**
 * @brief Pack the content of a folder 
 *
 * This is a DirHandler instance which add all file in a directory to a pack 
 *
 * @note It does not handle a full directory tree, only one level 
 * @internal 
 */
class Pack_dirHandler : public Util::DirHandler
{
public:
    /** 
     * @brief 
     * Constructor 
     * 
     * Constructor 
     * @param pack an opened pack ready for adding file intoit
     */
    Pack_dirHandler(Util::Pack& pack) 
        : mPack(pack)
    {
    }
    
    void onFile(const string& parentPath, const string& entryName)
    {
        mPack.add(entryName, parentPath + entryName);
    }
private:
    Util::Pack& mPack; //!< Store a reference to a pack object 
};

/*! 
  \brief Pack the results of an application execution. 
  
  This is a DirHandler instance which add all resulting parameter in the data directory to a pack
  
  \note It does not have to browse the full tree 
  \internal 
*/
class Output_dirHandler : public Util::DirHandler
{
public:
    Output_dirHandler(Util::Pack& pack, const ParameterList& parameters)
        : mPack(pack), mParameters(parameters)
    {
    }
    
    void onFile(const string& parentPath, const string& entryName)
    {
        
        const size_t count = mParameters.count();
        for(size_t i = 0 ; i < count ; ++i)
        {
            const Parameter& ref = mParameters.get(i);
            if (ref.getIOMode() & PARAM_IO_OUT)
            {
                if (ref.isCollection())
                {
                    string prefix = ref.getName() + "@@"; // Collection prefix 
                    if (prefix == entryName.substr(0, prefix.size()))
                        mPack.add(entryName, parentPath + entryName);
                }
                else 
                {
                    if (ref.getName() == entryName)
                        mPack.add(entryName, parentPath + entryName);
                }
            }
        }
    }
private:
    Util::Pack& mPack;
    const ParameterList& mParameters;
};

    

Application::Application(const string& appFile, const string& workingDir, const string& backendName)
    : mApplicationFileName(appFile), 
      mWorkingDir(workingDir), 
      mBackendName(backendName),
      mDataDir(),
      mSubGraphCount(0),
      mComponentCallCount(0), 
      mSignalCount(0),
      mEventCount(0), 
      mExceptionCount(0), 
      mConditionCount(0),
      mStatus(0),
      mTaskWaiting(0), 
      mTaskReady(0), 
      mTaskExecuting(0), 
      mTaskFinished(0),
      mRules(0),
      mRulesIndex(1000000),
      mTasksIndex(0)

{
    if (mWorkingDir[mWorkingDir.size() -1] != Util::RuntimeEnvironment::PATH_SEPARATOR)
        mWorkingDir += Util::RuntimeEnvironment::PATH_SEPARATOR;
    mDataDir = mWorkingDir + dataDirectory;
    if (mDataDir[mDataDir.size() - 1] != Util::RuntimeEnvironment::PATH_SEPARATOR)
        mDataDir += Util::RuntimeEnvironment::PATH_SEPARATOR;
}

Application::~Application(void)    
{
    delete mRules;
    delete mTasksIndex;
    mTasks.close();
}



// Prepare the application for a new compilation 
void Application::initializeCompilation()
{
    mApplicationFormat = formatVersion;
    mApplicationUID = Util::UID::createUID();
    // Create various tables used during the creation of the application 
    mRules = new RulesTable(mWorkingDir + dataRulesFile);
    UTIL_FATAL_ASSERT("default", mRules->open(), "Unable to open rule table");
    mTasks.open((mWorkingDir + dataTasksFile).c_str(), std::ios_base::out | std::ios_base::trunc);
    mTasksIndex = new TasksTable(mWorkingDir + dataTasksIndexFile);
    UTIL_FATAL_ASSERT("default", mTasksIndex->open(), "Unable to open rule table");
    // Create default events and register them 
    SchedulingRule evtStart(SchedulingRule::TypeEvent, "##start");
    SchedulingRule evtStop (SchedulingRule::TypeEvent, "##stop");
    SchedulingRule evtError(SchedulingRule::TypeEvent, "##error");
    SchedulingRule evtException(SchedulingRule::TypeException, "##exception");
    mRulesIndex["##start"] = add(evtStart);
    mRulesIndex["##stop"] = add(evtStop);
    mRulesIndex["##error"] = add(evtError);
    mRulesIndex["##exception"] = add(evtException);
}

void Application::setName(const string& name)
{
    mApplicationName = name;
}

void Application::setQuery(const string& xmlQuery)
{
    mApplicationQuery = xmlQuery;
}

void Application::setDescription(const string& description)
{
    mApplicationDescription = description;
}

void Application::addParameter(const string& name, const string& type, bool isCollection, ParameterIOMode mode, const string& description)
{
    Parameter p;
    p.setName(name);
    p.setType(type);
    p.setDescription(description);
    p.setIsCollection(isCollection);
    p.setIOMode(mode);
    mParameters.add(p);
}

void Application::pack()
{
    Util::File::remove(mApplicationFileName);
    Util::Pack pack(mApplicationFileName);
    // Create meta data before packing
    pack.add(infoVersionFile,     (byte*)mApplicationFormat.c_str(),      mApplicationFormat.size());
    pack.add(infoNameFile,        (byte*)mApplicationName.c_str(),        mApplicationName.size());
    pack.add(infoUidFile,         (byte*)mApplicationUID.c_str(),         mApplicationUID.size());
    pack.add(infoDescriptionFile, (byte*)mApplicationDescription.c_str(), mApplicationDescription.size());
    pack.add(infoQueryFile,       (byte*)mApplicationQuery.c_str(),       mApplicationQuery.size());
    pack.add(infoGraphFile,       (byte*)mApplicationGraph.c_str(),       mApplicationGraph.size());

    // Export parameters data 
    std::ostringstream params;
    Util::CSVSerializer csv(params);
    mParameters.toCSV(csv);
    csv.newRow();
    pack.add(infoParametersFile, (byte*)params.str().c_str(), params.str().size());

    // Pack the rest of the files
    Pack_dirHandler handler(pack);
    Util::Dir::visit(handler, mWorkingDir, false);
    pack.close();
}

uint32 Application::registerTask(Task* task)
{   
    TaskIndex ti;
    Util::UID::createUID(ti.uid());
    ti.ruleIndex(addPreCondition(task->preCondition()));
    mTasks << "***" << 1 + mComponentCallCount + mSignalCount << "***" << std::endl;
    ti.offset(mTasks.tellp());
    uint32 index = mTasksIndex->insertEntry(ti);
    string uid  = Util::MD5::MD5ToString(ti.uid());
    string computeDesc;

    int taskType = 1;
    TaskComputation* comp = task->getComputation();
    const ParameterList* scheme = 0;
    
    if (comp)
    {
        taskType = 2;
        // Detect wether the component exist or not if not it's a builtin :p 
        ++mComponentCallCount;
    
        scheme = PluginManager::getSingleton().getDevelopmentCatalog()
            .getComponentScheme(comp->componentName());
        if (scheme)
        {
            std::ostringstream compute;
            compute << comp->schedulingPolicy() << std::endl;
            compute << comp->componentName() << std::endl;
            compute << comp->parameters() << std::endl;
            if (scheme->count() != comp->parameters())
            {
                UTIL_ERROR("default", "Component " << comp->componentName() << " parameter count mismatch");
                mStatus = COMP_ERROR;
                finalizeCompilation();
                throw Util::Exception("Compilation aborted: Component " + comp->componentName() + " parameter mismatch");
            }
            for (uint32 i = 0 ; i < comp->parameters() ; ++i)
            {
                if (scheme->get(i).isCollection())
                {
                    if (comp->parameter(i).substr(0, 3) == "F[]")
                    {
                        compute << scheme->get(i).getIOMode() << " G[]"  <<  comp->parameter(i).substr(3) << std::endl;
                    }
                    else 
                    {
                        UTIL_ERROR("default", "Parameter " << i + 1 << ": " << comp->parameter(i));
                        UTIL_ERROR("default", "Component " << comp->componentName() << " expect a collection as its " << i + 1 << " parameter.");
                        mStatus = COMP_ERROR;
                        finalizeCompilation();
                        throw Util::Exception("Compilation aborted: Component parameter mismatch");
                    }
                }
                else 
                {
                    compute << scheme->get(i).getIOMode() << ' ' << comp->parameter(i) << std::endl;
                }
            } // for (comp->parameters)
            // Add information for parallel tasks 
            int nprocs = PluginManager::getSingleton().getDevelopmentCatalog().getImplComponentNbNodes(comp->componentName());
            compute << nprocs << std::endl;
            computeDesc = compute.str();
        }
        else 
        {
            // find out a builtin else cry 
            if (BuiltinManager::getSingleton().find(comp))
            {
                taskType = 3;
                // Create the computation description here !!! 
                std::ostringstream compute;
                compute << comp->schedulingPolicy() << std::endl;
                compute << comp->componentName() << std::endl;
                compute << comp->parameters() << std::endl;
                for (uint32 i = 0 ; i < comp->parameters() ; ++i)
                    compute << comp->parameter(i) << std::endl;
                computeDesc = compute.str();
            }
            else 
            {
                // We are in big trouble man 
                UTIL_ERROR("default", "Component " << comp->componentName() << " does not exists");
                mStatus = COMP_ERROR;
                finalizeCompilation();
                throw Util::Exception("Compilation aborted: Component " + comp->componentName() + " does not exists");
            }
        }
    }
    else 
    {
        ++mSignalCount;
    }
    
    // Output the task to the task file
    //mTasks.seekp(0, std::ios_base::end); // Position at end of file (Is it really needed ?)
    mTasks << taskType << std::endl;
    //Handle post events 
    mTasks << task->postEvents();
    for(uint32 i = 0 ; i < task->postEvents() ; ++i)
    {
        const string& tmp = task->postEvent(i);
        RulesIndex::iterator iter = mRulesIndex.find(tmp);
        if (iter != mRulesIndex.end())
        {
            mTasks << ' ' << iter->second;
        }
        else 
        {
            SchedulingRule rule(SchedulingRule::TypeEvent, tmp);
            uint32 rindex = add(rule);
            ++mEventCount;
            mRulesIndex[tmp] = rindex;
            mTasks << ' ' << rindex;
            
        }
    }
    mTasks << std::endl;
    mTasks << computeDesc << std::endl;
    delete task;
    return index;
}

uint32 Application::addPreCondition(PreCondition* pre)
{
    UTIL_FATAL_ASSERT("default", pre, "This pointer must point to a valid PreCondition object");
    uint32 res = 0;    
    switch(pre->op())
    {
    case PreCondition::OP_EVENT: 
    {
        // Findthe corresponding event 
        //Create the object corresponding to the event 
        RulesIndex::iterator iter = mRulesIndex.find(pre->event());
        if (iter == mRulesIndex.end())
        {
            SchedulingRule rule(SchedulingRule::TypeEvent, pre->event());
            mRulesIndex[pre->event()] = res = add(rule);
            ++mEventCount;
        }
        else 
        {
            res = iter->second;
        }
        
    }
    break;
    case PreCondition::OP_EXCEPTION:
    {   
        RulesIndex::iterator iter = mRulesIndex.find(pre->event());
        if (iter == mRulesIndex.end())
        {
            SchedulingRule rule(SchedulingRule::TypeException, pre->event());
            mRulesIndex[pre->event()] = res = add(rule);
            ++mExceptionCount;
        }
        else 
        {
            res = iter->second;
        }
    }
    break;
    case PreCondition::OP_AND:
    {
        uint32 left = addPreCondition(pre->opLeft());
        uint32 right = addPreCondition(pre->opRight());
        SchedulingRule rule(SchedulingRule::TypeConditionAnd, left, right);
        res = add(rule);
        ++mConditionCount;
    }
    break;
    case PreCondition::OP_OR:
    {
        uint32 left = addPreCondition(pre->opLeft());
        uint32 right = addPreCondition(pre->opRight());
        SchedulingRule rule(SchedulingRule::TypeConditionOr, left, right);
        res = add(rule);
        ++mConditionCount;
    }
    break;
    case PreCondition::OP_XOR:
    {
        uint32 left = addPreCondition(pre->opLeft());
        uint32 right = addPreCondition(pre->opRight());
        SchedulingRule rule(SchedulingRule::TypeConditionXor, left, right);
        res = add(rule);
        ++mConditionCount;
    }
    break;
    case PreCondition::OP_NOT:
    {    
        uint32 left = addPreCondition(pre->opRight());
        SchedulingRule rule(SchedulingRule::TypeConditionNot, left);
        res = add(rule);
        ++mConditionCount;
    }
    break;
    }
    return res;
}


void Application::finalizeCompilation(void)
{
    mTaskWaiting = mComponentCallCount + mSignalCount;
    if (mStatus == COMPILING)
        mStatus = COMPILED;
    std::ofstream status((mWorkingDir + dataStatusFile).c_str());
    status << mStatus << std::endl
           << mSubGraphCount << std::endl
           << mComponentCallCount << std::endl
           << mSignalCount << std::endl
           << mEventCount << std::endl
           << mExceptionCount << std::endl
           << mConditionCount << std::endl;
    status << std::endl 
           << mTaskWaiting << std::endl
           << mTaskReady << std::endl
           << mTaskExecuting << std::endl
           << mTaskFinished << std::endl;
    status.close();
    // Create version file 
    std::ostringstream query;
    {
        Util::XMLSerializer xml(query);
        xml.openTag("application")
            .attribute("name", mApplicationName)
            .openTag("description")
            .text(mApplicationDescription)
            .closeTag();
        mParameters.toXML(xml);
        xml.openTag("graph")
            .text(mApplicationGraph)
            .closeTag();
        xml.closeTag();
    }
    mApplicationQuery = query.str();
	UTIL_INFO("default", "Summary");
	UTIL_INFO("default", "  Number of component call: " << mComponentCallCount);
	UTIL_INFO("default", "  Number of event notification: " << mSignalCount);
	UTIL_INFO("default", "  Number of event: " << mEventCount);
	UTIL_INFO("default", "  Number of task: " << mTaskWaiting);
	pack();
}


void Application::initializeExecution() 
{

    bool mkdir_status = Util::Dir::mkdir(mWorkingDir);
    
    UTIL_FATAL_ASSERT("default", mkdir_status, "Working dir creation failed");
    mkdir_status = Util::Dir::mkdir(mDataDir);
    UTIL_FATAL_ASSERT("default", mkdir_status, "Data dir creation failed");

    initializeInfoOnly();
    Util::Pack appPack(mApplicationFileName);
    appPack.extractAll(mWorkingDir);
    
    // Create UID for this particular execution 
    mExecutionUID = Util::UID::createUID();
    std::ofstream uidStream;
    uidStream.open((mWorkingDir + dataUidFile).c_str());
    uidStream << mExecutionUID;
    uidStream.close();
    // Report part of the status right now
    UTIL_INFO("default", "Application execution UID: " << mExecutionUID);
    UTIL_INFO("default", "Application data path: " << mDataDir);
    
    // Defines pack prefix 
    Util::Config* config = Util::ConfigFactory::getSingleton().create("yml");
    mPackIn = config->get("path", "packin");
    if (mPackIn[mPackIn.size() -1] != Util::RuntimeEnvironment::PATH_SEPARATOR)
        mPackIn += Util::RuntimeEnvironment::PATH_SEPARATOR;
    Util::Dir::mkdir(mPackIn);
    mPackOut = config->get("path", "packout");
    if (mPackOut[mPackOut.size() -1] != Util::RuntimeEnvironment::PATH_SEPARATOR)
        mPackOut += Util::RuntimeEnvironment::PATH_SEPARATOR;
    Util::Dir::mkdir(mPackOut);
    mPackAdmin = mPackOut;
    mWorkDir = config->get("path", "workdir");
    if (mWorkDir[mWorkDir.size() -1] != Util::RuntimeEnvironment::PATH_SEPARATOR)
    	mWorkDir += Util::RuntimeEnvironment::PATH_SEPARATOR;
    Util::Dir::mkdir(mWorkDir);


    mExecutionLog.open((mWorkingDir + dataLogFile).c_str());
    mRules = new RulesTable(mWorkingDir + dataRulesFile);
    UTIL_FATAL_ASSERT("default", mRules->open(), "Unable to open rules");
    mTasks.open((mWorkingDir + dataTasksFile).c_str(), std::ios_base::in);
    mTasksIndex = new TasksTable(mWorkingDir + dataTasksIndexFile);
    UTIL_FATAL_ASSERT("default", mTasksIndex->open(), "Unable to open tasks index");
    UTIL_DEBUG("default", "Caching data for scheduling rules"); 
    // Create an in memory cache for the scheduling rules
    mRulesCache.resize(mRules->lastIndex() + 1);
    SchedulingRule tmpRule;
    for (uint32 i = 1 ; i <= mRules->lastIndex() ; ++i)
    {
        mRules->getEntry(i, tmpRule);
        memcpy((void*)&(mRulesCache[i]), (void*)&tmpRule, sizeof(tmpRule));
    }
    UTIL_DEBUG("default", "Caching data for tasks");
    // Create an in memory cache for the list of tasks index 
    mTasksCache.resize(mTasksIndex->lastIndex() + 1);
    TaskIndex tmpIndex;
    for (uint32 i = 1 ; i <=  mTasksIndex->lastIndex()  ; ++i)
    {
        mTasksIndex->getEntry(i, tmpIndex);
        memcpy((void*)(&mTasksCache[i]), (void*)&tmpIndex, sizeof(tmpIndex));
    }
    UTIL_INFO("default", "Initialization finished");
}

void Application::finalizeExecution()
{
    
}


void Application::importParameters(const string& packName)
{
    Util::Pack inputPack(packName);
    inputPack.extractAll(mDataDir);
}

void Application::exportParameters(const string& packName)
{
    // list all output parameters and add them to the pack 
    // if the parameter is a collection use the appropriate function call 
    // The correct namming of the file is done during the extraction
	Util::File::remove(packName);
	Util::Pack outputPack (packName);
	Output_dirHandler handler(outputPack, mParameters);
    Util::Dir::visit(handler, mDataDir, false);
    outputPack.close();
}


void Application::startScheduling()
{
    // Cache rule information and task information in memory. 
    
    // Add info to the log 
    set(1); // Generate ##start event
    mNeedRuleUpdates = true;
    mNeedUpdateReadyTasks = true;
    mStatusChanged = true;
    mStatus = EXECUTING;    
}


void Application::updateStatus(void)
{
    if (mStatusChanged)
    {
        mStatusChanged = false;
        if (mRulesCache[4].isSet())
        {
            mStatus = FINISHED;
            return;
        }
        if (mRulesCache[3].isSet())
        {
            mStatus = ERROR;
            return;
        }
        if (mRulesCache[2].isSet())
        {
            mStatus = ERROR;
            return;    
        }
        if (mTaskWaiting + mTaskReady == 0 && mTaskExecuting == 0)
            mStatus = FINISHED;
    
        std::ofstream status((mWorkingDir + dataStatusFile).c_str());
        status << mStatus << std::endl
               << mSubGraphCount << std::endl
               << mComponentCallCount << std::endl
               << mSignalCount << std::endl
               << mEventCount << std::endl
               << mExceptionCount << std::endl
               << mConditionCount << std::endl;
        status << std::endl 
               << mTaskWaiting << std::endl
               << mTaskReady << std::endl
               << mTaskExecuting << std::endl
               << mTaskFinished << std::endl;
        status.close();
    }
}

void Application::set(uint32 ruleIndex)
{
    // It only works if the rule corresponds to 
    // an event and an exception 
    mNeedRuleUpdates = true;
    mStatusChanged = true;
   if ((mRulesCache[ruleIndex].getType() == SchedulingRule::TypeEvent) || 
        (mRulesCache[ruleIndex].getType() == SchedulingRule::TypeException))
    {
        if (! mRulesCache[ruleIndex].isSet())
        {
          mRulesCache[ruleIndex].set();
          update(ruleIndex, mRulesCache[ruleIndex]);
        }
    }
    else 
    {
        UTIL_ERROR("default", "Try to set a condition (" << ruleIndex << ")");
    }
}

void Application::updateSchedulingRules(void)
{
    if (mNeedRuleUpdates)
    {
        UTIL_DEBUG("default", "start updating scheduling rules");
        mNeedUpdateReadyTasks = true;     
        //Clean all not finalize condition 
        RulesTableCache::iterator iter = mRulesCache.begin() + 1;
        for( ; iter != mRulesCache.end() ; ++iter)
        {
            if (! iter->isFinal() && iter->isSet())
            {
                iter->reset();
            }
        }
        // While some updates occurs 
        while(mNeedRuleUpdates)
        {
            mNeedRuleUpdates = false;
            iter = mRulesCache.begin() + 1;
            for( ; iter != mRulesCache.end() ; ++iter)
            {
                // Only condition 
                if (! iter->isFinal() && ! iter->isSet())
                {   
                    // If condition change 
                   // to set then update the table 
                    if (iter->eval(this))
                    {
                        UTIL_DEBUG("default", "Rule change");
                        mNeedRuleUpdates = true;
                        mStatusChanged = true;
                    }
                }
            }
        }
    }
}

// Extract Task Information 
SchedulerTask* Application::nextTaskReady(SchedulerTask* last)
{
    int maxlen = 256;
    SchedulerTask* res = 0;
    if (mNeedUpdateReadyTasks)
    {
        mNeedUpdateReadyTasks = false;
        TasksTableCache::iterator iter = mTasksCache.begin() + 1;
        for(; iter != mTasksCache.end() ; ++iter)
        {
            if (iter->flags() == TaskIndex::WAITING)
            {
                if (mRulesCache[iter->ruleIndex()].isSet())
                {
                    iter->flags(TaskIndex::READY);
                    mTasksIndex->updateEntry(iter - mTasksCache.begin(), *iter);
                    --mTaskWaiting;
                    ++mTaskReady;
                    mStatusChanged = true;                

                }
            }
        }
    }

    TasksTableCache::iterator iter = mTasksCache.begin() + 1;
    if (last)
        iter += last->index();
    for ( ; iter != mTasksCache.end() ; ++iter)
    {
        if (iter->flags() == TaskIndex::READY)
        {
            mExecutionLog << "Task " << iter - mTasksCache.begin() 
                          << ": Ready" << std::endl;
            iter->flags(TaskIndex::EXECUTING);
            mTasksIndex->updateEntry(iter - mTasksCache.begin(), *iter);
            --mTaskReady;
            ++mTaskExecuting;
            mStatusChanged = true;

            res = new SchedulerTask(iter - mTasksCache.begin());
            mReadyTasksQueue.push_back(res);
            UTIL_INFO("default", "Task: " 
                      << iter - mTasksCache.begin() 
                      << ": ready");
            std::ostringstream tuid;
            tuid << mExecutionUID << "_" 
                 << iter - mTasksCache.begin();
            res->uid(tuid.str());
            res->setPackNames(mPackIn, mPackOut, mWorkDir);
            // Fill res with correct values
            mTasks.seekg(iter->offset());

            uint32 type = 0;
            mTasks >> type; // 1 Signal // 2 call // 3 builtin 
            uint32 count = 0;
            mTasks >> count;
            for(uint32 i = 0 ; i < count ; ++i)
            {
                uint32 evt = 0;
                mTasks >> evt;
                res->addEvent(evt);
            }
            if (type == 3)
            {
                // handle builtin here 
                
                uint32 policy = 0;
                mTasks >> policy;
                res->policy((SchedulingPolicy)policy); // It is ignored for builtins 
                string builtin;
                mTasks >> builtin;
                res->builtin(builtin);
                uint32 pcount = 0;
                mTasks >> pcount;
                string type;
                string value;
                for(uint32 i = 0 ; i < pcount ; ++i)
                {
                    mTasks >> type;
                    std::getline(mTasks, value);
                    size_t pos = value.find_first_not_of(' ');
                    value = value.substr(pos);
                    res->addParameter(value);
                }
                // Execute the command right now it does not help to wait :p
                BuiltinManager::getSingleton().exec(res, mDataDir);
            }
            else if (type == 2)
            {
                // Component call
                uint32 policy;
                mTasks >> policy;
                res->policy((SchedulingPolicy)policy);
                string component(maxlen,'\0');
                mTasks >> component;
                res->component(component);
                // Parameter
                mTasks >> count;
                // Create the corresponding pack here
                Util::Pack pack(res->packInput());
                for(uint32 i = 0 ; i < count ; ++i)
                {
                    uint32 io = 0;
                    string type(32,'0');
                    string value(256,'0');
                    string fullpath(256,'0');
                    mTasks >> io;
                    mTasks >> type;
                    if (type[0] == 'F')
                    {
                        if(mBackendName=="MpiBackend" || mBackendName=="MpiOmrpcBackend"){ // Do not use pack 
                          mTasks >> value;
                          res->addParameter(value);
                          switch(io)
                          {
                          case PARAM_IO_IN:
                            { // Send fullpath of a file instead of the file itself
                              fullpath = mDataDir + value;
                              byte* buffer = new byte[fullpath.size()+1];
                              memset(buffer,0,fullpath.size()+1);
                              memcpy((char*)buffer, fullpath.c_str(), fullpath.size());
                              pack.add(value, buffer, fullpath.size());
                              break;
                            }
                          case PARAM_IO_OUT:
                              break;

                          case PARAM_IO_INOUT:
                              fullpath = mDataDir + value;
                              byte* buffer = new byte[fullpath.size()+1];
                              memset(buffer,0,fullpath.size()+1);
                              memcpy((char*)buffer, fullpath.c_str(), fullpath.size());
                              pack.add(value, buffer, fullpath.size());
                              break;
                          }
                        }else{ // Use pack
                          switch(io)
                          {
                          case PARAM_IO_IN:
                            // Add and Pack 
                            mTasks >> value;
                            res->addParameter(value);
                            pack.add(value, mDataDir + value);
                            break;
                            
                          case PARAM_IO_OUT:
                            // Add only
                            mTasks >> value;
                            res->addParameter(value);
                            break;
                            
                          case PARAM_IO_INOUT:
                            // Add and Pack 
                            mTasks >> value;
                            res->addParameter(value);
                            pack.add(value, mDataDir + value);
                            break;
                          }
                        }
                    }
                    else if (type[0] == 'C')
                    {
                        //std::ostringstream filename;
                        char   filename0[32];
                        sprintf(filename0,"const_%d\0",i);
                        string filename(filename0);
                        res->addParameter(filename);
                        switch(io)
                        {
                        case PARAM_IO_IN:
                            // Add and Pack 
                            if (type == "C[INTEGER]")
                            {
                                int32 value;
                                mTasks >> value;
                                pack.add(filename, reinterpret_cast<byte*>(&value), sizeof(value));
                            }
                            else if (type == "C[STRING]")
                            {
                                string value;
                                std::getline(mTasks,value);
                                byte* buffer = new byte[sizeof(value) + value.size()];
                                uint32 size = value.size();
                                memcpy((char*)buffer, (char*)&size, sizeof(value));
                                memcpy((char*)buffer + sizeof(value), value.c_str(), value.size());
                                pack.add(filename, buffer, sizeof(value) + value.size());
                            }
                            else if (type == "C[REAL]")
                            {
                                double value;
                                mTasks >> value;
                                pack.add(filename, reinterpret_cast<byte*>(&value), sizeof(value));
                            }
                            else 
                            {
                                UTIL_ERROR("default", "Unknown type");
                            }
                            break;
                            
                        case PARAM_IO_OUT:
                            // Add only
                            UTIL_FATAL("default", "Unable to have a constant value as a result");
                            break;
                            
                        case PARAM_IO_INOUT:
                            // Add and Pack 
                            UTIL_FATAL("default", "Unable to have a constant value as a result");
                            break;
                        default:
                            UTIL_ERROR("default", "Invalid IO mode");
                        }
                    }
                    // Handle Collection here 
                    else if (type[0] == 'G') 
                    {
                        mTasks >> value;
                        switch(io)
                        {
                        case PARAM_IO_IN:
                            res->addParameter(value);
                            // Select all file starting with this prefix
							// and add them to the pack 
                            packCollection(pack, value);
                            break;
                        case PARAM_IO_OUT:
                            res->addParameter(value);
							res->addOutputCollection(value);
                            break;
                        case PARAM_IO_INOUT:
                            res->addParameter(value);
                            // Select all file starting with this prefix 
							// and add them to the pack 
                            packCollection(pack, value);
							res->addOutputCollection(value);
							break;
                        default:
                            UTIL_ERROR("default", "Invalid IO mode");
                        }
                    }
                    else 
                    {
                        UTIL_ERROR("default", "Strange type");
                    }
                }
                if(mBackendName=="MpiBackend" || mBackendName=="MpiOmrpcBackend"){
                  int nprocs; 
                  mTasks >> nprocs;
                  res->setNprocs(nprocs);
                  // Send remote programs the path of data directory
                  byte* bufferDir = new byte[mDataDir.size()];
                  memcpy((char*)bufferDir, mDataDir.c_str(), mDataDir.size());
                  pack.add("data_dir.txt", bufferDir, mDataDir.size());
                }
                pack.close();
                UTIL_FATAL_ASSERT("default", Util::FileInfo(res->packInput()).exists(), "Pack does not exists");
            }
            else if (type != 1)
            {
                UTIL_FATAL("default", "Unknown task type");   
            }   
        }        
    }
    if (mReadyTasksQueue.empty())
        return 0;
    res = mReadyTasksQueue.front();
    mReadyTasksQueue.pop_front();
    return res;
}

// Scheduler interface 
void Application::finishTask(SchedulerTask* task)
{
    if (! task)
    {
        mExecutionLog  << "ERROR: An error occured while finising a task" << std::endl
                       << "ERROR: Aborting application execution" << std::endl;  
        mStatusChanged = true;
        set(3);
        return;
    }
    --mTaskExecuting;
    ++mTaskFinished;
    mStatusChanged = true;
    TaskIndex ti;
    
    mTasksIndex->getEntry(task->index(), ti);
    if (task->isSignal())
    {
        ti.flags(TaskIndex::FINISHED);
    }
    else 
    {
        mExecutionLog << "----------------------------------------" << std::endl
                      << "Task " << task->index() << ": Finished" << std::endl;
        if (task->status() == ExecSuccess)
        {
            if (task->extractAdminInfo())
            {
                // Clean all collection file for each output parameter of type collection	
                const uint32 collCounts = task->outputCollections();
                for (uint32 i = 0 ; i < collCounts ; ++i)
                {
                    clearCollection(task->outputCollection(i));	
                }
                Util::Pack pack(task->packOutput());
                
                pack.extractAll(mDataDir);
                pack.close();
                mExecutionLog << std::endl << "Task " << task->index() << ": " ;
                switch(task->status())
                {
                case ExecSuccess:
                    UTIL_INFO("default", "Task " << task->index() << " terminates successfully");
                    mExecutionLog << "SUCCESS" << std::endl;
                    ti.flags(TaskIndex::FINISHED);
                    break;
                    
                case ExecError:
                    UTIL_ERROR("default", "Task " << task->index() << " terminates with error");
                    mExecutionLog << "ERROR" << std::endl;
                    ti.flags(TaskIndex::ERROR);
                    set(3);
                    break;
                    
                case ExecException:
                    UTIL_ERROR("default", "Task " << task->index() << " throws an exception");
                    ti.flags(TaskIndex::EXCEPTION);
                    mExecutionLog << "EXCEPTION(" << task->exceptionName() << ")" << std::endl;
                    /* TODO EXCEPTION HANDLING */
                    set(4);
                    break;
                }

                mExecutionLog << task->trace();
            }
            else 
            {
                string status(12,'\0');
                
                switch(task->status())
                {
                case ExecError: 
                    status = "Error";
                    break;
                case ExecException:
                    status = "Exception";
                    break;
                case ExecSuccess:
                    status = "Success";
                    break;
                }
                mExecutionLog << "Task " << task->index() << ": " << status << std::endl;
                UTIL_ERROR("default", "Task " << task->index() << " terminates with error");
                ti.flags(TaskIndex::ERROR);
                set(3);
            }
        }
        else 
        {
            string status;
            switch(task->status())
            {
            case ExecError: 
                status = "Error";
                break;
            case ExecException:
                status = "Exception";
                break;
            case ExecSuccess:
                status = "Success";
                break;
                
            }
            mExecutionLog << "Task " << task->index() << ": " << status << std::endl;
            UTIL_ERROR("default", "Task " << task->index() << " terminates with error");
            ti.flags(TaskIndex::ERROR);
            set(3);
        }
        Util::File::remove(task->packAdmin());
        Util::File::remove(task->packInput());
        Util::File::remove(task->packOutput());

        mExecutionLog << "----------------------------------------" << std::endl;    
    }

    for(uint32 i = 0 ; i < task->events() ; ++i)
        set(task->event(i));
    mTasksCache[task->index()].flags(ti.flags());
    mTasksIndex->updateEntry(task->index(), ti);
    delete task;
}


void Application::clearCollection(const string& dataPrefix)
{
    class CollectionOutput_dirHandler : public Util::DirHandler
    {
    public:
        CollectionOutput_dirHandler(const string& prefix)
            : mPrefix(prefix)
        {
        }
        
        ~CollectionOutput_dirHandler()
        {
        }
        
        void onFile(const string& parentPath, const string& entryName)
        {
            if (entryName.substr(0, mPrefix.size()) == mPrefix)
            {
                Util::File::remove(parentPath + entryName);
            }
        }
    private:
        const string& mPrefix;
    };
    
    CollectionOutput_dirHandler handler(dataPrefix);
    Util::Dir::visit(handler, mDataDir, false);   
}

void Application::packCollection(Util::Pack& pack, const string& dataPrefix)
{
    class CollectionInput_dirHandler : public Util::DirHandler
    {
    public:
        CollectionInput_dirHandler(Util::Pack& pack, const string& prefix)
            : mPack(pack), mPrefix(prefix)
        {
            
        }
        
        ~CollectionInput_dirHandler()
        {
        }
        void onFile(const string& parentPath, const string& entryName)
        {
            if (entryName.substr(0, mPrefix.size()) == mPrefix)
            {
                mPack.add(entryName, parentPath + entryName);
            }    
        }
        
        
    private:
        Util::Pack& mPack;
        const string& mPrefix;
        
    };
    // Parse mDataDir for file starting with dataPrefix 
    CollectionInput_dirHandler handler(pack, dataPrefix);
    Util::Dir::visit(handler, mDataDir);
}


void Application::initializeInfoOnly()
{
    Util::Pack appPack(mApplicationFileName);
    Util::ByteArray tmp(0);
    
    appPack.extract(infoNameFile, tmp);
    mApplicationName.assign((char*)tmp.data(), tmp.size());
    appPack.extract(infoDescriptionFile, tmp);
    mApplicationDescription.assign((char*)tmp.data(), tmp.size());
    appPack.extract(infoQueryFile, tmp);
    mApplicationQuery.assign((char*)tmp.data(), tmp.size());
    appPack.extract(infoGraphFile, tmp);
    mApplicationGraph.assign((char*)tmp.data(), tmp.size());
    appPack.extract(infoVersionFile, tmp);
    mApplicationFormat.assign((char*)tmp.data(), tmp.size());
    appPack.extract(infoUidFile, tmp);
    mApplicationUID.assign((char*)tmp.data(), tmp.size());
    appPack.extract(infoParametersFile, tmp);
    ParameterList_csvHandler phandler(mParameters);
    Util::CSVParser().parse(phandler, tmp.data(), tmp.size());

    // Load the status file... 
    appPack.extract(dataStatusFile, tmp);
    std::istringstream in(string((char*)tmp.data(), tmp.size()));
    in >> mStatus 
       >> mSubGraphCount
       >> mComponentCallCount 
       >> mSignalCount 
       >> mEventCount 
       >> mExceptionCount 
       >> mConditionCount 
       >> mTaskWaiting
       >> mTaskReady
       >> mTaskExecuting 
       >> mTaskFinished;
    appPack.close();
}

const string& Application::backend(void) const
{
    return mBackendName;
}

void Application::backend (const string& name)
{
    mBackendName=name;
}

const string Application::infoVersionFile("info_version"); 
const string Application::infoNameFile("info_name");
const string Application::infoUidFile("info_uid");
const string Application::infoDescriptionFile("info_description");
const string Application::infoQueryFile("info_query");
const string Application::infoGraphFile("info_graph");
const string Application::infoParametersFile("info_parameters");
const string Application::dataTasksFile("data_tasks");
const string Application::dataTasksIndexFile("data_tasks_index");
const string Application::dataStatusFile("data_status");
const string Application::dataRulesFile("data_rules");
const string Application::dataLogFile("exec_log");
const string Application::dataUidFile("exec_uid");
const string Application::dataDirectory("data/");
const string Application::formatVersion("1.0.0");
const uint32 Application::COMPILING = 0;
const uint32 Application::COMPILED = 1;
const uint32 Application::EXECUTING = 2;
const uint32 Application::FINISHED = 3;
const uint32 Application::COMP_ERROR = 4;
const uint32 Application::ERROR = 5;
}    
}
