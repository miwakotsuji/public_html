/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/
/**
 * @file
 * @brief Class ParameterList declaration
 *  
 * 2006-11-20
 * Olivier Delannoy
 */
#ifndef YML_CORE_PARAMETERLIST_HH
#define YML_CORE_PARAMETERLIST_HH 1
#include "core.hh"
#include "Parameter.hh" 
#include <CSVHandler.hh>
#include <CSVSerializer.hh>
#include <XMLHandler.hh>
#include <XMLSerializer.hh>
#include <vector>

namespace Yml {
namespace Core {
/**
 * @brief This class encapsulate a collection of Parameter 
 * 
 * This collection is usefull to handle in a consistent way parameters
 * all around YML. 
 *
 */
class ParameterList 
{       
public:
    /**
     * Get the parameter corresponding to @em index. 
     */
    const Parameter& get(size_t index) const;
    /** 
     * Get the parameter corresponding to @em index. 
     */
    Parameter& get(size_t index);
    /**
     * Get the number of parameter in the list 
     */
    size_t count() const;
    /** 
     * Add a parameter to the list of parameters 
     */
    void add(const Parameter& parameter);
    /**
     * Serialize the parameter list to an XML stream 
     */
    Util::XMLSerializer& toXML(Util::XMLSerializer& stream) const;
    /** 
     * Serialize the parameter list to a CSV stream 
     */
    Util::CSVSerializer& toCSV(Util::CSVSerializer& stream) const;
protected:

private:
    std::vector<Parameter> mParameters; //!< Store all parameters
    friend class ParameterList_csvHandler;
    friend class ParameterList_xmlHandler;
    
};

/** 
 * @brief Parse a parameter list stored in a CSV File 
 * 
 * This class is used to parse a parameter list and fill a
 * ParameterList class entry stored as a CVS File. The CSV rows are
 * organized as follow:
 * - name (string)
 * - type (string) 
 * - collection (yes|no)
 * - mode (in|out|inout)
 * - description (string) 
 */
class ParameterList_csvHandler : public Util::CSVHandler
{
public:
    /**
     * @brief Create a new handler to fill @em list 
     *
     * @param list the list of parameter to be filled by the
     * handler. It is a common practice to provide an empty list here. 
     */
    ParameterList_csvHandler(ParameterList& list);
    
    void rowStart();
    void cell(const string& value);
    
private:
    ParameterList& mList;
    size_t mCellId;
    
};

/**
 * @brief Parse a parameter list stored in an XML File 
 * 
 * This class is a slave XML handler which can be used to parse a
 * parameter list in a more powerfull XMLHandler. The integration
 * within a complex handler can be done using the helper function
 * @em isHandle(const string& element)
 * 
 */
class ParameterList_xmlHandler : public Util::XMLHandler
{
public:
    ParameterList_xmlHandler(ParameterList& list);
    
    
    bool isHandled(const string& element);
    void elementStart(const string& element, const Util::Properties& attributes);
private:
    ParameterList& mList;
};

} // end of Core namespace 
} // end of YML namespace  

# ifdef HAVE_INLINE 
#  include "ParameterList.icc" 
# endif
#endif
