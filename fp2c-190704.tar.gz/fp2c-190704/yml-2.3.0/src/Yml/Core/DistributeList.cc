/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Maxime Hugues 2011
 *
 * Maxime Hugues
 *   Maxime.Hugues@gmail.com or Maxime.Hugues@inria.fr
 *	 INRIA Saclay
 *   PCRI - Bureau 142
 *   Rue Noetzlin
 *   91190 Gif-sur-Yvette France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/

/**
 * @file
 * @brief Class Distribute declaration
 *
 * 2011-09-20
 * Maxime Hugues
 */

 /* M.Tsuji 2012-04
    Extension for Template Definition */
 
#include "DistributeList.hh"
#ifndef HAVE_INLINE
#define inline
#include "DistributeList.icc"
#undef inline
#endif
#ifdef HAVE_CONFIG_H
#include <yml_config.hh> 
#endif 
#include <string>
#include <vector>
#include <sstream>
#include <cstdlib>
#include <iostream>
#include "LoggerFactory.hh"
#include "StringList.hh"

namespace Yml 
{
namespace Core
{
Util::XMLSerializer& DistributeList::toXML(Util::XMLSerializer& stream) const
{
	stream.openTag("distribute");
	std::vector<DistributeParam>::const_iterator end = mDistribute.end();
	std::vector<DistributeParam>::const_iterator iter = mDistribute.begin();
	for (;iter != end ; ++iter)
	{
		stream.openTag("param");

		std::vector<ParameterMapping> mapping = iter->getMapping();
		std::string paramMap;

		for (int i=0; i < mapping.size() ; i++)
		{
			if(i!=0) paramMap += ',';
			switch(mapping[i])
			{
			case PARAM_MAP_BLOCK:
				paramMap += "block";
				break;
			case PARAM_MAP_CYCLIC:
				paramMap += "cyclic";
				break;
			}
		}

		std::string align = iter->getDataAlign() + ":" + iter->getTemplateAlign();

		std::vector<int> vSize = iter->getSize();
		std::ostringstream size;

		size << "(";

		for (int i=0; i < vSize.size() ; i++)
		{
			if(i!=0) size << ',';

			size << vSize[i];
		}
		size << ")";

		stream.attribute("template", paramMap);
		stream.attribute("align", align);
		stream.attribute("name", iter->getName() + size.str())
								  .closeTag();
	}
	stream.closeTag();
	return stream;
}

Util::CSVSerializer& DistributeList::toCSV(Util::CSVSerializer& stream) const
{
	std::vector<DistributeParam>::const_iterator end = mDistribute.end();
	std::vector<DistributeParam>::const_iterator iter = mDistribute.begin();
	/*for (;iter != end ; ++iter)
	{
		stream.newRow();
		switch(iter->getMapping())
		{
		case PARAM_MAP_BLOCK:
			stream.cell("block");
			break;
		case PARAM_MAP_CYCLIC:
			stream.cell("cyclic");
			break;
		}
		stream.cell(iter->getName());
	}*/
	return stream;
}

DistributeList_csvHandler::DistributeList_csvHandler(DistributeList& list)
: mList(list), mCellId(0)
{
}

void DistributeList_csvHandler::rowStart()
{
	mList.add(DistributeParam());
	mCellId = 0;
}

void DistributeList_csvHandler::cell(const string& value)
{
	/*switch(mCellId)
	{
	case 0: // Mapping
		if (value == "block")
		{
			mList.mDistribute.back().setMapping(PARAM_MAP_BLOCK);
		}
		else if (value == "cyclic")
		{
			mList.mDistribute.back().setMapping(PARAM_MAP_CYCLIC);
		}
		break;

	case 1: // Name
		mList.mDistribute.back().setName(value);
		break;

	}
	++mCellId;*/
}
DistributeList_xmlHandler::DistributeList_xmlHandler(DistributeList& list)
: mList(list)
{
}

bool DistributeList_xmlHandler::isHandled(const string& element)
{
	if (element == "param")
		return true;
	return false;
}

void DistributeList_xmlHandler::elementStart(const string& element, const Util::Properties& attributes, const TemplateList& templateList)
{
	if (element == "param")
	{
/*
		const string& distribute = attributes.stringValue("template", "block"); // Extend for template tokenizing 
		std::istringstream distributeStream(distribute);
		std::vector<ParameterMapping> mapping;
		std::string distributeName;

		while ( std::getline(distributeStream,distributeName,',') )
		{
			if (distributeName == "block")
				mapping.push_back(PARAM_MAP_BLOCK);
			else if (distributeName == "cyclic")
				mapping.push_back(PARAM_MAP_CYCLIC);
			else
				mapping.push_back(PARAM_MAP_BLOCK);

		}
*/
		string align = attributes.stringValue("align");

		std::istringstream alignStream(align);
		std::string DataAlign;
		std::string TemplateAlign;
		std::string alignName;

		std::getline(alignStream,alignName,':');
		DataAlign = alignName;
		std::getline(alignStream,alignName,':');
		TemplateAlign = alignName;

                // Parse data & template align
                std::vector<string> data_align, template_align;
                string str;

                str=DataAlign;
                if(str.find("[")==string::npos && str.find("(")!=string::npos){ // may lang=="XMF"?
                  while(str.size()>2){
                    int i0=str.find("(")+1;
                    int i1=str.find(")");
                    data_align.push_back(str.substr(i0,i1-i0)); 
                    str=str.substr(i1+1,str.size()-i1);
                  }
                }else{
                  while(str.size()>2){
                    int i0=str.find("[")+1;
                    int i1=str.find("]");
                    data_align.push_back(str.substr(i0,i1-i0)); 
                    str=str.substr(i1+1,str.size()-i1);
                  }
                }

                while(str.size()>0){
                  int i0=str.find(",");
                  if(i0 == string::npos){
                    template_align.push_back(str);
                    break;
                  }
                  template_align.push_back(str.substr(0,i0));
                  str=str.substr(i0+1,str.size()-i0-1);
                }

                string template_name = attributes.stringValue("template");
                // Find the specified template
                TemplateList  tlist = templateList;
                TemplateParam t;
                for(int i=0; i<tlist.getSize(); i++){
                  t = tlist.get(i);
                  if(template_name==t.getName()) break; 
                }

                if(template_name!=t.getName()){
                  UTIL_ERROR("default","template " << template_name << " isn't defined"); 
                  exit(1);
                }

		string variableNames = attributes.stringValue("name");
		std::istringstream nameStream(variableNames);
		std::string nameAndsize;
		while ( std::getline(nameStream,nameAndsize,';') )
		{
			mList.mDistribute.push_back(DistributeParam());
			DistributeParam& ref = mList.mDistribute.back();

			std::string copyNameandSize(nameAndsize);
			std::istringstream tmpStream(copyNameandSize);
			std::string name;
			std::getline(tmpStream,name,'(');
                        std::vector<int> size_vector;

			copyNameandSize.erase(copyNameandSize.begin(),copyNameandSize.begin()+name.size()+1);
			copyNameandSize.erase(copyNameandSize.end()-1,copyNameandSize.end());

			std::istringstream sizeStream(copyNameandSize);
			std::string size;
                        int         count = 0;

			while ( std::getline(sizeStream,size,',') )
			{
                          string align_index = data_align[count++];
                          int    template_index_pos;
                          int    size1,size2;
                          if(align_index=="*"){
                              size2 = atoi(size.c_str());
                          }else{
                              for(template_index_pos=0; template_index_pos<template_align.size(); template_index_pos++){
                                  if(template_align[template_index_pos]==align_index) break;
                              }
                              size1 = t.getSize().at(template_index_pos);
                              size2 = atoi(size.c_str());
                              if(size1!=size2){
                                  UTIL_ERROR("default","The size of array (" << size2 << ") is out of template (" << size1 << ")");
                                  exit(1);
                              }
                          }
                          size_vector.push_back(size2);
			}

			ref.setSize(size_vector);
			ref.setName(name);
                        ref.setTemplateName(t.getName());
                        ref.setTemplatePrint(t.getPrint());
			ref.setMapping(t.getFormat());
			ref.setDataAlign(DataAlign);
			ref.setTemplateAlign(TemplateAlign);
                        ref.setNode(t.getNode());
		}
	}
}

// --- start ---------- declaration of TemplateList ---
TemplateList_xmlHandler::TemplateList_xmlHandler(TemplateList& list)
: mList(list)
{
}

size_t TemplateList::getSize(void)
{
  return mTemplate.size();
}

TemplateParam& TemplateList::get(int i)
{
  return mTemplate.at(i);
}

bool TemplateList_xmlHandler::isHandled(const string& element)
{
    if (element == "template")
        return true;
    return false;
}

void TemplateList_xmlHandler::elementStart(const string& element, const Util::Properties& attributes, const string& default_nodes, const string& lang)
{
  std::string str;
  if(element=="template"){
    string template_name   = attributes.stringValue("name");
    string template_format = attributes.stringValue("format","block");
    string template_size   = attributes.stringValue("size");
    string template_nodes  = attributes.stringValue("nodes","default");
    if(template_nodes=="" || template_nodes=="default"){
      if(lang=="XMF"){
        template_nodes="XMF_default_nodes("+default_nodes +")";
      }else{
        template_nodes="_XMP_default_nodes("+default_nodes +")";
      }
    }
    string template_nodes2 = template_nodes.substr(0,template_nodes.find("("));

    std::istringstream formatStream(template_format);
    std::vector<ParameterMapping> mapping;
    while(std::getline(formatStream, str, ',')){
      if(str=="block")       mapping.push_back(PARAM_MAP_BLOCK);
      else if(str=="cyclic") mapping.push_back(PARAM_MAP_CYCLIC);
      else                   mapping.push_back(PARAM_MAP_BLOCK);
    }
    string template_size_str="";

    std::istringstream sizeStream(template_size);
    std::vector<int> v;
    if(lang=="XMF"){ // XMP FORTRAN
      while(std::getline(sizeStream,str,',')){
        int size0 = atoi(str.c_str());
        std::ostringstream size1;
        size1 << size0;
        v.push_back(size0);
        if(template_size_str!="") template_size_str += ",";
        template_size_str += "1:" + size1.str();
      }
    }else{
      while(std::getline(sizeStream,str,',')){
        int size0 = atoi(str.c_str());
        std::ostringstream size1; 
        size1 << size0-1;
        v.push_back(size0);
        if(template_size_str!="") template_size_str += ",";
        template_size_str += "0:" + size1.str();
      }
    }
    string template_print;
    if(lang=="XMF"){ // XMP FORTRAN
      template_print = "!$xmp template " + template_name + "(" + template_size_str + ")\n";
      template_print +=  "!$xmp distribute " + template_name + "(" + template_format + ") onto " + template_nodes2 + "\n";
      if(template_nodes!="XMF_default_nodes("+default_nodes +")"){
        template_print = "!$xmp nodes " + template_nodes + "\n" + template_print;
      }
    }else{
      template_print = "#pragma xmp template " + template_name + "(" + template_size_str + ")\n";
      template_print +=  "#pragma xmp distribute " + template_name + "(" + template_format + ") onto " + template_nodes2 + "\n"; 
      if(template_nodes!="_XMP_default_nodes("+default_nodes +")"){
        template_print = "#pragma xmp nodes " + template_nodes + "\n" + template_print;
      }
    }
    mList.mTemplate.push_back(TemplateParam());
    TemplateParam& ref = mList.mTemplate.back();
    ref.setName(template_name);
    ref.setFormat(mapping);
    ref.setSize(v);
    ref.setNode(template_nodes);
    ref.setPrint(template_print);
  } // if(element=="template")
}

TemplateList& TemplateList_xmlHandler::getList(void)
{
  return mList;
}
// --- end ---------- declaration of TemplateList ---


}
}
