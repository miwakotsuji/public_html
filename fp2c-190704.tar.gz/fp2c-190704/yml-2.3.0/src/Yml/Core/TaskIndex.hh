/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/

/**
 * @file
 * @brief Class TaskIndex declaration
 *  
 * 2005-08-23
 * Olivier Delannoy
 */
#ifndef YML_CORE_TASKINDEX_HH
#define YML_CORE_TASKINDEX_HH 1
#include "core.hh"
#include <LittleEndianStream.hh>
namespace Yml {
    namespace Core {
        /**
         * @brief Task Index entry in the Task Table 
         * 
         * Each task information are represented by a TaskIndex entry
         * in the Task Index table and by a Task Data entry in the
         * Task Data file.
         */
        class TaskIndex
        {
        public:
            /**
             * Default Contstructor
             */
            TaskIndex(void);
            /**
             * Destructor
             */
            ~TaskIndex(void);
            /** 
             * retrieve task flags 
             */ 
            uint8 flags(void) const;
            /** 
             * set task flags 
             */
            void flags(uint8 newFlags);
            /** 
             * retrieve the offset 
             */
            uint32 offset(void) const;
            /** 
             * Set the offset 
             */
            void offset(uint32 newOffset);
            /** 
             * retrieve the rule index 
             */
            uint32 ruleIndex(void) const;
            /**
             *  Set the rule index 
             */ 
            void ruleIndex(uint32 newRule);
            /**
             * Retrieves the task uid 
             */
            byte* uid(void);
            /**
             * Set the uid of a task object 
             */
            void uid(byte* uid);
            /** 
             * Test whether to TaskIndex are the same or not 
             */
            bool operator==(const TaskIndex& rhs) const;
            /** 
             * Write to out the current object 
             */
            void write(Util::LittleEndianStream& out) const;
            /** 
             * Read from in the current object 
             */
            void read(Util::LittleEndianStream& in);
            /** Status used for tasks not yet ready  */ 
            static const uint8 WAITING=0;
            /** Status used for tasks ready to be executed */
            static const uint8 READY=1;
            /** Status used for tasks executing */
            static const uint8 EXECUTING=2;
            /** Status used for tasks finished */
            static const uint8 FINISHED=3;
            /** Status used for tasks finished with error */ 
            static const uint8 ERROR=4;
            /** Status used for tasks finished with exception */
            static const uint8 EXCEPTION=5;
            /** Store the number of bytes used to store a TaskIndex. */
            static const uint32 SIZE=25;
        protected:
    
        private:
            /** Some status flag */
            uint8  mFlags;     
            /** Must be a set condition */ 
            uint32 mRuleIndex; 
            /** The offset to the task data in the task file */
            uint32 mOffset;    
            /** an uid associated to a task */
            byte  mUID[16];  
        };
    }
}
#ifdef HAVE_INLINE
#include "TaskIndex.icc"
#endif
#endif

