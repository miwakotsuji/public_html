/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/

/**
 * @file
 * @brief Class Component_xmlHandler function definition 
 *
 * 2005-08-21
 * Olivier Delannoy
 */
#include "Component_xmlHandler.hh"
#ifndef HAVE_INLINE 
#define inline 
#include "Component_xmlHandler.icc" 
#undef inline 
#endif 
#ifdef HAVE_CONFIG_H
#include <yml_config.hh>
#endif
#include <LoggerFactory.hh>
namespace Yml
{
namespace Core
{
Component_xmlHandler::Component_xmlHandler(void) 
: mComponentAbstract(0),
  mComponentGraph(0),
  mComponentImpl(0),
  mComponentType(COMPONENT_TYPE_ERROR),
  mParameterList_xmlHandler(0),
  mDistributeList_xmlHandler(0),
  mTemplateList_xmlHandler(0),
  mError(false),
  mInHeader(false),
  mInSource(false),
  mInFooter(false)
{
}
Component_xmlHandler::~Component_xmlHandler() 
{
	delete mComponentAbstract;
	delete mComponentGraph;
	delete mComponentImpl;
	delete mParameterList_xmlHandler;
	delete mDistributeList_xmlHandler;
	delete mTemplateList_xmlHandler;
}
void Component_xmlHandler::elementStart(const string& element, const Util::Properties& attrs)
{
	if (!mError)
	{
		if (mParameterList_xmlHandler && mParameterList_xmlHandler->isHandled(element))
		{
			mParameterList_xmlHandler->elementStart(element, attrs);
		}
		else if (mDistributeList_xmlHandler && mDistributeList_xmlHandler->isHandled(element) && mTemplateList_xmlHandler)
		{
			mDistributeList_xmlHandler->elementStart(element, attrs, mTemplateList_xmlHandler->getList());
		}
                else if (mTemplateList_xmlHandler && mTemplateList_xmlHandler->isHandled(element) && mComponentImpl)
                {
                        mTemplateList_xmlHandler->elementStart(element, attrs, mComponentImpl->getImplNodesTopology(),mComponentImpl->getImplLanguage());
                }
		else if (element == "component")
		{
			// Create the components object
			string type = attrs.stringValue("type");         // The type of the component
			string name = attrs.stringValue("name");         // The name of the component
			string desc = attrs.stringValue("description");  // The description of the component
			string abstract = attrs.stringValue("abstract"); // The name of the corresponding abstract component
			if (type == "abstract")
			{
				mComponentAbstract = new ComponentAbstract;
				mComponentAbstract->setName(name);
				mComponentAbstract->setDescription(desc);
				mComponentType = COMPONENT_TYPE_ABSTRACT;
				mParameterList_xmlHandler = new ParameterList_xmlHandler(mComponentAbstract->getParameterList());
			}
			else if (type == "graph")
			{
				mComponentGraph = new ComponentGraph;
				mComponentGraph->setName(name);
				mComponentGraph->setDescription(desc);
				mComponentGraph->setComponentAbstractName(abstract);
				mComponentType= COMPONENT_TYPE_GRAPH;
			}
			else if (type == "impl")
			{
				mComponentImpl = new ComponentImpl;
				mComponentImpl->setName(name);
				mComponentImpl->setDescription(desc);
				mComponentImpl->setComponentAbstractName(abstract);
				mComponentType = COMPONENT_TYPE_IMPL;
			}
			else
			{
				mError = true;
			}

		}
		else if (element == "graph")
		{
			if (mComponentType == COMPONENT_TYPE_GRAPH)
			{
				mInSource = true;
			}
			else
			{
				mComponentType = COMPONENT_TYPE_ERROR;
				mError = true;
			}
		}
		else if (element == "impl")
		{
			if (mComponentType == COMPONENT_TYPE_IMPL)
			{
				// Handle lang and libs attributes
				mComponentImpl->setImplLanguage(attrs.stringValue("lang", "CXX"));
				mComponentImpl->setImplLibraries(attrs.stringValue("libs"));
				mComponentImpl->setImplNodes(attrs.stringValue("nodes"));
			}
			else
			{
				mComponentType = COMPONENT_TYPE_ERROR;
				mError = true;
			}
		}
		else if (element == "distribute")
		{
			if (mComponentType == COMPONENT_TYPE_IMPL)
			{
				UTIL_INFO("default", "Data Distribution Taken into account");
				mDistributeList_xmlHandler = new DistributeList_xmlHandler(mComponentImpl->getDistributeList());
			}
			else
			{
				mComponentType = COMPONENT_TYPE_ERROR;
				mError = true;
			}
		}
                else if (element == "templates")
                {
                        if (mComponentType == COMPONENT_TYPE_IMPL)
                        {
                                UTIL_INFO("default", "handle template");
                                mTemplateList_xmlHandler = new TemplateList_xmlHandler(mComponentImpl->getTemplateList());
                        }
                        else
                        {
                                mComponentType = COMPONENT_TYPE_ERROR;
                                mError = true;
                        }
                }
		else if (element == "header")
		{
			if (mComponentType == COMPONENT_TYPE_IMPL)
			{
				mInHeader = true;
			}
			else
			{
				mComponentType = COMPONENT_TYPE_ERROR;
				mError = true;
			}
		}
		else if (element == "source")
		{
			if (mComponentType == COMPONENT_TYPE_IMPL)
			{
				mInSource = true;
			}
			else
			{
				mComponentType = COMPONENT_TYPE_ERROR;
				mError = true;
			}
		}
		else if (element == "footer")
		{
			if (mComponentType == COMPONENT_TYPE_IMPL)
			{
				mInFooter = true;
			}
			else
			{
				mComponentType = COMPONENT_TYPE_ERROR;
				mError = true;
			}
		}
	}

}

void Component_xmlHandler::elementEnd(const string& element)
{
	if (!mError)
	{
		if (element == "header")
			mInHeader = false;
		else if (element == "source" || element == "graph")
			mInSource = false;
		else if (element == "footer")
			mInFooter = false;
	}
}

void Component_xmlHandler::text(const string& text)
{
	if (!mError)
	{

		if (mInHeader)
		{
			if (mComponentImpl)
			{
				mComponentImpl->setImplHeader(mComponentImpl->getImplHeader() + text);
			}
			else
			{
				mComponentType = COMPONENT_TYPE_ERROR;
				mError = true;
			}
		}
		else if (mInSource)
		{
			if (mComponentType == COMPONENT_TYPE_GRAPH)
			{
				mComponentGraph->setYvetteProgram(mComponentGraph->getYvetteProgram() + text);
			}
			else if (mComponentType == COMPONENT_TYPE_IMPL)
			{
				mComponentImpl->setImplSource(mComponentImpl->getImplSource() + text);
			}
			else
			{
				mComponentType = COMPONENT_TYPE_ERROR;
				mError = true;
			}
		}
		else if (mInFooter)
		{
			if (mComponentImpl)
			{
				mComponentImpl->setImplFooter(mComponentImpl->getImplFooter() + text);
			}
			else
			{
				mComponentType = COMPONENT_TYPE_ERROR;
				mError = true;
			}
		}
	}
}

}
}




