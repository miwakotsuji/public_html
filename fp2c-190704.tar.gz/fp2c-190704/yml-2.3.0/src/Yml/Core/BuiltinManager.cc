/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/
/**
 * @file
 * @brief Class BuiltinManager function definition 
 *
 * 2007-03-20
 * Olivier Delannoy
 */
#include "BuiltinManager.hh"
#include "SchedulerTask.hh" 
#include "TaskComputation.hh"


#ifdef HAVE_CONFIG_H
#include <yml_config.hh>
#endif
#include <fstream>
#include <sstream>
#include <LoggerFactory.hh>
#include <File.hh>
#include <Dir.hh>
namespace Yml 
{
namespace Core
{

// Builtins are hidden from the rest of YML for a better separation with the rest of the application. 
class Builtin 
{
public:
    virtual ~Builtin() {}
    virtual bool accept(TaskComputation* task) = 0;
    virtual bool exec(SchedulerTask* task, const string& dataDir) = 0;
};

////////////////////////////////////////////////////////////////
class BuiltinIntegerCreator : public Builtin
{
public:
    bool accept(TaskComputation* task);
    bool exec(SchedulerTask* task, const string& dataDir);
};
bool BuiltinIntegerCreator::accept(TaskComputation* task)
{
    if (task->parameters() == 2)
    {
        if (task->parameter(0).substr(0, 3) == "F[]" && 
            task->parameter(1).substr(0, 10) == "C[INTEGER]")
            return true;
    }
    return false;
}
bool BuiltinIntegerCreator::exec(SchedulerTask* task, const string& dataDir)
{
    std::istringstream in(task->parameter(1));
    int32 value;
    in >> value;
    
    std::ofstream out((dataDir + task->parameter(0)).c_str());
    if (in && out)
    {
        out.write(reinterpret_cast<char*>(&value), sizeof(value));
        out.close();
        return true;
    }
    return false;  
}
//////////////////////////////////////////////////////////
class BuiltinRealCreator : public Builtin
{
public:
    bool accept(TaskComputation* task);
    bool exec(SchedulerTask* task, const string& dataDir);
    
};
bool BuiltinRealCreator::accept(TaskComputation* task)
{
    if (task->parameters() == 2)
    {
        if (task->parameter(0).substr(0, 3) == "F[]" && 
            task->parameter(1).substr(0, 7) == "C[REAL]")
            return true;
    }
    return false;
}
bool BuiltinRealCreator::exec(SchedulerTask* task, const string& dataDir)
{
    std::istringstream in(task->parameter(1));
    real64 value;
    in >> value;
    std::ofstream out((dataDir + task->parameter(0)).c_str());
    if (in && out)
    {
        out.write(reinterpret_cast<char*>(&value), sizeof(value));
        out.close();
        return true;
    }
    return false;    
}
///////////////////////////////////////////////////////////
class BuiltinStringCreator : public Builtin
{
public:
    bool accept(TaskComputation* task);
    bool exec(SchedulerTask* task, const string& dataDir);
};

bool BuiltinStringCreator::accept(TaskComputation* task)
{
    if (task->parameters() == 2)
    {
        if (task->parameter(0).substr(0, 3) == "F[]" && 
            task->parameter(1).substr(0, 9) == "C[STRING]")
            return true;
    }
    return false;
}
bool BuiltinStringCreator::exec(SchedulerTask* task, const string& dataDir)
{
    const size_t size = task->parameter(1).size(); 
    std::ofstream out((dataDir + task->parameter(0)).c_str());
    if (out)
    {
        out.write(reinterpret_cast<const char*>(&size), sizeof(size));
        out << task->parameter(1);
        out.close();
        return true;
    }
    return false;   
}
///////////////////////////////////////////////////////////    
class BuiltinDelete : public Builtin 
{
public:
    bool accept(TaskComputation* task);
    bool exec(SchedulerTask* task, const string& dataDir);
    
};
bool BuiltinDelete::accept(TaskComputation* task)
{
    if (task->parameters() == 1)
        if (task->parameter(0).substr(0, 3) == "F[]")
            return true;
    return false;
}
bool BuiltinDelete::exec(SchedulerTask* task, const string& dataDir)
{
    return Util::File::remove(dataDir + task->parameter(0));
}
/////////////////////////////////////////////////////////
class BuiltinRename : public Builtin
{
public:
    bool accept(TaskComputation* task);
    bool exec(SchedulerTask*, const string& dataDir);
};
bool BuiltinRename::accept(TaskComputation* task)
{
    if (task->parameters() == 2)
    {
        if (task->parameter(0).substr(0, 3) == "F[]" && 
            task->parameter(1).substr(0, 3) == "F[]")
            return true;
    }
    return false;
}
bool BuiltinRename::exec(SchedulerTask* task, const string& dataDir)
{
    return Util::File::rename(dataDir + task->parameter(0), dataDir + task->parameter(1));
}
///////////////////////////////////////////////////////////
class BuiltinCopy : public Builtin
{
public:
    bool accept(TaskComputation* task);
    bool exec(SchedulerTask* task, const string& dataDir);
    
};
bool BuiltinCopy::accept(TaskComputation* task)
{
    if (task->parameters() == 2)
    {
        if (task->parameter(0).substr(0, 3) == "F[]" && 
            task->parameter(1).substr(0, 3) == "F[]")
            return true;
    }
    return false;
}
bool BuiltinCopy::exec(SchedulerTask* task, const string& dataDir)
{
    return Util::File::copy(dataDir + task->parameter(0), dataDir + task->parameter(1));
}

////////////////////////////////////////////////////////////
class BuiltinSwap : public Builtin
{
public:
    bool accept(TaskComputation* task);
    bool exec(SchedulerTask* task, const string& dataDir);
};

bool BuiltinSwap::accept(TaskComputation* task)
{
    if (task->parameters() == 2)
    {
        if (task->parameter(0).substr(0, 3) == "F[]" && 
            task->parameter(1).substr(0, 3) == "F[]")
            return true;
    }
    return false;
}
bool BuiltinSwap::exec(SchedulerTask* task, const string& dataDir)
{
    string tmp = dataDir + Util::File::tempName();
    string f0(dataDir + task->parameter(0));
    string f1(dataDir + task->parameter(1));
    
    if (Util::File::rename(tmp, f0))
    {
        if (Util::File::rename(f0, f1))
        {
            return Util::File::rename(f1, tmp);
        }
    }
    return false;
}



BuiltinManager::BuiltinManager()
    : Util::Singleton<BuiltinManager>()
{
    d_builtins["createInteger"] = new BuiltinIntegerCreator();
    d_builtins["createReal"] = new BuiltinRealCreator();
    d_builtins["createString"] = new BuiltinStringCreator();
    d_builtins["delete"] = new BuiltinDelete();
    d_builtins["rename"] = new BuiltinRename();
    d_builtins["copy"] = new BuiltinCopy();
    d_builtins["swap"] = new BuiltinSwap();
}

BuiltinManager::~BuiltinManager()
{    
    const std::map<string, Builtin*>::iterator end = d_builtins.end();
     std::map<string, Builtin*>::iterator iter = d_builtins.begin();
    for(; iter != end ; ++iter)
        delete iter->second;
}


bool BuiltinManager::find(TaskComputation* task)
{
    std::map<string, Builtin*>::iterator iter = d_builtins.find(task->componentName());
    if (iter != d_builtins.end())
    {
        return iter->second->accept(task);
    }
    return false;
}

void BuiltinManager::exec(SchedulerTask* task, const string& dataDir)
{
    if (task->isBuiltinCall())
    {
        std::map<string, Builtin*>::iterator iter = d_builtins.find(task->builtin());
        if (iter != d_builtins.end() && iter->second->exec(task, dataDir))
        {
            task->setStatus(ExecSuccess);
            return;
        }
    }
    task->setStatus(ExecError);
}

}
}
