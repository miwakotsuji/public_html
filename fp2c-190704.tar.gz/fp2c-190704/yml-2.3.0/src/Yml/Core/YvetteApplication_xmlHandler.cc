/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/
/**
 * @file
 * @brief Class YvetteApplication_xmlHandler function definition 
 *
 * 2007-01-22
 * Olivier Delannoy
 */
#include "YvetteApplication_xmlHandler.hh"
#ifndef HAVE_INLINE
#define inline
#include "YvetteApplication_xmlHandler.icc"
#undef inline
#endif 
#include "YvetteApplication.hh" 
#include "ParameterList.hh" 
#ifdef HAVE_CONFIG_H
#include <yml_config.hh>
#endif 
#include <LoggerFactory.hh> 
#include <StringHelper.hh> 
namespace Yml 
{
namespace Core
{

Application_xmlHandler::Application_xmlHandler(Application& app)
    : mApplication(app), 
      mParameterList_xmlHandler(app.mParameters),
      mError(false), 
      mInDescription(false), 
      mInGraph(false)
{
}

Application_xmlHandler::~Application_xmlHandler()
{    
}

void Application_xmlHandler::elementStart(const string& element, const Util::Properties& attr)
{
    if (mError)
        return;
    UTIL_DEBUG("default", "Element Open: " << element);
    if (mParameterList_xmlHandler.isHandled(element))
    {
        mParameterList_xmlHandler.elementStart(element, attr);    
    }
    else if (element == "application")
    {
        mApplication.setName(attr.stringValue("name"));
    }
    else if (element == "graph")
    {
        mInGraph = true;
    }
    else if (element == "description")
    {
        mInDescription = true;
    }
    else 
    {
        UTIL_DEBUG("default", "Error detected in element handle");
        mError = true;
    }
}
void Application_xmlHandler::elementEnd(const string& element)
{
    if (mError)
        return;
    UTIL_DEBUG("default", "Element close: " << element)

    if (mParameterList_xmlHandler.isHandled(element))
        ;
    else if (element == "description")
        mInDescription = false;
    else if (element == "graph")
        mInGraph = false;
}
void Application_xmlHandler::text(const string& text)
{
    if (mError)
        return;
    UTIL_DEBUG("default", "Text node: '" << Util::StringHelper::trim(text) << "'");
    if (mInDescription)
    {
        if (mApplication.mApplicationDescription.size() == 0)
            mApplication.mApplicationDescription = text;
        else 
            mApplication.mApplicationDescription += ' ' + text;
    }
    else if (mInGraph)
    {
        if (mApplication.mApplicationGraph.size() == 0)
            mApplication.mApplicationGraph = text;
        else 
            mApplication.mApplicationGraph += ' '+ text;
    }
    // Should set error to false if text is in between elements
}

}
}
