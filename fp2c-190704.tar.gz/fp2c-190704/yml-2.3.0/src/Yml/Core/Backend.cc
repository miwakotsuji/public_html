	/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
	/****************************************************************************
	 * Copyright Olivier Delannoy, Laurent Choy 2005
	 *
	 * Olivier Delannoy
	 *   Olivier.Delannoy@gmail.com
	 *   PRiSM Laboratory
	 *   Verailles University
	 *   45 avenue des Etats Unis
	 *   78035 Versailles Cedex FRANCE
	 *
	 * Laurent Choy
	 *   Choy.Laurent@gmail.com
	 *   INRIA Futurs
	 *   Parc Club Orsay Universit�
	 *   ZAC des vignes
	 *   2-4, rue Jacques Monod
	 *   91893 Orsay Cedex France
	 *
	 *
	 *
	 * This software is a computer program whose purpose is to [describe
	 * functionalities and technical features of your software].
	 *
	 * This software is governed by the CeCILL  license under French law and
	 * abiding by the rules of distribution of free software.  You can  use,
	 * modify and/ or redistribute the software under the terms of the CeCILL
	 * license as circulated by CEA, CNRS and INRIA at the following URL
	 * "http://www.cecill.info".
	 *
	 * As a counterpart to the access to the source code and  rights to copy,
	 * modify and redistribute granted by the license, users are provided only
	 * with a limited warranty  and the software's author,  the holder of the
	 * economic rights,  and the successive licensors  have only  limited
	 * liability.
	 *
	 * In this respect, the user's attention is drawn to the risks associated
	 * with loading,  using,  modifying and/or developing or reproducing the
	 * software by the user in light of its specific status of free software,
	 * that may mean  that it is complicated to manipulate,  and  that  also
	 * therefore means  that it is reserved for developers  and  experienced
	 * professionals having in-depth computer knowledge. Users are therefore
	 * encouraged to load and test the software's suitability as regards their
	 * requirements in conditions enabling the security of their systems and/or
	 * data to be ensured and,  more generally, to use and operate it in the
	 * same conditions as regards security.
	 *
	 * The fact that you are presently reading this means that you have had
	 * knowledge of the CeCILL license and that you accept its terms.
	 ****************************************************************************/

	/**
	 * @file
	 * @brief Class Backend function definition
	 *
	 * 2005-07-14
	 * Olivier Delannoy
	 */
	#include "Backend.hh"
	#include "ExecutionCatalog.hh"
	#include "PluginManager.hh"
	#include "SchedulerTask.hh"
	#ifndef HAVE_INLINE
	#define inline
	#include "Backend.icc"
	#undef inline
	#endif
	#ifdef HAVE_CONFIG_H
	#include <yml_config.hh>
	#endif

	#include <LoggerFactory.hh>
	#include <ConfigFactory.hh>
	#include <RuntimeEnvironment.hh>
	#include <sstream>
        #include<stdio.h>
	namespace Yml
	{
	namespace Core
	{
	Backend::Backend()
	{
	}

	Backend::~Backend()
	{
	}

	void Backend::init(const string& initData)
	{
		UTIL_INFO("default", "Back-end initialization");

		// Check for DR Server host and port
		Util::Config* drConfig = Util::ConfigFactory::getSingleton().create("dr");
		mDRHost = drConfig->get("general", "host", "127.0.0.1");
		mDRPort = drConfig->get("general", "port", "5441");
		mBinGroup = Yml::Core::PluginManager::getSingleton().getExecutionCatalog().getBinaryURI();
		initImpl(initData);
	}

        void Backend::setBackendName(const string& name)
        {
           mBackendName = name;
        }

	bool Backend::execute(SchedulerTask* task)
	{
		// Prepare work description used to interact with worker
		if (task->work().empty() || task->work()=="_YML_INITIAL_DUMMY_STRING_YML_INITIAL_DUMMY_STRING_")
		{
                    Yml::Core::string binary;
                    if(mBackendName!="MpiBackend"){
			// Retrieve the name of the binary component to use
			binary = Yml::Core::PluginManager::getSingleton()
			.getExecutionCatalog().selectComponent(task);
			size_t pos = binary.find_last_of(Util::RuntimeEnvironment::PATH_SEPARATOR);

			if (pos != Yml::Core::string::npos)
			{
				binary = binary.substr(pos + 1);
			}
			// Do this in that order in all backend
			if (binary.empty())
			{
				UTIL_ERROR("default", "No implementation component available");
				return false;
			}
                    }else{
                        binary = task->component();
                    }
			/* std::ostringstream workDescription;
			// We could enhance this
			pos = task->packInput().find_last_of(Util::RuntimeEnvironment::PATH_SEPARATOR);
			Yml::Core::string inputBaseName = task->packInput().substr(pos + 1);
			pos = task->packAdmin().find_last_of(Util::RuntimeEnvironment::PATH_SEPARATOR);
			Yml::Core::string adminBaseName = task->packAdmin().substr(pos + 1);
			pos = task->packOutput().find_last_of(Util::RuntimeEnvironment::PATH_SEPARATOR);
			Yml::Core::string outputBaseName = task->packOutput().substr(pos);*/

			Yml::Core::string inputBaseName = task->packInput();
			Yml::Core::string adminBaseName = task->packAdmin();
			Yml::Core::string outputBaseName = task->packOutput();
			Yml::Core::string tmpBaseName = task->packTmp();
/*
			// Prepare Task file
			workDescription << "<work binary=\"" << binary << "\" imports=\"2\" params=\""
					<< task->parameters()  << "\"><import host=\"" << mDRHost
					<< "\" port=\"" << mDRPort << "\" uri=\"/"
					<< mBinGroup << "/" << binary
					<< "\" pack=\"no\" /><import host=\"" << mDRHost << "\" port=\"" << mDRPort
					<< "\" uri=\"" << inputBaseName << "\" pack=\"yes\" /><export host=\""
					<< mDRHost << "\" port=\"" << mDRPort << "\" uri=\"" << outputBaseName
					<< "\" /><admin host=\"" << mDRHost << "\" port=\"" << mDRPort << "\" uri=\""<< adminBaseName << "\" />"
					<< "<tmp uri=\"" << tmpBaseName << "\" />";

			for(Yml::Core::uint32 i = 0 ; i < task->parameters() ; ++i){
				workDescription << "<param name=\"" << task->parameter(i) << "\" />";
                        }
			workDescription << "</work>";
			task->work() = workDescription.str();
*/                  
                        char   nparam[256];
                        sprintf(nparam,"%d",task->parameters());
                        task->work()  = "<work binary=\"" + binary + "\" imports=\"2\" params=\"" 
                                        + nparam + "\"><import host=\"" + mDRHost
                                        + "\" port=\"" + mDRPort + "\" uri=\"/"
                                        + mBinGroup + "/" + binary
                                        + "\" pack=\"no\" /><import host=\"" + mDRHost + "\" port=\"" + mDRPort
                                        + "\" uri=\"" + inputBaseName + "\" pack=\"yes\" /><export host=\""
                                        + mDRHost + "\" port=\"" + mDRPort + "\" uri=\"" + outputBaseName
                                        + "\" /><admin host=\"" + mDRHost + "\" port=\"" + mDRPort + "\" uri=\""+ adminBaseName + "\" />"
                                        + "<tmp uri=\"" + tmpBaseName + "\" />";
                        for(Yml::Core::uint32 i = 0 ; i < task->parameters() ; ++i){
				task->work()  =  task->work() + "<param name=\"" + task->parameter(i) + "\" />";
                        }
                        task->work()  =  task->work() + "</work>";

		}
		return executeImpl(task);
	}


	}
	}




