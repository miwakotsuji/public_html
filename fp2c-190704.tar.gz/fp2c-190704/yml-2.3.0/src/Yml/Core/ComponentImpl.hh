/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/

/**
 * @file
 * @brief Class ComponentImpl declaration
 *  
 * 2005-06-13
 * Olivier Delannoy
 */
#ifndef YML_CORE_COMPONENTIMPL_HH
#define YML_CORE_COMPONENTIMPL_HH 1
#include "core.hh"
#include "DistributeList.hh"
#include "ParameterList.hh"

#include <XMLSerializer.hh> 


namespace Yml {
namespace Core {
/**
 * @brief Implementation Component class.
 * 
 * The implementation component corresponds to binary
 * application executed on the middleware. This class
 * describes the component implementation code. The component
 * generator relies on this description to generate the
 * component binary.
 */
class ComponentImpl
{
public:
	/*!
      Constructor of componentImpl
	 */
	ComponentImpl();
	/*!
      Get the name of the component 
	 */
	const string& getName() const;
	/*!
      Set the name of the component 
	 */
	void setName(const string& name);
	/*!
      Get the name of the component abstract implemented 
	 */
	const string& getComponentAbstractName() const;
	/*!
      Set the name of the component abstract implemented 
	 */
	void setComponentAbstractName(const string& name);
	/*!
      Get the description of the component 
	 */
	const string& getDescription() const;
	/*!
      Set the description of the component 
	 */
	void setDescription(const string& description);
	/*!
      Get the implementation language used to define the component 
	 */
	const string& getImplLanguage() const;
	/*!
      Set the implementation language used to define the component 
	 */
	void setImplLanguage(const string& lang);
	/*!
      Parse the nodes attribute and set the NbNode, Type and Topology
	 */
	void setImplNodes(const string& nodes);
	/*!
      Get the total number of nodes and the distribution
	 */
	const int& getImplNbNodes() const;
	/*!
      Set the total number of nodes and the distribution
	 */
	void setImplNbNodes(const int& nodes);
	/*!
      Get the node type (CPU,GPU, ...)
	 */
	const string& getImplNodeType() const;
	/*!
      Set the node type (CPU,GPU, ...)
	 */
	void setImplNodeType(const string& nodes);
	/*!
       Get the node topology
	 */
	const string& getImplNodesTopology() const;
	/*!
       Set the node topology
	 */
	void setImplNodesTopology(const string& nodes);
	/*!
      Get the list of space separated library used to define the component 
	 */
	const string& getImplLibraries() const;
	/*!
      Set the list of space separated library used to define the component 
	 */
	void setImplLibraries(const string& list);
	/*!
      Add a library to the list of library used 
	 */
	void addImplLibrary(const string& library);
	/*!
      Get the header of the component source code 
	 */
	const string& getImplHeader() const;
	/*!
      Set the header of the component source code 
	 */
	void setImplHeader(const string& header);
	/*!
      Get the component computation code 
	 */
	const string& getImplSource() const;
	/*!
      Set the component computation code 
	 */
	void setImplSource(const string& source);
	/*!
      Get the footer of the component source code 
	 */
	const string& getImplFooter() const;
	/*!
      Set the footer of the component source code 
	 */
	void setImplFooter(const string& footer);
	/*!
     	 Get the list of data mapping
	 */
	const DistributeList& getDistributeList(void) const;
	/*!
      Get the list of data mapping
	 */
	DistributeList& getDistributeList(void);
	/*!
      Create an XML document representing the component description
	 */
	void toXML(Util::XMLSerializer& xmlStream) const;
        /*!
         Get the list of template
         */
        const TemplateList& getTemplateList(void) const;
        /*!
      Get the list of template
         */
        TemplateList& getTemplateList(void);

      


private:
	string mName;               //!< Store the name of the component
	string mAbstractName;       //!< Store the name of the abstract component implemented
	string mDescription;        //!< Store the description of the implementation
	string mImplLang;           //!< Store the name of the implementation language used
	string mImplLibs;           //!< Store the name of the libraries used by the implementation
	int mImplNbNodes;			//!< Total number of nodes YML and XMP extension
	string mImplNodesTopology;	//!< Nodes topology (5,6,2) YML and XMP extension
	string mImplNodeType;		//!< Type of nodes used YML and XMP extension
	string mImplHeader;         //!< Store the header of the component source code
	string mImplSource;         //!< Store the computation code of the component source code
	string mImplFooter;         //!< Store the footer of the component source code
	DistributeList mDistribute; //!< Store the data mapping of each parameter
        TemplateList mTemplate;
};
}
}
#ifdef HAVE_INLINE
#include "ComponentImpl.icc"
#endif
#endif

