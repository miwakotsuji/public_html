/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/
/**
 * @file
 * @brief Class YvetteParserDriver declaration
 *  
 * 2005-12-27
 * Olivier Delannoy
 */
#ifndef YML_CORE_YVETTEPARSERDRIVER_HH
#define YML_CORE_YVETTEPARSERDRIVER_HH 1
#include "core.hh"
#include "AST.hh"
#include "ParserError.hh" 
#include "location.hh" 
#include <string> 
#include <list>
#include <vector>
/** Typename for the Scanner and Parser */
#define YYSTYPE Yml::Core::AST*
namespace yy
{
    class location;
    class YvetteParser;
}
namespace Yml
{
    namespace Core
    {
        class YvetteParserDriver;
    }    
}

#define YY_DECL \
int yylex(YYSTYPE* yylval, yy::location* yylloc, Yml::Core::YvetteParserDriver& driver)
YY_DECL;

namespace Yml {
    namespace Core {
        /** 
         * Typename for a list of parsing error 
         */
        typedef std::list<ParserError> ErrorList;
        
        /**
         * @brief This class control the parsing operation of an Yvette program. 
         * 
         * This class define the frontend of the compiler. It parse an
         * input string corresponding to an Yvette program and build
         * the corresponding AST. The class also track errors. 
         *
         */
        class YvetteParserDriver
        {
        public:
            /**
             * Default Contstructor
             */
            YvetteParserDriver(bool traceScanner = false, bool traceParser = false);
            /**
             * Destructor
             */
            ~YvetteParserDriver(void);
            /** 
             * Does all of the parsing activity 
             *
             * @param input the string to parse
             *
             * @return a pointer to the AST resulting of the parsing
             * or 0 on error
             * 
             */
            AST* parse(const string& input);
            /**
             * Overloaded version of the parse function 
             * 
             * @param input the string to parse 
             *
             * @param length the size of @em input 
             *
             * @return a pointer to the AST resulting of the parsing
             * or 0 on error
             */
            AST* parse(const char* input, uint32 length);
            /**
             * Return the number of error detected
             */
            uint32 errorCount(void) const;
            /** 
             * Return the error list 
             */
            const ErrorList& errors(void) const;
            /** Return true if the tracing feature of the scanner is on */ 
            bool traceScanner(void) const;
            /** Return true if the tracing feature of the parser is on */  
            bool traceParser(void) const;
              /** Error reporting from Flex and Bison */
            void error(const yy::location& l, const std::string& m);
            /** Error reporting from Flex and Yacc */
            void error(const std::string& m);
            /** Return the root node of the whole parsing tree */
            AST& root(void);
            /** Initialize the scanner */ 
            void beginScan(const char* tmp, uint32 length);             
            /** Terminate the scanner */
            void endScan(void);

            AST* newASTNode();
        protected:
            
        private:
            /** True if the tracing of the scanner is enabled */
            bool mTraceScanner;
            /** True if the tracing of the parser is enabled */
            bool mTraceParser;
            /** Store the number of error (counting error from a list is in O(n))*/
            uint32 mErrorCount;
            /** Store all errors */
            ErrorList mErrors;
            /** Store the result of the parsing */
            AST* mAST;
            /** For internal use only */
            void* mBuffer;
            
            /** Store ast node for clean cleanup */
            std::vector<AST*> mASTNodes;
        };
    }
}
#ifdef HAVE_INLINE
#include "YvetteParserDriver.icc"
#endif
#endif
