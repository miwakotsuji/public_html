/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/

/**
 * @file
 * @brief Class YvetteObject function definition 
 *
 * 2005-06-28
 * Olivier Delannoy
 */
#include "YvetteObject.hh"
#ifndef HAVE_INLINE
#define inline
#include "YvetteObject.icc"
#undef inline
#endif 

#include <sstream>
#include <cassert>
#include <cstring>
const Yml::Core::YvetteObject Yml::Core::YvetteObject::INVALID_OBJECT;

Yml::Core::YvetteObject::YvetteObject(void)
    : mType(Yml::Core::YvetteObject::INVALID)
{
    mData.mInteger = 0;
    
}


Yml::Core::YvetteObject::YvetteObject(Yml::Core::int32 value)
    : mType(Yml::Core::YvetteObject::INTEGER)
{
    mData.mInteger = value;
}
Yml::Core::YvetteObject::YvetteObject(Yml::Core::real64 value)
    : mType(Yml::Core::YvetteObject::REAL)
{
    mData.mReal = value;
}

Yml::Core::YvetteObject::YvetteObject(const Yml::Core::string& value)
    : mType(Yml::Core::YvetteObject::STRING)
{
    
    mData.mString = new Yml::Core::string(value);
    assert(mData.mString);
}


Yml::Core::YvetteObject::~YvetteObject(void)
{
}
Yml::Core::YvetteObject::YvetteObject(const Yml::Core::YvetteObject& obj)
  : mType(obj.mType)
{
  memcpy((char*)&mData, (char*)&(obj.mData), sizeof(mData));
  if (obj.mType == STRING)
  {
    mData.mString = new Yml::Core::string(*(obj.mData.mString));
  }
}
Yml::Core::YvetteObject& Yml::Core::YvetteObject::operator=(const Yml::Core::YvetteObject& obj)
{
  if (&obj != this)
  {
    if (mType == STRING)
    {
      delete mData.mString;
    }
    mType = obj.mType;
    memcpy((char*)&mData, (char*)&(obj.mData), sizeof(mData));
    if (mType == STRING)
    {
      mData.mString = new Yml::Core::string(*(obj.mData.mString));
    }
    
  }
  return *this;
}

Yml::Core::uint32 Yml::Core::YvetteObject::getType(void) const
{
  return mType;
}


bool Yml::Core::YvetteObject::isTrue(void) const
{
    switch(mType)
    {
    case INTEGER:
        return mData.mInteger != 0;

    case REAL:
        return (Yml::Core::int32)mData.mReal != 0;
        
        
    case STRING:
        return ((*(mData.mString)).size() != 0);
    }
    return false;
}

Yml::Core::int32 Yml::Core::YvetteObject::integerValue(void) const
{
    switch(mType)
    {
    case INTEGER:
        return mData.mInteger;
    case REAL:
        return (Yml::Core::int32) mData.mReal;
    case STRING:
        Yml::Core::int32 res;
        std::istringstream formater(*(mData.mString));
        formater >> res;
        return res;
    }
    return 0;
}


Yml::Core::real64 Yml::Core::YvetteObject::realValue(void) const
{
    switch(mType)
    {
    case INTEGER:
        return (Yml::Core::real64) mData.mInteger;

    case REAL:
        return mData.mReal;

    case STRING:
        std::istringstream formater(*(mData.mString));
        Yml::Core::real64 res ;
        formater >> res;
        return res;
    }
    return 0.0;   
}


Yml::Core::string Yml::Core::YvetteObject::stringValue(void) const
{
    std::ostringstream formater;
    switch(mType)
    {
    case INTEGER:
        formater << mData.mInteger;
        return  formater.str();
        
        
    case REAL:
        formater << mData.mReal;
        return formater.str();
        
        
    case STRING:
        return *(mData.mString);    
    }
    return "";
}



void Yml::Core::YvetteObject::print(std::ostream& out) const
{
    switch(mType)
    {
    case INTEGER:
        out << "INTEGER<<<" << mData.mInteger << ">>>";
        break;
        
    case REAL:
        out << "REAL<<<" << mData.mReal << ">>>" ;
        break;
        
    case STRING:
        out << "STRING<<<" << *(mData.mString) << ">>>";
        break;
        
    default:
        out << "INVALID<<<>>>";
    }
}



