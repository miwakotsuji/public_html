/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy, Maxime Hugues 2011
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 * Maxime Hugues
 *   Maxime.Hugues@gmail.com or Maxime.Hugues@inria.fr
 *	 INRIA Saclay
 *   PCRI - Bureau 142
 *   Rue Noetzlin
 *   91190 Gif-sur-Yvette France
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/

/**
 * @file
 * @brief Class Parameter declaration
 *  
 * 2005-06-13
 * Olivier Delannoy
 */
#ifndef YML_CORE_PARAMETER_HH
#define YML_CORE_PARAMETER_HH 1
#include "core.hh"
#include <vector>
namespace Yml {
namespace Core {
/**
 * @brief Component Parameter Description class 
 *
 * Store Component Parameter Description 
 */
class Parameter
{
public:
    /**
     * Default Contstructor
     */
    Parameter(void);
    /**
     * Destructor
     */
    ~Parameter(void);
     
    /** Set Name */
    void setName(const string& name);
    /** retrieve the name */
    const string& getName(void) const;
    /** Set the typename of data */
    void setType(const string& name);
    /** Get the typename of data */
    const string& getType(void) const;
    /** Set the description of the parameter */
    void setDescription(const string& description);
    /** Get the description of the parameter */
    const string& getDescription(void) const;
    /** Set wether the parameter is a collection or not */
    void setIsCollection(bool collection);
    /** Get wether the parameter is a collection or not */ 
    bool isCollection() const;
    /** Set the communication mode of the parameter */
    void setIOMode(ParameterIOMode mode);
    /** Get the communication mode of the parameter */
    ParameterIOMode getIOMode(void) const;
    /** Set the data mapping on nodes of the parameter */
    void setMapping(const std::vector<ParameterMapping>& mapping);
    /** Get the data mapping on nodes of the parameter */
    std::vector<ParameterMapping> getMapping(void) const;
    /** Set the data size of the parameter */
    void setSize(const std::vector<int>& size);
    /** Get the data size of the parameter */
    std::vector<int> getSize(void) const;
    void setDataAlign(const string& align);
    /** Get the data alignment of the parameter */
    string getDataAlign(void) const;
    /** Set the template alignment of the parameter */
    void setTemplateAlign(const string& align);
    /** Get the template alignment of the parameter */
    string getTemplateAlign(void) const;
    /** Set the template of the parameter */
    void setTemplateName(const string& str);
    /** Get the template of the parameter */
    string getTemplateName(void) const;
    /** Set the template of the parameter */
    void setTemplatePrint(const string& str);
    /** Get the template of the parameter */
    string getTemplatePrint(void) const;
    /** Set node **/
    void setNode(const string&str);
    /** Get node **/
    const string& getNode(void) const;

protected:
            
private:
    string mName; //!<  Store the name of the parameter
    string mType; //!< Store the type of the parameter 
    string mDescription; //!< Store the description of the parameter 
    bool mCollection; //!< Store wether the parameter is a collection or not
    ParameterIOMode mMode; //!<  Store the IO mode of the parameter
    std::vector<ParameterMapping> mMapping; //!< Defined for XMP extension. Define the mapping of data on cores
    string mDataAlign; //!<  Store the data alignment of the parameter
    string mTemplateAlign; //!<  Store the template alignment of the parameter
    std::vector<int> mSize;
    string mTemplateName; // store the template name
    string mTemplatePrint; // store the template descrpition
    string mNode;           // nodes onto which mTemplateName is distributed  

};
}
}
#ifdef HAVE_INLINE
#include "Parameter.icc"
#endif
#endif

