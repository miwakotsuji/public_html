/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Maxime Hugues 2011
 *
 * Maxime Hugues
 *   Maxime.Hugues@gmail.com or Maxime.Hugues@inria.fr
 *	 INRIA Saclay
 *   PCRI - Bureau 142
 *   Rue Noetzlin
 *   91190 Gif-sur-Yvette France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/

/**
 * @file
 * @brief Class Distribute declaration
 *  
 * 2011-09-20
 * Maxime Hugues
 */
#ifndef YML_CORE_DISTRIBUTEPARAM_HH
#define YML_CORE_DISTRIBUTEPARAM_HH 1
#include "core.hh"
#include <vector>
#include <algorithm>
namespace Yml {
namespace Core {
/**
 * @brief Component DistributeParam Description class
 *
 * Store Component DistributeParam Description
 */
class DistributeParam
{
public:
    /**
     * Default Contstructor
     */
	DistributeParam(void);
    /**
     * Destructor
     */
    ~DistributeParam(void);
     
    /** Set Name */
    void setName(const string& name);
    /** retrieve the name */
    const string& getName(void) const;
    /** Set the data mapping on nodes of the parameter */
    void setMapping(const std::vector<ParameterMapping>& mapping);
    /** Get the data mapping on nodes of the parameter */
    std::vector<ParameterMapping> getMapping(void) const;
    /** Set the data alignment of the parameter */
    void setDataAlign(const string& align);
    /** Get the data alignment of the parameter */
    string getDataAlign(void) const;
    /** Set the template alignment of the parameter */
    void setTemplateAlign(const string& align);
    /** Get the template alignment of the parameter */
    string getTemplateAlign(void) const;
    /** Set the data size of the parameter */
    void setSize(const std::vector<int>& size);
    /** Get the data size of the parameter */
    std::vector<int> getSize(void) const;
    /** Set the name of template **/
    void setTemplateName(const string& template_name);
    /** Get the name of template **/
    const string& getTemplateName(void) const;
    /** Set the name of template **/
    void setTemplatePrint(const string& str);
    /** Get the name of template **/
    const string& getTemplatePrint(void) const;
    /** Set node **/
    void setNode(const string& node);                          
    /** Get node **/
    const string& getNode(void) const; 

private:
    string mName; //!<  Store the name of the parameter
    std::vector<ParameterMapping> mMapping; //!<  Store the IO mode of the parameter
    string mDataAlign; //!<  Store the data alignment of the parameter
    string mTemplateAlign; //!<  Store the template alignment of the parameter
    std::vector<int> mSize; //!<  Store the size of the parameter
    string mTemplateName;   // Store the name of template for this array
    string mTemplatePrint;  // Store #pragma xmp ... 
    string mNode;                          // nodes onto which this template is distributed  
};

/* Store Template parameters */
class TemplateParam
{
public:
  TemplateParam(void);
  ~TemplateParam(void);

  void setName(const string& name);                             // set name
  void setNode(const string& node);                             // set node
  void setPrint(const string& prt);                             // set print
  void setFormat(const std::vector<ParameterMapping>& mapping); // set distribution format
  void setSize(const std::vector<int>& size);                   // set size of array
  const string& getName(void) const;                            // get name
  const string& getNode(void) const;                            // get node
  const string& getPrint(void) const;                           // get print
  std::vector<int> getSize(void) const;                         // get size
  std::vector<ParameterMapping> getFormat(void) const;          // get format

private:
  string mName;                          // template name
  string mNode;                          // nodes onto which this template is distributed  
  string mPrint;                         // #pragma xmp template ... 
  std::vector<ParameterMapping> mFormat; // (list of) distribution format
  std::vector<int> mSize;                // (list of) size
};

}
}
#ifdef HAVE_INLINE
#include "DistributeParam.icc"
#endif
#endif

