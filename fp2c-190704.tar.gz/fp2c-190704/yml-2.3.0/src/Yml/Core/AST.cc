/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/

/**
 * @file
 * @brief Abstract Syntax Tree  
 *  
 * 2005-06-18
 * Olivier Delannoy
 */
#include "AST.hh"
#ifndef HAVE_INLINE
#define inline 
#include "AST.icc"
#undef inline 
#endif 
namespace Yml
{
    namespace Core
    {
        AST::AST(void) : mType(0), mLine(0), mParent(0), mChild(0), mNext(0)
        {
        }

        AST::~AST(void)
        {
        }

        void AST::reset(void)
        {
            mType = 0;
            mParent = 0;
            mChild = 0;
            mNext = 0;
            mLine = 0;
        }


        void AST::printTree(std::ostream& out, uint32 level)
        {
            for(uint32 i = 0;i < level ; ++i)
                out << "  ";
            out << '[' << mLine << ':'  << mType << ':' << mText << ']' << std::endl;
            if (mChild)
                mChild->printTree(out, level + 1);
            if (mNext)
                mNext->printTree(out, level);
        }

        uint32 AST::getType(void) const 
        {
            return mType;
        }
        void AST::setType(uint32 type) 
        {
            mType = type; 
        }
        const string& AST::getText(void) const
        {
            return mText;
        }
        void AST::setText(const string& text) 
        {
            mText = text; 
        }
        uint32 AST::getLine(void) const
        {
            return mLine;
        }
        void AST::setLine(uint32 line)
        {
            mLine = line; 
        }
        void AST::setFirstChild(AST* child)  
        {
            mChild = child;
        }
        AST* AST::getFirstChild(void)
        {
            return mChild; 
        }
        void AST::setNextSibling(AST* nextSibling)
        {
            mNext = nextSibling;
        }
        AST* AST::getNextSibling(void) 
        {
            return mNext;
        }
        void AST::setParent(AST *parent)
        {
            mParent = parent; 
        }
        AST* AST::getParent(void)
        {
            return mParent;
        }
        std::ostream& operator<<(std::ostream& out, AST& obj)
        {
            obj.printTree(out, 0);
            return out;
        }
    }
}
