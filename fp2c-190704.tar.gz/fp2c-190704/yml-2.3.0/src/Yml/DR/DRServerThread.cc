/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/
/**
 * @file
 * @brief Class DRServerThread function definition 
 *
 * @todo Make the protocol better than what it is at the moment 
 * 2006-03-19
 * Olivier Delannoy
 */
#include "DRServerThread.hh"
//Util includes 
#include <LoggerFactory.hh>
#include <RuntimeEnvironment.hh> 
#include <Dir.hh>

// Sys includes 
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <cerrno>
#include <cstring>
#include <cstdio>
namespace Yml
{
    namespace DR
    {
        DRServerThread::DRServerThread(Util::TCPRemoteClient* client, const string& root)
            : mClient(client), mRoot(root)
        {
            UTIL_INFO("", "Create DRServerThread object " << this);
        }
        DRServerThread::~DRServerThread(void)
        {
            UTIL_INFO("", "Destroy DRServerThread object " << this);
        }
        void DRServerThread::run(void)
        {
            UTIL_DEBUG("", "enter DRServerThread::run(void)");
            if (! mClient)
            {
                UTIL_WARN("", "Worker: No client specified");
                return;
            }

            
            // Header information 
            uint16 queryType;
            uint16 uriSize;
            string uri;
            uint32 dataSize;
            
            int data;
            int status; // Store status information
            //void *src_addr; // mmap address
            struct stat stat_buf; //File stats
            uint32 offset;
            uint32 toRead;
            bool completeHeader;
            uint32 tmp;
            completeHeader = false;
            queryType = 1;
            while(queryType)
            {        
                // Decode header 
                status = mClient->read(reinterpret_cast<byte*>(buffer), SIZE);
                UTIL_DEBUG("", "Read " << status << " bytes");
                offset = 0;
                if (status == -1)
                {
                    //It's an error 
                    UTIL_INFO("", "Worker: Read error");
                    return;
                }
                
                queryType = 0xffff;
                uriSize = 0;
                dataSize = 0;
                // Decode header 
                while(status - offset > 0 && queryType)
                {
                    UTIL_DEBUG("", "Parse header: " << offset << '/' << status);
                    // Decode the queryType 
                    if (offset < sizeof(queryType))
                    {
                        toRead = sizeof(queryType) - offset;
                        toRead = status - offset - toRead > 0 ? toRead : status - offset;
                        memcpy((char*)&queryType + sizeof(queryType) - toRead, buffer + offset, toRead);
                        offset += toRead;
                    }
                    // Decode the uriSize 
                    else if (offset < (sizeof(queryType) + sizeof(uriSize)))
                    {
                        toRead = sizeof(uriSize) - offset + sizeof(queryType);
                        toRead = (status - offset - toRead) > 0 ? toRead : status - offset;
                        memcpy((char*)&uriSize + sizeof(uriSize) - toRead, buffer + offset, toRead);
                        offset += toRead;
                    }
                    else if (offset < (sizeof(queryType) + sizeof(uriSize) + sizeof(dataSize)))
                    {
                        toRead = sizeof(dataSize) - offset + sizeof(queryType) + sizeof(uriSize);
                        toRead = status - offset - toRead > 0 ? toRead : status - offset;
                        memcpy((char*)&dataSize + sizeof(dataSize) - toRead, buffer + offset, toRead);
                        offset += toRead;
                        uri.clear();
                    }
                    else if (offset < sizeof(queryType) + sizeof(uriSize) + sizeof(dataSize) + uriSize)
                    {
                        toRead = uriSize - offset + sizeof(queryType) + sizeof(uriSize) + sizeof(dataSize);
                        toRead = status - offset - toRead > 0 ? toRead : status - offset;
                        uri += string(buffer + offset, toRead);
                        offset += toRead;
                    }
                    if (offset == sizeof(queryType) + sizeof(uriSize) + 
                        sizeof(dataSize) + uriSize)
                    {
                        UTIL_DEBUG("", "Header complete");
                        UTIL_DEBUG("", "Query Type: " << queryType);
                        UTIL_DEBUG("", "Uri Size: " << uriSize);
                        UTIL_DEBUG("", "Data Size: " << dataSize);
                        UTIL_DEBUG("", "Uri: " << uri);
                        completeHeader = true;
                        break;
                    }
                }
                // Handle the query itself 
                if (completeHeader) 
                {
                    // handle the query 
                    // At this point we have 
                    // queryType (GET/PUT)
                    // uriSize 
                    // dataSize
                    // uri (file full path name) 
                    if (queryType == 1) // Get 
                    {
                        bool error = false;
                        UTIL_INFO("", "Request: GET " << uri);
                        string fullname = mRoot + uri;
                        dataSize = 0;
                        UTIL_DEBUG("", "Request GET local filename " << fullname);        
                        
                        // Send the size (4 bytes) 
                        // Send the data
                        // Allow missing files 
                        data = open(fullname.c_str(),  O_RDONLY);
                        if (! data)
                        {
                            UTIL_ERROR("", "Resource does not exists " << uri);
                            mClient->send(reinterpret_cast<byte*>(&dataSize), sizeof(dataSize));
                            completeHeader = false;
                        }
                        else 
                        {
                            if ( fstat(data, &stat_buf) == -1 ) 
                            {
                                close(data);       
                                UTIL_ERROR("", "Unable to stat" << fullname); // Strange 
                                mClient->send(reinterpret_cast<byte*>(&dataSize), sizeof(dataSize));
                            }
                            else
                            {   
                                //Don't use mmap cause it might cause problem 
                                /*
                                src_addr = mmap(0, stat_buf.st_size, PROT_READ,MAP_NORESERVE|MAP_PRIVATE,data,0);
                                if ( src_addr==MAP_FAILED ) 
                                {
                                    UTIL_ERROR("", "Mapping error on file " << fullname);
                                    mClient->send(reinterpret_cast<byte*>(&dataSize), sizeof(dataSize));
                                }
                                else
                                {
                                    dataSize = stat_buf.st_size;
                                    status = mClient->send(reinterpret_cast<byte*>(&dataSize), sizeof(dataSize));
                                    UTIL_DEBUG("", "Send data size " << sizeof(dataSize) << " bytes");
                                       
                                        
                                    if (status == -1)
                                    {
                                        UTIL_ERROR("", "Failed sending the size of the result");
                                        dataSize = 0;
                                    }
                                    if (dataSize)
                                    {  

                                        UTIL_DEBUG("", "Send data " << dataSize << " bytes");
                                        status = mClient->send(reinterpret_cast<byte*>(src_addr), dataSize);
                                        if (status == -1)
                                        {
                                            UTIL_ERROR("", "Sending of the data failed");
                                        }
                                        munmap(src_addr,stat_buf.st_size);   
                                    }
                                }
                                */
                                dataSize = stat_buf.st_size;
                                status = mClient->send(reinterpret_cast<byte*>(&dataSize), sizeof(dataSize));
                                UTIL_DEBUG("", "Send data size " << sizeof(dataSize) << " bytes");
                                if (status == -1)
                                {
                                    UTIL_ERROR("", "Failed sending the size of the result");
                                    dataSize = 0;
                                    error = true;
                                }
                                size_t readed = 0;       
                                while(!error && readed < dataSize)
                                {
                                    int status = read(data, buffer, SIZE);
                                    if (status == -1)
                                    {
                                        UTIL_ERROR("", "Read failed");
                                        error = true;
                                    }
                                    else
                                    {
                                        readed += status;
                                        if (mClient->send(reinterpret_cast<byte*>(buffer), status) != status)
                                        {
                                            UTIL_ERROR("", "Send failed");
                                            error = true;
                                        }
                                    }
                                }
                                
                            }
                            close(data);
                        }
                        if (error)
                        {
                            UTIL_INFO("", "Request failed, aborting transaction");
                            delete mClient;
                            return;
                        }
                        else if (mClient->recv(reinterpret_cast<byte*>(&tmp), sizeof(tmp)) == 4 && tmp == dataSize)
                        {
                            UTIL_INFO("", "Request GET " << uri << " finished");
                        }
                        else 
                        {
                            UTIL_ERROR("", "Request GET " << uri << " failed");
                        }
                        
                    }
                    // handle the query 
                    // At this point we have 
                    // queryType (GET/PUT)
                    // uriSize 
                    // dataSize
                    // uri (file full path name) 
                    else if (queryType == 2) // Put 
                    {
                        UTIL_INFO("", "Request: PUT " << uri << " (" << dataSize << " bytes)");
                        string fullname = mRoot + uri;
                        UTIL_DEBUG("", "Request PUT local filename " << fullname);
                        // Try opening dest 
                        // Get Dirname and base name 
                        size_t pos = fullname.find_last_of(Util::RuntimeEnvironment::PATH_SEPARATOR);
                        string dirname = fullname.substr(0, pos);
                        UTIL_DEBUG("", "Request PUT local dirname " << dirname);
                        Util::Dir::mkdir(dirname);
                        
                        int data = open(fullname.c_str(), O_RDWR | O_CREAT | O_TRUNC, 0666);
                        if (data == -1)
                        {
                            UTIL_ERROR("", "Failed opening " << fullname);
                        }
                        uint32 dataRead = 0;
                        int status2 = ::write(data, buffer + offset, status - offset);
                        dataRead += status2;
                        bool error = false;
                        
                        while(!error && dataRead < dataSize)
                        {
                            uint32 toRead = SIZE < dataSize - dataRead ? SIZE : dataSize - dataRead;
                            status = mClient->recv(reinterpret_cast<byte*>(buffer), toRead);
                            if (status == -1)
                            {
                                // Reading error 
                                UTIL_ERROR("", "Reading from network failed");
                                error = true;
                            }
                            else 
                            {
                                // Write posix clear and efficient :) 
                                ::write(data, reinterpret_cast<char*>(buffer), status);
                                dataRead += status;
                            }
                            UTIL_DEBUG("", "Progress " << status << "/" << toRead << "(" << dataRead << "/" << dataSize << ")");
                        }
                        UTIL_INFO("", "Request PUT " << uri << " finished");
//#ifdef HAVE_DEBUG
                        mClient->send(reinterpret_cast<byte*>(&dataRead), sizeof(dataRead));
//#endif
                        ::close(data);
                        
                    }
                    else if (queryType != 0)
                    {
                        // Invalid Query 
                        UTIL_ERROR("", "Unsupported query type: "<< queryType);
                        delete mClient;
                        return;
                    }
                }
                
            }
            delete mClient;
            UTIL_INFO("", "Closing client connexion");
        }
    }    
}

