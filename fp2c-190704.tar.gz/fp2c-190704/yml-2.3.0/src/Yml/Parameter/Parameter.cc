/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/

/**
 * @file
 * @brief Class Parameter function definition 
 *
 * 2006-11-04
 * Olivier Delannoy
 */
#include <Yml/Core/core.hh>
#include <Yml/Core/YvetteApplication.hh>  
#include <Application.hh>
#include <CommandLineParser.hh>
#include <CommandLineOption.hh>
#include <ConfigFactory.hh>
#include <LoggerFactory.hh>
#include <Pack.hh>
#include <ConsoleApplicationAdaptor.hh>
#include <RuntimeEnvironment.hh>
#include <Dir.hh>
#include <sstream> 
#include <algorithm> 
#include <set>
#include <locale>
namespace Yml
{
/** 
 * @brief 
 * Parameter namespace 
 *
 * This namespace includes the definition of the parameter tool. This tool provides the services needed to 
 * create initial parameter pack for an application. This initial parameter pack is used to pass initial 
 * data to an application. 
 * 
 * The same prorgam also deals with the extraction of the results from the result pack. This program is similar 
 * to the tar program in its behavior. 
 */
namespace Parameter 
{
/** Signed integer of 8 bits */ 
typedef Yml::Core::int8 int8;    
/** Unsigned integer of 16 bits */
typedef Yml::Core::uint16 uint16;
/** Signed integer of 16 bits */
typedef Yml::Core::int16 int16;  
/** Unsigned integer of 32 bits */
typedef Yml::Core::uint32 uint32; 
/** Signed integer of 32 bits */
typedef Yml::Core::int32 int32;  
/** Unsigned integer of 64 bits */ 
typedef Yml::Core::uint64 uint64;
/** Signed integer of 64 bits */ 
typedef Yml::Core::int64 int64;  
/** 32 bits Real number */
typedef Yml::Core::real32 real32;
/** 64 bits Real number */
typedef Yml::Core::real64 real64;
/** a byte 8 bits long data */
typedef Yml::Core::byte byte;    
/** a word 16 bits long data */ 
typedef Yml::Core::word word;   
/** a double word 32 bits long data */  
typedef Yml::Core::dword dword; 
/** a quad word 64 bits long data */
typedef Yml::Core::qword qword;  
/** a string of text */
typedef Yml::Core::string string;
/** The command apply to inputs/outputs or both */
enum TARGET
{
    TARGET_INPUT, 
    TARGET_OUTPUT, 
    TARGET_BOTH, 
};
/** The command itself */
enum COMMAND
{
    CMD_NA = 0, 
    CMD_LIST,
    CMD_STATUS,
    CMD_EXTRACT_ALL,
    CMD_EXTRACT, 
    CMD_ADD,    
};
/** Source/Dest for command EXTRACT and ADD */
enum PARAMETER_TYPE
{
    PARAM_NA = 0, 
    PARAM_FILE, 
    PARAM_INTEGER, 
    PARAM_REAL, 
    PARAM_STRING,
};


/**
 * @brief 
 * initial data and result management for applications 
 * 
 * This program allow one to manipulate a set of parameters/results
 * given/produce to/by an application scheduling. Using this
 * application one can prepare a set of parameters that are going to 
 * used during the execution. 
 * 
 * @since YML 1.0.5 
 */
class Parameter : public Util::Application 
{
public:
    Parameter(Util::ApplicationAdaptor* adaptor, int argc, char** argv) 
        : Util::Application(adaptor, argc, argv)
    {
	    std::locale::global(std::locale("C"));
    }

    ~Parameter(void)
    {   
    }
    
    void configureCommandLine(void);
    
    uint32 run(void);

    string usageQuick(void) const
    {
        return " --app=<application> --pack=<application> [commands]";
    }
    string usageParameters(void) const
    {
        return "";
    }
    string usageOptions(void) const
    {
        return 
            "\n *--app=<application> ..: The corresponding compiled application" \
            "\n  --pack=<pack> ........: The pack we are going to manipulate" \
            "\n  --list ...............: List all parameters defined by an application" \
            "\n  --list-input .........: List all input parameter defined by an application" \
            "\n  --list-output ........: List all output parameter defined by an application" \
            "\n" \
            "\n  --status .............: Status of all parameters" \
            "\n  --status-input .......: Status of all parameters in input" \
            "\n  --status-output ......: Status of all parameters in output" \
            "\n" \
            "\n  --extract-all=<dir> ..: Extract all data in the pack to dir" \
            "\n  --extract=<name> .....: Extract data name" \
            "\n  --extract-dest=<file> : Extract name to file if the option" \
            "\n" \
            "\n  --add=<name> .........: Add a resource to the pack name" \
            "\n  --integer=<value> ....: Set name as an integer set to value" \
            "\n  --real=<value> .......: Set name as a real set to value" \
            "\n  --string=<value> .....: Set name as a string set to value" \
            "\n  --file=<file> ........: Set name as the content of file";
    }
    string configDir(void) const
    {
        return CONFIG_DIR;
    }
    string loggersDir(void) const
    {
        return Util::ConfigFactory::getSingleton().create("yml")->get("path", "loggers", ".");  
    }
    string pluginDir(void) const 
    {
        return Util::ConfigFactory::getSingleton().create("yml")->get("path", "plugins", ".");
    }
    static string convertNameToYML(string name);
    static string convertYMLToName(string name);
    static string printMode(Yml::Core::ParameterIOMode mode);
    
};

struct ExtractFile : public std::unary_function<const Util::PackEntry&, void>
{
    ExtractFile(Util::Pack pack, const string& targetPath)
        : d_pack(pack), d_target(targetPath)
    {
    }
    
    
    void operator()(const Util::PackEntry& p)
    {
        d_pack.extract(p.d_name, d_target + Util::RuntimeEnvironment::PATH_SEPARATOR + Parameter::convertYMLToName(p.d_name));
    }
    Util::Pack& d_pack;
    const string& d_target;
};

    


void Parameter::configureCommandLine()
{
    // First parameter is the query itself
    const string empty("");
    mCmdLineParser->parameterCount(0);
    mCmdLineParser->addOption(new Util::CommandLineOption("app", empty, true, true));
    mCmdLineParser->addOption(new Util::CommandLineOption("pack", empty, true));
    mCmdLineParser->addOption(new Util::CommandLineOption("list"));        // No pack needed  //cmd
    mCmdLineParser->addOption(new Util::CommandLineOption("list-input"));  // no pack needed  //cmd
    mCmdLineParser->addOption(new Util::CommandLineOption("list-output")); // no pack needed  //cmd 

    // Pack needed for the other options 
    mCmdLineParser->addOption(new Util::CommandLineOption("status"));                         //cmd
    mCmdLineParser->addOption(new Util::CommandLineOption("status-input"));                   //cmd
    mCmdLineParser->addOption(new Util::CommandLineOption("status-output"));                  //cmd
    mCmdLineParser->addOption(new Util::CommandLineOption("extract-all", empty, true));       //cmd

    // Extract and its suboption
    mCmdLineParser->addOption(new Util::CommandLineOption("extract", empty, true));           //cmd
    mCmdLineParser->addOption(new Util::CommandLineOption("extract-to", empty, true));        //sub

    // Add and its suboptions 
    mCmdLineParser->addOption(new Util::CommandLineOption("add", empty, true));               //cmd
    mCmdLineParser->addOption(new Util::CommandLineOption("integer", empty, true));           //sub
    mCmdLineParser->addOption(new Util::CommandLineOption("real", empty, true));              //sub
    mCmdLineParser->addOption(new Util::CommandLineOption("string", empty, true));            //sub
    mCmdLineParser->addOption(new Util::CommandLineOption("file", empty, true));              //sub
}



uint32 Parameter::run(void)
{
    // Parse command line 
    
    // Extract the name of the application (compiled)
    Util::CommandLineOption* option = mCmdLineParser->option("app");
    string applicationFile = option->value();
    if (applicationFile.empty())
    {
        UTIL_ERROR("default", "No application file specified");
        return ERROR;
    }
    // Extract the name of the pack if any 
    option = mCmdLineParser->option("pack");
    string packFile = option->value();
    
    // Parse the commands 
    COMMAND cmd = CMD_NA;
    TARGET target = TARGET_BOTH;
    // For extract-all /extract+extract-to add+file 
    string path;
    // For add and Extract 
    PARAMETER_TYPE type = PARAM_NA;
    string pname;
    string pvalueS;
    int32 pvalueI;
    real64 pvalueR;
    
    // List command 
    if (mCmdLineParser->option("list")->count())
    {
        if (cmd != CMD_NA)
        {
            UTIL_ERROR("default", "One command is allowed at a time");
            return ERROR;
        }
        cmd = CMD_LIST;
        target = TARGET_BOTH;
    }
    if (mCmdLineParser->option("list-input")->count())
    {
        if (cmd != CMD_NA)
        {
            UTIL_ERROR("default", "One command is allowed at a time");
            return ERROR;
        }
        cmd = CMD_LIST;
        target = TARGET_INPUT;
    }
    if (mCmdLineParser->option("list-output")->count())
    {
        if (cmd != CMD_NA)
        {
            UTIL_ERROR("default", "One command is allowed at a time");
            return ERROR;
        }
        cmd = CMD_LIST;
        target = TARGET_OUTPUT;
    }
    // Status command 
    if (mCmdLineParser->option("status")->count())
    {
        if (cmd != CMD_NA)
        {
            UTIL_ERROR("default", "One command is allowed at a time");
            return ERROR;
        }
        cmd = CMD_STATUS;
        target = TARGET_BOTH;
    }
    if (mCmdLineParser->option("status-input")->count())
    {
        if (cmd != CMD_NA)
        {
            UTIL_ERROR("default", "One command is allowed at a time");
            return ERROR;
        }
        cmd = CMD_STATUS;
        target = TARGET_INPUT;
    }
    if (mCmdLineParser->option("status-output")->count())
    {
        if (cmd != CMD_NA)
        {
            UTIL_ERROR("default", "One command is allowed at a time");
            return ERROR;
        }
        cmd = CMD_STATUS;
        target = TARGET_OUTPUT;
    }
    // Extraction command 
    option = mCmdLineParser->option("extract-all");
    if (option->count())
    {
        if (cmd != CMD_NA)
        {
            UTIL_ERROR("default", "One command is allowed at a time");
            return ERROR;
        }
        cmd = CMD_EXTRACT_ALL;
        // Set target here as well 
        path = option->value();
        if (path.empty())
        {
            UTIL_ERROR("default", "--extract-all command required a path");
            return ERROR;
        }
    }
    option = mCmdLineParser->option("extract");
    if (option->count())
    {
        if (cmd != CMD_NA)
        {
            UTIL_ERROR("default", "One command is allowed at a time");
            return ERROR;
        }
        cmd = CMD_EXTRACT;
        pname = option->value();
        if (pname.empty())
        {
            UTIL_ERROR("default", "--extract command require a parameter name");
            return ERROR;
        }
    }
    option = mCmdLineParser->option("add");
    if (option->count())
    {
        if (cmd != CMD_NA)
        {
            UTIL_ERROR("default", "One command is allowed at a time");
            return ERROR;
        }
        cmd = CMD_ADD;
        pname = option->value();
        if (pname.empty())
        {
            UTIL_ERROR("default", "--add command require a parameter name");
            return ERROR;
        }
    }
    
    // Suboptions 
    option = mCmdLineParser->option("extract-to");
    if (option->count())
    {
        if (cmd != CMD_EXTRACT)
        {
            UTIL_ERROR("default", "--extract-to=<path> is only valid when using command --extract");
            return ERROR;
        }
        path = option->value();
        if (path.empty())
        {
            UTIL_ERROR("default", "--extract-to=<path> require a path");
            return ERROR;
        }
        type = PARAM_FILE;
    }

    option = mCmdLineParser->option("integer");
    if (option->count())
    {
        if (cmd != CMD_ADD)
        {
            UTIL_ERROR("default", "--integer=<value> is only valid when using command --add");
            return ERROR;
        }
        std::istringstream in(option->value());
        in >> pvalueI;
        if (! in)
        {
            UTIL_ERROR("default", "--integer=<value> requires value to be an integer");
            return ERROR;
        }
        type = PARAM_INTEGER;
    }
    option = mCmdLineParser->option("real");
    if (option->count())
    {
        if (cmd != CMD_ADD)
        {
            UTIL_ERROR("default", "--real=<value> is only valid when using command --add");
            return ERROR;
        }
        std::istringstream in(option->value());
        in >> pvalueR;
        if (!in)
        {
            UTIL_ERROR("default", "--real=<value> requires value to be a real");
            return ERROR;
        }
        type = PARAM_REAL;
    }
    option = mCmdLineParser->option("string");
    if (option->count())
    {
        if (cmd != CMD_ADD)
        {
            UTIL_ERROR("default", "--string=<value> is only valid when using command --add");
            return ERROR;
        }
        pvalueS = option->value();
        type = PARAM_STRING;
    }
    option = mCmdLineParser->option("file");
    if (option->count())
    {
        if (cmd != CMD_ADD)
        {
            UTIL_ERROR("default", "--file=<path> is only valid when using command --add");
            return ERROR;
        }
        path = option->value();
        if (path.empty())
        {
            UTIL_ERROR("default", "--file=<path> require a path");
            return ERROR;
        }
        type = PARAM_FILE;
    }
    // Okay every command line parameter has been parsed successfully 
    // Lets do the job now 
    Yml::Core::Application yvetteApp(applicationFile);
    yvetteApp.initializeInfoOnly();
    
    switch(cmd)
    {
    case CMD_LIST: {
        UTIL_INFO("default", "Parameter #: name, description, type, collection, mode");
        const Yml::Core::ParameterList& params = yvetteApp.getParameters();
        for(size_t i = 0 ; i < params.count() ; ++i)
        {
            const Yml::Core::Parameter &param = params.get(i);
            if (Yml::Core::PARAM_IO_IN == param.getIOMode())
            {
                if (target == TARGET_BOTH || target == TARGET_INPUT)
                {
                    UTIL_INFO("default", "Parameter " << i << ": " << param.getName() 
                              << ", " << param.getDescription() << ", " 
                              << param.getType() << ", " 
                              << (param.isCollection() ? "yes" : "no")  << ", "
                              << printMode(param.getIOMode()));    
                }
            }
            else if (Yml::Core::PARAM_IO_OUT == param.getIOMode())
            {
                if (target == TARGET_BOTH || target == TARGET_OUTPUT)
                {
                    UTIL_INFO("default", "Parameter " << i << ": " << param.getName() 
                              << ", " << param.getDescription() << ", " 
                              << param.getType() << ", " 
                              << (param.isCollection() ? "yes" : "no") << ", "
                              << printMode(param.getIOMode()));    
                }
            }
            else 
            {
                // Always print 
                UTIL_INFO("default", "Parameter " << i << ": " << param.getName() 
                          << ", " << param.getDescription() << ", " 
                          << param.getType() << ", " 
                          << (param.isCollection() ? "yes" : "no") << ", "
                          << printMode(param.getIOMode()));
            }
            
        }
    }
        break;
    case CMD_STATUS: {
        try 
        {
            Util::Pack pack(packFile);
            Util::PackIndex* index = pack.createIndex();
            // Create pack name (including collections)
            UTIL_DEBUG("default", "Creating pack index");
            std::set<string> names;
            const size_t end = index->size();
            UTIL_DEBUG("default", "Number of entries: " << end);
            for (size_t i = 0 ; i < end ; ++i)
            {
                string name((*index)[i].d_name);
                string::size_type j = name.find_first_of('@');
                if (j != string::npos)
                    names.insert(name.substr(0, j));
                else
                    names.insert(name);
            }
            UTIL_INFO("default", "Parameter #: name, mode, set");
            const Yml::Core::ParameterList& params = yvetteApp.getParameters();
            for(size_t i = 0 ; i < params.count() ; ++i)
            {
                const Yml::Core::Parameter &param = params.get(i);
                if (Yml::Core::PARAM_IO_IN == param.getIOMode())
                {
                    if (target == TARGET_BOTH || target == TARGET_INPUT)
                    {
                        // Print 
                        UTIL_INFO("default", "Parameter " << i << ": " << param.getName() 
                                  << ", " << printMode(param.getIOMode()) << ", "
                                  << (names.find(param.getName()) != names.end() ? "yes" : "no"));
                    }
                }
                else if (Yml::Core::PARAM_IO_OUT == param.getIOMode())
                {
                    if (target == TARGET_BOTH || target == TARGET_OUTPUT)
                    {
                        // Print 
                        UTIL_INFO("default", "Parameter " << i << ": " << param.getName() 
                                  << ", " << printMode(param.getIOMode()) << ", "
                                  << (names.find(param.getName()) != names.end() ? "yes" : "no"));
                    }    
                }
                else 
                {
                    // Always show status 
                    UTIL_INFO("default", "Parameter " << i << ": " << param.getName() 
                              << ", " << printMode(param.getIOMode()) << ", "
                              << (names.find(param.getName()) != names.end() ? "yes" : "no"));
                }
            }
            pack.destroyIndex(index);
            pack.close();
        }
        catch(Util::IOException &e) 
        {
            // Pack open failed 
            UTIL_ERROR("default", "Pack '" << packFile << "' open failed");
            return ERROR;
        }
    }
        break;
    case CMD_EXTRACT_ALL: {
        if (! Util::Dir::mkdir(path))
        {
            UTIL_ERROR("default", "Unable to create target directory: '" << path << "'");
            return ERROR;
        }
        try
        {
            Util::Pack pack(packFile);
            Util::PackIndex* index = pack.createIndex();
            std::for_each(index->begin(), index->end(), ExtractFile(pack, path));
            pack.destroyIndex(index);
            pack.close();
        }
        catch(Util::IOException &e) 
        {
            // Pack open failed 
            UTIL_ERROR("default", "Pack '" << packFile << "' open failed");
            return ERROR;
        }
    }
        break;
    case CMD_EXTRACT: {
        try
        {
            Util::Pack pack(packFile);
            Util::PackIndex* index = pack.createIndex();
            const Util::PackIndex::const_reverse_iterator end = index->rend();
            Util::PackIndex::const_reverse_iterator iter = index->rbegin();
            string ymlName(convertNameToYML(pname));
            bool found = false;
            for(; iter != end ; ++iter)
            {
                if (ymlName == iter->d_name)
                {
                    // Try to do the extraction 
                    if (type == PARAM_FILE)
                    {
                        pack.extract(ymlName, path);
                        found = true;
                    }
                    else 
                    {
                        // Display the value to the screen if its one of the known type 
                        // we must display the value and thus determine its data type
                        // We have to look for this information in the parameter list 
                        string prefix;
                        string::size_type i = ymlName.find_first_of('@');
                        if (i != string::npos)
                            prefix = ymlName.substr(0, i);
                        else
                            prefix = ymlName;
                        const Yml::Core::ParameterList& params = yvetteApp.getParameters();
                        for(size_t i = 0 ; i < params.count() ; ++i)
                        {
                            const Yml::Core::Parameter &param = params.get(i);
                            if (param.getName() == prefix)
                            {
                                // Okay we have the correct parameter lets print it:
                                if (param.getType() == "integer")
                                {
                                    Util::ByteArray res(sizeof(pvalueI));
                                    pack.extract(ymlName, res);
                                    UTIL_INFO("default", "Parameter: " << pname << " (integer) value is '" 
                                              << *(int*)res.data() << "'");
                                    found = true;
                                }
                                else if (param.getType() == "real")
                                {
                                    Util::ByteArray res(sizeof(pvalueR));
                                    pack.extract(ymlName, res);
                                    UTIL_INFO("default", "Parameter: " << pname << " (real) value is '" 
                                              << *(double*)res.data() << "'");
                                    found = true;
                                }
                                else if (param.getType() == "string")
                                {
                                    Util::ByteArray res(0);
                                    pack.extract(ymlName, res);
                                    size_t length;
                                    memcpy((char*)&length, res.data(), sizeof(length));
                                    pvalueS.assign((const char*)res.data() + sizeof(length), length);
                                    UTIL_INFO("default", "Parameter: " << pname << " (string) value is '" 
                                              << pvalueS << "'");
                                    found = true;
                                }
                                else 
                                {
                                    UTIL_ERROR("default", "Paramater: " << pname << " (" << param.getType() 
                                               << ") is a user defined type. this tool cannot "\
                                               " display the value of the parameter correctly." \
                                               " please use --file=<path> to extract the parameter"\
                                               " to a file.");
                                    return ERROR;
                                }
                                break;
                                found = true;
                            }
                        }
                        break;
                    }
                }
            }
            pack.destroyIndex(index);
            pack.close();
            if (! found)
            {
                UTIL_ERROR("default", "Fail to find a data file corresponding to '" << pname << "'");
                return ERROR;
            }
        }
        catch(Util::IOException &e) 
        {
            // Pack open failed 
            UTIL_ERROR("default", "Pack '" << packFile << "' open failed");
            return ERROR;
        }
    }
        break;
    case CMD_ADD: {
        try 
        {
            Util::Pack pack(packFile);
            string ymlName(convertNameToYML(pname));
            switch(type)
            {
            case PARAM_INTEGER:
                pack.add(ymlName, (byte*)&pvalueI, sizeof(pvalueI));
                break;
            case PARAM_REAL:
                pack.add(ymlName, (byte*)&pvalueR, sizeof(pvalueR));
                break;
            case PARAM_STRING: {
                
                //prepare the string as size|data 
                size_t length = pvalueS.size();
                byte* tmp = new byte[sizeof(length) + length];
                memcpy(tmp, (char*)&length, sizeof(length));
                memcpy(tmp + sizeof(length), pvalueS.data(), length);
                pack.add(ymlName, tmp, sizeof(length) + length);
                delete [] tmp;
            }
                break;
            case PARAM_FILE:
                pack.add(ymlName, path);
                break;
            default:
                break;
            }

            pack.close();
        }
        catch(Util::IOException &e) 
        {
            // Pack open failed 
            UTIL_ERROR("default", "Pack '" << packFile << "' open failed");
            return ERROR;
        }
    }    
        break;
    default: 
        break;
    }
    return SUCCESS;
}

string Parameter::convertNameToYML(string name)
{
    UTIL_DEBUG("default", "Name To YML: " << name);
    
    std::replace_if(name.begin(), name.end(), std::bind2nd(std::equal_to<char>(), '['), ' ');
    std::replace_if(name.begin(), name.end(), std::bind2nd(std::equal_to<char>(), ']'), ' ');
    std::istringstream in(name);
    std::ostringstream out;
    string tmp;
    in >> tmp;
    
    out << tmp;
    while(in)
    {
        in >> tmp ;
        if (in && ! tmp.empty())
            out << "@@" << tmp;
    }
    UTIL_DEBUG("default", "Name '" << name << "' --> '" << out.str() << "'");
    return out.str();
}

string Parameter::convertYMLToName(string name)
{
    UTIL_DEBUG("default", "YML to Name: " << name);
    std::replace_if(name.begin(), name.end(), std::bind2nd(std::equal_to<char>(), '@'), ' ');
    std::istringstream in(name);
    std::ostringstream out;
    string tmp;
    in >> tmp;
    out << tmp;
    while(in)
    {
        in >> tmp;
        if (in && ! tmp.empty())
            out << "[" << tmp << "]";
    }
    UTIL_DEBUG("default", "Name '" << name << "' --> '" << out.str() << "'");
    return out.str();
}


string Parameter::printMode(Yml::Core::ParameterIOMode mode)
{
switch(mode)
{
case Yml::Core::PARAM_IO_IN:
    return "in";
    
case Yml::Core::PARAM_IO_OUT:
    return "out";
    
case Yml::Core::PARAM_IO_INOUT:
    return "inout";
}
return "";

}


}
}
UTIL_APPLICATION(Yml::Parameter::Parameter, Util::ConsoleApplicationAdaptor());
