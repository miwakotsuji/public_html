/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/
/**
 * @file
 * @brief Class BackendManager function definition 
 *
 * 2007-09-26
 * Olivier Delannoy
 */
#include <Yml/Core/core.hh>
#include <Yml/Core/SchedulerTask.hh>
#include <Yml/UDP/UDP.hh>


#include <Application.hh> // Util::Application 
#include <ConsoleApplicationAdaptor.hh>
#include <ConfigFactory.hh>
#include <LoggerFactory.hh>
#include <UID.hh> 


#include <locale>
#include <list>
#include <map>
#include <vector>
#include <deque> 
#include <queue>
#include <set> 
namespace Yml
{
namespace BackendManager
{
using Yml::Core::string;
using Yml::Core::uint32;
using Yml::UDP::TaskIdentifier;
using Yml::Core::SchedulerTask;
typedef std::list<SchedulerTask*> TaskList;
typedef std::deque<SchedulerTask*> TaskQueue;
typedef std::deque<TaskIdentifier> TaskChangeQueue;


class BackendManager;
class Client;
class ClientBackend;
class ClientApplication;
class ClientApplicationManager;

class TaskDispatcher
{
public:
    TaskDispatcher() {}
    virtual ~TaskDispatcher() {}
    virtual void dispatch(SchedulerTask* task) = 0;
    virtual void addBackend(ClientBackend* backend) = 0;
    virtual void remBackend(ClientBackend* backend) = 0;
};




/*! \brief base class of all client interacting with the backend manager */    
class Client 
{
protected:
    Client(Yml::UDP::Peer peer) : mPeer(peer) { peer.udata(this); }
public:
    typedef std::deque<Client*> Queue;
    virtual ~Client() 
    {
    }
    
    
    virtual void cleanup(BackendManager* manager) = 0;
    virtual void unregister(BackendManager* manager) = 0;
    void resetPeer() { mPeer.udata(0);}
    void send(Yml::UDP::Message* message)
    {
        mPeer.send(message, 0);
    }
protected:
    Yml::UDP::Peer mPeer; 
};

    
/*! \brief This class represent an application being executed */
class ClientApplication : public Client 
{
public:
    ClientApplication(Yml::UDP::Peer peer)  : Client(peer) {}
    ~ClientApplication() { UTIL_INFO("default", "Application destroyed");}
    void setId(uint32 id) { mId = id; }     
    uint32 getId() const { return mId; }
    void cleanup(BackendManager* manager) {}
    void unregister(BackendManager* manager);
private:
    uint32 mId;
};
/*! \brief this class manage all YML application currently executed */
class ClientApplicationManager
{
    typedef std::vector<ClientApplication*> List;
public:
    ClientApplicationManager()
    {
        mApps.push_back(0); // 0 is not a valid application id
    }   
    ~ClientApplicationManager() 
    {
    }
    
    
    ClientApplication* get(uint32 appId)
    {
        if (appId < mApps.size())
            return mApps[appId];
        return 0;
    }
    void addApplication(ClientApplication* app)
    {
        for (List::size_type i = 1 ; i < mApps.size() ; ++i)
        {
            if (mApps[i] == 0)
            {
                mApps[i] = app;
                app->setId(i);
                return;
            }
        }
        app->setId(mApps.size());
        mApps.push_back(app);
    }
    
    void remApplication(ClientApplication* app)
    {
        if (mApps[app->getId()] == app)
        {
            mApps[app->getId()] = 0;
        }
        app->setId(0);
    }
    
private:
    std::vector<ClientApplication*> mApps;
    ClientApplicationManager(ClientApplicationManager&);
    ClientApplicationManager& operator=(ClientApplicationManager&);
};

/*! \brief This class represent a backend which can handle a bunch of work */
class ClientBackend : public Client
{
    typedef std::list<SchedulerTask*> TaskList;
public:
    typedef std::vector<ClientBackend*> List;
    ClientBackend(Yml::UDP::Peer& peer)
        : Client(peer)
    {
    }
    
    ~ClientBackend()
    {
        UTIL_INFO("default", "Back-end destroyed");
    }
    

    void cleanup(BackendManager* manager) ;
    void unregister(BackendManager* manager);
    
    void remTask(SchedulerTask* task) 
    {
        --mStatRunning;
        mRunning.remove(task);
        
        ++mStatExecuted;
        
    }
    void addTask(SchedulerTask* task)
    {
        UTIL_INFO("default", "Back-end assigned a new task");
        ++ mStatRunning;
        mRunning.push_back(task);
        Yml::UDP::MSGTaskSubmit msg;
        msg.setTask(task);
        mPeer.send(&msg, 0);
    }
    bool cancelTask(uint32 app_id, uint32 task_id)
    {
        TaskList::iterator iter = mRunning.begin();
        const TaskList::iterator end = mRunning.end();
        
        for(; iter != end ; ++iter)
        {
            if ((*iter)->index() == task_id && (*iter)->appId() == app_id)
            {
                Yml::UDP::MSGTaskCancel cancel;
                cancel.task().app_id = app_id;
                cancel.task().task_id = task_id;
                send(&cancel);
                return true;
            }
        }
        return false;
    }
    
    
    uint32 statRunning() { return mStatRunning; }
    uint32 statExecuted() { return mStatExecuted; }
private:
    TaskList mRunning;
    uint32 mStatRunning;
    uint32 mStatExecuted;
};
    



class LoadBalancerTaskDispatcher : public TaskDispatcher
{
    struct ClientBackendComp 
    {
        bool operator()(ClientBackend* backend1, ClientBackend* backend2)
        {
            return  (backend1->statRunning() < backend2->statRunning());
        }
    };
    
        
    typedef std::queue<SchedulerTask*> TaskQueue;
    typedef std::queue<ClientBackend*> BackendQueue;
    typedef std::set<ClientBackend*> BackendList;

public:
       
    void dispatch(SchedulerTask* task)
    {        
	UTIL_INFO("default", "Dispatch of a new task (number of backend: " << 
			mBackends.size() << ")");
        ClientBackend* backend = 0;
        // Find a not removed backend 
	UTIL_INFO("default", "Backend: " << backend);
        while(!backend && ! mBackends.empty())
        {
            backend = mBackends.front();
            mBackends.pop();
            BackendList::iterator iter = mRemoved.find(backend);
            if (iter != mRemoved.end())
            {
                mRemoved.erase(iter);
                backend = 0;
            }
        }
	UTIL_INFO("default", "Backend: " << backend);
        if (backend)
        {
            backend->addTask(task);
            mBackends.push(backend);
        }
        else
        {
            mPending.push(task);
        }
    }
    void addBackend(ClientBackend* backend)
    {
        UTIL_INFO("default", "New back-end connected");
        mBackends.push(backend);
        // Empty the list of pending tasks
        UTIL_INFO("default", "There is " << mPending.size() << " pending tasks");
        
        while(!mPending.empty())
        {
            SchedulerTask* top = mPending.front();
            dispatch(top);
            mPending.pop();
        }
    }
    void remBackend(ClientBackend* backend) 
    {
        UTIL_INFO("default", "Back-end disconnected, registered for removal");
        mRemoved.insert(backend);
    }
private:
    TaskQueue mPending;
    BackendList mRemoved;
    BackendQueue mBackends;
    
};


/*! \brief Main class of the backend manager */
class BackendManager : public Util::Application, public enet::SignalBindable 
{
public:
    BackendManager(Util::ApplicationAdaptor* adaptor, int argc, char** argv);
    ~BackendManager();
    void unregister(ClientApplication* application);
    void unregister(ClientBackend* backend);
    void submit(SchedulerTask* task);
protected:
    void configureCommandLine();
    string usageQuick() const;
    string usageParameters() const;
    string usageOptions() const;
    string configDir() const;
    string loggerDir() const;
    string pluginDir() const;
    uint32 run();
private:
    void doConnect(Yml::UDP::Peer& peer);
    void doDisconnect(Yml::UDP::Peer& peer);
    void doMessageReceived(Yml::UDP::Peer& peer, Yml::UDP::Message* message);
    void doDispatchPendingTasks();
    void doCleanup();
    // Components 
    TaskDispatcher* mDispatcher;
    ClientApplicationManager mApplications;
    Yml::UDP::Host* mHost;
    Client::Queue mCleanup; //!< Store client waiting for cleanup
    TaskQueue mPendingTask; //!< Store task ready for execution

    ClientBackend::List mBackends;
    
    
};


BackendManager::BackendManager(Util::ApplicationAdaptor* adaptor, int argc, char** argv) 
    : Util::Application(adaptor, argc, argv)
{
    std::locale::global(std::locale("C"));
}

BackendManager::~BackendManager()
{
    doCleanup();
}

void BackendManager::configureCommandLine() 
{
}
string BackendManager::usageQuick() const
{
    return "";    
}


string BackendManager::usageParameters() const
{
    return "";
}
string BackendManager::usageOptions() const 
{
    return "";
}
string BackendManager::configDir() const
{
    return CONFIG_DIR;
}
string BackendManager::loggerDir() const
{
    return Util::ConfigFactory::getSingleton().create("yml")->get("path", "loggers", ".");
}
string BackendManager::pluginDir() const
{
    return Util::ConfigFactory::getSingleton().create("yml")->get("path", "plugins", ".");
}


void BackendManager::unregister(ClientApplication* application)
{
    mApplications.remApplication(application);
}

void BackendManager::unregister(ClientBackend* backend)
{
    UTIL_INFO("default", "Unregister back-end\n");
    mDispatcher->remBackend(backend);
}
uint32 BackendManager::run() 
{
    UTIL_INFO("default", "Starting BackendManager");
    // Initialization

    // Check initialization results 
    Yml::UDP::UDP udpLibrary;
    mDispatcher = new LoadBalancerTaskDispatcher();
    uint32 confPort = 5666;
    uint32 confDelay = 3000;
    UTIL_INFO("default", "BackendManager running");
    // Main loop

    // Initialize data structure
    //  Accept 2000 client
    Yml::UDP::Host host(confPort, 2000);
    host.onIdle.connect(*this, &BackendManager::doCleanup);
    host.onPeerConnect.connect(*this, &BackendManager::doConnect);
    host.onPeerDisconnect.connect(*this, &BackendManager::doDisconnect);
    host.onMessageReceived.connect(*this, &BackendManager::doMessageReceived);
    mHost = &host;
    UTIL_INFO("default", "Dispatching requests");
    
    while(true) {
        host.service(confDelay);
    }    
    UTIL_INFO("default", "Stoping BackendManager");    
    return SUCCESS;
}


void BackendManager::doConnect(Yml::UDP::Peer& peer)
{
    UTIL_INFO("default", "A client connects to the back-end manager");
}

void BackendManager::doDisconnect(Yml::UDP::Peer& peer)
{
    UTIL_INFO("default", "Disconnection of a client");
    if (peer.udata())
    {
        UTIL_INFO("default", "Client disconnexion");
        Client* client = reinterpret_cast<Client*>(peer.udata());
        client->resetPeer();
        client->unregister(this);
        mCleanup.push_back(client);
    }
    peer.udata(0);
}

void BackendManager::doMessageReceived(Yml::UDP::Peer& peer, Yml::UDP::Message* message)
{
    switch(message->type())
    {
     
        ///////////////////////////////
        // From Multi-Backend backend 
        ///////////////////////////////
    case Yml::UDP::MSG_TASK_SUBMIT: 
    {
        ClientApplication* client = reinterpret_cast<ClientApplication*>(peer.udata());
        SchedulerTask* task = static_cast<Yml::UDP::MSGTaskSubmit*>(message)->task();
        task->appId() = client->getId();
        mDispatcher->dispatch(task);
    }
    break;
        
    case Yml::UDP::MSG_TASK_CANCEL:
    {
        ClientApplication* client = reinterpret_cast<ClientApplication*>(peer.udata());
        Yml::UDP::TaskIdentifier task = static_cast<Yml::UDP::MSGTaskCancel*>(message)->task();
        task.app_id = client->getId();
        ClientBackend::List::iterator iter = mBackends.begin();
        while(iter != mBackends.end() && ! (*iter)->cancelTask(task.app_id, task.task_id)) ++iter;
    }
    break;
        
    ///////////////////////////////
    // From Backend-connector
    ///////////////////////////////
    case Yml::UDP::MSG_TASK_FINISHED:
    {
        TaskIdentifier task = static_cast<Yml::UDP::MSGTaskFinished*>(message)->task();
        ClientApplication* app = mApplications.get(task.app_id);
        if (app)
        {
            Yml::UDP::MSGTaskFinished finished;
            finished.task() = task;
            app->send(&finished);
        }
    }
    break;    

    case Yml::UDP::MSG_TASK_FAILED:
    {
        TaskIdentifier task = static_cast<Yml::UDP::MSGTaskFinished*>(message)->task();
        ClientApplication* app = mApplications.get(task.app_id);
        if (app)
        {
            Yml::UDP::MSGTaskFailed failed;
            failed.task() = task;
            app->send(&failed);
        }
    }
    break;    
    /////////////////////////////
    // From Multi-Backend backend
    /////////////////////////////
    case Yml::UDP::MSG_APP_START: 
    {
        ClientApplication* app = new ClientApplication(peer);
        // Register the newly created app 
        mApplications.addApplication(app);
        UTIL_INFO("default", "New application with id: " << app->getId());
    }
    break;

    case Yml::UDP::MSG_BCK_START:
    {
        ClientBackend* backend = new ClientBackend(peer);
        mDispatcher->addBackend(backend);
    }
    break;
    }
}

void BackendManager::submit(SchedulerTask* task)
{
    mDispatcher->dispatch(task);
}
void BackendManager::doCleanup()
{
    // Check for application and backend which requires cleanup
    while(! mCleanup.empty())
    {
        Client* client = mCleanup.front();
        mCleanup.pop_front();
        client->cleanup(this);
        delete client;
    }
}

// Client application definitions 
void ClientApplication::unregister(BackendManager* manager)
{
    manager->unregister(this);
}


void ClientBackend::cleanup(BackendManager* manager)
{

    // Requeue all runing tasks 
    TaskList::iterator iter = mRunning.begin();
    const TaskList::iterator end = mRunning.end();
    for (; iter != end ; ++iter)
    {
        manager->submit(*iter);
    }
}

// Backend application definitions 
void ClientBackend::unregister(BackendManager* manager)
{
    manager->unregister(this);
}






} // end of namespace BackendManager 
} // end of namesapce Yml



UTIL_APPLICATION(Yml::BackendManager::BackendManager, Util::ConsoleApplicationAdaptor())
