/*
// ***********************************************************************
// VFS library 
// Author: Olivier Delannoy
// Date: 15 Jul 2007
// ***********************************************************************
// Copyright (c) 2006 listed in Authors.txt file 
//
// Permission is hereby granted, free of charge, to any person 
// obtaining a copy of this software and associated documentation 
// files (the "Software"), to deal in the Software without restriction,
// including without limitation the rights to use, copy, modify, merge,
// publish, distribute, sublicense, and/or sell copies of the Software,
// and to permit persons to whom the Software is furnished to do so, 
// subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be 
// included in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND 
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS 
// BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN 
// ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
// CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
// ***********************************************************************
*/
#ifndef VFS_H_
#define VFS_H_ 1
#ifdef __cplusplus
extern "C" {
#endif 
#include <sys/types.h> /* For mode_t */

#define VFS_PATH_SEPARATOR '/'

  /* Directory handling routines */
  /*!  \brief Create a dir and all required parent path  */
  int vfs_mkdir(char* dir, mode_t mode);
  /*! \brief Destroy a dir and all its content */ 
  int vfs_rmdir(char* dir);
  /*! \brief File copy from one path to another */ 
  int vfs_file_copy(char* dest, char* source);
#ifdef __cplusplus
}
#endif 
#endif
