/*
// ***********************************************************************
// VFS library 
// Author: Olivier Delannoy
// Date: 15 Jul 2007
// ***********************************************************************
// Copyright (c) 2006 listed in Authors.txt file 
//
// Permission is hereby granted, free of charge, to any person 
// obtaining a copy of this software and associated documentation 
// files (the "Software"), to deal in the Software without restriction,
// including without limitation the rights to use, copy, modify, merge,
// publish, distribute, sublicense, and/or sell copies of the Software,
// and to permit persons to whom the Software is furnished to do so, 
// subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be 
// included in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND 
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS 
// BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN 
// ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
// CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
// ***********************************************************************
 */
#include "vfs.h"
#include <stdlib.h>
#include <string.h> 
#include <strings.h>
#include <errno.h>

#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>
#include <stdio.h>

int vfs_mkdir(char* dir, mode_t mode)
{
    int status;
    struct stat dinfo;
    status = stat(dir, &dinfo);
    if (status == 0) 
    {
        if (S_ISDIR(dinfo.st_mode))
        {
            /* Nothing to do */
            return 0;
        }
        else 
        {
            /* The file exists but it's not a directory */
            return -1;
        }
    }
    status = mkdir(dir, mode);
    if (status == 0) {
      /* The first time ouah */
      return 0;
    }
    else 
    {
      char* pos = 0;
      char* parent = 0;
      if (errno == EEXIST)
      {
          return -1;
      }
        
        pos = rindex(dir, VFS_PATH_SEPARATOR);
        if (pos == 0)
        {
	        /* Error nothing to be done here  */
            return -1;
        }
        parent = malloc(pos - dir + 1);
        memset(parent, 0, pos - dir + 1);
        memcpy(parent, dir, pos - dir);
        status = vfs_mkdir(parent, mode);
        free(parent);
        if (status != 0)
        {
            /* failed create the parent dir */
            return -1;
        }
        /* Create dir */
        status = mkdir(dir, mode);
        if (status != 0)
        {
            return -1;
        }
        return 0;
    }
}
int vfs_rmdir(char* dir)
{
    int status;
    struct dirent* entry;
    DIR* dh;
    char buffer [PATH_MAX];
    int rootsize;
    char* pos;
    struct stat finfo;
    rootsize = strlen(dir);
    strncpy(buffer, dir, PATH_MAX);
    pos = buffer + rootsize;
    pos[0] = VFS_PATH_SEPARATOR;
    ++pos;
    /* Clean the dir */
    dh= opendir(dir);
    if (dh == 0)
    {
        return -errno;
    }
    while((entry = readdir(dh)) != 0)
    {
        if ((strcmp(entry->d_name, ".") != 0) &&
            (strcmp(entry->d_name, "..") != 0))
        {
            strncpy(pos, entry->d_name, PATH_MAX - rootsize);
            /* Check whether it is a file or a dir */
            if (stat(buffer, &finfo) != 0)
            {
                closedir(dh);
                return -errno;
            } 
            if ( S_ISDIR(finfo.st_mode))
            {
                status = vfs_rmdir(buffer);
                if (status != 0)
                {
                    closedir(dh);
                    return -errno;
                }
            }
            else
            {
                if (unlink(buffer) != 0)
                {
                    closedir(dh);
                    return -errno;
                }
            }
            
        }
    }
    closedir(dh);
    status = rmdir(dir);
    if (status != 0)
    {
        return -errno;
    }
    return 0;
}
