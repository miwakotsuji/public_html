/* -*- mode: c; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/
/**
 * @file
 * @brief Default Worker implementation file 
 *
 * 2006-04-16
 * Olivier Delannoy
 */
#ifdef HAVE_CONFIG_H
#include <yml_config.hh> 
#endif 
#include "worker_common.h" 
#include "drclient.h"
#include "network.h"
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>

#define BUFFER_SIZE 8192

void drclient_disconnect_hook(network_client_t net)
{
    YML_DEBUG_INSTRUMENT_START("drclient_disconnect_hook");
    uint16 tmp = 0;
    network_write(net, (char*)&tmp, sizeof(tmp)); 
    YML_DEBUG_INSTRUMENT_STOP("drclient_disconnect_hook");
}
int drclient_connect(drclient_t* client, char* host, unsigned short port)
{
    
    network_client_t net;
    int status;
    status = network_connect(&net, host, port, drclient_disconnect_hook);
    *client = net;
    YML_DEBUG_INSTRUMENT_STOP("drclient_connect");
    return status;
}

void drclient_disconnect(drclient_t client)
{
    network_client_t net;
    YML_DEBUG_INSTRUMENT_START("drclient_disconnect");
    net = (network_client_t) client;
    // Send No more query byte and close everything. 
    network_disconnect(net);
    YML_DEBUG_INSTRUMENT_STOP("drclient_disconnect");
}
int drclient_change_server(drclient_t client, char* host, unsigned short port)
{
    int status;
    YML_DEBUG_INSTRUMENT_START("drclient_change_server");
    status = network_change_server((network_client_t)client, host, port);
    YML_DEBUG_INSTRUMENT_STOP("drclient_change_server");
    return status;
}

int drclient_get(drclient_t client, char* uri, char* local)
{
    network_client_t net;
    uint16 queryType;
    uint16 uriSize;
    uint32 dataSize;
    uint32 headerSize;
    char* header;
    uint32 offset;
    uint32 written;
    uint32 read;
    int fd_out;
    int status;
    char buffer[BUFFER_SIZE];
    YML_DEBUG_INSTRUMENT_START("drclient_get");
    net = (network_client_t) client;
    /* Create query header information */
    uriSize = strlen(uri);
    queryType = 1;
    dataSize = 0;
    headerSize = sizeof(queryType) + sizeof(uriSize) + sizeof(dataSize) + uriSize;
    header = (char*)malloc(headerSize);
    if (header == 0)
    {
        // malloc failed 
        YML_DEBUG_INSTRUMENT_STOP("drclient_get");
        return -errno;
    }
    offset = 0;
    memcpy(header + offset, (char*)&queryType, sizeof(queryType));
    offset += sizeof(queryType);
    memcpy(header + offset, (char*)&uriSize, sizeof(uriSize));
    offset += sizeof(uriSize);
    memcpy(header + offset, (char*)&dataSize, sizeof(dataSize));
    offset += sizeof(dataSize);
    memcpy(header + offset, uri, uriSize);
    written = 0;
#ifdef HAVE_WORKER_DEBUG 
    printf("DEBUG(%15s:%3d): Local file '%s'\n", __FILE__, __LINE__, local);
#endif 
    fd_out = open(local, O_WRONLY | O_CREAT, 0600);
    if (fd_out == -1)
    {
        free(header);
        YML_DEBUG_INSTRUMENT_STOP("drclient_get");
        return -errno;
    }
    do 
    {
        status = network_write(net, header, headerSize);
        if (status == -1)
        {
            close(fd_out);
            free(header);
            YML_DEBUG_INSTRUMENT_STOP("drclient_get");
            return -errno;
        }
        written += status;
    }
    while(written < headerSize);
    free(header);
    /* Get the data from the server */
    status = network_read(net, (char*)&dataSize, sizeof(dataSize));
    if (status == -1)
    {
        // Unable to read from network
        YML_DEBUG_INSTRUMENT_STOP("drclient_get_data");
        return -errno;   
    }
    if (status < sizeof(dataSize))
    {
        // Not enough data read it seems to me it is an error 
        YML_DEBUG_INSTRUMENT_STOP("drclient_get_data");
        return -1;
    }
    
    read = 0;
    while(read < dataSize)
    {
#ifdef HAVE_WORKER_DEBUG
        printf("DEBUG(%15s:%3d): progress %d/%d bytes\n", __FILE__, __LINE__, read, dataSize);
#endif
        status = network_read(net, buffer, BUFFER_SIZE);
        if (status == -1)
        {
            close(fd_out);
            YML_DEBUG_INSTRUMENT_STOP("drclient_get");
            return -errno;
        }
        
        written = 0;
        do 
        {
            int status2 = write(fd_out, buffer + written, status - written);
            if (status2 == -1 && errno != EINTR)
            {
                close(fd_out);
                YML_DEBUG_INSTRUMENT_STOP("drclient_get");
                return -errno;
            }
            written += status2;
        }
        while(written < status);    
        read += status;
    }
    close(fd_out);
    if (network_write(net, (char*)&read, sizeof(read)) != sizeof(read)) // Send acknoledgement 
    {
        YML_DEBUG_INSTRUMENT_STOP("drclient_get");
        return -errno;
    }
    YML_DEBUG_INSTRUMENT_STOP("drclient_get");
    return 0;
}
int drclient_get_data(drclient_t client, char* uri, char** data, uint32* dataSize)
{
    network_client_t net;
    uint16 queryType;
    uint16 uriSize;
    uint32 headerSize;
    char* header;
    uint32 offset;
    uint32 written;
    int status;
    char buffer[BUFFER_SIZE];
    YML_DEBUG_INSTRUMENT_START("drclient_get_data");
    net = (network_client_t) client;
    *data = 0;
    /* Create query header information */
    uriSize = strlen(uri);
    queryType = 1;
    *dataSize = 0;
    headerSize = sizeof(queryType) + sizeof(uriSize) + sizeof(*dataSize) + uriSize;
    header = (char*)malloc(headerSize);
    if (header == 0)
    {
        // malloc failed 
        YML_DEBUG_INSTRUMENT_STOP("drclient_get_data");
        return -errno;
    }
    offset = 0;
    memcpy(header + offset, (char*)&queryType, sizeof(queryType));
    offset += sizeof(queryType);
    memcpy(header + offset, (char*)&uriSize, sizeof(uriSize));
    offset += sizeof(uriSize);
    memcpy(header + offset, (char*)dataSize, sizeof(*dataSize));
    offset += sizeof(*dataSize);
    memcpy(header + offset, uri, uriSize);
    written = 0;
    
    do 
    {
        status = network_write(net, header, headerSize);
        if (status == -1)
        {
            free(header);
            YML_DEBUG_INSTRUMENT_STOP("drclient_get_data");
            return -errno;
        }
        written += status;
    }
    while(written < headerSize);
    free(header);
    
    /* Get the data from the server: Size of the result */
    status = network_read(net, buffer, BUFFER_SIZE);
    if (status == -1)
    {
        // Unable to read from network
        YML_DEBUG_INSTRUMENT_STOP("drclient_get_data");
        return -errno;   
    }
    
    if (status < sizeof(*dataSize))
    {
        // Not enough data read it seems to me it is an error 
        YML_DEBUG_INSTRUMENT_STOP("drclient_get_data");
        return -1;
    }
    
    memcpy((char*)dataSize, buffer,sizeof(*dataSize));
    *data = (char*) malloc(*dataSize);
    if (*data == 0)
    {
        YML_DEBUG_INSTRUMENT_STOP("drclient_get_data");
        return -1;
    }
    written = sizeof(*dataSize);
    memcpy(*data, buffer + written, status - written);
    offset = status - written;
    while(offset < *dataSize)
    {
        status = network_read(net, (*data) + offset, (*dataSize) - offset);
        //printf("Progess: %d/%d\n", offset, *dataSize);
        if (status == -1)
        {
            free(*data);
            *data = 0;
            YML_DEBUG_INSTRUMENT_STOP("drclient_get_data");
            return -errno;
        }
        offset += status;
    }
    if (network_write(net, (char*)&offset, sizeof(offset)) != sizeof(offset)) // Send acknoledgement 
    {
        free(*data);
        *data = 0;
        YML_DEBUG_INSTRUMENT_STOP("drclient_get_data");
        return -errno;  
    }
    YML_DEBUG_INSTRUMENT_STOP("drclient_get_data");
    return 0;
}
int drclient_put(drclient_t client, char* uri, char* local)
{
    network_client_t net;
    uint16 queryType;
    uint16 uriSize;
    uint32 dataSize;
    uint32 headerSize;
    char* header;
    uint32 offset;
    uint32 written;
    uint32 dataRead;
    int fd_in;
    struct stat finfo;
    int status;
    int status2;
    
    char buffer[BUFFER_SIZE];
    YML_DEBUG_INSTRUMENT_START("drclient_put");
#ifdef HAVE_WORKER_DEBUG
    printf("DEBUG(%15s:%3d): PUT to '%s' from local file '%s'\n", __FILE__, __LINE__, uri, local);
#endif 
    net = (network_client_t) client;
    /* Create query header information */
    uriSize = strlen(uri);
    queryType = 2;
    dataSize = 0;
    fd_in = open(local, O_RDONLY);
    if (fd_in == -1)
    {
        close(fd_in);
        YML_DEBUG_INSTRUMENT_STOP("drclient_put");
        return -errno;
    }
    status = fstat(fd_in, &finfo);
    if (status == -1)
    {
        close(fd_in);
        YML_DEBUG_INSTRUMENT_STOP("drclient_put");
        return -errno;
    }
    dataSize = finfo.st_size;
    headerSize = sizeof(queryType) + sizeof(uriSize) + sizeof(dataSize) + uriSize;
    header = (char*)malloc(headerSize);
    if (header == 0)
    {
        // malloc failed 
        close(fd_in);
        YML_DEBUG_INSTRUMENT_STOP("drclient_put");
        return -errno;
    }
    offset = 0;
    memcpy(header + offset, (char*)&queryType, sizeof(queryType));
    offset += sizeof(queryType);
    memcpy(header + offset, (char*)&uriSize, sizeof(uriSize));
    offset += sizeof(uriSize);
    memcpy(header + offset, (char*)&dataSize, sizeof(dataSize));
    offset += sizeof(dataSize);
    memcpy(header + offset, uri, uriSize);
    written = 0;
    do 
    {
        status = network_write(net, header, headerSize);
        if (status == -1)
        {
            close(fd_in);
            free(header);
            YML_DEBUG_INSTRUMENT_STOP("drclient_put");
            return -errno;
        }
        written += status;
    }
    while(written < headerSize);
    free(header);
    /* upload the data */
    dataRead = 0;
    do
    {
        status = read(fd_in, buffer, BUFFER_SIZE);
        if (status == -1)
        {
            close(fd_in);
            YML_DEBUG_INSTRUMENT_STOP("drclient_put");
            return -errno;
        }
        written = 0;
        do 
        {
            status2 = network_write(net, buffer + written, status - written);
            if (status2 == -1)
            {
                close(fd_in);
                YML_DEBUG_INSTRUMENT_STOP("drclient_put");
                return -errno;
            }
            written += status2;
        }
        while(written < status);
        dataRead += status;
    }
    while(dataRead < dataSize);
    close(fd_in);

    // Way for the acknoledgement 
    status = network_read(net, (char*)&dataRead, sizeof(dataRead));
    if (status != sizeof(dataRead))
    {
        YML_DEBUG_INSTRUMENT_STOP("drclient_put");
        return -errno;
    }
#ifdef HAVE_WORKER_DEBUG
    printf("DEUBG(%15s:%3d): Acknoledgement %d == %d\n", __FILE__, __LINE__, dataRead, dataSize);
#endif
    YML_DEBUG_INSTRUMENT_STOP("drclient_put");
    return ! (dataRead == dataSize);
}
/****************************************************************************/
