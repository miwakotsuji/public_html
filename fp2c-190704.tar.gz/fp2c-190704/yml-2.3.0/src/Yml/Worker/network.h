/* -*- mode: c; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/
/**
 * @file
 * @brief Default Worker header file network
 *  
 * 2006-04-15
 * Olivier Delannoy
 */
#ifndef YML_WORKER_NETWORK_H
#define YML_WORKER_NETWORK_H 1
#ifdef __cplusplus
extern "C" {
#endif 
#include "worker_private.h"
/**
 *  Opaque type for a network client 
 */
typedef void* network_client_t;
/**
 * Hook for disconnexion event 
 */
typedef void (*network_client_disconnect_hook_t)(network_client_t client);
/**
 * Create a network connection to a remote server 
 * 
 * @param client A pointer handle to the network communication (result)
 *
 * @param host the name of the host to connect to 
 * 
 * @param port the port number to use 
 *
 * @return 0 on success -errno on error 
 */
int network_connect(network_client_t* client, char* host, unsigned short port, network_client_disconnect_hook_t hook);
/**
 * Create a network connection to a remote server 
 * 
 * @param client A handle to the network communication 
 *
 * @param host the name of the host to connect to 
 * 
 * @param port the port number to use 
 *
 * @return 0 on success -errno on error 
 */
int network_change_server(network_client_t client, char* host, unsigned short port);
/**
 * Disconnect from the server 
 * 
 * @param client A handle to the network communication 
 */
void network_disconnect(network_client_t client);
/**
 * Read from the network server
 * 
 * @param client A handle to the network communication 
 *
 * @param buffer A buffer previously allocated to store the data 
 * 
 * @param size The size of the buffer. The call will read at most size byte
 *
 * @return On success, the number of bytes read is returned (zero
 * indicates end of file), and the file position is advanced by
 * this number.  It is not an error if this number is smaller than
 * the number of bytes requested; this may happen for example
 * because fewer bytes are actually available right now (maybe
 * because we were close to end-of-file, or because we are reading
 * from a pipe, or from a terminal), or because read() was
 * interrupted by a signal.  On error, -1 is returned. In this
 * case it is left unspecified whether the file position (if any)
 * changes. errno is set correctly.
 */
int network_read(network_client_t client, char* buffer, size_t size);
/**
 * Write to the network server 
 * 
 * @param client A handle to the network communication 
 *
 * @param buffer A buffer previously allocated to store the data 
 * 
 * @param size The size of the buffer. The call will read at most size byte
 *
 * @return On success, the number of bytes read is returned (zero
 * indicates end of file), and the file position is advanced by
 * this number.  It is not an error if this number is smaller than
 * the number of bytes requested; this may happen for example
 * because fewer bytes are actually available right now (maybe
 * because we were close to end-of-file, or because we are reading
 * from a pipe, or from a terminal), or because read() was
 * interrupted by a signal.  On error, -1 is returned. In this
 * case it is left unspecified whether the file position (if any)
 * changes. errno is set correctly. 
 */
int network_write(network_client_t client, char* buffer, size_t size);
#ifdef __cplusplus
}
#endif 
#endif
