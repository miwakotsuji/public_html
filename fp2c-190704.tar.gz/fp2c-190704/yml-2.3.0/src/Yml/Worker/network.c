/* -*- mode: c; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/
/**
 * @file
 * @brief Default Worker implementation file 
 *
 * 2006-04-15
 * Olivier Delannoy
 */
#ifdef HAVE_CONFIG_H
#include <yml_config.hh> 
#endif 
#include "worker_common.h" 
#ifndef _GNU_SOURCE
# define _GNU_SOURCE
#endif
#include "network.h"
#include "udns/udns.h" 
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>   
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <stdlib.h>
#include <stdio.h> 
#include <errno.h> 
#include <string.h>

struct network
{
    int mSocket;
    struct sockaddr_in mAddress;
    network_client_disconnect_hook_t mHook;
};
typedef struct network* network_t;

static int network_dns_parse_hosts(struct in_addr* addr, const char* hostname)
{
#define NETWORK_DNS_ETC_HOSTS_FILE "/etc/hosts" 
#define NETWORK_DNS_BUFFER_SIZE 8192
    
    int status = -1;
    char buffer[NETWORK_DNS_BUFFER_SIZE];
    FILE* fd = 0;
    YML_DEBUG_INSTRUMENT_START("network_dns_parse_hosts");
    fd = fopen(NETWORK_DNS_ETC_HOSTS_FILE, "r");
    if (fd)
    {
        while (fgets(buffer, NETWORK_DNS_BUFFER_SIZE, fd) == buffer)
        {
            char* token = 0;
            char* ip = 0;
            char* state = 0;
            token = strtok_r(buffer, " \t\n", &state);
            if (token == 0 || token[0] == '#')
                continue;
            ip = token;
#ifdef HAVE_WORKER_DEBUG      
            printf("DEBUG(%15s:%03d): IP: <%s>\n", __FILE__, __LINE__, ip);
#endif 
            while(token)
            {
                token = strtok_r(0, " \t\n", &state);
                if (token == 0 || token[0] == '#')
                    break;
#ifdef HAVE_WORKER_DEBUG
                printf("DEBUG(%15s,%03d)\t-<%s>\n", __FILE__, __LINE__, token);
#endif 
                if (strcmp(token, hostname) == 0)
                {
                    status = ! inet_aton(ip, addr);
                    fclose(fd);
                    YML_DEBUG_INSTRUMENT_STOP("network_dns_parse_hosts");
                    return status;
                }
            }
        }
        fclose(fd);
    }
    return status;
    YML_DEBUG_INSTRUMENT_STOP("network_dns_parse_hosts");
#undef NETWORK_DNS_BUFFER_SIZE 
#undef NETWORK_DNS_ETC_HOSTS_FILE
}

// Not thread safe Take care 
static int network_dns(struct in_addr* addr, const char*  hostname)
{
    static int dnsHasBeenInitOnce =  0;
    int status = -1;
    YML_DEBUG_INSTRUMENT_START("network_dns");
    // Check wether its an IP address 
    status = ! inet_aton(hostname, addr);
    if (status != 0)
    {
        // Check wether its available in /etc hosts 
        status = network_dns_parse_hosts(addr, hostname);
        if (status != 0)
        {
            struct dns_ctx * dnsContext;
            struct dns_rr_a4 *result;
            //Use udns to resolve 
            if (dnsHasBeenInitOnce == 0)
            {   
                status = dns_init(1);
                if (status < 0)
                {
                    YML_DEBUG_INSTRUMENT_STOP("network_dns");
                    return status;              
                }
                dnsHasBeenInitOnce = 1;
            }
            dnsContext = dns_new(0);
            if (dnsContext == 0) 
            {
                // Stop DNS 
                YML_DEBUG_INSTRUMENT_STOP("network_dns");
                return -1;
            }
            result = dns_resolve_a4(dnsContext, hostname, 0);
            if (result == NULL)
            {
                status = -dns_status(dnsContext);
                dns_free(dnsContext);
                YML_DEBUG_INSTRUMENT_STOP("network_dns");
                return status;
            }
            memcpy(addr, result->dnsa4_addr, sizeof(*addr));
            dns_free(dnsContext);
            status = 0;
        }
    }
    YML_DEBUG_INSTRUMENT_STOP("network_dns");
    return status;
}


int network_connect(network_client_t* client, char* host, unsigned short port, network_client_disconnect_hook_t hook)
{
    // Resolve host at the time being only ip address is supported 
    int status;
    int retry = 0; 
    network_t net;
    // Create client 
    YML_DEBUG_INSTRUMENT_START("network_client_connect");
    *client = 0;
    net = (network_t) malloc(sizeof(*net));
    if (net == 0)
    {
        // Oups memory allocation failed 
        YML_DEBUG_INSTRUMENT_STOP("network_client_connect");
        return -errno;
    }
    memset((char*)net, 0, sizeof(*net));
    net->mHook = hook;
    net->mAddress.sin_family = AF_INET;
    net->mAddress.sin_port = htons(port);
    if (network_dns(&(net->mAddress.sin_addr), host) != 0)
    {
        // Invalid address 
        free(net);
        YML_DEBUG_INSTRUMENT_STOP("network_client_connect");
        return -errno;    
    }
    
    // Create the socket 
    net->mSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (net->mSocket == -1)
    {
        // Socket creation failed 
        free(net);
        YML_DEBUG_INSTRUMENT_STOP("network_client_connect");
        return -errno;
    }
    // Contact 5 times before returning an error 
    status = 1; 
    while(status &&  retry < 5)
    {
        status = connect(net->mSocket, (struct sockaddr*)&(net->mAddress), sizeof(net->mAddress));
        if (status != 0)
        {
            // It's an error 
            ++retry;
            usleep(5000);
        }
    }
    
    if (status != 0)
    {
        close(net->mSocket);
        free(net);
        *client = 0;
        YML_DEBUG_INSTRUMENT_STOP("network_client_connect");
        return -errno;
    }
    *client = net;
    YML_DEBUG_INSTRUMENT_STOP("network_client_connect");
    return 0;
}
void network_disconnect(network_client_t client)
{
    network_client_disconnect_hook_t hook;
    YML_DEBUG_INSTRUMENT_START("network_client_disconnect");
    if (((network_t)client)->mSocket != -1)
    {
        hook = ((network_t)client)->mHook;
        if (hook)
            hook(client);
        close(((network_t)client)->mSocket);
    }
#ifdef HAVE_WORKER_DEBUG
    printf("DEBUG(%15s:%3d): Socket %d disconnected\n", __FILE__, __LINE__, ((network_t)client)->mSocket);
#endif 
    free(client);
    YML_DEBUG_INSTRUMENT_STOP("network_client_disconnect");
}
int network_change_server(network_client_t client, char* host, unsigned short port)
{
    network_client_disconnect_hook_t hook;
    network_t net;
    struct sockaddr_in addr;
    int status;
    int retry = 0; 
    int cmp;
    int cmp2;
    YML_DEBUG_INSTRUMENT_START("nerwork_change_server");
    net = (network_t) client;
    hook = net->mHook;
    if (network_dns(&(addr.sin_addr), host) != 0)
    {
        // Invalid address 
        free(net);
        YML_DEBUG_INSTRUMENT_STOP("network_client_connect");
        return -errno;    
    }

#ifdef HAVE_WORKER_DEBUG
    printf("DEBUG(%15s:%3d): Current Address %s:%d\n", __FILE__, __LINE__, 
           inet_ntoa(net->mAddress.sin_addr), ntohs(net->mAddress.sin_port));
    printf("DEBUG(%15s:%3d): New Address %s:%d\n", __FILE__, __LINE__,
           inet_ntoa(addr.sin_addr), port);
#endif 
    
    cmp = ! strcmp(inet_ntoa(net->mAddress.sin_addr), inet_ntoa(addr.sin_addr));
    cmp2 =  ntohs(net->mAddress.sin_port) == port;
    if (!( cmp && cmp2))
    {
        
        // Disconnect from the current server 
        if (hook)
            hook(net);
        close(net->mSocket);
        
        // Create the new address 
        addr.sin_family = AF_INET;
        addr.sin_port = htons(port);
        if (inet_aton(host, &(net->mAddress.sin_addr)) == 0)
        {
            // Invalid address 
            YML_DEBUG_INSTRUMENT_STOP("network_change_server");
            return -errno;
        }
        memcpy((char*)&(net->mAddress), 
               (char*)&addr, 
               sizeof(addr));
        
        net->mSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        if (net->mSocket == -1)
        {
            // Socket creation failed 
            free(net);
            YML_DEBUG_INSTRUMENT_STOP("network_change_server");
            return -errno;
        }
        // Contact 5 times before returning an error 
        status = 1; 
        while(status &&  retry < 1)
        {
            printf("Connect to the server %d\n", retry + 1);
            status = connect(net->mSocket, (struct sockaddr*)&(net->mAddress), sizeof(net->mAddress));
            if (status != 0)
            {
                // It's an error 
                ++retry;
                usleep(5000);
            }
        }
        
        if (status != 0)
        {
            // Connect failed after five try at it 
            close(net->mSocket);
            net->mSocket = -1;
            YML_DEBUG_INSTRUMENT_STOP("network_change_server");
            return -errno;
        }
    }
    YML_DEBUG_INSTRUMENT_STOP("network_change_server");
    return 0;
}
int network_read(network_client_t client, char* buffer, size_t size)
{
    int status;
    network_t net;
    YML_DEBUG_INSTRUMENT_START("network_client_read");
    net = (network_t) client;
    status = read(net->mSocket, buffer, size);
#ifdef HAVE_WORKER_DEBUG
    printf("DEBUG(%15s:%3d): Socket %d read %d bytes\n", __FILE__, __LINE__, net->mSocket, status);
#endif
    YML_DEBUG_INSTRUMENT_STOP("network_client_read");
    return status;

}
int network_write(network_client_t client, char* buffer, size_t size)
{
    int status;
    network_t net;
    YML_DEBUG_INSTRUMENT_START("network_client_write");
    net = (network_t) client;
    status = write(net->mSocket, buffer, size);
#ifdef HAVE_WORKER_DEBUG
    printf("DEBUG(%15s:%3d): Socket %d write %d / %d bytes\n" , __FILE__, __LINE__, net->mSocket, status, size);
#endif 
    YML_DEBUG_INSTRUMENT_STOP("network_client_write");
    return status;
}
/****************************************************************************/
