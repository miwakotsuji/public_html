#include <digest.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define TEST_DATA "abcdefg"
#define TEST_DATA_MD5_DIGEST "7ac66c0f148de9519b8bd264312c4d64"
#define TEST_DATA_SHA1_DIGEST "" 

int main()
{
    int success = 0;
    digest_md5_state_t md5_state;
    digest_byte_t      md5_digest[DIGEST_MD5_HASH_SIZE];
    char               md5_string[DIGEST_MD5_STRING_SIZE];

    digest_sha1_state_t sha1_state;
    digest_byte_t       sha1_digest[DIGEST_SHA1_HASH_SIZE];
    char                sha1_string[DIGEST_SHA1_STRING_SIZE];

    char* string;
    
    digest_md5_init  (&md5_state);
    digest_md5_append(&md5_state, (digest_byte_t*)TEST_DATA,  
		      strlen(TEST_DATA));
    digest_md5_finish(&md5_state, md5_digest);
    digest_md5_string(md5_digest, md5_string);
    string = digest_to_string(md5_digest, DIGEST_MD5_HASH_SIZE);
    printf("MD5 Expecting ...: %s -- %s\n", TEST_DATA, 
           TEST_DATA_MD5_DIGEST);
    printf("MD5 Result ......: %s -- %s\n", TEST_DATA, md5_string);
    if (strcmp(md5_string, TEST_DATA_MD5_DIGEST) == 0)
    {
        printf("MD5 digest match\n");
        success = 0x01;
    }
    printf("MD5 Result 2 ....: %s -- %s\n", TEST_DATA, string);
    if (strcmp(string, TEST_DATA_MD5_DIGEST) == 0)
    {
        printf("MD5 digest match\n");
        success = 0x02;
    }
    free(string);
      
    /* Sha1 */
    digest_sha1_init(&sha1_state);
    digest_sha1_append(&sha1_state, (digest_byte_t*)TEST_DATA,  
		       strlen(TEST_DATA));
    digest_sha1_finish(&sha1_state, sha1_digest);
    digest_sha1_string(sha1_digest, sha1_string);
    string = digest_to_string(sha1_digest, DIGEST_SHA1_HASH_SIZE);
    printf("SHA1 Expecting ...: %s -- %s\n", TEST_DATA, 
           TEST_DATA_SHA1_DIGEST);
    printf("SHA1 Result ......: %s -- %s\n", TEST_DATA, sha1_string);
    if (strcmp(sha1_string, TEST_DATA_SHA1_DIGEST) == 0)
    {
        printf("SHA1 digest match\n");
        success = 0x04;
    }
    printf("MD5 Result 2 ....: %s -- %s\n", TEST_DATA, string);
    if (strcmp(string, TEST_DATA_SHA1_DIGEST) == 0)
    {
        printf("MD5 digest match\n");
        success = 0x08;
    }
    free(string);
    return EXIT_FAILURE;
}

