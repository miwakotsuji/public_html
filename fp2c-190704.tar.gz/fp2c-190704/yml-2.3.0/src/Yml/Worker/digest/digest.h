/*
// ***********************************************************************
// Digest library 
// File: digest.h 
// Author: Olivier Delannoy
// Date: 15 Jul 2007
// ***********************************************************************
// Copyright (c) 2006 listed in Authors.txt file 
//
// Permission is hereby granted, free of charge, to any person 
// obtaining a copy of this software and associated documentation 
// files (the "Software"), to deal in the Software without restriction,
// including without limitation the rights to use, copy, modify, merge,
// publish, distribute, sublicense, and/or sell copies of the Software,
// and to permit persons to whom the Software is furnished to do so, 
// subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be 
// included in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND 
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS 
// BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN 
// ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
// CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
// ***********************************************************************
*/
#ifndef DIGEST_H 
#define DIGEST_H 1 
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus 
extern "C" 
{
#endif 
  #define DIGEST_MD5_HASH_WORD_SIZE  4
  #define DIGEST_MD5_HASH_SIZE  16
  #define DIGEST_MD5_STRING_SIZE 1 + 2 * DIGEST_MD5_HASH_SIZE 
  #define DIGEST_SHA1_HASH_WORD_SIZE 5
  #define DIGEST_SHA1_HASH_SIZE 20
  #define DIGEST_SHA1_STRING_SIZE 1 + 2 * DIGEST_SHA1_HASH_SIZE 
  
  struct digest_md5_state_s;
  struct digest_sha1_state_s;
  typedef uint8_t digest_byte_t;  
  typedef uint32_t  digest_word_t;
  
  typedef struct digest_md5_state_s  digest_md5_state_t;
  typedef struct digest_sha1_state_s digest_sha1_state_t;
  
  struct digest_md5_state_s
  {
    digest_word_t count[2];
    digest_word_t abcd[4];
    digest_byte_t buf[64];
  };

  struct digest_sha1_state_s
  {
    uint64_t totalLength;
    digest_word_t hash[5];
    uint32_t bufferLength;
    union 
    {
      digest_word_t words[16];
      uint8_t bytes[64];
    } buffer;
  };
  /*! \brief Initialize the context. */
  void digest_md5_init(digest_md5_state_t *pms);
  /*! \brief Append a string to the message. */
  void digest_md5_append(digest_md5_state_t *pms, const digest_byte_t *data, size_t dataLength);
  /*! \brief Finish the message and return the digest. */
  void digest_md5_finish(digest_md5_state_t *pms, digest_byte_t digest[DIGEST_MD5_HASH_SIZE]);
  /*! \brief Convert a md5 digest to a string */
  void digest_md5_string(digest_byte_t digest[DIGEST_MD5_HASH_SIZE], 
			 char stringDigest[DIGEST_MD5_STRING_SIZE]);
  
  /*! \brief Initialize the context. */
  void digest_sha1_init(digest_sha1_state_t *pms);
  /*! \brief append a string to the message. */ 
  void digest_sha1_append(digest_sha1_state_t *pms, const digest_byte_t *data, size_t dataLength);
  /*! \brief finish the message and return the digest. */
  void digest_sha1_finish(digest_sha1_state_t *pms, digest_byte_t digest[DIGEST_SHA1_HASH_SIZE]);
  /*! \brief Convert a sha1 digest to a string */
  void digest_sha1_string(digest_byte_t digest[DIGEST_SHA1_HASH_SIZE], 
			  char stringDigest[DIGEST_SHA1_STRING_SIZE]);

  /*! \brief create a string representation of the digest (memory is dynam */ 
  char* digest_to_string(digest_byte_t* digest, size_t digestLength);

#ifdef __cplusplus
}
#endif


#endif 
