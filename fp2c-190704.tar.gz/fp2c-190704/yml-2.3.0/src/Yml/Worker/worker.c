/* -*- mode: c; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/
/**
 * @file
 * @brief Default Worker implementation file 
 *
 * 2006-04-13
 * Olivier Delannoy
 */
#include "worker_private.h"
#include "worker.h"
#include "vfs/vfs.h"
#include "drclient.h"
#include "pack.h" 
#define _GNU_SOURCE

#include <stdlib.h>
#include <errno.h> 
#include <unistd.h>
#include <fcntl.h> 
#include <dirent.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h> 
#include <fcntl.h>
#include <sys/wait.h>
#include <locale.h> 

#include <expat.h> 
#define WORKER_FILE_PACK_DATA "worker_pack_data.arc1"
#define WORKER_FILE_DATA_OUTPUT "output.txt"
#define WORKER_FILE_PACK_ADMIN "worker_pack_admin.arc1"
#define WORKER_FILE_ADMIN_STATUS "status.txt"
#define WORKER_FILE_ADMIN_TRACE "trace.txt"
#define WORKER_DEBUG_TRACE "/tmp/yml-worker-trace.txt"
#define WORKER_CACHE_PATH "/tmp/yml-worker-cache"


struct droperation
{
	char*          mHost;
	unsigned short mPort;
	char*          mUri;
	uint8          mIsPacked;
};
typedef struct droperation droperation_t;

struct worker 
{
	drclient_t mClient;
	char mInitialWorkingDir[PATH_MAX];
	char mWorkingDir[PATH_MAX];
	char* mWorkDescription;
	uint32 mWorkDescriptionSize;
	char* mBinaryName;

	char** mParameters;
	uint32 mParameterCurrent;
	uint32 mParameterCount;

	droperation_t* mImports;
	uint32 mImportCurrent;
	uint32 mImportCount;

	droperation_t mExport;
	droperation_t mAdmin;
	uint8 mXmlErrorDetected;
};
typedef struct worker* worker_t;
/**
 * @brief Initialize a new worker context 
 * 
 * Does the initialization of the worker options 
 * 
 * @param context the worker handler 
 * @param options a list of options of the form options[i]= key, options[i+1]=value NULL terminated.  
 * @param client a pointer or 0 
 */
int worker_init(worker_t* context, char* data, uint32 dataSize, drclient_t client);
/**
 * @brief Destroy a worker context 
 * 
 * Do all the cleaning required for this stuff 
 * 
 * @param context The context to be cleaned 
 */
static void worker_destroy(worker_t context);
/**
 * Import resources before the execution 
 */
int worker_import_resources(worker_t context);
/**
 * Export resources after the execution  
 */
int worker_export_resources(worker_t context);
/**
 * Execute the component 
 */
static int worker_execute(worker_t context);
/** 
 * Import data from the worker cache
 */
static int worker_get_from_cache(worker_t context, const char* full_path);
/**
 * Add something into the cache for later use 
 */
static int worker_put_in_cache(worker_t context, const char* local_path);
/**
 * Element start handler for the work expat parser 
 */
static void work_start_element(void *data, const char *el, const char **attr);
/** 
 * Element end handler for the work expat parser 
 */
static void work_end_element(void *data, const char *el);

int worker(char* data, uint32 dataSize, drclient_t client)
{
	worker_t context;
	int status;
#ifdef HAVE_WORKER_DEBUG
	freopen(WORKER_DEBUG_TRACE, "a", stdout);
	setbuf(stdout, NULL);
#endif 
	setlocale(LC_ALL, "C");
	YML_DEBUG_INSTRUMENT_START("worker");
#ifdef HAVE_WORKER_DEBUG
	printf("----------------------------------------\n");
	printf("-- Input\n");
	printf("----------------------------------------\n");
	int i = 0;
	for (i = 0 ; i < dataSize ; ++i)
		putc(data[i], stdout);
	putc('\n', stdout);
	printf("----------------------------------------\n");
#endif 
#ifdef HAVE_WORKER_CACHE 
	vfs_mkdir(WORKER_CACHE_PATH, 0777);
#endif 
	// Create the worker context and fill it with the correct
	// value from the work description
	status = worker_init(&context, data, dataSize, client);
	if (status != 0)
	{
		YML_DEBUG_INSTRUMENT_STOP("worker");
		return status;
	}
	// Import all datas
	status = worker_import_resources(context);
	if (status != 0)
	{
		worker_destroy(context);
		YML_DEBUG_INSTRUMENT_STOP("worker");
		return status;
	}
	// Execute the work
	status = worker_execute(context);
	if (status != 0)
	{
		worker_destroy(context);
		YML_DEBUG_INSTRUMENT_STOP("worker");
		return status;
	}
	// Export the result
	status = worker_export_resources(context);
	if (status != 0)
	{
		worker_destroy(context);
		YML_DEBUG_INSTRUMENT_STOP("worker");
		return status;
	}
	worker_destroy(context);
	YML_DEBUG_INSTRUMENT_STOP("worker");
	return 0;
}

int worker_init(worker_t* context, char* data, uint32 dataSize, drclient_t client)
{
	int i;
	YML_DEBUG_INSTRUMENT_START("worker_init");
	*context = (worker_t)malloc(sizeof(**context));
	if (*context == 0)
	{
		// Malloc failed
		YML_DEBUG_INSTRUMENT_STOP("worker_init");
		return -errno;
	}
	memset((char*)*context, 0, sizeof(**context));
	if (client)
	{
		(*context)->mClient = client;
	}
	else
	{
		(*context)->mClient = 0;
	}
	(*context)->mWorkDescription = data;
	(*context)->mWorkDescriptionSize = dataSize;
	// Parse the work description data
	XML_Parser parser = XML_ParserCreate(NULL);
	if (! parser)
	{
		if (client)
			drclient_disconnect(client);
		free(*context);
		YML_DEBUG_INSTRUMENT_STOP("worker_init");
		return -2;
	}
	XML_SetUserData(parser, (void*)(*context));
	XML_SetElementHandler(parser, work_start_element, work_end_element);
	if (! XML_Parse(parser, data, dataSize, 1))
	{
		int errorCode = XML_GetErrorCode(parser);
		// Parse error
		printf("%d: %s at (%d,%d) in the work description\n",
				XML_GetErrorCode(parser),
				XML_ErrorString(XML_GetErrorCode(parser)),
				XML_GetCurrentLineNumber(parser),
				XML_GetCurrentColumnNumber(parser));
		XML_ParserFree(parser);
		if (client)
			drclient_disconnect(client);
		free(*context);
		YML_DEBUG_INSTRUMENT_STOP("worker_init");
		return errorCode;
	}
	XML_ParserFree(parser);
	if ((*context)->mXmlErrorDetected)
	{
		for(i = 0 ; (*context)->mParameterCount ; ++i)
		{
			free((*context)->mParameters[i]);
		}
		free((*context)->mParameters);
		// Free imports
		for(i = 0 ; i < (*context)->mImportCount ; ++i)
		{
			free((*context)->mImports[i].mHost);
			free((*context)->mImports[i].mUri);
		}
		free((*context)->mImports);
		// Free Export
		free((*context)->mExport.mHost);
		free((*context)->mExport.mUri);
		// Free Admin
		free((*context)->mAdmin.mHost);
		free((*context)->mAdmin.mUri);
		// Destroy the drclient
		if ((*context)->mClient)
			drclient_disconnect((*context)->mClient);
		// Free the context
		free((*context));
		YML_DEBUG_INSTRUMENT_STOP("worker_init");
		return -1;
	}

	// Create working dir and move to the correct place
	getcwd((*context)->mInitialWorkingDir, PATH_MAX);

	// Go to a temporary directory where we should be able to work
	sprintf((*context)->mWorkingDir,
			"%syml-worker-%d-XXXXXX",(*context)->mWorkingDir,
			getpid());
	if (mkdtemp((*context)->mWorkingDir) == 0)
	{
		for(i = 0 ; (*context)->mParameters[i] ; ++i)
		{
			free((*context)->mParameters[i]);
		}
		free((*context)->mParameters);
		// Free imports
		for(i = 0 ; i < (*context)->mImportCount ; ++i)
		{
			free((*context)->mImports[i].mHost);
			free((*context)->mImports[i].mUri);
		}
		free((*context)->mImports);
		// Free Export
		free((*context)->mExport.mHost);
		free((*context)->mExport.mUri);
		// Free Admin
		free((*context)->mAdmin.mHost);
		free((*context)->mAdmin.mUri);
		// Destroy the drclient
		if ((*context)->mClient)
			drclient_disconnect((*context)->mClient);
		// Free the context
		free((*context));
		YML_DEBUG_INSTRUMENT_STOP("worker_init");
		return -errno;
	}

	// change to a newly created temporary dir
	if (chdir((*context)->mWorkingDir) != 0)
	{
		vfs_rmdir((*context)->mWorkingDir);
		for(i = 0 ; (*context)->mParameters[i] ; ++i)
		{
			free((*context)->mParameters[i]);
		}
		free((*context)->mParameters);
		// Free imports
		for(i = 0 ; i < (*context)->mImportCount ; ++i)
		{
			free((*context)->mImports[i].mHost);
			free((*context)->mImports[i].mUri);
		}
		free((*context)->mImports);
		// Free Export
		free((*context)->mExport.mHost);
		free((*context)->mExport.mUri);
		// Free Admin
		free((*context)->mAdmin.mHost);
		free((*context)->mAdmin.mUri);
		// Destroy the drclient
		if ((*context)->mClient)
			drclient_disconnect((*context)->mClient);
		// Free the context
		free((*context));
		YML_DEBUG_INSTRUMENT_STOP("worker_init");
		return -errno;
	}
	YML_DEBUG_INSTRUMENT_STOP("worker_init");
	return 0;
}

void worker_destroy(worker_t context)
{
	int i;
	YML_DEBUG_INSTRUMENT_START("worker_destroy");

	// Get back to the intial working dir
	chdir(context->mInitialWorkingDir);
	// Clean the subfolder
#ifndef HAVE_WORKER_DEBUG   
	vfs_rmdir(context->mWorkingDir);
#endif 


	// Free parameters
	for(i = 0 ; context->mParameters[i] ; ++i)
	{
		free(context->mParameters[i]);
	}
	free(context->mParameters);
	// Free imports
	for(i = 0 ; i < context->mImportCount ; ++i)
	{
		free(context->mImports[i].mHost);
		free(context->mImports[i].mUri);
	}
	free(context->mImports);
	// Free Export
	free(context->mExport.mHost);
	free(context->mExport.mUri);
	// Free Admin
	free(context->mAdmin.mHost);
	free(context->mAdmin.mUri);
	// Destroy the drclient
	if (context->mClient)
		drclient_disconnect(context->mClient);
	// Free the context
	context->mWorkDescription = 0;
	free(context);
	YML_DEBUG_INSTRUMENT_STOP("worker_destroy");
}

/*
int worker_import_resources(worker_t context)
{
    int i;
    int status;
    char* local;
    int foundInCache;
    YML_DEBUG_INSTRUMENT_START("worker_import_resources");
    for(i = 0; i < context->mImportCount ; ++i)
    {
        foundInCache = 0;
#ifdef HAVE_WORKER_DEBUG
        printf("DEBUG(%15s:%3d): Import: dr://%s:%d%s pack: %s\n", __FILE__, __LINE__, context->mImports[i].mHost, 
               context->mImports[i].mPort, context->mImports[i].mUri, 
               context->mImports[i].mIsPacked ? "yes" : "no");        
#endif 
        local = rindex(context->mImports[i].mUri, VFS_PATH_SEPARATOR);
        if (local == 0)
        {
            // No basename detected: invalid uri 
            YML_DEBUG_INSTRUMENT_STOP("worker_import_resources");
            return -1;
        }
        ++local;
#ifdef HAVE_WORKER_CACHE        
        if (! context->mImports[i].mIsPacked)
        {
# ifdef HAVE_WORKER_DEBUG 
            printf("DEBUG(%15s:%3d) Checking for %s in cache\n", 
                    __FILE__, __LINE__, local);
# endif 
            // Check in the cache 
            if (worker_get_from_cache(context, local) == 0)
            {
# ifdef HAVE_WORKER_DEBUG
                printf("DEBUG(%15s:%3d) %s imported from cache\n", 
                        __FILE__, __LINE__, local);
# endif
                foundInCache = 1;
            }
        }
#endif

        if (! foundInCache)
        {
# ifdef HAVE_WORKER_DEBUG
            printf("DEBUG(%15s:%3d) %s not found in the cache\n", 
                    __FILE__, __LINE__, local);
# endif 
            if (context->mClient)
            {

                status = drclient_change_server(
                             context->mClient, 
                             context->mImports[i].mHost, 
                             context->mImports[i].mPort);
            }
            else 
            {
                status = drclient_connect(&(context->mClient), 
                        context->mImports[i].mHost, 
                        context->mImports[i].mPort);
            }
            if (status != 0)
            {
                // It's an error grrrr 
                YML_DEBUG_INSTRUMENT_STOP("worker_import_resources");
                return status;
            }
            status = drclient_get(context->mClient, 
                    context->mImports[i].mUri, local);
            if (status != 0)
            {
                // DR GET Request failed 
                YML_DEBUG_INSTRUMENT_STOP("worker_import_resources");
                return status;
            }
            // if it's a pack let's extract it 
            if (context->mImports[i].mIsPacked)
            {
                pack_t pack;
                status = pack_open(&pack, local);
                if (status != 0)
                {
                    // ERROR invalid pack file 
                    YML_DEBUG_INSTRUMENT_STOP("worker_import_resources");
                    return status;
                }
                status = pack_extract(pack, context->mWorkingDir);
                pack_close(pack);
                remove(local);
    	        if (status != 0)
                {
                    // Error while extracting the pack file
                    YML_DEBUG_INSTRUMENT_STOP("worker_import_resources");
                    return status;
                }
            }
        }
#ifdef HAVE_WORKER_CACHE
        if ((! foundInCache) && (! context->mImports[i].mIsPacked))
        {
# ifdef HAVE_WORKER_DEBUG
            printf("DEBUG(%15s:%3d): Put %s in cache\n", 
                    __FILE__, __LINE__, local);
# endif 
            // Put in cache 
            // It doesn't really matter if it failed  
            worker_put_in_cache(context, local);
        }
#endif        

    }
    YML_DEBUG_INSTRUMENT_STOP("worker_import_resources");
    return 0;
} */

/* for nfs */

int worker_import_resources(worker_t context)
{
	int i;
	int status;
//	char local[PATH_MAX];
	int foundInCache;
	char dir[PATH_MAX];

	YML_DEBUG_INSTRUMENT_START("worker_import_resources");
	// Omit i=0 (biinary)
	for(i = 1; i < context->mImportCount ; ++i)
	{
		foundInCache = 0;
		if (! foundInCache)
		{
# ifdef HAVE_WORKER_DEBUG
			printf("DEBUG(%15s:%3d) %s not found in the cache\n",
					__FILE__, __LINE__, context->mImports[i].mUri);
# endif
			// if it's a pack let's extract it
			if (context->mImports[i].mIsPacked)
			{
				pack_t pack;
				status = pack_open(&pack, context->mImports[i].mUri);
				if (status != 0)
				{
					// ERROR invalid pack file
					YML_DEBUG_INSTRUMENT_STOP("worker_import_resources");
					return status;
				}
				status = pack_extract(pack, context->mWorkingDir);

				pack_close(pack);
				//remove(local);
				if (status != 0)
				{
					// Error while extracting the pack file
					YML_DEBUG_INSTRUMENT_STOP("worker_import_resources");
					return status;
				}
			}
		}
#ifdef HAVE_WORKER_CACHE
		if ((! foundInCache) && (! context->mImports[i].mIsPacked))
		{
# ifdef HAVE_WORKER_DEBUG
			printf("DEBUG(%15s:%3d): Put %s in cache\n",
					__FILE__, __LINE__, context->mWorkingDir);
# endif
			// Put in cache
			// It doesn't really matter if it failed
			worker_put_in_cache(context, context->mWorkingDir);
		}
#endif

	}
	YML_DEBUG_INSTRUMENT_STOP("worker_import_resources");
	return 0;
}


/*
int worker_export_resources(worker_t context)
{
    pack_t packAdmin;
    pack_t packData;
    FILE* outputList;
    char file[PATH_MAX];
//    char* fstatus;
    int status;
    YML_DEBUG_INSTRUMENT_START("worker_export_resources");
    // Export results 
    status = pack_open(&packData, WORKER_FILE_PACK_DATA);
    if (status != 0)
    {
        // Error while creating data pack 
        YML_DEBUG_INSTRUMENT_STOP("worker_export_resources");
        return status;
    }        
    // Parse the output.txt file and file the result pack 
    outputList = fopen(WORKER_FILE_DATA_OUTPUT, "r");
    if (! outputList)
    {
        // unable to open the list of resulting files 
        pack_close(packData);
        YML_DEBUG_INSTRUMENT_STOP("worker_export_resources");
        return -errno;
    }
    // Parse the list and pack files one after the other 
    while(!feof(outputList))
    {
        int tmp = fscanf(outputList, "%s", file);
        if (tmp == EOF)
            continue;
        if (tmp == 0)
        {
            // Error ... 
            fclose(outputList);
            pack_close(packData);
            YML_DEBUG_INSTRUMENT_STOP("worker_export_resources");
            return -errno;
        }
        // Pack the file
        status = pack_add_file(packData, file, file);
        if (status != 0)
        {
            // Pack of file failed 
            fclose(outputList);
            pack_close(packData);
            YML_DEBUG_INSTRUMENT_STOP("worker_export_resources");
            return status;
        }
        remove(file);
    }
    fclose(outputList);
    pack_close(packData);
    // Send the pack to the remote host
#ifdef HAVE_WORKER_DEBUG
    printf("DEBUG(%15s:%3d): Export dr://%s:%d:%s packed=yes\n", __FILE__, __LINE__,
           context->mExport.mHost, context->mExport.mPort, context->mExport.mUri);

#endif
    status = drclient_change_server(context->mClient, context->mExport.mHost, context->mExport.mPort);
    if (status != 0)
    {
        // Unable to connect to the correct DRServer 
        YML_DEBUG_INSTRUMENT_STOP("worker_export_resources");
        return status;
    }
    status = drclient_put(context->mClient, context->mExport.mUri, WORKER_FILE_PACK_DATA);
    if (status != 0)
    {
        // Unable to send data to the DRServer 
        YML_DEBUG_INSTRUMENT_STOP("worker_export_resources");
        return status;
    }
    // Export admin 
#ifdef HAVE_WORKER_DEBUG
    printf("DEBUG(%15s:%3d): Admin dr://%s:%d:%s packed=yes\n", __FILE__, __LINE__,
           context->mAdmin.mHost, context->mAdmin.mPort, context->mAdmin.mUri);

#endif
    status = pack_open(&packAdmin, WORKER_FILE_PACK_ADMIN);
    if (status != 0)
    {
        // Error while creating data pack 
        YML_DEBUG_INSTRUMENT_STOP("worker_export_resources");
        return status;
    }
    // Pack Status file 
    status = pack_add_file(packAdmin, WORKER_FILE_ADMIN_STATUS, WORKER_FILE_ADMIN_STATUS);
    if (status != 0)
    {
        pack_close(packAdmin);
        YML_DEBUG_INSTRUMENT_STOP("worker_export_resources");
        return status;
    }
    // Pack Trace file 
    status = pack_add_file(packAdmin, WORKER_FILE_ADMIN_TRACE, WORKER_FILE_ADMIN_TRACE);
    if (status != 0)
    {
        pack_close(packAdmin);
        YML_DEBUG_INSTRUMENT_STOP("worker_export_resources");
        return status;
    }
    pack_close(packAdmin);
    // Send admin data back to the server 
    status = drclient_change_server(context->mClient, context->mAdmin.mHost, context->mAdmin.mPort);
    if (status != 0)
    {
        // Unable to connect to the correct DRServer 
        YML_DEBUG_INSTRUMENT_STOP("worker_export_resources");
        return status;
    }
    status = drclient_put(context->mClient, context->mAdmin.mUri, WORKER_FILE_PACK_ADMIN);
    if (status != 0)
    {
        // Unable to send data to the DRServer 
        YML_DEBUG_INSTRUMENT_STOP("worker_export_resources");
        return status;
    }
    YML_DEBUG_INSTRUMENT_STOP("worker_export_resources");
    return 0;
}
 */

/* for nfs */
int worker_export_resources(worker_t context)
{
	pack_t packAdmin;
	pack_t packData;
	FILE* outputList;
	char file[PATH_MAX];
	char path[PATH_MAX];
	char outadmin[PATH_MAX];
	int status;
	int data;
	YML_DEBUG_INSTRUMENT_START("worker_export_resources");
	// Export results
//	sprintf(outpack,"%s%s\0",TMP_DR_ROOT,context->mExport.mUri);
	//status = pack_open(&packData, WORKER_FILE_PACK_DATA);
	status = pack_open(&packData, context->mExport.mUri);
	if (status != 0)
	{
		// Error while creating data pack
		YML_DEBUG_INSTRUMENT_STOP("worker_export_resources");
		return status;
	}
	// Parse the output.txt file and file the result pack
	sprintf(path,"%s/%s\0",context->mWorkingDir,WORKER_FILE_DATA_OUTPUT);
	//outputList = fopen(WORKER_FILE_DATA_OUTPUT, "r");
	outputList = fopen(path, "r");
	if (! outputList)
	{
		// unable to open the list of resulting files
		pack_close(packData);
		YML_DEBUG_INSTRUMENT_STOP("worker_export_resources");
		return -errno;
	}
	// Parse the list and pack files one after the other
	while(!feof(outputList))
	{
		int tmp = fscanf(outputList, "%s", file);
		if (tmp == EOF)
			continue;
		if (tmp == 0)
		{
			// Error ...
			fclose(outputList);
			pack_close(packData);
			YML_DEBUG_INSTRUMENT_STOP("worker_export_resources");
			return -errno;
		}
                // Skip the file which is exchanged directory using NFS
                if(file[0] == '0' && file[1] == ',')
                  continue;

		// Pack the file
		sprintf(path,"%s/%s\0",context->mWorkingDir,file);
		status = pack_add_file(packData, file, path);
		if (status != 0)
		{
			// Pack of file failed
			fclose(outputList);
			pack_close(packData);
			YML_DEBUG_INSTRUMENT_STOP("worker_export_resources");
			return status;
		}
		remove(path);
	}
	fclose(outputList);
	pack_close(packData);
	// Send the pack to the remote host
#ifdef HAVE_WORKER_DEBUG
	printf("DEBUG(%15s:%3d): Export dr://%s:%d:%s packed=yes\n", __FILE__, __LINE__,
			context->mExport.mHost, context->mExport.mPort, context->mExport.mUri);

#endif
	// Export admin
#ifdef HAVE_WORKER_DEBUG
	printf("DEBUG(%15s:%3d): Admin dr://%s:%d:%s packed=yes\n", __FILE__, __LINE__,
			context->mAdmin.mHost, context->mAdmin.mPort, context->mAdmin.mUri);

#endif
	//sprintf(outadmin,"%s%s\0",context->mWorkingDir,context->mAdmin.mUri);
	//status = pack_open(&packAdmin, WORKER_FILE_PACK_ADMIN);
	status = pack_open(&packAdmin, context->mAdmin.mUri);
	if (status != 0)
	{
		// Error while creating data pack
		YML_DEBUG_INSTRUMENT_STOP("worker_export_resources");
		return status;
	}
	// Pack Status file
	sprintf(path,"%s/%s\0",context->mWorkingDir, WORKER_FILE_ADMIN_STATUS);
	status = pack_add_file(packAdmin, WORKER_FILE_ADMIN_STATUS, path);
	if (status != 0)
	{
		pack_close(packAdmin);
		YML_DEBUG_INSTRUMENT_STOP("worker_export_resources");
		return status;
	}
	// Pack Trace file
	sprintf(path,"%s/%s\0",context->mWorkingDir, WORKER_FILE_ADMIN_TRACE);
	status = pack_add_file(packAdmin, WORKER_FILE_ADMIN_TRACE, path);
	if (status != 0)
	{
		pack_close(packAdmin);
		YML_DEBUG_INSTRUMENT_STOP("worker_export_resources");
		return status;
	}
	pack_close(packAdmin);
	// Send admin data back to the server

        // detete temporary directory
        sprintf(path,"rm -rf %s\n",context->mWorkingDir);
        system(path);

}

int worker_execute(worker_t context)
{

	int pos;
	int pid;
	int status;
	char binaryFullName[PATH_MAX];
	YML_DEBUG_INSTRUMENT_START("worker_execute");

	strncpy(binaryFullName, context->mWorkingDir, PATH_MAX);
	pos = strlen(binaryFullName);
	binaryFullName[pos] = VFS_PATH_SEPARATOR;
	strcpy(binaryFullName + pos + 1, context->mBinaryName);

	if (chmod(binaryFullName, 0700) == -1)
	{
		// Unable to make this executable
		YML_DEBUG_INSTRUMENT_STOP("worker_execute");
		return -errno;
	}
	pid = fork();
	if (pid == -1)
	{

		YML_DEBUG_INSTRUMENT_STOP("worker_execute");
		return -errno;
	}
	else if (pid == 0)
	{
		// Child
		execv(binaryFullName, context->mParameters);
		// Fork failed
		exit(-1);
	}
	else
	{
		pos = wait(&status);
		if (pos == -1)
		{
			YML_DEBUG_INSTRUMENT_STOP("worker_execute");
			return -errno;
		}
		else
		{
			if (WIFEXITED(status) && WEXITSTATUS(status) == EXIT_SUCCESS)
			{
				YML_DEBUG_INSTRUMENT_STOP("worker_execute");
				return 0;
			}
			else if (WIFEXITED(status))
			{
#ifdef HAVE_WORKER_DEBUG         
				printf("DEBUG(%15s:%3d): Child process exited with status: %d\n",
						__FILE__, __LINE__, WEXITSTATUS(status));
#endif 
				// It's an error fuck
				YML_DEBUG_INSTRUMENT_STOP("worker_execute");

				return -1;
			}
			else if (WIFSIGNALED(status))
			{
				// It's an error fuck
				YML_DEBUG_INSTRUMENT_STOP("worker_execute");
				return -1;
			}
			else
			{
				// It's far more strange and should not happen
				YML_DEBUG_INSTRUMENT_STOP("worker_execute");
				return -2;
			}
		}
	}
}

static int worker_get_from_cache(worker_t context, const char* basename)
{
	int status;
	char* full_path;
	char* work_path;
	YML_DEBUG_INSTRUMENT_START(__FUNCTION__);
	status = asprintf(&full_path, "%s/%s", WORKER_CACHE_PATH, basename);
	if (status == -1)
	{
		YML_DEBUG_INSTRUMENT_STOP(__FUNCTION__);
		return -1;
	}
	status = asprintf(&work_path, "%s/%s", context->mWorkingDir, basename);
	if (status == -1)
	{
		free(full_path);
		YML_DEBUG_INSTRUMENT_STOP(__FUNCTION__);
		return -1;
	}
#ifdef HAVE_WORKER_DEBUG
	printf("DEBUG(%15s:%3d): Cache path: %s, Local path: %s\n",
			__FILE__, __LINE__, full_path, work_path);
#endif 

	if (access(full_path, R_OK) == 0)
	{
		if (vfs_file_copy(work_path, full_path) == 0)
		{

			free(work_path);
			free(full_path);
			YML_DEBUG_INSTRUMENT_STOP(__FUNCTION__);
			return 0;
		}
		// Copy failed
		free(work_path);
		free(full_path);
		YML_DEBUG_INSTRUMENT_STOP(__FUNCTION__);
		return -1;
	}

	free(work_path);
	free(full_path);
	// Not in cache
	YML_DEBUG_INSTRUMENT_STOP(__FUNCTION__);
	return 1;
}
static int worker_put_in_cache(worker_t context, const char* local_path)
{
	int status;
	char* work_path;
	char* cache_path;
	YML_DEBUG_INSTRUMENT_START(__FUNCTION__);
#ifdef HAVE_WORKER_DEBUG
	printf("DEBUG(%15s:%3d): Put in cache '%s'\n",
			__FILE__, __LINE__, local_path);
#endif
	status = asprintf(&work_path, "%s/%s", context->mWorkingDir, local_path);
	if (status == -1)
	{
		YML_DEBUG_INSTRUMENT_STOP(__FUNCTION__);
		return -1;
	}
	status = asprintf(&cache_path, "%s/%s", WORKER_CACHE_PATH, local_path);
	if (status == -1)
	{
		free(work_path);
		YML_DEBUG_INSTRUMENT_STOP(__FUNCTION__);
		return -1;
	}
	status = vfs_file_copy(cache_path, work_path);
	free(cache_path);
	free(work_path);
	YML_DEBUG_INSTRUMENT_STOP(__FUNCTION__);
	return status; // Mostly ignored ;)
}



#define WORKER_ELEM_WORK            "work"
#define WORKER_ATTR_WORK_BINARY     "binary"
#define WORKER_ATTR_WORK_IMPORTS    "imports"
#define WORKER_ATTR_WORK_PARAMS     "params"
#define WORKER_ELEM_IMPORT          "import"
#define WORKER_ATTR_IMPORT_HOST     "host"
#define WORKER_ATTR_IMPORT_PORT     "port" 
#define WORKER_ATTR_IMPORT_URI      "uri" 
#define WORKER_ATTR_IMPORT_PACK     "pack"
#define WORKER_ELEM_EXPORT          "export"
#define WORKER_ELEM_TMP            "tmp"
#define WORKER_ATTR_TMP_URI        WORKER_ATTR_IMPORT_URI
#define WORKER_ATTR_EXPORT_HOST     WORKER_ATTR_IMPORT_HOST
#define WORKER_ATTR_EXPORT_PORT     WORKER_ATTR_IMPORT_PORT
#define WORKER_ATTR_EXPORT_URI      WORKER_ATTR_IMPORT_URI
#define WORKER_ELEM_ADMIN           "admin"
#define WORKER_ATTR_ADMIN_HOST     WORKER_ATTR_IMPORT_HOST
#define WORKER_ATTR_ADMIN_PORT     WORKER_ATTR_IMPORT_PORT
#define WORKER_ATTR_ADMIN_URI      WORKER_ATTR_IMPORT_URI
#define WORKER_ELEM_PARAM          "param" 
#define WORKER_ATTR_PARAM_NAME     "name"


static void work_start_element(void *data, const char *el, const char **attr)
{
	worker_t context;
	int i;
	YML_DEBUG_INSTRUMENT_START("work_start_element");
	context = (worker_t)data;
	// Handle parameter
#ifdef HAVE_WORKER_DEBUG
	printf("DEBUG(%15s:%d): Element: %s\n", __FILE__, __LINE__, el);
	for(i = 0 ; attr[i] ; i+=2)
	{
		printf("DEBUG(%15s:%d): \t-<%s>=<%s>\n", __FILE__, __LINE__, attr[i], attr[i+1]);
	}
#endif
	if (context->mXmlErrorDetected)
	{
		YML_DEBUG_INSTRUMENT_STOP("work_start_element");
		return;
	}
	if (strcmp(WORKER_ELEM_PARAM, el) == 0)
	{
		//printf("Current number of parameters: %d / %d\n", context->mParameterCurrent, context->mParameterCount);
		if (context->mParameterCurrent > context->mParameterCount)
		{
			context->mXmlErrorDetected = 1;
			YML_DEBUG_INSTRUMENT_STOP("work_start_element");
			return;
		}
		for(i = 0 ; attr[i] ; i +=2)
		{
			if (strcmp(WORKER_ATTR_PARAM_NAME, attr[i]) == 0)
			{
				if (context->mParameters[context->mParameterCurrent])
					free(context->mParameters[context->mParameterCurrent]);
				context->mParameters[context->mParameterCurrent] = strdup(attr[i + 1]);
				if (context->mParameters[context->mParameterCurrent] == 0)
				{
					context->mXmlErrorDetected = 1;
					YML_DEBUG_INSTRUMENT_STOP("work_start_element");
					return;
				}
			}
			else
			{
				// Strange
				context->mXmlErrorDetected = 1;
				YML_DEBUG_INSTRUMENT_STOP("work_start_element");
				return;
			}
		}
		++(context->mParameterCurrent);
	}
	// Data imports
	else if (strcmp(WORKER_ELEM_IMPORT, el) == 0)
	{
		if (context->mImportCurrent >= context->mImportCount)
		{
			context->mXmlErrorDetected = 1;
			YML_DEBUG_INSTRUMENT_STOP("work_start_element");
			return;
		}

		for(i = 0 ; attr[i] ; i +=2)
		{
			if (strcmp(WORKER_ATTR_IMPORT_HOST, attr[i]) == 0)
			{
				if (context->mImports[context->mImportCurrent].mHost)
					free(context->mImports[context->mImportCurrent].mHost);
				context->mImports[context->mImportCurrent].mHost = strdup(attr[i+1]);
				if (context->mImports[context->mImportCurrent].mHost == 0)
				{
					context->mXmlErrorDetected = 1;
					YML_DEBUG_INSTRUMENT_STOP("work_start_element");
					return;
				}
			}
			else if (strcmp(WORKER_ATTR_IMPORT_PORT, attr[i]) == 0)
			{
				char* tmp;
				context->mImports[context->mImportCurrent].mPort = strtoul(attr[i+1], &tmp, 0);
				if (context->mImports[context->mImportCurrent].mPort == 0 && attr[i+1] == tmp)
				{
					context->mXmlErrorDetected = 1;
					YML_DEBUG_INSTRUMENT_STOP("work_start_element");
					return;
				}
			}
			else if (strcmp(WORKER_ATTR_IMPORT_URI, attr[i]) == 0)
			{
				if (context->mImports[context->mImportCurrent].mUri)
					free(context->mImports[context->mImportCurrent].mUri);
				context->mImports[context->mImportCurrent].mUri = strdup(attr[i+1]);
				if (context->mImports[context->mImportCurrent].mUri == 0)
				{
					context->mXmlErrorDetected = 1;
					YML_DEBUG_INSTRUMENT_STOP("work_start_element");
					return;
				}
			}
			else if (strcmp(WORKER_ATTR_IMPORT_PACK, attr[i]) == 0)
			{
				if (strcmp(attr[i+1], "yes") == 0)
				{
					context->mImports[context->mImportCurrent].mIsPacked = 1;
				}
				else if (strcmp(attr[i+1], "no") == 0)
				{
					context->mImports[context->mImportCurrent].mIsPacked = 0;
				}
				else
				{
					context->mXmlErrorDetected = 1;
					YML_DEBUG_INSTRUMENT_STOP("work_start_element");
					return;
				}
			}
			else
			{
				context->mXmlErrorDetected = 1;
				YML_DEBUG_INSTRUMENT_STOP("work_start_element");
				return;
			}
		}
		++(context->mImportCurrent);
	}
	// Export of results
	else if (strcmp(WORKER_ELEM_EXPORT, el) == 0)
	{
		context->mExport.mIsPacked = 1;
		for(i = 0 ; attr[i] ; i +=2)
		{
			if (strcmp(WORKER_ATTR_EXPORT_HOST, attr[i]) == 0)
			{
				if (context->mExport.mHost)
					free(context->mExport.mHost);
				context->mExport.mHost = strdup(attr[i+1]);
				if (context->mExport.mHost == 0)
					context->mXmlErrorDetected = 1;
			}
			else if (strcmp(WORKER_ATTR_EXPORT_PORT, attr[i]) == 0)
			{
				char* tmp;
				context->mExport.mPort = strtoul(attr[i+1], &tmp, 0);
				if (context->mExport.mPort == 0 && attr[i+1] == tmp)
				{
					context->mXmlErrorDetected = 1;
				}
			}
			else if (strcmp(WORKER_ATTR_EXPORT_URI, attr[i]) == 0)
			{
				if (context->mExport.mUri)
					free(context->mExport.mUri);
				context->mExport.mUri = strdup(attr[i+1]);
				if (context->mExport.mUri == 0)
					context->mXmlErrorDetected = 1;
			}
			else
			{
				context->mXmlErrorDetected = 1;
				YML_DEBUG_INSTRUMENT_STOP("work_start_element");
				return;
			}
		}
	}
	// Tmp element
	else if (strcmp(WORKER_ELEM_TMP, el) == 0)
	{
		for(i = 0 ; attr[i] ; i +=2)
		{
			if (strcmp(WORKER_ATTR_TMP_URI , attr[i]) == 0)
			{

				strcpy(context->mWorkingDir,attr[i+1]);
				if (strlen(context->mWorkingDir) == 0)
					context->mXmlErrorDetected = 1;
			}
			else
			{
				context->mXmlErrorDetected = 1;
				YML_DEBUG_INSTRUMENT_STOP("work_start_element");
				return;
			}
		}
	}
	// Admin information
	else if (strcmp(WORKER_ELEM_ADMIN, el) == 0)
	{
		context->mAdmin.mIsPacked = 1;
		for(i = 0 ; attr[i] ; i +=2)
		{
			if (strcmp(WORKER_ATTR_ADMIN_HOST, attr[i]) == 0)
			{
				if (context->mAdmin.mHost)
					free(context->mAdmin.mHost);
				context->mAdmin.mHost = strdup(attr[i+1]);
				if (context->mAdmin.mHost == 0)
					context->mXmlErrorDetected = 1;
			}
			else if (strcmp(WORKER_ATTR_ADMIN_PORT, attr[i]) == 0)
			{
				char* tmp;
				context->mAdmin.mPort = strtoul(attr[i+1], &tmp, 0);
				if (context->mAdmin.mPort == 0 && attr[i+1] == tmp)
				{
					context->mXmlErrorDetected = 1;
				}
			}
			else if (strcmp(WORKER_ATTR_ADMIN_URI, attr[i]) == 0)
			{
				if (context->mAdmin.mUri)
					free(context->mAdmin.mUri);
				context->mAdmin.mUri = strdup(attr[i+1]);
				if (context->mAdmin.mUri == 0)
					context->mXmlErrorDetected = 1;
			}
			else
			{
				context->mXmlErrorDetected = 1;
				YML_DEBUG_INSTRUMENT_STOP("work_start_element");
				return;
			}
		}
	}
	// Work element
	else if(strcmp(WORKER_ELEM_WORK, el) == 0)
	{
		for(i = 0 ; attr[i] ; i +=2)
		{
			if (strcmp(WORKER_ATTR_WORK_BINARY, attr[i]) == 0)
			{
				if (context->mBinaryName)
					free(context->mBinaryName);
				context->mBinaryName = strdup(attr[i+1]);
				if (context->mBinaryName == 0)
				{
					context->mXmlErrorDetected = 1;
				}
				else if (context->mParameters)
					context->mParameters[0] = context->mBinaryName;
			}
			else if (strcmp(WORKER_ATTR_WORK_IMPORTS, attr[i]) == 0)
			{
				char *tmp;
				context->mImportCount = strtoul(attr[i+1], &tmp, 0);
				if (context->mImportCount == 0 && attr[i+1] == tmp)
				{
					context->mXmlErrorDetected = 1;
				}
				else
				{
					context->mImports = (droperation_t*)malloc(sizeof(droperation_t)*context->mImportCount);
					if (context->mImports == 0)
					{
						context->mXmlErrorDetected = 1;
						YML_DEBUG_INSTRUMENT_STOP("work_start_element");
						return;
					}
					memset((char*)context->mImports, 0, sizeof(droperation_t)*context->mImportCount);
				}
			}
			else if (strcmp(WORKER_ATTR_WORK_PARAMS, attr[i]) == 0)
			{
				char *tmp;
				context->mParameterCount = strtoul(attr[i+1], &tmp, 0);
				if (context->mParameterCount == 0 && attr[i+1] == tmp)
				{
					context->mXmlErrorDetected = 1;
					YML_DEBUG_INSTRUMENT_STOP("work_start_element");
					return;
				}
				else
				{
					context->mParameterCurrent = 1;
					context->mParameters = (char**)malloc(sizeof(char*)*(context->mParameterCount + 2));
					if (context->mParameters == 0)
					{
						context->mXmlErrorDetected = 1;
						YML_DEBUG_INSTRUMENT_STOP("work_start_element");
						return;
					}
					memset((char*)context->mParameters, 0, sizeof(char*)*(context->mParameterCount + 2));
					if (context->mBinaryName)
						context->mParameters[0] = context->mBinaryName;
					context->mParameters[context->mParameterCount] = 0;
				}
			}
			else
			{
				context->mXmlErrorDetected = 1;
				YML_DEBUG_INSTRUMENT_STOP("work_start_element");
				return;
			}
		}
	}
	else
	{
		// Strange nothing special to do here
		context->mXmlErrorDetected = 1;
		YML_DEBUG_INSTRUMENT_STOP("work_start_element");
		return;
	}
	YML_DEBUG_INSTRUMENT_STOP("work_start_element");
}

static void work_end_element(void* data, const char *el)
{
	//worker_t context;
	//YML_DEBUG_INSTRUMENT_START("work_end_element");
	//context = (worker_t)data;

	//YML_DEBUG_INSTRUMENT_STOP("work_end_element");
}

/****************************************************************************/
