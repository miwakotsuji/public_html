/* -*- mode: c; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/
/**
 * @file
 * @brief Default Worker implementation file 
 *
 * 2006-04-14
 * Olivier Delannoy
 */
#ifdef HAVE_CONFIG_H
#include <yml_config.hh> 
#endif 
#include "pack.h"
#include "vfs/vfs.h" 
#define _GNU_SOURCE 1
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <dirent.h>
#include <unistd.h> 
#include <string.h>
#include <errno.h> 
/**
 * @brief internal representation of a pack file 
 *
 * @internal 
 */
struct pack
{
    int mFd;
    int mAddLast;
};

#define PACK_BUFFER 8192

int pack_open(pack_t* pack, char* file)
{
    int fd = open(file, O_RDWR | O_CREAT, 0600);
    char header[4];
    int status;
    YML_DEBUG_INSTRUMENT_START("pack_open");
    *pack = 0;
    if (fd == -1)
    {
        // File open failed
        YML_DEBUG_INSTRUMENT_STOP("pack_open");
        return -errno;
    }
    // Decode header 
    status = read(fd, header, 4);
    if (status == -1)
    {
        // Read failed 
        close(fd);
        YML_DEBUG_INSTRUMENT_STOP("pack_open");
        return -errno;
    }
    else if (status == 0)
    {
        // Empty file (new pack)
        memcpy(header, "ARC1", 4);
        status = write(fd, header, 4);
        if (status == -1)
        {
            // Write failed 
            close(fd);
            YML_DEBUG_INSTRUMENT_STOP("pack_open");
            return -errno;
        }
    }
    else if (status < 4)
    {
        // Invalid ARC1 file 
        close(fd);
        YML_DEBUG_INSTRUMENT_STOP("pack_open");
        return -1;
    }

    // Check the header content 
    if (memcmp(header, "ARC1", 4) != 0)
    {
        // Invalid ARC1 file
        close(fd);
        YML_DEBUG_INSTRUMENT_STOP("pack_open");
        return -1;        
    }
    (*pack) = (pack_t) malloc(sizeof(**pack));
    if ((*pack) == 0)
    {
        // Memory allocation failed 
        YML_DEBUG_INSTRUMENT_STOP("pack_open");
        return -errno;
    }
    (*pack)->mFd = fd;
    (*pack)->mAddLast = 0;
    YML_DEBUG_INSTRUMENT_STOP("pack_open");
    return 0;
}
void pack_close(pack_t pack)
{
    YML_DEBUG_INSTRUMENT_START("pack_close");
    close(pack->mFd);
    free(pack);
    YML_DEBUG_INSTRUMENT_STOP("pack_close");
}
int pack_extract(pack_t pack, char* dir)
{
    
    char buffer[PACK_BUFFER];
    char filename[PATH_MAX];
    char* fileroot;
    int rootsize = strlen(dir);
    int status = 1;
    int status2 = 1;
    uint32 nameSize = 0;
    uint32 dataSize = 0;
    uint32 offset = 0;
    uint32 state = 0;
    uint32 toRead = 0;
    int fd_out = -1;
    uint32 written = 0;
    YML_DEBUG_INSTRUMENT_START("pack_extract");
    strncpy(filename, dir, PATH_MAX);
    filename[rootsize] = VFS_PATH_SEPARATOR;
    fileroot = filename + rootsize + 1;
    // Create dir 
    status = vfs_mkdir(dir, 0755);
    if (status != 0)
    {
        // Unable to create dir
        YML_DEBUG_INSTRUMENT_STOP("pack_extract");
        return status;
    }
    status = lseek(pack->mFd, 4, SEEK_SET);
    if (status != 4)
    {
        // Unable to seek at the correct position 
        YML_DEBUG_INSTRUMENT_STOP("pack_extract");
        return -errno;
    }
#ifdef HAVE_WORKER_DEBUG
    printf("DEBUG(%15s:%3d): extract files to '%s'\n", __FILE__, __LINE__, filename);
#endif 
    // Extract file one after the other 
    state = 0;
    while(status)
    {
    	offset = 0;
        status = read(pack->mFd, buffer, PACK_BUFFER);
        if (status == -1)
        {
            if (errno != EINTR)
            {
                YML_DEBUG_INSTRUMENT_STOP("pack_extract");
                return -errno;
            }
        }   
        else if (status > 0)
        {
            while(status - offset > 0)
            {
                // We are in the nameSize chunk of the header 
                if (state < sizeof(nameSize))
                {
                    toRead = sizeof(nameSize) - state;
                    toRead = status - offset > toRead ? toRead : status - offset;
                    memcpy((char*)&nameSize + sizeof(nameSize) - toRead, buffer + offset, toRead);
                    offset += toRead;
                    state += toRead;
                }
                // We are in the dataSize chunk of the header 
                else if (state < sizeof(nameSize) + sizeof(dataSize))
                {
                    toRead = sizeof(dataSize) - state + sizeof(nameSize);
                    toRead = ((status - offset) > toRead)  ? toRead : status - offset;
                    memcpy((char*)&dataSize + sizeof(dataSize) - toRead, buffer + offset, toRead);
                    offset += toRead;
                    state += toRead;
                }
                // We are in the name chunk of the header 
                else if (state < sizeof(nameSize) + sizeof(dataSize) + nameSize)
                {
                    toRead = nameSize - state + sizeof(nameSize) + sizeof(dataSize);
                    toRead = ((status - offset) > toRead)  ? toRead : status - offset;
                    memcpy(fileroot, buffer + offset, toRead);
                    offset += toRead;
                    state += toRead;
                    fileroot += toRead;
                }
                // We are in the data chunk
                else 
                {
                    if (fd_out == -1)
                    {
                        fileroot[nameSize] = '\0';
#ifdef HAVE_WORKER_DEBUG
			printf("DEBUG(%15s:%3d): extract file '%s' (%d bytes)\n", __FILE__, __LINE__, filename, dataSize);
#endif 
                        fd_out = open(filename, O_WRONLY|O_CREAT|O_TRUNC, 0666);
                        if (fd_out == -1)
                        {
                            YML_DEBUG_INSTRUMENT_STOP("pack_extract");
                            return -errno;
                        }
                    }
                    toRead = dataSize - state + sizeof(nameSize) + sizeof(dataSize) + nameSize;
                    toRead = ((status - offset) > toRead)  ? toRead : status - offset;
                    status2 = write(fd_out, buffer + offset + written, toRead - written);
                    if (status2 == -1)
                    {
                        if (errno != EINTR)
                        {
			     printf("write error %d: %s\n", errno, strerror(errno));
                             YML_DEBUG_INSTRUMENT_STOP("pack_extract");
                             return -errno;
                        }
                    }
                    else 
                    {
                    	offset += status2;
                    	state += status2;
                    }
                    if (state == sizeof(nameSize) + sizeof(dataSize) + nameSize + dataSize)
                    {
                        close(fd_out);
                        fd_out = -1;
                        state = 0;
			fileroot = filename + rootsize + 1;
			memset(fileroot, 0, PATH_MAX - (fileroot - filename));
              	    }
                }
            }
        }
    }
    pack->mAddLast = 0;
    YML_DEBUG_INSTRUMENT_STOP("pack_extract");
    return 0;
}
int pack_add_entry(pack_t pack, char* name, char* data, uint32 size)
{
    char* header;
    int status;
    uint32 headerLength = 0; 
    uint32 offset = 0;
    uint32 written = 0;
    uint32 nameSize = 0;
    YML_DEBUG_INSTRUMENT_START("pack_add_entry");
    nameSize = strlen(name);
    headerLength = nameSize + sizeof(size) + sizeof(nameSize);

    // Create file entry header 
    header = (char*)malloc(headerLength);
    if (header == 0)
    {
        YML_DEBUG_INSTRUMENT_STOP("pack_add_entry");
        return -errno;
    }
    memcpy(header + offset, (char*)&nameSize, sizeof(nameSize));
    offset += sizeof(nameSize);
    memcpy(header + offset, (char*)&size, sizeof(size));
    offset += sizeof(size);
    memcpy(header + offset, name, nameSize);
    // Write the header 
    if (! pack->mAddLast)
    {
        if (lseek(pack->mFd, 0, SEEK_END) == -1)
        {
            free(header);
            YML_DEBUG_INSTRUMENT_STOP("pack_add_entry");
            return -errno;
        }
        pack->mAddLast = 1;
    }
    
    do 
    {
        status = write(pack->mFd, header + written, headerLength - written);
        if (status == -1)
        {
            if (errno != EINTR)
            {
                free(header);
                YML_DEBUG_INSTRUMENT_STOP("pack_add_entry");
                return -errno;
            }
        }
        else 
        {
            written += status;
        }
        
    }
    while(written < headerLength);
    free(header);
    written = 0;
    do 
    {
        status = write(pack->mFd, data + written, size - written);
        if (status == -1)
        {
            if (errno != EINTR)
            {
                YML_DEBUG_INSTRUMENT_STOP("pack_add_entry");
                return -errno;
            }
        }
        else 
        {
            written += status;    
        }
    }
    while(written < size);
    YML_DEBUG_INSTRUMENT_STOP("pack_add_entry");
    return 0;
}

int pack_add_file(pack_t pack, char* name, char* filename)
{
    int fd;
    int status;
    YML_DEBUG_INSTRUMENT_START("pack_add_file");
#ifdef HAVE_WORKER_DEBUG
    printf("DEBUG(%15s:%3d): Add file '%s' to pack\n", __FILE__, __LINE__, filename);
#endif
    fd = open(filename, O_RDONLY);
    if (fd == -1)
    {
        YML_DEBUG_INSTRUMENT_STOP("pack_add_file");
        return  -errno;
    }
    status = pack_add_ffile(pack, name, fd);
    close(fd);
    YML_DEBUG_INSTRUMENT_STOP("pack_add_file");
    return status;
}

int pack_add_ffile(pack_t pack, char* name, int fd)
{
    char buffer[PACK_BUFFER];
    char* header;
    uint32 nameSize;
    uint32 size;
    uint32 headerLength;
    uint32 offset = 0;
    int status;
    uint32 written = 0;
    struct stat finfo;
    uint32 fpos;
    uint32 justRead;
    YML_DEBUG_INSTRUMENT_START("pack_add_ffile");
    nameSize = strlen(name);
    headerLength = nameSize + sizeof(size) + sizeof(nameSize);
    status = fstat(fd, &finfo);
    if (status == -1)
    {
        YML_DEBUG_INSTRUMENT_STOP("pack_add_ffile");
        return -errno;
    }
    size = finfo.st_size;
    // Create file entry header 
    header = (char*)malloc(headerLength);
    if (header == 0)
    {
        YML_DEBUG_INSTRUMENT_STOP("pack_add_ffile");
        return -errno;
    }
    memcpy(header + offset, (char*)&nameSize, sizeof(nameSize));
    offset += sizeof(nameSize);
    memcpy(header + offset, (char*)&size, sizeof(size));
    offset += sizeof(size);
    memcpy(header + offset, name, nameSize);
    // Go to the correct place in the file 
    if (! pack->mAddLast)
    {
        if (lseek(pack->mFd, 0, SEEK_END) == -1)
        {
            free(header);
            YML_DEBUG_INSTRUMENT_STOP("pack_add_ffile");
            return -errno;
        }
        pack->mAddLast = 1;
    }
    // Write the header 
    do 
    {
        status = write(pack->mFd, header + written, headerLength - written);
        if (status == -1)
        {
            if (errno != EINTR)
            {
                free(header);
                YML_DEBUG_INSTRUMENT_STOP("pack_add_ffile");
                return -errno;
            }
        }
        else 
        {
            written += status;
        }
        
    }
    while(written < headerLength);
    free(header);
    // Write the file content 
    fpos = lseek(fd, 0, SEEK_CUR);
    if (fpos == -1)
    {
        // Can't save the file position 
        YML_DEBUG_INSTRUMENT_STOP("pack_add_ffile");
        return -errno;
    }
    status = lseek(fd, 0, SEEK_SET);
    if (status == -1)
    {
        YML_DEBUG_INSTRUMENT_STOP("pack_add_ffile");
        return -errno;
    }

    justRead = 0;
    do 
    {
        int toread = PACK_BUFFER > size - justRead ? size - justRead : PACK_BUFFER;
        status = read(fd, buffer, toread);
        if (status == -1)
        {
            if (errno != EINTR)
            {
                YML_DEBUG_INSTRUMENT_STOP("pack_add_ffile");
                return -errno;
            }
        }
        else 
        {
            justRead += toread;
            written = 0;
            do 
            {
                
                status = write(pack->mFd, buffer + written, toread - written);
                if (status == -1)
                {
                    if (errno != EINTR)
                    {
                        YML_DEBUG_INSTRUMENT_STOP("pack_add_ffile");
                        return -errno;
                    }
                }
                else 
                {
                    written += status;    
                }
            }
            while(written < toread);
        }
    }
    while(justRead < size);    
    // Restore position in  the file before it's packing
    status = lseek(fd, fpos, SEEK_SET);
    if (status == -1)
    {
        YML_DEBUG_INSTRUMENT_STOP("pack_add_ffile");
        return -errno;
    }
    YML_DEBUG_INSTRUMENT_STOP("pack_add_ffile");
    return 0;
}
/****************************************************************************/
