/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/

/**
 * @file
 * @brief Class Component function definition 
 *
 * 2005-07-18
 * Olivier Delannoy
 */
#include "Component.hh"
#ifdef HAVE_CONFIG_H
#include <yml_config.hh>
#endif 
#include <Yml/Core/DevelopmentCatalog.hh>
#include <Yml/Core/ExecutionCatalog.hh>
#include <Yml/Core/ComponentAbstract.hh>
#include <Yml/Core/ComponentImpl.hh>
#include <Yml/Core/ComponentGraph.hh>
#include <Yml/Core/Component_xmlHandler.hh>


#include <ConsoleApplicationAdaptor.hh>
#include <RuntimeEnvironment.hh>
#include <ConfigFactory.hh>
#include <PluginFactory.hh>
#include <LoggerFactory.hh>
#include <CommandLineParser.hh>
#include <CommandLineOption.hh>
#include <XMLParser.hh>
#include <XMLParserFactory.hh> 
#include <XMLHandler.hh>

#include <locale> 
namespace Yml 
{
namespace Component 
{


void Component::configureCommandLine(void)
{
	mCmdLineParser->parameterCount(1);
	mCmdLineParser->addOption(new Util::CommandLineOption("force", "", false));
}

string Component::usageQuick(void) const
{
	return " [--force] <query file>";
}

string Component::usageParameters(void) const
{
	return "\n *<query file> ......: The query file of the component definition";
}

string Component::usageOptions(void) const
{
	return "\n  --force ...........: Force update of the component if"
			"\n                       the entry already exists";
}

Component::Component(Util::ApplicationAdaptor* adaptor, int argc, char** argv)
: Util::Application(adaptor, argc, argv)
{
	std::locale::global(std::locale("C"));    
}


Component::~Component(void)
{
}

string Component::configDir(void) const
{
	return CONFIG_DIR;
}
string Component::loggersDir(void) const
{
	return Util::ConfigFactory::getSingleton().create("yml")->get("path", "loggers", ".");
}
string Component::pluginDir(void) const 
{
	return Util::ConfigFactory::getSingleton().create("yml")->get("path", "plugins", ".");
}

uint32 Component::run(void)
{
	// Retrieve Command line parameters
	string xmlFile = mCmdLineParser->parameter(1);
	bool force = false;

	// Load configuration files
	UTIL_INFO("default", "Starting");
	UTIL_INFO("default", "Loading configuration files");

	Yml::Core::DevelopmentCatalog& devCatalog = Yml::Core::PluginManager::getSingleton().getDevelopmentCatalog();
	Yml::Core::ExecutionCatalog& execCatalog = Yml::Core::PluginManager::getSingleton().getExecutionCatalog();

	UTIL_INFO("default", "Configuration summary");
	UTIL_INFO("default", "  Input File: " << xmlFile);
	// Parse component description
	UTIL_DEBUG("default", "Start parsing XML file");
	Util::XMLParser parser = Util::XMLParserFactory::getSingleton().create();
	UTIL_DEBUG("default", "XML parser initialized successfully");
	Yml::Core::Component_xmlHandler handler;
	parser.parse(handler, xmlFile, "yml_component.xsd");
	UTIL_DEBUG("default", "End parsing XML file");

	if ( (mCmdLineParser->option("force"))->count() !=0 )
		force=true;
	UTIL_INFO("default", "Force overwrite: " << (force ? "yes" : "no"));

	switch(handler.getComponentType())
	{
	// Abstract component registration
	case Yml::Core::COMPONENT_TYPE_ABSTRACT:
		UTIL_INFO("default", "Registering a new abstract component");
		UTIL_INFO("default", "Component name: " << handler.getComponentAbstract().getName());
		UTIL_INFO("default", "Component description: " << handler.getComponentAbstract().getDescription());
		if (devCatalog.registerComponent(&handler.getComponentAbstract(), force))
		{
			UTIL_INFO("default", "Registration successfull");
			return SUCCESS;
		}
		UTIL_ERROR("default", "Registration failed");
		return ERROR;
		// Component graph
	case Yml::Core::COMPONENT_TYPE_GRAPH:
		UTIL_INFO("default", "Registering a new graph component");
		UTIL_INFO("default", "Component name: " << handler.getComponentGraph().getName());
		UTIL_INFO("default", "Component description: " << handler.getComponentGraph().getDescription());
		UTIL_INFO("default", "Abstract component implemented: " << handler.getComponentGraph().getComponentAbstractName());
		if (devCatalog.registerComponent(&handler.getComponentGraph(), force))
		{
			UTIL_INFO("default", "Registration successfull");
			return SUCCESS;
		}
		UTIL_ERROR("default", "Registration failed");
		return ERROR;
		// Component impl
	case Yml::Core::COMPONENT_TYPE_IMPL: {
		UTIL_INFO("default", "Registering a new implementation component");
		UTIL_INFO("default", "Component name: " << handler.getComponentImpl().getName());
		UTIL_INFO("default", "Component description: " << handler.getComponentImpl().getDescription());
		UTIL_INFO("default", "Abstract component implemented: " << handler.getComponentImpl().getComponentAbstractName());
		UTIL_INFO("default", "Programming language used: " << handler.getComponentImpl().getImplLanguage());
		UTIL_INFO("default", "Number of nodes used: " << handler.getComponentImpl().getImplNbNodes());
		UTIL_INFO("default", "Nodes topology: " << handler.getComponentImpl().getImplNodesTopology());
		UTIL_INFO("default", "Type of nodes used: " << handler.getComponentImpl().getImplNodeType());
		const Yml::Core::ParameterList* scheme = devCatalog.getComponentScheme(handler.getComponentImpl().getComponentAbstractName());

		if (scheme)
		{
			if(handler.getComponentImpl().getDistributeList().count())
			{
				UTIL_INFO("default", "Aligning parameter and data distribution");
				devCatalog.setComponentScheme(handler.getComponentImpl().getComponentAbstractName(),handler.getComponentImpl().getDistributeList());
			}

			if (execCatalog.registerComponent(handler.getComponentImpl(), *scheme, force))
			{
				UTIL_INFO("default", "Component registered in the execution catalog");
				UTIL_INFO("default", "Binary implementation created");
				if (devCatalog.registerComponent(&handler.getComponentImpl(), force))
				{
					UTIL_INFO("default", "Component registered in the development catalog");
					UTIL_INFO("default", "Component registration successfull");
					return SUCCESS;
				}
				else
				{
					UTIL_ERROR("default", "Component failed registration in the development catalog");
					return ERROR;
				}
			}
			else
			{
				UTIL_ERROR("default", "Binary implementation generation failed, check your xml document");
				UTIL_ERROR("default", "Component registration failed");
				return ERROR;
			}
		}
		else
		{
			UTIL_ERROR("default", "Abstract component " << handler.getComponentImpl().getComponentAbstractName() << " does not exists");
			UTIL_ERROR("default", "Component registration failed");
			return ERROR;
		}
	}
	default:
		UTIL_ERROR("default", "Component parsing failed");
		UTIL_ERROR("default", "Please check your xml document");
		return ERROR;
	}
}
}
}

UTIL_APPLICATION(Yml::Component::Component, Util::ConsoleApplicationAdaptor())

