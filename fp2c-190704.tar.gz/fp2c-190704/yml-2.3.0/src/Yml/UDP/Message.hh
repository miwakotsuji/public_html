/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/
/**
 * @file
 * @brief Class Message declaration
 *  
 * 2007-09-27
 * Olivier Delannoy
 */
#ifndef YML_MESSAGE_HH
#define YML_MESSAGE_HH 1

#include <Yml/Core/core.hh>
#include <Yml/Core/SchedulerTask.hh>
#include <Yml/UDP/enetpp.hh>
#include <cassert>
namespace Yml 
{
namespace UDP 
{

struct TaskIdentifier 
{ 
    Yml::Core::uint32 app_id;
    Yml::Core::uint32 task_id;
    Yml::Core::uint8  task_status; 
};

/*! 
  \brief 
  Deserialization helper for operation on byte array.
*/
class Reader
{
public:

    Reader(const char* data, size_t dataLength);
    template <typename T> 
    void read(T& object) 
    {
        if (! mError)
        {
            if (mOffset + sizeof(T) <= mSourceLength)
            {
                std::memcpy(&object, mSource + mOffset, sizeof(T));
                mOffset += sizeof(T);
                // Do some byte swapping if in big endian 
            }  
            else 
            {
                mError = true;
            }
        }
    }
    void read(bool& object);
    void read(Yml::Core::string& object);
    bool isOk() const { return ! mError ; }
    size_t offset() const { return mOffset;}

     
private:
    const char* mSource;
    size_t mSourceLength;
    size_t mOffset; 
    bool mError;
};


/*! 
  \brief 
  Serialization helper class to write arbitrary data type to a byte array.
*/
class Writer
{
public:
    Writer(char* data, size_t dataLength);
    
    template <typename T> void write(const T& object) 
    {
        if (!mError)
        {
            if (mOffset + sizeof(T) <= mDestLength)
            {
                std::memcpy(mDest + mOffset, &object, sizeof(T));
                mOffset += sizeof(T);
            }
            else 
            {
                mError = true;
            }
        }
    }
    void write(const bool& object);
    void write(const Yml::Core::string& object);
    bool isOk() const { return !mError; }
    size_t offset() const { return mOffset;}
private:
    char*  mDest; //!< Store the destination buffer 
    size_t mDestLength; //!< Store the size of the destination buffer 
    size_t mOffset; //!< Current write offset
    bool   mError; //!< Store wether an error occured or not
};
 
typedef char message_type;
typedef enet::MessageFactoryManager<message_type> MessageFactoryManager;
typedef enet::MessageFactoryManager<message_type>::Message Message;
typedef enet::Host<MessageFactoryManager> Host;
typedef enet::Host<MessageFactoryManager>::Peer Peer;


const message_type MSG_TASK_SUBMIT   = 1; //!< Task submission 
const message_type MSG_TASK_CANCEL   = 2; //!< Task cancelation 
const message_type MSG_TASK_FINISHED = 3; //!< Task finished
const message_type MSG_TASK_FAILED   = 4; //!< Task failed at submission
const message_type MSG_APP_START     = 5; //!< Application start
const message_type MSG_APP_END       = 6; //!< Application end 
const message_type MSG_BCK_START     = 7; //!< Backend start



// Task Management messages
class MSGTaskSubmit : public Message
{
public:
    MSGTaskSubmit()  
        : Message(MSG_TASK_SUBMIT, Reliable), mTask(0) {}
    ~MSGTaskSubmit() {}
    typedef enet::MessageFactoryManager<message_type>::MessageFactory<MSGTaskSubmit, MSG_TASK_SUBMIT> Factory;
    
public:    
    void setTask(Yml::Core::SchedulerTask* task) { mTask = task; }
    const Yml::Core::SchedulerTask* task() const { return mTask;}
    Yml::Core::SchedulerTask* task() { return mTask; }
protected:
    size_t contentSize() const;
    size_t contentPack(char* data, size_t dataLength) const;
    size_t contentUnpack(const char* data, size_t dataLength);
private:
    Yml::Core::SchedulerTask* mTask;
};
class MSGTaskChangeBase : public Message
{
protected: 
    MSGTaskChangeBase(message_type type) : Message(type, Reliable) 
    {
        mTask.app_id = 0;
        mTask.task_id = 0;
        mTask.task_status = 0;
    }
public:
    TaskIdentifier& task() { return mTask;}
    const TaskIdentifier& task() const { return mTask; }
     
protected:
    size_t contentSize() const;
    size_t contentPack(char* data, size_t dataLength) const;
    size_t contentUnpack(const char* data, Yml::Core::uint32 dataLength);
private:
    TaskIdentifier mTask;
};

    
class MSGTaskCancel : public MSGTaskChangeBase
{
public:
    MSGTaskCancel() : MSGTaskChangeBase(MSG_TASK_CANCEL){}
    typedef enet::MessageFactoryManager<message_type>::MessageFactory<MSGTaskCancel, MSG_TASK_CANCEL> Factory;
};


class MSGTaskFinished : public MSGTaskChangeBase
{
public:
    MSGTaskFinished() : MSGTaskChangeBase(MSG_TASK_FINISHED) {}
    typedef enet::MessageFactoryManager<message_type>::MessageFactory<MSGTaskFinished, MSG_TASK_FINISHED> Factory;
};


class MSGTaskFailed : public MSGTaskChangeBase
{
public:
    MSGTaskFailed() : MSGTaskChangeBase(MSG_TASK_FAILED) {}
    typedef enet::MessageFactoryManager<message_type>::MessageFactory<MSGTaskFailed, MSG_TASK_FAILED> Factory;
};


// App management messages 

class MSGApplicationStart : public Message
{
public:
    MSGApplicationStart() : Message(MSG_APP_START, Reliable) {}
    ~MSGApplicationStart() {}
    typedef enet::MessageFactoryManager<message_type>::MessageFactory<MSGApplicationStart, MSG_APP_START> Factory;
protected:
    size_t contentSize() const { return 0; }
    size_t contentPack(char* data, size_t dataLength) const { return 0; }
    size_t contentUnpack(const char* data, size_t dataLength) { return 0; }
private:
};

class MSGApplicationEnd : public Message
{
public:
    MSGApplicationEnd() : Message(MSG_APP_END, Reliable) {}
    ~MSGApplicationEnd() {}
    typedef enet::MessageFactoryManager<message_type>::MessageFactory<MSGApplicationEnd, MSG_APP_END> Factory;
protected:
    size_t contentSize() const { return 0; }
    size_t contentPack(char* data, size_t dataLength) const { return 0; }
    size_t contentUnpack(const char* data, size_t dataLength) { return 0; }
private:
};

// Backend management messages  
class MSGBackendStart : public Message
{
public:
    MSGBackendStart() : Message(MSG_BCK_START, Reliable) {}
    ~MSGBackendStart() {}
    typedef enet::MessageFactoryManager<message_type>::MessageFactory<MSGBackendStart, MSG_BCK_START> Factory;
protected:
    size_t contentSize() const { return 0; }
    size_t contentPack(char* data, size_t dataLength) const { return 0; }
    size_t contentUnpack(const char* data, size_t dataLength) { return 0; }
private:
};    


///////////////////////////////////////////////////////////////////
// Reader
///////////////////////////////////////////////////////////////////


Reader::Reader(const char* data, size_t dataLength)
    : mSource(data), mSourceLength(dataLength), mOffset(0), mError(false)
{
    assert(mSource);
    assert(mSourceLength);
}
void Reader::read(bool& object)
{
    if (!mError)
    {
        if (mOffset < mSourceLength)
        {
            object = (mSource[mOffset++] ? true : false);
        }
        else 
        {
            mError = true;
        }
    }        
}
void Reader::read(Yml::Core::string& object)
{
    Yml::Core::uint32 size;
    read(size);
    if (!mError)
    {
        if (mOffset + size <= mSourceLength)
        {
            object.assign(reinterpret_cast<const char*>(mSource + mOffset), size);
            mOffset += size;
        }
        else 
        {
            mError = true;
        }
    }
}
///////////////////////////////////////////////////////////////////
// Writer
///////////////////////////////////////////////////////////////////

Writer::Writer(char* data, size_t dataLength)
    : mDest(data), mDestLength(dataLength), mOffset(0), mError(false)
{
    assert(data);
    assert(dataLength);
}
void Writer::write(const bool& object) 
{
    if (!mError)
    {
        if (mOffset < mDestLength )
        {
            mDest[mOffset++] = (object ? 1 : 0);
        }
        else 
        {
            mError = true;
        }
    }
}
void Writer::write(const Yml::Core::string& object)
{
    size_t slen = object.size();
    write(slen);
    if (! mError)
    {
        if (mOffset + slen <= mDestLength)
        {
            std::memcpy(mDest + mOffset, object.c_str(), slen);
            mOffset += slen;
        }
        else 
        {
            mError = true;
        }
    }
}
////////////////////////////////////////////////////////////////////////////////
// Message and derivates 
////////////////////////////////////////////////////////////////////////////////


// Messages classes methods

size_t MSGTaskSubmit::contentSize() const
{
    using Yml::Core::uint32;
    
    assert(mTask);
    size_t size = sizeof(uint32) +  // index
        sizeof(uint32) +  // appId 
        sizeof(uint32) +  // size of work 
        mTask->work().size() + // work content 
        sizeof(uint32) + // size of component 
        mTask->component().size() + // component content 
        sizeof(uint32) + // Policy 
        sizeof(uint32); // Number of parameters 
    for(uint32 i = 0 ; i < mTask->parameters() ; ++i)
    {
        size += sizeof(uint32) + // Size of the parameter string 
            mTask->parameter(i).size(); // parameter content 
        
    }
    size += sizeof(uint32) + // uid size 
        mTask->uid().size(); // uid content 
    return size;
    
    
}
size_t MSGTaskSubmit::contentPack(char* data, size_t dataLength) const
{
    assert(mTask); // Bad no scheduler task associated
    Writer writer(data, dataLength);
    writer.write(mTask->index());
    writer.write(mTask->appId());
    writer.write(mTask->work());
    writer.write(mTask->component());
    Yml::Core::uint32 tmp = mTask->policy();
    writer.write(tmp);
    tmp = mTask->parameters();
    writer.write(tmp);
    for (Yml::Core::uint32 i = 0 ; i < tmp ; ++i)
    {
        writer.write(mTask->parameter(i));
    }
    writer.write(mTask->uid());
    assert(writer.isOk());
    return writer.offset();
}
size_t MSGTaskSubmit::contentUnpack(const char* data, size_t dataLength)
{
    Reader reader(data, dataLength);
    Yml::Core::uint32 tmp;
    Yml::Core::string tmp2;
    reader.read(tmp);
    mTask = new Yml::Core::SchedulerTask(tmp);
    reader.read(tmp);
    mTask->appId() = tmp;
    reader.read(tmp2);
    mTask->work() = tmp2;

    reader.read(tmp2);
    mTask->component(tmp2);
    reader.read(tmp);
    mTask->policy((Yml::Core::SchedulingPolicy)tmp);
    reader.read(tmp);
    for(Yml::Core::uint32 i = 0 ; i < tmp ; ++i)
    {
        reader.read(tmp2);
        mTask->addParameter(tmp2);
    }
    reader.read(tmp2);
    mTask->uid(tmp2);
    
    assert(reader.isOk());  
    return reader.offset();
}


size_t MSGTaskChangeBase::contentSize() const 
{
    return 2 * sizeof(Yml::Core::uint32) + sizeof(Yml::Core::uint8);
}

size_t MSGTaskChangeBase::contentPack(char* data, size_t dataLength) const
{
    Writer writer(data, dataLength);
    writer.write(mTask.app_id);
    writer.write(mTask.task_id);
    writer.write(mTask.task_status);
    assert(writer.isOk());
    return writer.offset();
}
size_t MSGTaskChangeBase::contentUnpack(const char* data, size_t dataLength)
{
    Reader reader(data, dataLength);
    reader.read(mTask.app_id);
    reader.read(mTask.task_id);
    reader.read(mTask.task_status);
    assert(reader.isOk());    
    return reader.offset();
}





}
}

#endif 
