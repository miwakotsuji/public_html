// ***********************************************************************
// Copyright (c) 2006 Olivier Delannoy <Olivier.Delannoy@gmail.com> 
//
//
// Permission is hereby granted, free of charge, to any person 
// obtaining a copy of this software and associated documentation 
// files (the "Software"), to deal in the Software without restriction,
// including without limitation the rights to use, copy, modify, merge,
// publish, distribute, sublicense, and/or sell copies of the Software,
// and to permit persons to whom the Software is furnished to do so, 
// subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be 
// included in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND 
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS 
// BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN 
// ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
// CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
// ***********************************************************************
#ifndef ENETPP_H_
#define ENETPP_H_ 
#include <cstring>
#include <list> 
#include <map>
#include <cassert>
#include <enet/enet.h> 

namespace enet
{
  class SignalBindable;
  class SignalBinding;
  class Signal0;
  class Binding0;
  class GlobalBinding0;
  template <typename T> class MethodBinding0;
  class SignalBindable
  {
    typedef std::list<SignalBinding*> BindingList;
  public:
    virtual ~SignalBindable();
  private:
    BindingList d_bindings;
    friend class SignalBinding;
  };
  class SignalBinding
  {
  protected:
    SignalBinding(SignalBindable* object = 0);  
  public:
    virtual ~SignalBinding() = 0;
  protected:
    SignalBindable* d_object;
  };
  class Signal0
  {  
    typedef std::list<Binding0*> BindingList;
  public:
    typedef Binding0 Binding;
    struct GlobalBinding 
    {
      typedef void (*Function)();
    };
    template <typename T>
    struct MethodBinding
    {
      typedef void (T::*Function)();
    };

    Signal0() {}
    ~Signal0();
    inline void emit();
    inline Binding* connect(Binding* binding);
    inline Binding* connect(GlobalBinding::Function func);
    template <typename T>
    inline Binding* connect(T& object, typename MethodBinding<T>::Function func);  
    void disconnect(Binding* binding) { d_bindings.remove(binding); }
  private:
    BindingList d_bindings;
  };
  template <typename S>
  class SignalConnector
  {
  public:
    typedef typename S::Binding Binding;
  
    explicit SignalConnector(S& signal) : d_signal(signal){}
  
    Binding* connect(Binding* binding) 
    {
      return d_signal.connect(binding);
    }
    Binding* connect(typename S::GlobalBinding::Function function)
    {
      return d_signal.connect(function);
    }
    template <typename T>
    Binding* connect(T& object, typename S::template MethodBinding<T>::Function function)
    {
      return d_signal.connect(object, function);
    }
    void disconnect(Binding* binding)
    {
      d_signal.disconnect(binding);
    } 
  private:
    S& d_signal;
  };
  class Binding0 : public SignalBinding
  {
  public:
    ~Binding0();
    virtual void emit() = 0;
  protected:
    Binding0(SignalBindable* binding) : SignalBinding(binding), d_signal(0) {}
  private:
    Signal0* d_signal;
    friend class Signal0;
  };
  class GlobalBinding0 : public Binding0
  {
  public:
    typedef void(*Function)();
  
    GlobalBinding0(Function func)
      : Binding0(0), d_func(func) 
    {
    }
    void emit() 
    {
      d_func();
    }
  private:
    Function d_func;
  };
  template <typename T> 
  class MethodBinding0 : public Binding0
  {
  public:
    typedef void (T::*Function)();
    MethodBinding0(T& object, Function func) 
      : Binding0(&object), d_bind(object), d_func(func)
    {
    }
  
    void emit()
    {
      (d_bind.*d_func)();
    }
  private:
    T& d_bind;
    Function d_func;
  };  

  Signal0::Binding* Signal0::connect(Signal0::Binding* binding)
  {
    d_bindings.push_back(binding);
    binding->d_signal = this;
    return binding;
  }

  template <typename T> 
  inline Signal0::Binding* Signal0::connect(T& object, typename MethodBinding<T>::Function function)
  {
    return connect(new MethodBinding0<T>(object, function));
  }

  inline Signal0::Binding* Signal0::connect(void (*function)())
  {
    return connect(new GlobalBinding0(function)); 
  }

  inline void Signal0::emit()
  {
    BindingList::iterator iter = d_bindings.begin();
    const BindingList::iterator end = d_bindings.end();
    for(;iter != end; ++iter)
      {   
        (*iter)->emit();
      }   
  }
  inline SignalBindable::~SignalBindable()
  {
    while(!d_bindings.empty())
      delete d_bindings.front();
  }

  inline SignalBinding::SignalBinding(SignalBindable* object) 
    : d_object(object)
  {
    if (d_object)
      d_object->d_bindings.push_front(this);
  }

  inline SignalBinding::~SignalBinding()
  {
    if (d_object)
      d_object->d_bindings.remove(this);
  }
  inline Signal0::~Signal0()
  {
    while(!d_bindings.empty())
      delete d_bindings.front();
  }
  // Binding0 
  inline Binding0::~Binding0()
  {
    if (d_signal)
      d_signal->disconnect(this);
  }


  ////////////////////////////////////////////
  // Number of parameters: 1
  ////////////////////////////////////////////
  template<typename A1 > class Binding1;
  template<typename A1 > class GlobalBinding1;
  template<typename T, typename A1 > class MethodBinding1;
  template<typename A1 > class Signal1;
  template <typename A1 >
  class Signal1
  { 
    typedef std::list<Binding1<A1 >* > BindingList;
  public:
    typedef Binding1<A1 > Binding;
    struct GlobalBinding
    {
      typedef void(*Function)(A1 a1);
    };
    template <typename T>
    struct MethodBinding
    {
      typedef void (T::*Function)(A1 a1);
    };
    Signal1() {}
    ~Signal1();
    inline Binding* connect(Binding* binding);
    inline Binding* connect(typename GlobalBinding::Function function);
    template <typename T>
    inline Binding* connect(T& object, typename MethodBinding<T >::Function function);
    void disconnect(Binding* binding) { d_bindings.remove(binding);}
    inline void emit(A1 a1);
  private:
    BindingList d_bindings;
  };
  template <typename A1 >
  class Binding1 : public SignalBinding 
  {
  public:
    ~Binding1();
    virtual void emit(A1 a1) = 0;
  protected:
    Binding1(SignalBindable* binded = 0) : SignalBinding(binded), d_signal(0) {}
  private:
    Signal1<A1 >* d_signal;
    friend class Signal1<A1 >;
  };
  template <typename A1 >
  class GlobalBinding1 : public Binding1<A1 >
  {
  public:
    GlobalBinding1(void(*func)(A1 a1)) : d_func(func) {}
    void emit(A1 a1) { d_func(a1);}
  private:
    void(*d_func)(A1 a1);
  };
  template <typename T, typename A1 >
  class MethodBinding1 : public Binding1<A1 >
  {
  public:
    MethodBinding1(T& object, void (T::*func)(A1 a1)) 
      : Binding1<A1 >(&object), d_binded(object), d_func(func) {}
    void emit(A1 a1) { (d_binded.*d_func)(a1);}
  private:
    T& d_binded;
    void (T::*d_func)(A1 a1);
  };

  template <typename A1 > 
  Signal1<A1 >::~Signal1()
  {
    while(!d_bindings.empty())
      delete d_bindings.front();
  }

  template <typename A1>
  typename Signal1<A1 >::Binding* Signal1<A1 >::connect(typename Signal1<A1 >::Binding* binding)
  {
    d_bindings.push_back(binding);
    binding->d_signal = this;
    return binding;
  }

  template <typename A1 > 
  template <typename T>
  typename Signal1<A1 >::Binding* Signal1<A1 >::connect(T& object, typename Signal1<A1 >::template MethodBinding<T>::Function function)
  {
    return connect(new MethodBinding1<T, A1 >(object, function));
  }

  template <typename A1 >
  typename Signal1<A1 >::Binding* Signal1<A1 >::connect(typename Signal1<A1 >::GlobalBinding::Function function)
  {
    return connect(new GlobalBinding1<A1 >(function));
  }

  template <typename A1 >
  void Signal1<A1>::emit(A1 a1)
  {
    typename BindingList::iterator iter = d_bindings.begin();
    const typename BindingList::iterator end = d_bindings.end();
    for(;iter != end; ++iter)
      {
        (*iter)->emit(a1);
      }
  }

  template <typename A1 > 
  Binding1<A1 >::~Binding1() 
  {
    if (d_signal)
      d_signal->disconnect(this);
  }
  ////////////////////////////////////////////
  // Number of parameters: 2
  ////////////////////////////////////////////
  template<typename A1, typename A2 > class Binding2;
  template<typename A1, typename A2 > class GlobalBinding2;
  template<typename T, typename A1, typename A2 > class MethodBinding2;
  template<typename A1, typename A2 > class Signal2;
  template <typename A1, typename A2 >
  class Signal2
  { 
    typedef std::list<Binding2<A1, A2 >* > BindingList;
  public:
    typedef Binding2<A1, A2 > Binding;
    struct GlobalBinding
    {
      typedef void(*Function)(A1 a1, A2 a2);
    };
    template <typename T>
    struct MethodBinding
    {
      typedef void (T::*Function)(A1 a1, A2 a2);
    };
    Signal2() {}
    ~Signal2();
    inline Binding* connect(Binding* binding);
    inline Binding* connect(typename GlobalBinding::Function function);
    template <typename T>
    inline Binding* connect(T& object, typename MethodBinding<T >::Function function);
    void disconnect(Binding* binding) { d_bindings.remove(binding);}
    inline void emit(A1 a1, A2 a2);
  private:
    BindingList d_bindings;
  };
  template <typename A1, typename A2 >
  class Binding2 : public SignalBinding 
  {
  public:
    ~Binding2();
    virtual void emit(A1 a1, A2 a2) = 0;
  protected:
    Binding2(SignalBindable* binded = 0) : SignalBinding(binded), d_signal(0) {}
  private:
    Signal2<A1, A2 >* d_signal;
    friend class Signal2<A1, A2 >;
  };
  template <typename A1, typename A2 >
  class GlobalBinding2 : public Binding2<A1, A2 >
  {
  public:
    GlobalBinding2(void(*func)(A1 a1, A2 a2)) : d_func(func) {}
    void emit(A1 a1, A2 a2) { d_func(a1, a2);}
  private:
    void(*d_func)(A1 a1, A2 a2);
  };
  template <typename T, typename A1, typename A2 >
  class MethodBinding2 : public Binding2<A1, A2 >
  {
  public:
    MethodBinding2(T& object, void (T::*func)(A1 a1, A2 a2)) 
      : Binding2<A1, A2 >(&object), d_binded(object), d_func(func) {}
    void emit(A1 a1, A2 a2) { (d_binded.*d_func)(a1, a2);}
  private:
    T& d_binded;
    void (T::*d_func)(A1 a1, A2 a2);
  };

  template <typename A1, typename A2 > 
  Signal2<A1, A2 >::~Signal2()
  {
    while(!d_bindings.empty())
      delete d_bindings.front();
  }

  template <typename A1, typename A2>
  typename Signal2<A1, A2 >::Binding* Signal2<A1, A2 >::connect(typename Signal2<A1, A2 >::Binding* binding)
  {
    d_bindings.push_back(binding);
    binding->d_signal = this;
    return binding;
  }

  template <typename A1, typename A2 > 
  template <typename T>
  typename Signal2<A1, A2 >::Binding* Signal2<A1, A2 >::connect(T& object, typename Signal2<A1, A2 >::template MethodBinding<T>::Function function)
  {
    return connect(new MethodBinding2<T, A1, A2 >(object, function));
  }

  template <typename A1, typename A2 >
  typename Signal2<A1, A2 >::Binding* Signal2<A1, A2 >::connect(typename Signal2<A1, A2 >::GlobalBinding::Function function)
  {
    return connect(new GlobalBinding2<A1, A2 >(function));
  }

  template <typename A1, typename A2 >
  void Signal2<A1, A2>::emit(A1 a1, A2 a2)
  {
    typename BindingList::iterator iter = d_bindings.begin();
    const typename BindingList::iterator end = d_bindings.end();
    for(;iter != end; ++iter)
      {
        (*iter)->emit(a1, a2);
      }
  }

  template <typename A1, typename A2 > 
  Binding2<A1, A2 >::~Binding2() 
  {
    if (d_signal)
      d_signal->disconnect(this);
  }
  ////////////////////////////////////////////
  // Number of parameters: 3
  ////////////////////////////////////////////
  template<typename A1, typename A2, typename A3 > class Binding3;
  template<typename A1, typename A2, typename A3 > class GlobalBinding3;
  template<typename T, typename A1, typename A2, typename A3 > class MethodBinding3;
  template<typename A1, typename A2, typename A3 > class Signal3;
  template <typename A1, typename A2, typename A3 >
  class Signal3
  { 
    typedef std::list<Binding3<A1, A2, A3 >* > BindingList;
  public:
    typedef Binding3<A1, A2, A3 > Binding;
    struct GlobalBinding
    {
      typedef void(*Function)(A1 a1, A2 a2, A3 a3);
    };
    template <typename T>
    struct MethodBinding
    {
      typedef void (T::*Function)(A1 a1, A2 a2, A3 a3);
    };
    Signal3() {}
    ~Signal3();
    inline Binding* connect(Binding* binding);
    inline Binding* connect(typename GlobalBinding::Function function);
    template <typename T>
    inline Binding* connect(T& object, typename MethodBinding<T >::Function function);
    void disconnect(Binding* binding) { d_bindings.remove(binding);}
    inline void emit(A1 a1, A2 a2, A3 a3);
  private:
    BindingList d_bindings;
  };
  template <typename A1, typename A2, typename A3 >
  class Binding3 : public SignalBinding 
  {
  public:
    ~Binding3();
    virtual void emit(A1 a1, A2 a2, A3 a3) = 0;
  protected:
    Binding3(SignalBindable* binded = 0) : SignalBinding(binded), d_signal(0) {}
  private:
    Signal3<A1, A2, A3 >* d_signal;
    friend class Signal3<A1, A2, A3 >;
  };
  template <typename A1, typename A2, typename A3 >
  class GlobalBinding3 : public Binding3<A1, A2, A3 >
  {
  public:
    GlobalBinding3(void(*func)(A1 a1, A2 a2, A3 a3)) : d_func(func) {}
    void emit(A1 a1, A2 a2, A3 a3) { d_func(a1, a2, a3);}
  private:
    void(*d_func)(A1 a1, A2 a2, A3 a3);
  };
  template <typename T, typename A1, typename A2, typename A3 >
  class MethodBinding3 : public Binding3<A1, A2, A3 >
  {
  public:
    MethodBinding3(T& object, void (T::*func)(A1 a1, A2 a2, A3 a3)) 
      : Binding3<A1, A2, A3 >(&object), d_binded(object), d_func(func) {}
    void emit(A1 a1, A2 a2, A3 a3) { (d_binded.*d_func)(a1, a2, a3);}
  private:
    T& d_binded;
    void (T::*d_func)(A1 a1, A2 a2, A3 a3);
  };

  template <typename A1, typename A2, typename A3 > 
  Signal3<A1, A2, A3 >::~Signal3()
  {
    while(!d_bindings.empty())
      delete d_bindings.front();
  }

  template <typename A1, typename A2, typename A3>
  typename Signal3<A1, A2, A3 >::Binding* Signal3<A1, A2, A3 >::connect(typename Signal3<A1, A2, A3 >::Binding* binding)
  {
    d_bindings.push_back(binding);
    binding->d_signal = this;
    return binding;
  }

  template <typename A1, typename A2, typename A3 > 
  template <typename T>
  typename Signal3<A1, A2, A3 >::Binding* Signal3<A1, A2, A3 >::connect(T& object, typename Signal3<A1, A2, A3 >::template MethodBinding<T>::Function function)
  {
    return connect(new MethodBinding3<T, A1, A2, A3 >(object, function));
  }

  template <typename A1, typename A2, typename A3 >
  typename Signal3<A1, A2, A3 >::Binding* Signal3<A1, A2, A3 >::connect(typename Signal3<A1, A2, A3 >::GlobalBinding::Function function)
  {
    return connect(new GlobalBinding3<A1, A2, A3 >(function));
  }

  template <typename A1, typename A2, typename A3 >
  void Signal3<A1, A2, A3>::emit(A1 a1, A2 a2, A3 a3)
  {
    typename BindingList::iterator iter = d_bindings.begin();
    const typename BindingList::iterator end = d_bindings.end();
    for(;iter != end; ++iter)
      {
        (*iter)->emit(a1, a2, a3);
      }
  }

  template <typename A1, typename A2, typename A3 > 
  Binding3<A1, A2, A3 >::~Binding3() 
  {
    if (d_signal)
      d_signal->disconnect(this);
  }
  ////////////////////////////////////////////
  // Number of parameters: 4
  ////////////////////////////////////////////
  template<typename A1, typename A2, typename A3, typename A4 > class Binding4;
  template<typename A1, typename A2, typename A3, typename A4 > class GlobalBinding4;
  template<typename T, typename A1, typename A2, typename A3, typename A4 > class MethodBinding4;
  template<typename A1, typename A2, typename A3, typename A4 > class Signal4;
  
  template<typename A1, typename A2, typename A3, typename A4 >
  class Signal4
  { 
    typedef std::list<Binding4<A1, A2, A3, A4 >* > BindingList;
  public:
    typedef Binding4<A1, A2, A3, A4 > Binding;
    struct GlobalBinding
    {
      typedef void(*Function)(A1 a1, A2 a2, A3 a3, A4 a4);
    };
    template <typename T>
    struct MethodBinding
    {
      typedef void (T::*Function)(A1 a1, A2 a2, A3 a3, A4 a4);
    };
    Signal4() {}
    ~Signal4();
    inline Binding* connect(Binding* binding);
    inline Binding* connect(typename GlobalBinding::Function function);
    template <typename T>
    inline Binding* connect(T& object, typename MethodBinding<T >::Function function);
    void disconnect(Binding* binding) { d_bindings.remove(binding);}
    inline void emit(A1 a1, A2 a2, A3 a3, A4 a4);
  private:
    BindingList d_bindings;
  };
  template <typename A1, typename A2, typename A3, typename A4 >
  class Binding4 : public SignalBinding 
  {
  public:
    ~Binding4();
    virtual void emit(A1 a1, A2 a2, A3 a3, A4 a4) = 0;
  protected:
    Binding4(SignalBindable* binded = 0) : SignalBinding(binded), d_signal(0) {}
  private:
    Signal4<A1, A2, A3, A4 >* d_signal;
    friend class Signal4<A1, A2, A3, A4 >;
  };
  template <typename A1, typename A2, typename A3, typename A4 >
  class GlobalBinding4 : public Binding4<A1, A2, A3, A4 >
  {
  public:
    GlobalBinding4(void(*func)(A1 a1, A2 a2, A3 a3, A4 a4)) : d_func(func) {}
    void emit(A1 a1, A2 a2, A3 a3, A4 a4) { d_func(a1, a2, a3, a4);}
  private:
    void(*d_func)(A1 a1, A2 a2, A3 a3, A4 a4);
  };
  template <typename T, typename A1, typename A2, typename A3, typename A4 >
  class MethodBinding4 : public Binding4<A1, A2, A3, A4 >
  {
  public:
    MethodBinding4(T& object, void (T::*func)(A1 a1, A2 a2, A3 a3, A4 a4)) 
      : Binding4<A1, A2, A3, A4 >(&object), d_binded(object), d_func(func) {}
    void emit(A1 a1, A2 a2, A3 a3, A4 a4) { (d_binded.*d_func)(a1, a2, a3, a4);}
  private:
    T& d_binded;
    void (T::*d_func)(A1 a1, A2 a2, A3 a3, A4 a4);
  };

  template <typename A1, typename A2, typename A3, typename A4 > 
  Signal4<A1, A2, A3, A4 >::~Signal4()
  {
    while(!d_bindings.empty())
      delete d_bindings.front();
  }

  template <typename A1, typename A2, typename A3, typename A4>
  typename Signal4<A1, A2, A3, A4 >::Binding* Signal4<A1, A2, A3, A4 >::connect(typename Signal4<A1, A2, A3, A4 >::Binding* binding)
  {
    d_bindings.push_back(binding);
    binding->d_signal = this;
    return binding;
  }

  template <typename A1, typename A2, typename A3, typename A4 > 
  template <typename T>
  typename Signal4<A1, A2, A3, A4 >::Binding* Signal4<A1, A2, A3, A4 >::connect(T& object, typename Signal4<A1, A2, A3, A4 >::template MethodBinding<T>::Function function)
  {
    return connect(new MethodBinding4<T, A1, A2, A3, A4 >(object, function));
  }

  template <typename A1, typename A2, typename A3, typename A4 >
  typename Signal4<A1, A2, A3, A4 >::Binding* Signal4<A1, A2, A3, A4 >::connect(typename Signal4<A1, A2, A3, A4 >::GlobalBinding::Function function)
  {
    return connect(new GlobalBinding4<A1, A2, A3, A4 >(function));
  }

  template <typename A1, typename A2, typename A3, typename A4 >
  void Signal4<A1, A2, A3, A4>::emit(A1 a1, A2 a2, A3 a3, A4 a4)
  {
    typename BindingList::iterator iter = d_bindings.begin();
    const typename BindingList::iterator end = d_bindings.end();
    for(;iter != end; ++iter)
      {
        (*iter)->emit(a1, a2, a3, a4);
      }
  }

  template <typename A1, typename A2, typename A3, typename A4 > 
  Binding4<A1, A2, A3, A4 >::~Binding4() 
  {
    if (d_signal)
      d_signal->disconnect(this);
  }
  //////////////////////////////////////////////////////////////////////////
  // ENet itself 
  //////////////////////////////////////////////////////////////////////////
  class ENet
  {
  public:
    ENet()
    {    
      if (count_ == 0)
	if (! enet_initialize())
	  ; // Report the error 
      ++count_;
    }
    
    ~ENet()
    {
      --count_;
      if (count_ == 0)
	enet_deinitialize();
    }
    
    private:
    static int count_;
    
  };
  
  int ENet::count_(0);
  
    


  template <typename T = char> 
  class MessageFactoryManager
  {
  public:
    typedef T message_type;
    class Message
    {
    protected:
      enum Flag {
	Reliable = ENET_PACKET_FLAG_RELIABLE, 
	Unsequenced = ENET_PACKET_FLAG_UNSEQUENCED, 
      };

      Message(message_type type, int flags): type_(type), flags_(flags) {}
    public:
            
      virtual ~Message() {} 
      message_type type() const { return type_;}
      int flags() const { return flags_; }
      size_t packedSize() const 
      {
	return sizeof(message_type) + contentSize();
      }
      void   pack(char* data, size_t dataLength)  const 
      {
	assert(sizeof(message_type) <= dataLength);
	std::memcpy(data, &type_, sizeof(message_type));
	size_t written = contentPack(data + sizeof(message_type), 
				     dataLength - sizeof(message_type));
	assert(written + sizeof(message_type) == dataLength);
      }
      void   unpack(const char* data, size_t dataLength) 
      {
	message_type type;
	assert(dataLength >= sizeof(message_type));
	std::memcpy(&type, data, sizeof(message_type));
	assert(type == type_);
	size_t readed = contentUnpack(data + sizeof(message_type), 
                                      dataLength - sizeof(message_type));
	assert(readed + sizeof(message_type) == dataLength);
      }
    protected:
      virtual size_t contentSize() const = 0; 
      virtual size_t contentPack(char* data, size_t dataLength) const = 0;
      virtual size_t contentUnpack(const char* data, size_t dataLength) = 0;
    private:
      message_type type_;
      int flags_;
      Message(const Message&);
      Message& operator=(const Message&);
    };

    class MessageFactoryBase 
    {
    protected:
      MessageFactoryBase(message_type type);
    public:
      virtual ~MessageFactoryBase();
      virtual Message* create() = 0;
      virtual void destroy(Message* message) = 0;
    };

    template <typename M, message_type type> 
    class MessageFactory : public MessageFactoryBase
    {
    public:
      MessageFactory() : MessageFactoryBase(type) {}
      ~MessageFactory() {}
      Message* create() { return new M(); }
      void destroy(Message* message) { delete static_cast<M*>(message); }
    private:
    };

    static Message* create(message_type type);
    static void destroy(Message* message);
        
  private:
    typedef std::map<message_type, MessageFactoryBase*> FactoryList; 
    static void registerMessageFactory(message_type type, MessageFactoryBase* base);
    static void unregisterMessageFactory(MessageFactoryBase* base);
         
    static FactoryList factories_;

    friend class MessageFactoryBase; // Grant access to both register / unregister 

    // Disabled operation 
    MessageFactoryManager();
    ~MessageFactoryManager();
    MessageFactoryManager(MessageFactoryManager&);
    MessageFactoryManager& operator=(MessageFactoryManager&);
  };
  template <typename T> 
  typename MessageFactoryManager<T>::FactoryList MessageFactoryManager<T>::factories_;





  template <typename T>
  MessageFactoryManager<T>::MessageFactoryBase::MessageFactoryBase(message_type type)  
  {
    MessageFactoryManager::registerMessageFactory(type, this);
  }

  template <typename T>
  MessageFactoryManager<T>::MessageFactoryBase::~MessageFactoryBase()
  {
    MessageFactoryManager::unregisterMessageFactory(this);
  }

  template <typename T>
  typename MessageFactoryManager<T>::Message* MessageFactoryManager<T>::create(message_type type)
  {
    typename FactoryList::iterator iter = factories_.find(type);
    if (iter != factories_.end())
      return iter->second->create();
    return 0;
  }

  template <typename T>
  void MessageFactoryManager<T>::destroy(Message* message)
  {
    assert(message);
    typename FactoryList::iterator iter = factories_.find(message->type());
    if (iter != factories_.end())
      iter->second->destroy(message);
    else 
      delete message;
  }

  template <typename T> 
  void MessageFactoryManager<T>::registerMessageFactory(message_type type, MessageFactoryBase* base)
  {
    factories_[type] = base;
  }

  template <typename T> 
  void MessageFactoryManager<T>::unregisterMessageFactory(MessageFactoryBase* base) 
  {
    typename FactoryList::iterator iter = factories_.begin();
    for(; iter != factories_.end() ; ++iter)
      {
        if (iter->second == base)
	  {
            factories_.erase(iter);
            break;
	  }
      }
  }

  template <typename MFM = MessageFactoryManager<char> > 
  class Host
  {
  public:
    typedef typename MFM::message_type message_type_type;
    typedef typename MFM::Message message_base_type;
    typedef typename MFM::MessageFactoryBase message_factory_base_type;
    class Peer 
    {
    protected:
      Peer(ENetPeer* peer) : peer_(peer) {}
    public:
      ~Peer() {}
      unsigned short port() const;
      char* ip(char* buffer, size_t bufferLength) const;
      char* name(char* buffer, size_t bufferLength) const;
      void* udata();
      void udata(void* object);
      void send(message_base_type* message, int channel = 0);
      void ping();
      void disconnect();
    private:  
      ENetPeer* peer_;
      friend class Host;
    };
    explicit Host(int peers=1);
    Host(int peers, int downBandwidth, int upBandwidth);
    Host(unsigned short port, int peers);
    ~Host();
    
    bool connect(const char* hostname, int port, int channels = 1, int retry = 5);
    void service(int delay);
    void flush();
    
    // Send a message to one or several peers 
    void send(Peer& peer,  message_base_type* message, int channel = 0);
    void broadcast(message_base_type* message, int channel = 0);
    
    // Event connector 
    SignalConnector<Signal0>                   onIdle;
    SignalConnector<Signal1<Peer&> >           onPeerConnect;
    SignalConnector<Signal1<Peer&> >           onPeerDisconnect;
    SignalConnector<Signal2<Peer&, message_base_type*> > onMessageReceived;

  private:
    ENetHost* host_;
    Signal0        signalIdle_;
    Signal1<Peer&> signalPeerConnect_;
    Signal1<Peer&> signalPeerDisconnect_;
    Signal2<Peer&, message_base_type*> signalMessageReceived_;
    
    Host(const Host&);
    Host& operator=(const Host&);
  };
  template <typename MFM>
  Host<MFM>::Host(int peers)
    : onIdle(signalIdle_), 
      onPeerConnect(signalPeerConnect_), 
      onPeerDisconnect(signalPeerDisconnect_), 
      onMessageReceived(signalMessageReceived_), 
      host_(0)
  {
    host_ = enet_host_create(0, peers, 0, 0);
  }
  

  template <typename MFM>
  Host<MFM>::Host(int peers, int downBandwidth, int upBandwidth)
    : onIdle(signalIdle_), 
      onPeerConnect(signalPeerConnect_), 
      onPeerDisconnect(signalPeerDisconnect_), 
      onMessageReceived(signalMessageReceived_), 
      host_(0)
  {
    host_ = enet_host_create(0, peers, downBandwidth, upBandwidth);
    // Add error checking 
  

  }
  
  template <typename MFM>
  Host<MFM>::Host(unsigned short port, int peers)
    : onIdle(signalIdle_),
      onPeerConnect(signalPeerConnect_), 
      onPeerDisconnect(signalPeerDisconnect_), 
      onMessageReceived(signalMessageReceived_), 
      host_(0)
  {
    ENetAddress address;
    address.port = port;
    address.host = ENET_HOST_ANY;
    host_ = enet_host_create(&address, peers, 0, 0);
    // Add error checking 
  }

  template <typename MFM>
  Host<MFM>::~Host() 
  {
    enet_host_destroy(host_);
    
  }

  template <typename MFM>
  bool Host<MFM>::connect(const char* host, int port, int channels, int retry)
  {
    
    ENetAddress address;
    address.port = port;
    enet_address_set_host(&address, host);

    while(retry) {
      ENetPeer* peer = enet_host_connect(host_, &address, channels);
      Peer obj(peer);
      ENetEvent event;
      int status = enet_host_service(host_, &event, 1000);
      if (status > 0) {
	if (event.type == ENET_EVENT_TYPE_CONNECT) {
	  signalPeerConnect_.emit(obj);
	  return true;
	}  
      }
      enet_peer_reset(peer);
      --retry;
    }
    return false;
  }
    template <typename MFM>
  void Host<MFM>::service(int delay)
  {
    ENetEvent event;
    int eventCount = 0;
    while (enet_host_service(host_, &event, delay) > 0) {
      Peer peer(event.peer);
      message_type_type type;
      message_base_type* message = 0;
      switch(event.type){
      case ENET_EVENT_TYPE_NONE:
	// Ignored 
	break;
      case ENET_EVENT_TYPE_CONNECT:
	++eventCount;
	signalPeerConnect_.emit(peer);
	break;
      case ENET_EVENT_TYPE_RECEIVE:
	++eventCount;
	std::memcpy(&type, event.packet->data, sizeof(type));
	message = MFM::create(type);
	if (message) {
	  message->unpack((const char*)event.packet->data, event.packet->dataLength);
	  signalMessageReceived_.emit(peer, message);
	  MFM::destroy(message);
	} else {
	  
	  // It's an error !!! report it 
	  ;
	}
	enet_packet_destroy(event.packet);
	break;
      case ENET_EVENT_TYPE_DISCONNECT:
	++eventCount;
	signalPeerDisconnect_.emit(peer);
	peer.udata(0);
	break;
      }
      delay = 0;
    }
    if (eventCount == 0)
      signalIdle_.emit();
    
  }
  
  template <typename MFM>  
  void Host<MFM>::flush() 
  {
    enet_host_flush(host_);
  }
  template <typename MFM>
  void Host<MFM>::send(Peer& peer, message_base_type* message, int channel)
  {
    peer.send(message, channel);
  }
  
  template<typename MFM>  
  void Host<MFM>::broadcast(message_base_type* message, int channel)
  {
    ENetPacket* packet = enet_packet_create(0, message->packedSize(), message->flags());
    message->pack((char*)packet->data, packet->dataLength);
    enet_host_broadcast(host_, channel, packet);
  }
  
  template <typename MFM>
  unsigned short Host<MFM>::Peer::port() const
  {
    return peer_->address.port;
  }
  
  template <typename MFM>
  char* Host<MFM>::Peer::ip(char* buffer, size_t bufferLength) const
  {
    return 0;
  
  }
  template <typename MFM>
  char* Host<MFM>::Peer::name(char* buffer, size_t bufferLength) const
  {
    return 0;
  }
  template <typename MFM>
  void* Host<MFM>::Peer::udata() 
  { 
    return peer_->data; 
  }
  
  template <typename MFM>
  void Host<MFM>::Peer::udata(void* object) 
  {
    peer_->data = object;
  }
  
  template <typename MFM>
  void Host<MFM>::Peer::send(message_base_type* message, int channel)
  {
    ENetPacket* packet = enet_packet_create(0, message->packedSize(), message->flags());
    message->pack((char*)packet->data, packet->dataLength);
    enet_peer_send(peer_, channel, packet);
  }
  template <typename MFM>
  void Host<MFM>::Peer::ping()
  {
    enet_peer_ping(peer_);
  }
  template <typename MFM>
  void Host<MFM>::Peer::disconnect()
  {
    enet_peer_disconnect(peer_, 0);
  }
  
} // end of enet namespace
#endif 
