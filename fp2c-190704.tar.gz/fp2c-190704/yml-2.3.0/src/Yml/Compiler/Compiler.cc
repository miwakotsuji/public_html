/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/

/**
 * @file
 * @brief Class Compiler function definition 
 *
 * 2005-06-18
 * Olivier Delannoy
 */
#include "Compiler.hh"
#include <Yml/Core/DevelopmentCatalog.hh>
#include <Yml/Core/BuiltinManager.hh>
#include <Yml/Core/YvetteFunctionTable.hh>
#include <Yml/Core/YvetteCompiler.hh>
#include <Yml/Core/YvetteApplication.hh>
#include <Yml/Core/YvetteApplication_xmlHandler.hh>

// Util include 
#include <RuntimeEnvironment.hh>
#include <FileInfo.hh>
#include <XMLParser.hh>
#include <XMLParserFactory.hh> 
#include <Properties.hh>
#include <CommandLineParser.hh>
#include <CommandLineOption.hh>
#include <ConfigFactory.hh>
#include <LoggerFactory.hh>
#include <PluginFactory.hh> 
#include <Dir.hh>
#include <File.hh>
#include <locale> 

Yml::Compiler::Compiler::Compiler(Util::ApplicationAdaptor* adaptor, 
                                  int argc, char** argv) 
    : Util::Application(adaptor, argc, argv)
{
	std::locale::global(std::locale("C"));
}

Yml::Compiler::Compiler::~Compiler(void)
{   
}

void Yml::Compiler::Compiler::configureCommandLine(void)
{
    // First parameter is the query itself
    mCmdLineParser->parameterCount(1);
    mCmdLineParser->addOption(new Util::CommandLineOption("output", "", true));
}

Yml::Compiler::string Yml::Compiler::Compiler::usageQuick(void) const
{
    return " [--output=<destname>] query";
}

Yml::Compiler::string Yml::Compiler::Compiler::usageParameters(void) const
{
    return "\n *<query> ...........: The query file";
}

Yml::Compiler::string Yml::Compiler::Compiler::usageOptions(void) const
{
    return "\n\n  --output=destname .: The resulting application file";
}


Yml::Compiler::string Yml::Compiler::Compiler::configDir(void) const
{
    return CONFIG_DIR;
}

Yml::Compiler::string Yml::Compiler::Compiler::loggersDir(void) const
{
    return Util::ConfigFactory::getSingleton().create("yml")->get("path", "loggers", "value");  
}
Yml::Compiler::string Yml::Compiler::Compiler::pluginDir(void) const 
{
    return Util::ConfigFactory::getSingleton().create("yml")->get("path", "plugins", ".");
}
Yml::Compiler::uint32 Yml::Compiler::Compiler::run(void)
{
    Yml::Core::BuiltinManager bmanager;
    class DirCleaner
    {
        public:
            DirCleaner(const Yml::Compiler::string& path) : d_path(path)  {}
            ~DirCleaner() 
            {
                //UTIL_DEBUG("default", "Clean: " << d_path);
                Util::Dir::rmdir(d_path, true);
            }
        private:
            Yml::Compiler::string d_path;
    };

    // Parse command line 
    mQueryFileName = mCmdLineParser->parameter(1);
    Util::CommandLineOption* opt;
    opt = option("output");
    if (opt->count())
    {
        mResultFileName = opt->value();
    }
    else 
    {
        mResultFileName = mQueryFileName + ".yapp";
    }    
    //check if the query file exists before any other operation 
    if (! Util::FileInfo(mQueryFileName).exists())
    {
        UTIL_ERROR("default", "Query file does not exists");
        return ERROR;
    }
    // Print command line information
    UTIL_INFO("default", "Loading configuration files");
    // Initialize temporary dir
    mTempPath = Util::Dir::mktemp();
    DirCleaner cleanup(mTempPath); // Register cleanup of the temporary directory 
    Util::File::remove(mResultFileName);
    UTIL_INFO("default", "Configuration summary");
    UTIL_INFO("default", "Query filename ........: " << mQueryFileName);
    UTIL_INFO("default", "Compiled application ..: " << mResultFileName);
    UTIL_INFO("default", "Temporary working dir .: " << mTempPath);
    Yml::Core::PluginManager::getSingleton().getDevelopmentCatalog();
    Util::XMLParser xmlParser = Util::XMLParserFactory::getSingleton().create();
    UTIL_INFO("default", "Parsing Query from: " << mQueryFileName);
    Yml::Core::Application app(mResultFileName, mTempPath);
    Yml::Core::Application_xmlHandler handler(app);
    xmlParser.parse(handler, mQueryFileName);
    if (handler.isError())
    {
        UTIL_ERROR("default", "Malformed application query detected, skeep compilation stage");
        return ERROR;
    }
    // At this point we are sure we have a valid application query
    app.initializeCompilation(); 
    // Start the compiler instance
    Yml::Core::YvetteCompiler compiler;
    compiler.setApplication(&app);
    compiler.setSource(app.getYvetteProgram());
    compiler.setFirstLine(1);
    bool result = compiler.compile();
    app.finalizeCompilation();
    // Clean compilation files 
    if (result)
    {
        UTIL_INFO("default", "Compilation finished successfully");
    }
    else 
    {
        Util::File::remove(mResultFileName);
        UTIL_ERROR("default", "Compilation failed during the generation");
    }
    return SUCCESS;
}



