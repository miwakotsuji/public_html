/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/****************************************************************************
 * Copyright Olivier Delannoy, Laurent Choy 2005
 *
 * Olivier Delannoy   
 *   Olivier.Delannoy@gmail.com
 *   PRiSM Laboratory 
 *   Verailles University 
 *   45 avenue des Etats Unis 
 *   78035 Versailles Cedex FRANCE 
 *
 * Laurent Choy 
 *   Choy.Laurent@gmail.com
 *   INRIA Futurs
 *   Parc Club Orsay Universit�                      
 *   ZAC des vignes                      
 *   2-4, rue Jacques Monod                      
 *   91893 Orsay Cedex France
 *
 *
 *
 * This software is a computer program whose purpose is to [describe
 * functionalities and technical features of your software].
 * 
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 ****************************************************************************/

/**
 * @file
 * @brief Class Scheduler function definition 
 *
 * 2005-07-18
 * Olivier Delannoy
 */
#include "Scheduler.hh"
#include <RuntimeEnvironment.hh>
#include <FileInfo.hh>
#include <File.hh>
#include <Dir.hh>
#include <CommandLineParser.hh>
#include <CommandLineOption.hh>
#include <ConfigFactory.hh>
#include <LoggerFactory.hh>
#include <PluginFactory.hh>
//Extension points 
#include <Yml/Core/BackendManager.hh> 
#include <Yml/Core/YvetteApplication.hh> 
#include <Yml/Core/SecondLevelScheduler.hh>
#include <Yml/Core/BuiltinManager.hh>
#include <unistd.h>
#include <locale> 
Yml::Scheduler::Scheduler::Scheduler(Util::ApplicationAdaptor* adaptor, 
                                     int argc, char** argv)
    : Util::Application(adaptor, argc, argv)
{
	std::locale::global(std::locale("C"));
}
Yml::Scheduler::Scheduler::~Scheduler(void)
{
}
void Yml::Scheduler::Scheduler::configureCommandLine(void)
{
    // First parameter is the path to the file to compile
    // Second parameter is query unique id 
    mCmdLineParser->parameterCount(1);
    mCmdLineParser->addOption(new Util::CommandLineOption("input", "", true));
    mCmdLineParser->addOption(new Util::CommandLineOption("output", "", true));
    mCmdLineParser->addOption(new Util::CommandLineOption("clean", "", false));
    
}
Yml::Scheduler::string Yml::Scheduler::Scheduler::usageQuick(void) const
{
    return " <options> <compiled application>";
}
Yml::Scheduler::string Yml::Scheduler::Scheduler::usageParameters(void) const
{
    return 
        "\n *<compiled application> ...: The application file to execute";
}
Yml::Scheduler::string Yml::Scheduler::Scheduler::usageOptions(void) const
{
    return 
        "\n  --input=<inputPack> ......: The parameter of the application" \
        "\n  --output=<outputPack> ....: The filename of the result pack" \
        "\n  --clean ..................: Destroy all file created during the execution\n"; 
}


Yml::Scheduler::string Yml::Scheduler::Scheduler::configDir(void) const
{
    return CONFIG_DIR;
}
Yml::Scheduler::string Yml::Scheduler::Scheduler::loggersDir(void) const
{
    return Util::ConfigFactory::getSingleton().create("yml")->get("path", "loggers", ".");
}
Yml::Scheduler::string Yml::Scheduler::Scheduler::pluginDir(void) const 
{
    return Util::ConfigFactory::getSingleton().create("yml")->get("path", "plugins", ".");
}
Yml::Scheduler::uint32 Yml::Scheduler::Scheduler::run(void)
{
    Yml::Core::BuiltinManager b;
    UTIL_INFO("default", "Starting");
    UTIL_INFO("default", "Loading configuration files");
    Util::Config* yml = Util::ConfigFactory::getSingleton().create("yml");
    Util::Config* config = Util::ConfigFactory::getSingleton().create("default");
    string dirData = yml->get("path", "database", ".");
    string dirBin = yml->get("path", "programs", ".");
    UTIL_INFO("default", "Loading plugins");
    Yml::Core::BackendManager backendManager;
    Yml::Core::PluginManager::getSingleton().getExecutionCatalog();
    
    // Retrieve Command line parameters 
    mApplicationFile = mCmdLineParser->parameter(1);
    if (!Util::FileInfo(mApplicationFile).isFile())
    {
        UTIL_ERROR("default", "Invalid application file");
        return ERROR;
    }
    Util::CommandLineOption* opt;
    // Input pack ? 
    opt = option("input");
    if (opt->count())
    {
        mInputParameterPackName = opt->value();
    }
    // Output pack ? 
    opt = option("output");
    mOutputParameterPackName = opt->value();
    
    // Cleanup after execution 
    opt = option("clean");
    if (opt->count())
        mDoCleanup = true;
    else 
        mDoCleanup = false;
    
    // Create the current working dir 
    mWorkingDir = Util::RuntimeEnvironment::workingDir() + Util::RuntimeEnvironment::PATH_SEPARATOR + "run";
    uint32 i = 0;
    do 
    {
        ++i;
        std::ostringstream dirName;
        dirName << mWorkingDir << i << Util::RuntimeEnvironment::PATH_SEPARATOR;
        
        if (! Util::Dir::exists(dirName.str()))
        {
            i = 0;
            mWorkingDir = dirName.str();
        }
    }
    while(i);
    if (! Util::Dir::mkdir(mWorkingDir))
    {
        UTIL_FATAL("default", "Unable to create working directory: '" << mWorkingDir << "'");
        return ERROR;
    }
    // Printout summary of the configuration 
    UTIL_INFO("default", "Configuration summary");
    UTIL_INFO("default", "  Application           : " << mApplicationFile);
    UTIL_INFO("default", "  Input pack            : " << mInputParameterPackName);
    UTIL_INFO("default", "  Output pack           : " << mOutputParameterPackName);
    UTIL_INFO("default", "  Cleanup execution file: " << (mDoCleanup ? "yes" : "no" ));
    UTIL_INFO("default", "  Path information");
    UTIL_INFO("default", "    Binary application  : " << dirBin);
    UTIL_INFO("default", "    Runtime Data        : " << dirData);
    UTIL_INFO("default", "    Working Dir         : " << mWorkingDir);
    // Make sure mInputParameterPackName is an absolute path 
    if (! mInputParameterPackName.empty())
    {
        if (mInputParameterPackName[0] != Util::RuntimeEnvironment::PATH_SEPARATOR)
            mInputParameterPackName = Util::RuntimeEnvironment::workingDir() + Util::RuntimeEnvironment::PATH_SEPARATOR + mInputParameterPackName;
        if (! Util::FileInfo(mInputParameterPackName).isFile())
            mInputParameterPackName.clear();
    }
    
    
    // Make sure mOutputParameterPackName is an absolute path 
    // Option not set use the default : run%d_results.pack
    if (mOutputParameterPackName.empty())
    {
        mOutputParameterPackName.assign(mWorkingDir.data(), mWorkingDir.size() - 1);
        mOutputParameterPackName += "_results.pack";
    }
    else if (mOutputParameterPackName[0] != Util::RuntimeEnvironment::PATH_SEPARATOR)
    {
        string tmp = Util::RuntimeEnvironment::workingDir() + Util::RuntimeEnvironment::PATH_SEPARATOR;
        tmp += mOutputParameterPackName;
        mOutputParameterPackName = tmp;
    }
    UTIL_INFO("default", "  Parameters pack");
    UTIL_INFO("default", "    Input pack: " << mInputParameterPackName );
    UTIL_INFO("default", "    Output pack: " << mOutputParameterPackName);
    
    // Create the application object 
    Yml::Core::Application app(mApplicationFile, mWorkingDir, backendManager.backend());
    app.initializeExecution(); 
    if (! mInputParameterPackName.empty())
    {
        app.importParameters(mInputParameterPackName);
    }
    // Start the execution of the application
    UTIL_INFO("default", "Starting application execution");
    UTIL_DEBUG("default", "Application status: " << app.status());
    app.startScheduling();
    UTIL_DEBUG("default", "Application status: " << app.status());
    
    // Do the scheduling loop
    

    while(app.status() == Yml::Core::Application::EXECUTING)
    {
        UTIL_DEBUG("default", "Check for finished tasks");
        Yml::Core::SchedulerTask* task;
        uint32 taskFinished = 0;
        while((task = backendManager.finishedTask()))
        {
            ++taskFinished;
            //Do the deletion of the task object 
            app.finishTask(task);
        }
        app.updateStatus();
        if (app.status() == Yml::Core::Application::ERROR)
        {
            UTIL_ERROR("default", "Tasks terminates with error, execution stopped");
            continue;
        }
        
        UTIL_DEBUG("default", "Update scheduling rules");
        // Update all condition rules 
        app.updateSchedulingRules();
        task = 0;
        uint32 taskSubmitted = 0;
        UTIL_DEBUG("default", "Queue pending tasks");
        while((task = app.nextTaskReady()) != 0)
        {
            ++taskSubmitted;
            backendManager.queue(task);
        }
        //UTIL_INFO("default", "Number of finished/submitted tasks: " << taskFinished << "/" << taskSubmitted);
        if (! backendManager.schedulePendingTasks())
        {
            UTIL_ERROR("default", "Unable to schedule some tasks");
            UTIL_ERROR("default", "Execution finished with error");
            break;
        }
        
        app.updateStatus();
        UTIL_DEBUG("default", "Application status: " << app.status());
        usleep(200); // Why do we sleep for one second ? 
    }
    UTIL_INFO("default", "Application finished");
    app.finalizeExecution();

    UTIL_INFO("default", "Packing output parameters");
    Util::File::remove(mOutputParameterPackName);
    app.exportParameters(mOutputParameterPackName);
    
    
    UTIL_INFO("default", "finishing");
    if (mDoCleanup)
    {
        UTIL_INFO("default", "Cleanup execution files");
        Util::Dir::rmdir(mWorkingDir, true);
    }
    return SUCCESS;
}


