/* A Bison parser, made by GNU Bison 2.1.  */

/* C++ Skeleton parser for LALR(1) parsing with Bison,
   Copyright (C) 2002, 2003, 2004, 2005 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */


#include "YvetteParser.hh"

#ifndef YY_
# if YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* FIXME: INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* A pseudo ostream that takes yydebug_ into account. */
# define YYCDEBUG							\
  for (bool yydebugcond_ = yydebug_; yydebugcond_; yydebugcond_ = false)	\
    (*yycdebug_)

/* Enable debugging if requested.  */
#if YYDEBUG

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)	\
do {							\
  if (yydebug_)						\
    {							\
      *yycdebug_ << (Title) << ' ';			\
      yysymprint_ ((Type), (Value), (Location));	\
      *yycdebug_ << std::endl;				\
    }							\
} while (0)

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug_)				\
    yyreduce_print_ (Rule);		\
} while (0)

# define YY_STACK_PRINT()		\
do {					\
  if (yydebug_)				\
    yystack_print_ ();			\
} while (0)

#else /* !YYDEBUG */

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_REDUCE_PRINT(Rule)
# define YY_STACK_PRINT()

#endif /* !YYDEBUG */

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab

#if YYERROR_VERBOSE

/* Return YYSTR after stripping away unnecessary quotes and
   backslashes, so that it's suitable for yyerror.  The heuristic is
   that double-quoting is unnecessary unless the string contains an
   apostrophe, a comma, or backslash (other than backslash-backslash).
   YYSTR is taken from yytname.  */
std::string
yy::YvetteParser::yytnamerr_ (const char *yystr)
{
  if (*yystr == '"')
    {
      std::string yyr = "";
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    yyr += *yyp;
	    break;

	  case '"':
	    return yyr;
	  }
    do_not_strip_quotes: ;
    }

  return yystr;
}

#endif

#if YYDEBUG
/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

void
yy::YvetteParser::yysymprint_ (int yytype,
                         const semantic_type* yyvaluep, const location_type* yylocationp)
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;
  (void) yylocationp;
  /* Backward compatibility, but should be removed eventually. */
  std::ostream& cdebug_ = *yycdebug_;
  (void) cdebug_;

  *yycdebug_ << (yytype < yyntokens_ ? "token" : "nterm")
	     << ' ' << yytname_[yytype] << " ("
             << *yylocationp << ": ";
  switch (yytype)
    {
      default:
        break;
    }
  *yycdebug_ << ')';
}
#endif /* ! YYDEBUG */

void
yy::YvetteParser::yydestruct_ (const char* yymsg,
                         int yytype, semantic_type* yyvaluep, location_type* yylocationp)
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yymsg;
  (void) yyvaluep;
  (void) yylocationp;

  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
        break;
    }
}

void
yy::YvetteParser::yypop_ (unsigned int n)
{
  yystate_stack_.pop (n);
  yysemantic_stack_.pop (n);
  yylocation_stack_.pop (n);
}

std::ostream&
yy::YvetteParser::debug_stream () const
{
  return *yycdebug_;
}

void
yy::YvetteParser::set_debug_stream (std::ostream& o)
{
  yycdebug_ = &o;
}


yy::YvetteParser::debug_level_type
yy::YvetteParser::debug_level () const
{
  return yydebug_;
}

void
yy::YvetteParser::set_debug_level (debug_level_type l)
{
  yydebug_ = l;
}


int
yy::YvetteParser::parse ()
{
  /* Look-ahead and look-ahead in internal form.  */
  int yylooka;
  int yyilooka;

  /// Semantic value of the look-ahead.
  semantic_type yylval;
  /// Location of the look-ahead.
  location_type yylloc;
  /// The locations where the error started and ended.
  location yyerror_range[2];

  /// $$.
  semantic_type yyval;
  /// @$.
  location_type yyloc;

  int yyresult_;

  YYCDEBUG << "Starting parse" << std::endl;

  yynerrs_ = 0;
  yyerrstatus_ = 0;

  /* Start.  */
  yystate_ = 0;
  yylooka = yyempty_;


  /* User initialization code. */
  #line 71 "YvetteParser.yy"
{
	yylloc.begin.filename = yylloc.end.filename = 0;
}
/* Line 548 of yacc.c.  */
#line 238 "YvetteParser.cc"
  /* Initialize the stacks.  The initial state will be pushed in
     yynewstate, since the latter expects the semantical and the
     location values to have been already stored, initialize these
     stacks with a primary value.  */
  yystate_stack_ = state_stack_type (0);
  yysemantic_stack_ = semantic_stack_type (0);
  yylocation_stack_ = location_stack_type (0);
  yysemantic_stack_.push (yylval);
  yylocation_stack_.push (yylloc);

  /* New state.  */
yynewstate:
  yystate_stack_.push (yystate_);
  YYCDEBUG << "Entering state " << yystate_ << std::endl;
  goto yybackup;

  /* Backup.  */
yybackup:

  /* Try to take a decision without look-ahead.  */
  yyn_ = yypact_[yystate_];
  if (yyn_ == yypact_ninf_)
    goto yydefault;

  /* Read a look-ahead token.  */
  if (yylooka == yyempty_)
    {
      YYCDEBUG << "Reading a token: ";
      yylooka = yylex (&yylval, &yylloc, driver);
    }


  /* Convert token to internal form.  */
  if (yylooka <= yyeof_)
    {
      yylooka = yyilooka = yyeof_;
      YYCDEBUG << "Now at end of input." << std::endl;
    }
  else
    {
      yyilooka = yytranslate_ (yylooka);
      YY_SYMBOL_PRINT ("Next token is", yyilooka, &yylval, &yylloc);
    }

  /* If the proper action on seeing token ILOOKA_ is to reduce or to
     detect an error, take that action.  */
  yyn_ += yyilooka;
  if (yyn_ < 0 || yylast_ < yyn_ || yycheck_[yyn_] != yyilooka)
    goto yydefault;

  /* Reduce or error.  */
  yyn_ = yytable_[yyn_];
  if (yyn_ < 0)
    {
      if (yyn_ == yytable_ninf_)
	goto yyerrlab;
      else
	{
	  yyn_ = -yyn_;
	  goto yyreduce;
	}
    }
  else if (yyn_ == 0)
    goto yyerrlab;

  /* Accept?  */
  if (yyn_ == yyfinal_)
    goto yyacceptlab;

  /* Shift the look-ahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yyilooka, &yylval, &yylloc);

  /* Discard the token being shifted unless it is eof.  */
  if (yylooka != yyeof_)
    yylooka = yyempty_;

  yysemantic_stack_.push (yylval);
  yylocation_stack_.push (yylloc);

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus_)
    --yyerrstatus_;

  yystate_ = yyn_;
  goto yynewstate;

/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn_ = yydefact_[yystate_];
  if (yyn_ == 0)
    goto yyerrlab;
  goto yyreduce;

/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  yylen_ = yyr2_[yyn_];
  /* If LEN_ is nonzero, implement the default value of the action:
     `$$ = $1'.  Otherwise, use the top of the stack.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  */
  if (yylen_)
    yyval = yysemantic_stack_[yylen_ - 1];
  else
    yyval = yysemantic_stack_[0];

  {
    slice<location_type, location_stack_type> slice (yylocation_stack_, yylen_);
    YYLLOC_DEFAULT (yyloc, slice, yylen_);
  }
  YY_REDUCE_PRINT (yyn_);
  switch (yyn_)
    {
        case 2:
#line 157 "YvetteParser.yy"
    { driver.root().setFirstChild((yysemantic_stack_[0])); ;}
    break;

  case 3:
#line 160 "YvetteParser.yy"
    {(yyval) = 0; ;}
    break;

  case 4:
#line 162 "YvetteParser.yy"
    { (yyval) = (yysemantic_stack_[1]); (yysemantic_stack_[1])->setNextSibling((yysemantic_stack_[0]));   ;}
    break;

  case 5:
#line 167 "YvetteParser.yy"
    {(yyval)=(yysemantic_stack_[1]); ;}
    break;

  case 6:
#line 169 "YvetteParser.yy"
    {(yyval)=(yysemantic_stack_[0]); ;}
    break;

  case 7:
#line 173 "YvetteParser.yy"
    {(yyval)=(yysemantic_stack_[0]);;}
    break;

  case 8:
#line 175 "YvetteParser.yy"
    {(yyval)=(yysemantic_stack_[0]);;}
    break;

  case 9:
#line 177 "YvetteParser.yy"
    {(yyval)=(yysemantic_stack_[0]);;}
    break;

  case 10:
#line 179 "YvetteParser.yy"
    {(yyval)=(yysemantic_stack_[0]);;}
    break;

  case 11:
#line 183 "YvetteParser.yy"
    {(yyval)=(yysemantic_stack_[0]);;}
    break;

  case 12:
#line 185 "YvetteParser.yy"
    {(yyval)=(yysemantic_stack_[0]);;}
    break;

  case 13:
#line 187 "YvetteParser.yy"
    {(yyval)=(yysemantic_stack_[0]);;}
    break;

  case 14:
#line 191 "YvetteParser.yy"
    {(yysemantic_stack_[1])->setFirstChild((yysemantic_stack_[2])); (yysemantic_stack_[2])->setNextSibling((yysemantic_stack_[0])) ; (yyval)=(yysemantic_stack_[1]); ;}
    break;

  case 15:
#line 195 "YvetteParser.yy"
    {(yyval) = (yysemantic_stack_[3]); (yyval)->setFirstChild((yysemantic_stack_[1]));;}
    break;

  case 16:
#line 198 "YvetteParser.yy"
    {(yyval)=(yysemantic_stack_[1]); (yysemantic_stack_[1])->getFirstChild()->setNextSibling((yysemantic_stack_[2])); (yysemantic_stack_[2])->setNextSibling((yysemantic_stack_[0]));;}
    break;

  case 17:
#line 200 "YvetteParser.yy"
    {(yyval)=(yysemantic_stack_[1]); (yysemantic_stack_[1])->getFirstChild()->setNextSibling((yysemantic_stack_[2])); (yysemantic_stack_[2])->setNextSibling((yysemantic_stack_[0]));;}
    break;

  case 18:
#line 202 "YvetteParser.yy"
    {(yyval)=(yysemantic_stack_[1]); (yysemantic_stack_[1])->getFirstChild()->setNextSibling((yysemantic_stack_[2])); (yysemantic_stack_[2])->setNextSibling((yysemantic_stack_[0]));;}
    break;

  case 19:
#line 204 "YvetteParser.yy"
    {(yyval)=(yysemantic_stack_[0]);;}
    break;

  case 20:
#line 208 "YvetteParser.yy"
    {(yyval)=(yysemantic_stack_[1]); (yyval)->getFirstChild()->setNextSibling((yysemantic_stack_[0]));;}
    break;

  case 21:
#line 210 "YvetteParser.yy"
    {(yyval)=(yysemantic_stack_[0]);;}
    break;

  case 22:
#line 214 "YvetteParser.yy"
    {(yyval)=(yysemantic_stack_[1]);;}
    break;

  case 23:
#line 216 "YvetteParser.yy"
    { (yyval)=(yysemantic_stack_[0]);;}
    break;

  case 24:
#line 221 "YvetteParser.yy"
    { (yysemantic_stack_[4])->setFirstChild((yysemantic_stack_[2])); (yysemantic_stack_[2])->setNextSibling((yysemantic_stack_[1])); (yyval) = (yysemantic_stack_[4]);;}
    break;

  case 25:
#line 224 "YvetteParser.yy"
    {(yysemantic_stack_[4])->setFirstChild((yysemantic_stack_[3])); (yysemantic_stack_[3])->setFirstChild((yysemantic_stack_[1])) ; (yyval) = (yysemantic_stack_[4]);;}
    break;

  case 26:
#line 226 "YvetteParser.yy"
    {(yysemantic_stack_[4])->setFirstChild((yysemantic_stack_[3])); (yysemantic_stack_[3])->setFirstChild((yysemantic_stack_[1])) ; (yyval) = (yysemantic_stack_[4]);;}
    break;

  case 27:
#line 230 "YvetteParser.yy"
    {(yysemantic_stack_[2])->setFirstChild((yysemantic_stack_[1])); (yyval) = (yysemantic_stack_[2]); ;}
    break;

  case 28:
#line 232 "YvetteParser.yy"
    {(yysemantic_stack_[1])->setFirstChild((yysemantic_stack_[0])); (yyval)=(yysemantic_stack_[1]);;}
    break;

  case 29:
#line 236 "YvetteParser.yy"
    {(yysemantic_stack_[1])->setFirstChild((yysemantic_stack_[0])); (yyval)=(yysemantic_stack_[1]);;}
    break;

  case 30:
#line 240 "YvetteParser.yy"
    {(yyval) = driver.newASTNode();
                             (yyval)->setType(TK_K_PAR_SEP);
                             (yyval)->setText("//");
                             (yyval)->setLine((yysemantic_stack_[1])->getLine());
                             (yyval)->setFirstChild((yysemantic_stack_[1]));
                             (yyval)->setNextSibling((yysemantic_stack_[0]));;}
    break;

  case 31:
#line 248 "YvetteParser.yy"
    {(yyval)=0;;}
    break;

  case 32:
#line 250 "YvetteParser.yy"
    { (yysemantic_stack_[2])->setFirstChild((yysemantic_stack_[1])); (yysemantic_stack_[2])->setNextSibling((yysemantic_stack_[0])); (yyval)= (yysemantic_stack_[2]);;}
    break;

  case 33:
#line 262 "YvetteParser.yy"
    {
   /* $1 -> iterators 
      $2 -> exclude 
      $3 -> do 
      $4 -> stmts 
    */
    /* Handle exclude list */ 
    Yml::Core::AST* stmt  = (yysemantic_stack_[1]);
    Yml::Core::AST* doast = 0;
    Yml::Core::AST* iter  = 0;
    if ((yysemantic_stack_[3]) != 0)
    {
      /* Create the if stmt arround $4 */
      Yml::Core::AST * tmp = (yysemantic_stack_[3]);
      Yml::Core::AST * thenast = 0;
      Yml::Core::AST * elseast = 0;
      Yml::Core::AST * left = 0;
      Yml::Core::AST * andast = 0;
      Yml::Core::AST * funcast = 0;
      stmt = driver.newASTNode();
      stmt->setType(TK_K_IF);
      stmt->setText("if");
      stmt->setLine((yysemantic_stack_[3])->getLine());
      stmt->setFirstChild(tmp);
      while (tmp->getNextSibling())
      {
        left = tmp;
        tmp = tmp->getNextSibling();
        left->setNextSibling(0);
        left = stmt->getFirstChild();
        funcast = driver.newASTNode();
        funcast->setType(TK_FUNC);
        funcast->setText("function");
        funcast->setLine(stmt->getLine());
        andast = driver.newASTNode();
        funcast->setFirstChild(driver.newASTNode());
        funcast->getFirstChild()->setText("");
        funcast->getFirstChild()->setType(TK_IDENTIFIER);
        funcast->getFirstChild()->setLine(stmt->getLine());
        funcast->getFirstChild()->setFirstChild(andast);
        andast->setType(TK_IDENTIFIER);
        andast->setText("operator_and");
        funcast->getFirstChild()->setNextSibling(left);
        left->setNextSibling(tmp);
        stmt->setFirstChild(funcast);
      }
      thenast = driver.newASTNode();
      thenast->setType(TK_K_IF_THEN);
      thenast->setText("then");
      thenast->setLine((yysemantic_stack_[3])->getLine());
      thenast->setFirstChild((yysemantic_stack_[1]));
      elseast = driver.newASTNode();
      elseast->setType(TK_K_IF_ELSE);
      elseast->setText("else");
      elseast->setLine((yysemantic_stack_[3])->getLine());
      thenast->setNextSibling(elseast);
      stmt->getFirstChild()->setNextSibling(thenast);
    }
    /* Handle Iterator list (at least one value) */
    doast = (yysemantic_stack_[2]);
    iter  = (yysemantic_stack_[4])->getNextSibling();
    (yysemantic_stack_[2])->setFirstChild((yysemantic_stack_[4]));
    (yysemantic_stack_[4])->setNextSibling(stmt);
    /* Du deuxieme au dernier faire */
    while (iter)
    {
      Yml::Core::AST* nparast = driver.newASTNode();
      Yml::Core::AST* ndoast = driver.newASTNode();

      nparast->setType(TK_K_PAR);
      nparast->setText("par");
      nparast->setFirstChild(ndoast);
      nparast->setLine((yysemantic_stack_[2])->getLine()); 
      ndoast->setType(TK_K_DO);
      ndoast->setText("do");
      ndoast->setFirstChild(iter);
      ndoast->setLine((yysemantic_stack_[2])->getLine());
      iter = iter->getNextSibling();
      ndoast->getFirstChild()->setNextSibling(stmt);
      doast->getFirstChild()->setNextSibling(nparast);
      doast = ndoast; 
    }
    (yyval)=(yysemantic_stack_[2]);
  ;}
    break;

  case 34:
#line 356 "YvetteParser.yy"
    {
   /* $1 -> iterators 
      $2 -> exclude 
      $3 -> do 
      $4 -> stmts 
    */
    
    /* Handle exclude list */ 
    Yml::Core::AST* stmt  = (yysemantic_stack_[1]);
    Yml::Core::AST* doast = 0;
    Yml::Core::AST* iter  = 0;
    if ((yysemantic_stack_[3]) != 0)
    {
      /* Create the if stmt arround $4 */
      Yml::Core::AST * tmp = (yysemantic_stack_[3]);
      Yml::Core::AST * thenast = 0;
      Yml::Core::AST * elseast = 0;
      Yml::Core::AST * left = 0;
      Yml::Core::AST * andast = 0;
      Yml::Core::AST * funcast = 0;
      stmt = driver.newASTNode();
      stmt->setType(TK_K_IF);
      stmt->setText("if");
      stmt->setLine((yysemantic_stack_[3])->getLine());
      stmt->setFirstChild(tmp);
      while (tmp->getNextSibling())
      {
        left = tmp;
        tmp = tmp->getNextSibling();
        left->setNextSibling(0);
        left = stmt->getFirstChild();
        funcast = driver.newASTNode();
        funcast->setType(TK_FUNC);
        funcast->setText("function");
        funcast->setLine(stmt->getLine());
        andast = driver.newASTNode();
        funcast->setFirstChild(driver.newASTNode());
        funcast->getFirstChild()->setText("");
        funcast->getFirstChild()->setType(TK_IDENTIFIER);
        funcast->getFirstChild()->setLine(stmt->getLine());
        funcast->getFirstChild()->setFirstChild(andast);
        andast->setType(TK_IDENTIFIER);
        andast->setText("operator_and");
        funcast->getFirstChild()->setNextSibling(left);
        left->setNextSibling(tmp);
        stmt->setFirstChild(funcast);
      }
      thenast = driver.newASTNode();
      thenast->setType(TK_K_IF_THEN);
      thenast->setText("then");
      thenast->setLine((yysemantic_stack_[3])->getLine());
      thenast->setFirstChild((yysemantic_stack_[1]));
      elseast = driver.newASTNode();
      elseast->setType(TK_K_IF_ELSE);
      elseast->setText("else");
      elseast->setLine((yysemantic_stack_[3])->getLine());
      thenast->setNextSibling(elseast);
      stmt->getFirstChild()->setNextSibling(thenast);
    }
    /* Handle Iterator list (at least one value) */
    doast = (yysemantic_stack_[2]);
    iter  = (yysemantic_stack_[4])->getNextSibling();
    (yysemantic_stack_[2])->setFirstChild((yysemantic_stack_[4]));
    (yysemantic_stack_[4])->setNextSibling(stmt);
    /* Du deuxieme au dernier faire */
    while (iter)
    {
      Yml::Core::AST* nparast = driver.newASTNode();
      Yml::Core::AST* ndoast = driver.newASTNode();

      nparast->setType(TK_K_SEQ);
      nparast->setText("seq");
      nparast->setFirstChild(ndoast);
      nparast->setLine((yysemantic_stack_[2])->getLine()); 
      ndoast->setType(TK_K_DO);
      ndoast->setText("do");
      ndoast->setFirstChild(iter);
      ndoast->setLine((yysemantic_stack_[2])->getLine());
      iter = iter->getNextSibling();
      ndoast->getFirstChild()->setNextSibling(stmt);
      doast->getFirstChild()->setNextSibling(nparast);
      doast = ndoast; 
    }
    (yyval)=(yysemantic_stack_[2]);
  ;}
    break;

  case 35:
#line 444 "YvetteParser.yy"
    { 
                                    (yyval)= driver.newASTNode(); 
                                    (yyval)->setType(TK_K_DO_COND_ITERATOR); 
                                    (yyval)->setText("iterator");   
                                    (yyval)->setLine((yysemantic_stack_[3])->getLine());
                                    (yyval)->setFirstChild((yysemantic_stack_[3]));
                                    (yysemantic_stack_[3])->setNextSibling((yysemantic_stack_[1])); 
                                 ;}
    break;

  case 36:
#line 454 "YvetteParser.yy"
    {(yyval)=(yysemantic_stack_[1]) ; (yysemantic_stack_[1])->setNextSibling((yysemantic_stack_[0]));;}
    break;

  case 37:
#line 457 "YvetteParser.yy"
    {(yyval) = 0; ;}
    break;

  case 38:
#line 459 "YvetteParser.yy"
    { (yyval)=(yysemantic_stack_[1]) ; (yysemantic_stack_[1])->setNextSibling((yysemantic_stack_[0])); ;}
    break;

  case 39:
#line 463 "YvetteParser.yy"
    {(yyval) = 0;;}
    break;

  case 40:
#line 465 "YvetteParser.yy"
    {(yysemantic_stack_[1])->setNextSibling((yysemantic_stack_[0])) ; (yyval)=(yysemantic_stack_[1]);;}
    break;

  case 41:
#line 469 "YvetteParser.yy"
    {(yyval) = 0;;}
    break;

  case 42:
#line 471 "YvetteParser.yy"
    {(yysemantic_stack_[1])->setNextSibling((yysemantic_stack_[0])) ; (yyval)=(yysemantic_stack_[1]);;}
    break;

  case 43:
#line 475 "YvetteParser.yy"
    { 
                    /* 
                    $$ = driver.newASTNode(); 
                    $$->setType(TK_K_DO_COND_EXCLUDE); 
                    $$->setLine($2->getLine());
                    $$->setText("exclude");
                    $$->setFirstChild($2);
                    */ 
                    (yyval) = (yysemantic_stack_[1]);
                  ;}
    break;

  case 44:
#line 488 "YvetteParser.yy"
    {(yysemantic_stack_[5])->setFirstChild((yysemantic_stack_[4])); 
                                                              (yysemantic_stack_[4])->setNextSibling((yysemantic_stack_[3])); 
                                                              (yysemantic_stack_[3])->setFirstChild((yysemantic_stack_[2]));
                                                              (yysemantic_stack_[3])->setNextSibling((yysemantic_stack_[1]));
                                                              (yyval) = (yysemantic_stack_[5]);
                                                              
                                                              ;}
    break;

  case 45:
#line 498 "YvetteParser.yy"
    {(yyval) = driver.newASTNode(); (yyval)->setType(TK_K_IF_ELSE); (yyval)->setText("else"); ;}
    break;

  case 46:
#line 500 "YvetteParser.yy"
    { (yysemantic_stack_[1])->setFirstChild((yysemantic_stack_[0])); (yyval)=(yysemantic_stack_[1]);;}
    break;

  case 47:
#line 505 "YvetteParser.yy"
    { (yyval)=(yysemantic_stack_[1]); (yysemantic_stack_[1])->setNextSibling((yysemantic_stack_[0]));;}
    break;

  case 48:
#line 508 "YvetteParser.yy"
    {(yyval)=0l;;}
    break;

  case 49:
#line 510 "YvetteParser.yy"
    { (yyval)=(yysemantic_stack_[1]); (yysemantic_stack_[1])->setNextSibling((yysemantic_stack_[0]));;}
    break;

  case 50:
#line 515 "YvetteParser.yy"
    {(yyval) = (yysemantic_stack_[1]); (yysemantic_stack_[1])->setFirstChild((yysemantic_stack_[0]));;}
    break;

  case 51:
#line 519 "YvetteParser.yy"
    {(yyval) = 0;;}
    break;

  case 52:
#line 521 "YvetteParser.yy"
    {(yysemantic_stack_[1])->setNextSibling((yysemantic_stack_[0])); (yyval) = (yysemantic_stack_[1]);;}
    break;

  case 53:
#line 525 "YvetteParser.yy"
    {(yyval)=0 ; ;}
    break;

  case 54:
#line 527 "YvetteParser.yy"
    {(yysemantic_stack_[1])->setNextSibling((yysemantic_stack_[0])); (yyval)=(yysemantic_stack_[1]);;}
    break;

  case 55:
#line 530 "YvetteParser.yy"
    {(yyval) = (yysemantic_stack_[1]);;}
    break;

  case 56:
#line 535 "YvetteParser.yy"
    { (yyval)=(yysemantic_stack_[1]) ; (yysemantic_stack_[1])->getFirstChild()->setNextSibling((yysemantic_stack_[2])) ; (yysemantic_stack_[2])->setNextSibling((yysemantic_stack_[0]));;}
    break;

  case 57:
#line 537 "YvetteParser.yy"
    { (yyval)=(yysemantic_stack_[1]) ; (yysemantic_stack_[1])->getFirstChild()->setNextSibling((yysemantic_stack_[2])) ; (yysemantic_stack_[2])->setNextSibling((yysemantic_stack_[0])); ;}
    break;

  case 58:
#line 539 "YvetteParser.yy"
    { (yyval)=(yysemantic_stack_[1]) ; (yysemantic_stack_[1])->getFirstChild()->setNextSibling((yysemantic_stack_[2])) ; (yysemantic_stack_[2])->setNextSibling((yysemantic_stack_[0])); ;}
    break;

  case 59:
#line 541 "YvetteParser.yy"
    {(yyval)=(yysemantic_stack_[0]);;}
    break;

  case 60:
#line 545 "YvetteParser.yy"
    { (yyval)=(yysemantic_stack_[1]) ; (yysemantic_stack_[1])->getFirstChild()->setNextSibling((yysemantic_stack_[2])) ; (yysemantic_stack_[2])->setNextSibling((yysemantic_stack_[0]));;}
    break;

  case 61:
#line 547 "YvetteParser.yy"
    { (yyval)=(yysemantic_stack_[1]) ; (yysemantic_stack_[1])->getFirstChild()->setNextSibling((yysemantic_stack_[2])) ; (yysemantic_stack_[2])->setNextSibling((yysemantic_stack_[0]));;}
    break;

  case 62:
#line 549 "YvetteParser.yy"
    {(yyval)=(yysemantic_stack_[0]);;}
    break;

  case 63:
#line 553 "YvetteParser.yy"
    { (yyval)=(yysemantic_stack_[1]) ; (yysemantic_stack_[1])->getFirstChild()->setNextSibling((yysemantic_stack_[2])) ; (yysemantic_stack_[2])->setNextSibling((yysemantic_stack_[0]));;}
    break;

  case 64:
#line 555 "YvetteParser.yy"
    { (yyval)=(yysemantic_stack_[1]) ; (yysemantic_stack_[1])->getFirstChild()->setNextSibling((yysemantic_stack_[2])) ; (yysemantic_stack_[2])->setNextSibling((yysemantic_stack_[0]));;}
    break;

  case 65:
#line 557 "YvetteParser.yy"
    { (yyval)=(yysemantic_stack_[1]) ; (yysemantic_stack_[1])->getFirstChild()->setNextSibling((yysemantic_stack_[2])) ; (yysemantic_stack_[2])->setNextSibling((yysemantic_stack_[0]));;}
    break;

  case 66:
#line 559 "YvetteParser.yy"
    { (yyval)=(yysemantic_stack_[1]) ; (yysemantic_stack_[1])->getFirstChild()->setNextSibling((yysemantic_stack_[2])) ; (yysemantic_stack_[2])->setNextSibling((yysemantic_stack_[0]));;}
    break;

  case 67:
#line 561 "YvetteParser.yy"
    {(yyval)=(yysemantic_stack_[0]);;}
    break;

  case 68:
#line 565 "YvetteParser.yy"
    { (yyval)=(yysemantic_stack_[1]) ; (yysemantic_stack_[1])->getFirstChild()->setNextSibling((yysemantic_stack_[2])) ; (yysemantic_stack_[2])->setNextSibling((yysemantic_stack_[0]));;}
    break;

  case 69:
#line 567 "YvetteParser.yy"
    { (yyval)=(yysemantic_stack_[1]) ; (yysemantic_stack_[1])->getFirstChild()->setNextSibling((yysemantic_stack_[2])) ; (yysemantic_stack_[2])->setNextSibling((yysemantic_stack_[0]));;}
    break;

  case 70:
#line 569 "YvetteParser.yy"
    {(yyval)=(yysemantic_stack_[0]);;}
    break;

  case 71:
#line 573 "YvetteParser.yy"
    {(yyval)=(yysemantic_stack_[1]) ; (yysemantic_stack_[1])->getFirstChild()->setNextSibling((yysemantic_stack_[2])); (yysemantic_stack_[2])->setNextSibling((yysemantic_stack_[0]));;}
    break;

  case 72:
#line 575 "YvetteParser.yy"
    {(yyval)=(yysemantic_stack_[1]) ; (yysemantic_stack_[1])->getFirstChild()->setNextSibling((yysemantic_stack_[2])); (yysemantic_stack_[2])->setNextSibling((yysemantic_stack_[0]));;}
    break;

  case 73:
#line 577 "YvetteParser.yy"
    {(yyval)=(yysemantic_stack_[1]) ; (yysemantic_stack_[1])->getFirstChild()->setNextSibling((yysemantic_stack_[2])); (yysemantic_stack_[2])->setNextSibling((yysemantic_stack_[0]));;}
    break;

  case 74:
#line 579 "YvetteParser.yy"
    {(yyval)=(yysemantic_stack_[0]);;}
    break;

  case 75:
#line 583 "YvetteParser.yy"
    {
                                     (yyval) = driver.newASTNode() ; 
                                     (yyval)->setType(TK_FUNC);
                                     (yyval)->setText("function");
                                     (yyval)->setLine((yysemantic_stack_[3])->getLine());
                                     (yyval)->setFirstChild(driver.newASTNode());
                                     (yyval)->getFirstChild()->setType(TK_IDENTIFIER);
                                     (yyval)->getFirstChild()->setText("");
                                     (yyval)->getFirstChild()->setLine((yysemantic_stack_[3])->getLine());
                                     (yyval)->getFirstChild()->setFirstChild((yysemantic_stack_[3]));
                                     (yyval)->getFirstChild()->setNextSibling((yysemantic_stack_[1]));
                                    ;}
    break;

  case 76:
#line 596 "YvetteParser.yy"
    {
                                                                (yyval) = driver.newASTNode();
                                                                (yyval)->setType(TK_FUNC);
                                                                (yyval)->setText("function");
                                                                (yyval)->setLine((yysemantic_stack_[5])->getLine());
                                                                (yyval)->setFirstChild((yysemantic_stack_[5]));
                                                                (yysemantic_stack_[5])->setFirstChild((yysemantic_stack_[3]));
                                                                (yysemantic_stack_[5])->setNextSibling((yysemantic_stack_[1]));
                                                               ;}
    break;

  case 77:
#line 606 "YvetteParser.yy"
    {(yyval)=(yysemantic_stack_[1]);;}
    break;

  case 78:
#line 608 "YvetteParser.yy"
    {(yyval)=(yysemantic_stack_[1]);(yysemantic_stack_[1])->getFirstChild()->setNextSibling((yysemantic_stack_[0]));;}
    break;

  case 79:
#line 610 "YvetteParser.yy"
    {(yyval)=(yysemantic_stack_[1]); (yysemantic_stack_[1])->getFirstChild()->setNextSibling((yysemantic_stack_[0]));;}
    break;

  case 80:
#line 612 "YvetteParser.yy"
    {(yyval)=(yysemantic_stack_[0]);;}
    break;

  case 81:
#line 614 "YvetteParser.yy"
    {(yyval)=(yysemantic_stack_[0]);;}
    break;

  case 82:
#line 616 "YvetteParser.yy"
    {(yyval)=(yysemantic_stack_[0]);;}
    break;

  case 83:
#line 618 "YvetteParser.yy"
    {(yyval) = (yysemantic_stack_[0]);;}
    break;

  case 84:
#line 622 "YvetteParser.yy"
    {(yyval)=0;;}
    break;

  case 85:
#line 624 "YvetteParser.yy"
    { (yyval)=(yysemantic_stack_[1]);(yysemantic_stack_[1])->setNextSibling((yysemantic_stack_[0]));;}
    break;

  case 86:
#line 628 "YvetteParser.yy"
    {(yyval)=0;;}
    break;

  case 87:
#line 630 "YvetteParser.yy"
    {(yyval)=(yysemantic_stack_[1]);(yysemantic_stack_[1])->setNextSibling((yysemantic_stack_[0]));;}
    break;


      default: break;
    }

/* Line 676 of lalr1.cc.  */
#line 1006 "YvetteParser.cc"

  yypop_ (yylen_);

  YY_STACK_PRINT ();

  yysemantic_stack_.push (yyval);
  yylocation_stack_.push (yyloc);

  /* Shift the result of the reduction.  */
  yyn_ = yyr1_[yyn_];
  yystate_ = yypgoto_[yyn_ - yyntokens_] + yystate_stack_[0];
  if (0 <= yystate_ && yystate_ <= yylast_
      && yycheck_[yystate_] == yystate_stack_[0])
    yystate_ = yytable_[yystate_];
  else
    yystate_ = yydefgoto_[yyn_ - yyntokens_];
  goto yynewstate;

/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus_)
    {
      ++yynerrs_;
      error (yylloc, yysyntax_error_ (YYERROR_VERBOSE_IF (yyilooka)));
    }

  yyerror_range[0] = yylloc;
  if (yyerrstatus_ == 3)
    {
      /* If just tried and failed to reuse look-ahead token after an
	 error, discard it.  */

      if (yylooka <= yyeof_)
        {
	  /* Return failure if at end of input.  */
	  if (yylooka == yyeof_)
	    YYABORT;
        }
      else
        {
          yydestruct_ ("Error: discarding", yyilooka, &yylval, &yylloc);
          yylooka = yyempty_;
        }
    }

  /* Else will try to reuse look-ahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (false)
    goto yyerrorlab;

  yyerror_range[0] = yylocation_stack_[yylen_ - 1];
  yypop_ (yylen_);
  yystate_ = yystate_stack_[0];
  goto yyerrlab1;

/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus_ = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn_ = yypact_[yystate_];
      if (yyn_ != yypact_ninf_)
	{
	  yyn_ += yyterror_;
	  if (0 <= yyn_ && yyn_ <= yylast_ && yycheck_[yyn_] == yyterror_)
	    {
	      yyn_ = yytable_[yyn_];
	      if (0 < yyn_)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yystate_stack_.height () == 1)
	YYABORT;

      yyerror_range[0] = yylocation_stack_[0];
      yydestruct_ ("Error: popping",
                   yystos_[yystate_],
                   &yysemantic_stack_[0], &yylocation_stack_[0]);
      yypop_ ();
      yystate_ = yystate_stack_[0];
      YY_STACK_PRINT ();
    }

  if (yyn_ == yyfinal_)
    goto yyacceptlab;

  yyerror_range[1] = yylloc;
  // Using YYLLOC is tempting, but would change the location of
  // the look-ahead.  YYLOC is available though.
  YYLLOC_DEFAULT (yyloc, yyerror_range - 1, 2);
  yysemantic_stack_.push (yylval);
  yylocation_stack_.push (yyloc);

  /* Shift the error token. */
  YY_SYMBOL_PRINT ("Shifting", yystos_[yyn_],
		   &yysemantic_stack_[0], &yylocation_stack_[0]);

  yystate_ = yyn_;
  goto yynewstate;

  /* Accept.  */
yyacceptlab:
  yyresult_ = 0;
  goto yyreturn;

  /* Abort.  */
yyabortlab:
  yyresult_ = 1;
  goto yyreturn;

yyreturn:
  if (yylooka != yyeof_ && yylooka != yyempty_)
    yydestruct_ ("Cleanup: discarding lookahead", yyilooka, &yylval, &yylloc);

  while (yystate_stack_.height () != 1)
    {
      yydestruct_ ("Cleanup: popping",
		   yystos_[yystate_stack_[0]],
		   &yysemantic_stack_[0],
		   &yylocation_stack_[0]);
      yypop_ ();
    }

  return yyresult_;
}

// Generate an error message.
std::string
yy::YvetteParser::yysyntax_error_ (YYERROR_VERBOSE_IF (int tok))
{
  std::string res;
#if YYERROR_VERBOSE
  yyn_ = yypact_[yystate_];
  if (yypact_ninf_ < yyn_ && yyn_ < yylast_)
    {
      /* Start YYX at -YYN if negative to avoid negative indexes in
         YYCHECK.  */
      int yyxbegin = yyn_ < 0 ? -yyn_ : 0;

      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = yylast_ - yyn_;
      int yyxend = yychecklim < yyntokens_ ? yychecklim : yyntokens_;
      int count = 0;
      for (int x = yyxbegin; x < yyxend; ++x)
        if (yycheck_[x + yyn_] == x && x != yyterror_)
          ++count;

      // FIXME: This method of building the message is not compatible
      // with internationalization.  It should work like yacc.c does it.
      // That is, first build a string that looks like this:
      // "syntax error, unexpected %s or %s or %s"
      // Then, invoke YY_ on this string.
      // Finally, use the string as a format to output
      // yytname_[tok], etc.
      // Until this gets fixed, this message appears in English only.
      res = "syntax error, unexpected ";
      res += yytnamerr_ (yytname_[tok]);
      if (count < 5)
        {
          count = 0;
          for (int x = yyxbegin; x < yyxend; ++x)
            if (yycheck_[x + yyn_] == x && x != yyterror_)
              {
                res += (!count++) ? ", expecting " : " or ";
                res += yytnamerr_ (yytname_[x]);
              }
        }
    }
  else
#endif
    res = YY_("syntax error");
  return res;
}


/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
const signed char yy::YvetteParser::yypact_ninf_ = -65;
const short int
yy::YvetteParser::yypact_[] =
{
     128,   -47,   -11,    14,    74,   -35,     9,   -31,   -25,    38,
     -65,   128,    47,   -65,   -65,   -65,   -65,   -65,   -65,   -65,
     -65,    36,     9,   -65,   -47,    19,    43,    78,    73,    89,
     -65,   -35,    83,   -65,    83,   -65,   -65,   -65,     9,     9,
      37,     9,   -65,   104,    13,   103,    45,   102,   -65,    78,
      44,   -65,   -65,   -65,     9,     6,   -65,     9,     9,    93,
     128,   -65,   -65,   -35,   -65,     9,   112,    83,   113,   -65,
     -65,   126,     9,    30,     9,     9,     9,   128,     9,     9,
       9,     9,     9,     9,     9,     9,     9,     9,     9,    99,
      26,    44,    34,   -65,   -65,   -65,    72,   -65,   105,    12,
     106,     9,    73,   -65,    25,   128,   -65,    83,   128,   109,
      20,   110,   -65,    13,    13,    13,   116,   103,   103,    45,
      45,    45,    45,   102,   102,   -65,   -65,   -65,    78,   111,
     -65,    56,    44,    44,    44,   -65,   -65,     9,   -65,   -65,
      68,   -65,   -65,   130,   -65,   131,     9,     9,   -65,   -65,
     128,   124,    99,   -65,   -65,   -65,   -65,   -65,    12,   -65,
     -65,   -65,   115,    20,   -65,   -65,   -65,   -65,   -65,   -65
};

/* YYDEFACT[S] -- default rule to reduce with in state S when YYTABLE
   doesn't specify something else to do.  Zero means the default is an
   error.  */
const unsigned char
yy::YvetteParser::yydefact_[] =
{
       3,    53,     0,     0,     3,     0,     0,     0,     0,     0,
       2,     3,     0,     6,     7,     8,     9,    10,    11,    12,
      13,     0,     0,    50,    53,     0,     0,     0,    31,     0,
      28,    37,    39,    29,    39,    80,    81,    82,     0,     0,
      53,     0,    83,     0,    59,    62,    67,    70,    74,     0,
       0,     1,     4,     5,     0,     0,    54,     0,     0,     0,
       3,    30,    27,    37,    36,     0,     0,    41,     0,    79,
      78,     0,    84,     0,     0,     0,     0,     3,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    51,
       0,     0,     0,    19,    21,    23,    14,    55,     0,    48,
       0,     0,    31,    38,     0,     3,    40,    41,     3,     0,
      86,     0,    77,    56,    57,    58,    45,    60,    61,    64,
      65,    63,    66,    68,    69,    71,    72,    73,     0,     0,
      20,     0,     0,     0,     0,    15,    25,     0,    47,    26,
       0,    32,    43,     0,    42,     0,    84,     0,    85,    75,
       3,     0,    51,    24,    22,    18,    16,    17,    48,    35,
      33,    34,     0,    86,    46,    44,    52,    49,    76,    87
};

/* YYPGOTO[NTERM-NUM].  */
const short int
yy::YvetteParser::yypgoto_[] =
{
     -65,   -65,    -2,   -65,   -65,   -65,   142,   -65,    79,    -7,
      81,   -65,   -65,   -65,   -65,   -65,    70,   -65,   -65,   -30,
     168,   114,   140,    69,   -64,   -65,   -65,   117,    21,     0,
      28,   154,   -65,    -1,    55,    -6,    57,     4,   -32,    35,
      22
};

/* YYDEFGOTO[NTERM-NUM].  */
const short int
yy::YvetteParser::yydefgoto_[] =
{
      -1,     9,    10,    11,    12,    13,    14,    15,    92,    93,
      94,    16,    17,    18,    19,    29,    61,    30,    33,    31,
      32,    64,    66,   106,    67,    20,   151,    98,   138,    42,
     129,    23,    24,    99,    44,    45,    46,    47,    48,   111,
     148
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.  */
const signed char yy::YvetteParser::yytable_ninf_ = -1;
const unsigned char
yy::YvetteParser::yytable_[] =
{
      21,    63,    28,   107,    21,    43,    69,    70,    22,    52,
      25,    21,    35,    36,    37,    27,    38,    74,    75,    49,
      76,    55,    39,    74,    75,    50,    76,    21,    78,    79,
      40,    74,    75,    63,    76,    26,    74,    75,    51,    76,
      73,    74,    75,   107,    76,   132,   133,     1,   134,    89,
      95,    84,    85,    96,   125,   126,   127,    90,   102,    41,
      21,    54,    97,    71,   104,     1,   137,   132,   133,    57,
     134,   110,   117,   118,   147,   116,    91,    21,   142,    74,
      75,   112,    76,    74,    75,   135,    76,    72,   123,   124,
      95,    95,    22,    58,    91,     1,    53,     2,     3,     1,
     140,     4,    60,   143,     5,    21,   145,   154,    21,     6,
      86,    87,    88,     7,     8,    74,    75,    62,    76,   159,
      80,    81,    82,    83,    27,   155,   156,   157,   152,   113,
     114,   115,    95,    95,    95,    65,   158,   119,   120,   121,
     122,    77,   101,   105,   108,   110,   163,   109,   164,     1,
      21,     2,     3,   128,   150,     4,   136,   139,     5,   146,
     165,   149,   153,     6,   160,   161,   168,     7,     8,    59,
     131,   130,   141,    34,    68,   100,   144,   103,    56,   167,
     166,   162,     0,     0,     0,   169
};

/* YYCHECK.  */
const short int
yy::YvetteParser::yycheck_[] =
{
       0,    31,     4,    67,     4,     6,    38,    39,    55,    11,
      21,    11,     3,     4,     5,    50,     7,    11,    12,    50,
      14,    22,    13,    11,    12,    50,    14,    27,    15,    16,
      21,    11,    12,    63,    14,    21,    11,    12,     0,    14,
      41,    11,    12,   107,    14,    11,    12,    21,    14,    49,
      50,     6,     7,    54,    86,    87,    88,    13,    60,    50,
      60,    25,    56,    26,    65,    21,    54,    11,    12,    50,
      14,    72,    78,    79,    54,    77,    50,    77,    53,    11,
      12,    51,    14,    11,    12,    51,    14,    50,    84,    85,
      90,    91,    55,    50,    50,    21,    49,    23,    24,    21,
     101,    27,    29,   105,    30,   105,   108,    51,   108,    35,
       8,     9,    10,    39,    40,    11,    12,    28,    14,    51,
      17,    18,    19,    20,    50,   132,   133,   134,   128,    74,
      75,    76,   132,   133,   134,    52,   137,    80,    81,    82,
      83,    37,    49,    31,    31,   146,   147,    21,   150,    21,
     150,    23,    24,    54,    38,    27,    51,    51,    30,    50,
      36,    51,    51,    35,    34,    34,    51,    39,    40,    27,
      91,    90,   102,     5,    34,    58,   107,    63,    24,   158,
     152,   146,    -1,    -1,    -1,   163
};

/* STOS_[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
const unsigned char
yy::YvetteParser::yystos_[] =
{
       0,    21,    23,    24,    27,    30,    35,    39,    40,    58,
      59,    60,    61,    62,    63,    64,    68,    69,    70,    71,
      82,    86,    55,    88,    89,    21,    21,    50,    59,    72,
      74,    76,    77,    75,    77,     3,     4,     5,     7,    13,
      21,    50,    86,    90,    91,    92,    93,    94,    95,    50,
      50,     0,    59,    49,    25,    90,    88,    50,    50,    63,
      29,    73,    28,    76,    78,    52,    79,    81,    79,    95,
      95,    26,    50,    90,    11,    12,    14,    37,    15,    16,
      17,    18,    19,    20,     6,     7,     8,     9,    10,    86,
      13,    50,    65,    66,    67,    86,    90,    56,    84,    90,
      84,    49,    59,    78,    90,    31,    80,    81,    31,    21,
      90,    96,    51,    91,    91,    91,    59,    92,    92,    93,
      93,    93,    93,    94,    94,    95,    95,    95,    54,    87,
      67,    65,    11,    12,    14,    51,    51,    54,    85,    51,
      90,    73,    53,    59,    80,    59,    50,    54,    97,    51,
      38,    83,    86,    51,    51,    66,    66,    66,    90,    51,
      34,    34,    96,    90,    59,    36,    87,    85,    51,    97
};

#if YYDEBUG
/* TOKEN_NUMBER_[YYLEX-NUM] -- Internal symbol number corresponding
   to YYLEX-NUM.  */
const unsigned short int
yy::YvetteParser::yytoken_number_[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,    59,
      40,    41,   123,   125,    44,    91,    93
};
#endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
const unsigned char
yy::YvetteParser::yyr1_[] =
{
       0,    57,    58,    59,    59,    60,    60,    61,    61,    61,
      61,    62,    62,    62,    63,    64,    65,    65,    65,    65,
      66,    66,    67,    67,    68,    69,    69,    70,    70,    71,
      72,    73,    73,    74,    75,    76,    77,    78,    78,    79,
      79,    80,    80,    81,    82,    83,    83,    84,    85,    85,
      86,    87,    87,    88,    88,    89,    90,    90,    90,    90,
      91,    91,    91,    92,    92,    92,    92,    92,    93,    93,
      93,    94,    94,    94,    94,    95,    95,    95,    95,    95,
      95,    95,    95,    95,    96,    96,    97,    97
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
const unsigned char
yy::YvetteParser::yyr2_[] =
{
       0,     2,     1,     0,     2,     2,     1,     1,     1,     1,
       1,     1,     1,     1,     3,     4,     3,     3,     3,     1,
       2,     1,     3,     1,     5,     5,     5,     3,     2,     2,
       2,     0,     3,     5,     5,     5,     2,     0,     2,     0,
       2,     0,     2,     3,     6,     0,     2,     2,     0,     3,
       2,     0,     3,     0,     2,     3,     3,     3,     3,     1,
       3,     3,     1,     3,     3,     3,     3,     1,     3,     3,
       1,     3,     3,     3,     1,     4,     6,     3,     2,     2,
       1,     1,     1,     1,     0,     2,     0,     3
};

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at \a yyntokens_, nonterminals. */
const char*
const yy::YvetteParser::yytname_[] =
{
  "\"end of file\"", "error", "$undefined", "\"integer\"", "\"real\"",
  "\"string\"", "\"operator add\"", "\"operator minus\"",
  "\"operator product\"", "\"operator division\"", "\"operator modulo\"",
  "\"boolean operator and\"", "\"boolean operator or\"",
  "\"boolean operator not\"", "\"boolean operator xor\"",
  "\"operator equals to\"", "\"operator not equals to\"",
  "\"operator lesser or equals to\"", "\"operator greater or equals to\"",
  "\"operator lesser than\"", "\"operator greater than\"",
  "\"identifier\"", "\"function\"", "\"Compute scheduling policy\"",
  "\"Migrate scheduling policy\"", "\":=\"", "\"Namespace\"", "\"par\"",
  "\"endpar\"", "\"//\"", "\"seq\"", "\"do\"", "\"(\"", "\"{\"",
  "\"enddo\"", "\"if\"", "\"endif\"", "\"then\"", "\"else\"", "\"notify\"",
  "\"wait\"", "\"event\"", "TK_K_EX_EXCEPTION", "TK_K_EX_TRY",
  "TK_K_EX_TRY_END", "TK_K_EX_CATCH", "TK_K_EX_CATCH_END",
  "TK_K_EX_FINALLY", "TK_K_EX_FINALLY_END", "';'", "'('", "')'", "'{'",
  "'}'", "','", "'['", "']'", "$accept", "start", "stmt_list", "stmt",
  "simple_stmt", "complex_stmt", "assign_stmt", "evt_wait_stmt",
  "evt_cond", "evt_cond_not", "evt_cond_single", "evt_notify_stmt",
  "call_stmt", "par_stmt", "seq_stmt", "par_block_list", "par_block_list2",
  "pardo_block", "seqdo_block", "do_cond_iterator",
  "do_cond_iterator_list", "do_cond_iterator_list2",
  "do_cond_exclude_list", "do_cond_exclude_list2", "do_cond_exclude",
  "if_stmt", "if_else", "param_list", "param_list2", "lvalue",
  "lvalue_list", "range_list", "range", "rvalue", "rvalue_equality",
  "rvalue_comp", "rvalue_add", "rvalue_mul", "rvalue_primary",
  "rvalue_list", "rvalue_list2", 0
};
#endif

#if YYDEBUG
/* YYRHS -- A `-1'-separated list of the rules' RHS. */
const yy::YvetteParser::rhs_number_type
yy::YvetteParser::yyrhs_[] =
{
      58,     0,    -1,    59,    -1,    -1,    60,    59,    -1,    61,
      49,    -1,    62,    -1,    63,    -1,    64,    -1,    68,    -1,
      69,    -1,    70,    -1,    71,    -1,    82,    -1,    86,    25,
      90,    -1,    40,    50,    65,    51,    -1,    65,    12,    66,
      -1,    65,    14,    66,    -1,    65,    11,    66,    -1,    66,
      -1,    13,    67,    -1,    67,    -1,    50,    65,    51,    -1,
      86,    -1,    39,    50,    86,    87,    51,    -1,    23,    21,
      50,    84,    51,    -1,    24,    21,    50,    84,    51,    -1,
      27,    72,    28,    -1,    27,    74,    -1,    30,    75,    -1,
      59,    73,    -1,    -1,    29,    59,    73,    -1,    77,    79,
      31,    59,    34,    -1,    77,    79,    31,    59,    34,    -1,
      50,    63,    49,    90,    51,    -1,    76,    78,    -1,    -1,
      76,    78,    -1,    -1,    81,    80,    -1,    -1,    81,    80,
      -1,    52,    90,    53,    -1,    35,    90,    37,    59,    83,
      36,    -1,    -1,    38,    59,    -1,    90,    85,    -1,    -1,
      54,    90,    85,    -1,    21,    88,    -1,    -1,    54,    86,
      87,    -1,    -1,    89,    88,    -1,    55,    90,    56,    -1,
      90,    11,    91,    -1,    90,    12,    91,    -1,    90,    14,
      91,    -1,    91,    -1,    91,    15,    92,    -1,    91,    16,
      92,    -1,    92,    -1,    92,    19,    93,    -1,    92,    17,
      93,    -1,    92,    18,    93,    -1,    92,    20,    93,    -1,
      93,    -1,    93,     6,    94,    -1,    93,     7,    94,    -1,
      94,    -1,    94,     8,    95,    -1,    94,     9,    95,    -1,
      94,    10,    95,    -1,    95,    -1,    21,    50,    96,    51,
      -1,    21,    26,    21,    50,    96,    51,    -1,    50,    90,
      51,    -1,    13,    95,    -1,     7,    95,    -1,     3,    -1,
       4,    -1,     5,    -1,    86,    -1,    -1,    90,    97,    -1,
      -1,    54,    90,    97,    -1
};

/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
const unsigned short int
yy::YvetteParser::yyprhs_[] =
{
       0,     0,     3,     5,     6,     9,    12,    14,    16,    18,
      20,    22,    24,    26,    28,    32,    37,    41,    45,    49,
      51,    54,    56,    60,    62,    68,    74,    80,    84,    87,
      90,    93,    94,    98,   104,   110,   116,   119,   120,   123,
     124,   127,   128,   131,   135,   142,   143,   146,   149,   150,
     154,   157,   158,   162,   163,   166,   170,   174,   178,   182,
     184,   188,   192,   194,   198,   202,   206,   210,   212,   216,
     220,   222,   226,   230,   234,   236,   241,   248,   252,   255,
     258,   260,   262,   264,   266,   267,   270,   271
};

/* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
const unsigned short int
yy::YvetteParser::yyrline_[] =
{
       0,   157,   157,   160,   162,   167,   169,   173,   175,   177,
     179,   183,   185,   187,   191,   195,   198,   200,   202,   204,
     208,   210,   214,   216,   221,   224,   226,   230,   232,   236,
     240,   248,   250,   261,   355,   444,   454,   457,   459,   463,
     465,   469,   471,   475,   488,   498,   500,   505,   508,   510,
     515,   519,   521,   525,   527,   530,   535,   537,   539,   541,
     545,   547,   549,   553,   555,   557,   559,   561,   565,   567,
     569,   573,   575,   577,   579,   583,   596,   606,   608,   610,
     612,   614,   616,   618,   622,   624,   628,   630
};

// Print the state stack on the debug stream.
void
yy::YvetteParser::yystack_print_ ()
{
  *yycdebug_ << "Stack now";
  for (state_stack_type::const_iterator i = yystate_stack_.begin ();
       i != yystate_stack_.end (); ++i)
    *yycdebug_ << ' ' << *i;
  *yycdebug_ << std::endl;
}

// Report on the debug stream that the rule \a yyrule is going to be reduced.
void
yy::YvetteParser::yyreduce_print_ (int yyrule)
{
  unsigned int yylno = yyrline_[yyrule];
  /* Print the symbols being reduced, and their result.  */
  *yycdebug_ << "Reducing stack by rule " << yyn_ - 1
             << " (line " << yylno << "), ";
  for (unsigned short int i = yyprhs_[yyn_];
       0 <= yyrhs_[i]; ++i)
    *yycdebug_ << yytname_[yyrhs_[i]] << ' ';
  *yycdebug_ << "-> " << yytname_[yyr1_[yyn_]] << std::endl;
}
#endif // YYDEBUG

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
yy::YvetteParser::token_number_type
yy::YvetteParser::yytranslate_ (int token)
{
  static
  const token_number_type
  translate_table[] =
  {
         0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
      50,    51,     2,     2,    54,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,    49,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    55,     2,    56,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    52,     2,    53,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48
  };
  if ((unsigned int) token <= yyuser_token_number_max_)
    return translate_table[token];
  else
    return yyundef_token_;
}

const int yy::YvetteParser::yyeof_ = 0;
const int yy::YvetteParser::yylast_ = 185;
const int yy::YvetteParser::yynnts_ = 41;
const int yy::YvetteParser::yyempty_ = -2;
const int yy::YvetteParser::yyfinal_ = 51;
const int yy::YvetteParser::yyterror_ = 1;
const int yy::YvetteParser::yyerrcode_ = 256;
const int yy::YvetteParser::yyntokens_ = 57;

const unsigned int yy::YvetteParser::yyuser_token_number_max_ = 303;
const yy::YvetteParser::token_number_type yy::YvetteParser::yyundef_token_ = 2;

#line 633 "YvetteParser.yy"

void yy::YvetteParser::error(const yy::YvetteParser::location_type& l, const std::string& m)
{
	driver.error(l, m);
}

