/* Automatically generated. */
#include "udns.hh"
namespace Util
{
  namespace UDNS
  {

const struct dns_nameval dns_typetab[] = {
 {0,0}};
const char *dns_typename(enum dns_type code) {
 static char nm[20];
 switch(code) {
 }
 return _dns_format_code(nm,"type",code);
}

const struct dns_nameval dns_classtab[] = {
 {0,0}};
const char *dns_classname(enum dns_class code) {
 static char nm[20];
 switch(code) {
 }
 return _dns_format_code(nm,"class",code);
}

const struct dns_nameval dns_rcodetab[] = {
 {0,0}};
const char *dns_rcodename(enum dns_rcode code) {
 static char nm[20];
 switch(code) {
 }
 return _dns_format_code(nm,"rcode",code);
}
}
}
