#include "udns.hh"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <errno.h>
namespace Util
{
  namespace UDNS
  {
static char* dns_parse_hosts_file(const char* hostname)
{
#define HOSTS_ETC_HOSTS_FILE "/etc/hosts" 
#define HOSTS_BUFFER_SIZE 8192
    char buffer[HOSTS_BUFFER_SIZE];
    FILE* fd = 0;
    fd = fopen(HOSTS_ETC_HOSTS_FILE, "r");
    if (fd == 0)
    {
        return 0;
    }
    while (fgets(buffer, HOSTS_BUFFER_SIZE, fd) == buffer)
    {
        char* token = 0;
        char* ip = 0;
        char* state = 0;
        token = strtok_r(buffer, " \t\n", &state);
        if (token == 0 || token[0] == '#')
            continue;
        ip = token;
#ifdef HAVE_DEUBG      
        printf("IP: <%s>\n", ip);
#endif 
        while(token)
        {
            token = strtok_r(NULL, " \t\n", &state);
            if (token == 0 || token[0] == '#')
                break;
#ifdef HAVE_DEBUG
            printf("\t-<%s>\n", token);
#endif 
            if (strcmp(token, hostname) == 0)
            {
                fclose(fd);
                return strdup(ip);
            }
        }
    }
    fclose(fd);
    return 0;        
#undef HOSTS_BUFFER_SIZE 
#undef HOSTS_ETC_HOSTS_FILE
}
// Store the value of the last request to udns_gethostbyname 
// Not thread safe at all 
static struct hostent hp_data = {0, 0, 0, 0, 0};
static struct hostent *hp = &hp_data; 

struct hostent *dns_gethostbyname (const char *name) {

  struct dns_ctx *my_context;
  struct dns_rr_a4 *result;
  //struct in_addr ip_address;
  struct in_addr addr;
  int ret;
  int name_size;
  int i;
  //char *addr_buff;
  char *ip;

  // Clean previous results 
  if (hp->h_name)
  {
    int i; 
    free(hp->h_name);
    for (i = 0; hp->h_aliases[i] ; ++i)
      free(hp->h_aliases[i]);
    free(hp->h_aliases);
    for (i = 0; hp->h_addr_list[i] ; ++i)
      free(hp->h_addr_list[i]);
    free(hp->h_addr_list);
    memset(hp, 0, sizeof(struct hostent));
  }
  else
  {
    memset(hp, 0, sizeof(struct hostent));
  }
  // check if name = IP address first 
  if (inet_aton(name, &addr) != 0){
    // name is an IP address
    // h_name
    hp->h_name = strdup(name);
    // h_aliases   
    hp->h_aliases = (char**)malloc((1)*sizeof(char*));
    hp->h_aliases[0] = NULL;
    // address type
    hp->h_addrtype = AF_INET;
    // address length
    hp->h_length = sizeof(struct in_addr);
    // address list
    hp->h_addr_list = (char**)malloc((2)*sizeof(char*));
    (hp->h_addr_list)[0] = (char*)malloc(hp->h_length);
    inet_aton(name, &addr);
    memcpy((hp->h_addr_list)[0], &addr.s_addr, hp->h_length); 
    (hp->h_addr_list)[1] = NULL; 
    return hp;    
  }
  // Look in /etc/hosts second 
  ip = dns_parse_hosts_file(name);
  if (ip)
  {
    hp->h_name = strdup(name);
    hp->h_aliases = (char**)malloc((1)*sizeof(char*));
    hp->h_aliases[0] = NULL;
    hp->h_addrtype = AF_INET;
    hp->h_length = sizeof(struct in_addr);    
    hp->h_addr_list = (char**)malloc((2)*sizeof(char*)); 
    (hp->h_addr_list)[0] = (char*)malloc(hp->h_length);
    inet_aton(ip, &addr);
    memcpy((hp->h_addr_list)[0], &addr.s_addr, hp->h_length); 
    (hp->h_addr_list)[1] = NULL;   
    free(ip);
    return hp;
  }
  // Check DNS server third 
  // init the default context
  dns_init(0); 

  // copy the default context
  my_context = dns_new(NULL);
  if (my_context == NULL){
    errno = dns_status(my_context);
    return NULL;
  }
    
  // open the context ie. open an UDP socket for requests
  ret = dns_open(my_context);
  if (ret < 0){
    errno = dns_status(my_context);
    return NULL;
  }
  //fprintf(stdout,"Value of socket descriptor  = %d\n", ret);

  ret = dns_active(my_context);
  //fprintf(stdout,"Number of requests inqueued = %d\n", ret);

  // synchronous query: name -> IPv4 address
  result = dns_resolve_a4(my_context, name, 0);  
  if (result == NULL){
    errno = dns_status(my_context);
    return NULL;
  }else{
    //fprintf(stdout,"dns_resolve_a4 is OK\n");
  }
 
  
  // we fill each field of struc hostent

  // first: h_name and h_aliases&

  // we found a canonical name
  if (result->dnsa4_cname != NULL){
    // h_name
    hp->h_name = strdup(result->dnsa4_cname);
    
    // h_aliases
    // we check that qname is not null
    if ( result->dnsa4_qname != NULL){

      if (strcmp(result->dnsa4_cname, result->dnsa4_qname) != 0){
	// One alias (the original name isn't the the canonical one)
	name_size = strlen(result->dnsa4_qname);
	hp->h_aliases = (char**)malloc((2)*sizeof(char*));
	hp->h_aliases[0] = strdup(result->dnsa4_qname);
	hp->h_aliases[1] = NULL;
      }else{
	// no alias because the query name was the canonical name
	hp->h_aliases = (char**)malloc((1)*sizeof(char*));
	hp->h_aliases[0] = NULL;
      }
    }else{
      // no alias
      hp->h_aliases = (char**)malloc((1)*sizeof(char*));
      hp->h_aliases[0] = NULL;
    }
  }else{
    // we didn't find a canonical name
    
    // we check that qname is not null
    if ( result->dnsa4_qname != NULL){
      hp->h_name = strdup(result->dnsa4_qname);
      // no alias because no canonical name
      hp->h_aliases = (char**)malloc((1)*sizeof(char*));
      hp->h_aliases[0] = NULL;
    }else{
      // it should never happen!
      hp->h_name = NULL;
      hp->h_aliases = (char**)malloc((1)*sizeof(char*));
      hp->h_aliases[0] = NULL;
    }
  }

  // address type
  hp->h_addrtype = AF_INET;

  hp->h_length = sizeof(struct in_addr);



 // addresses list
  hp->h_addr_list = (char**)malloc((result->dnsa4_nrr + 1)*sizeof(char*));
  for (i=0; i<result->dnsa4_nrr;i++){
    (hp->h_addr_list)[i] = (char*)malloc(hp->h_length);
    memcpy((hp->h_addr_list)[i], &(result->dnsa4_addr)[i], hp->h_length);         
    // without explicit cast: warning: passing arg 1 of `strdup' makes pointer from integer without a cast   
  }
  (hp->h_addr_list)[result->dnsa4_nrr] = NULL; 
  free(result);
  // close the socket
  dns_close(my_context);
  // free the context
  dns_free(my_context);
  return hp;
}
}
}
