/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @file
 * @brief Class StringHelper test file 
 *  
 *
 * 
 * 
 * - Supports: All 
 * - Created: 2006-04-01
 * - Creator: Olivier Delannoy
 * - $Revision $
 * - Changelog: 
 *    
 *    * 2006-04-01 : Initial version  
 ******************************************************************************
@LICENSE@
 *******************************************************************************/
#include "StringHelper.hh"
#include <cstdlib> 
#include <iostream>
int main(int argc, char** argv)
{
    Util::String source("   \t \t \tmot1    mot2\t\nmot3   \nmot4     \n\n\n\n");
    std::cout << "Initial string: [" << source << "]" << std::endl;
    std::cout << "Simplify White Space: [" << Util::StringHelper::simplifyWhiteSpace(source) << "]" << std::endl;
    std::cout << "Left Trim: [" << Util::StringHelper::ltrim(source) << "]" << std::endl;
    std::cout << "Right Trim: [" << Util::StringHelper::rtrim(source) << "]" << std::endl;
    std::cout << "Trim: [" << Util::StringHelper::trim(source) << "]" << std::endl;
    Util::String source2("");
    std::cout << "Initial string: [" << source2 << "]" << std::endl;
    std::cout << "Simplify White Space: [" << Util::StringHelper::simplifyWhiteSpace(source2) << "]" << std::endl;
    std::cout << "Left Trim: [" << Util::StringHelper::ltrim(source2) << "]" << std::endl;
    std::cout << "Right Trim: [" << Util::StringHelper::rtrim(source2) << "]" << std::endl;
    std::cout << "Trim: [" << Util::StringHelper::trim(source2) << "]" << std::endl;
    Util::String source3("mot1 mot2");
    std::cout << "Initial string: [" << source3 << "]" << std::endl;
    std::cout << "Simplify White Space: [" << Util::StringHelper::simplifyWhiteSpace(source3) << "]" << std::endl;
    std::cout << "Left Trim: [" << Util::StringHelper::ltrim(source3) << "]" << std::endl;
    std::cout << "Right Trim: [" << Util::StringHelper::rtrim(source3) << "]" << std::endl;
    std::cout << "Trim: [" << Util::StringHelper::trim(source3) << "]" << std::endl;
    Util::String source4("\n\n\n");
        std::cout << "Initial string: [" << source4 << "]" << std::endl;
    std::cout << "Simplify White Space: [" << Util::StringHelper::simplifyWhiteSpace(source4) << "]" << std::endl;
    std::cout << "Left Trim: [" << Util::StringHelper::ltrim(source4) << "]" << std::endl;
    std::cout << "Right Trim: [" << Util::StringHelper::rtrim(source4) << "]" << std::endl;
    std::cout << "Trim: [" << Util::StringHelper::trim(source4) << "]" << std::endl;
    return EXIT_SUCCESS;
    
}
/*******************************************************************************/
