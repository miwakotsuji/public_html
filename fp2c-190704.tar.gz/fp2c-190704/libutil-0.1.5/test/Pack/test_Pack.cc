/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @file
 * @brief Class test_Pack definitions 
 *  
 *
 * 
 * 
 * - Supports: All 
 * - Created: 2005-10-04
 * - Creator: Olivier Delannoy
 * - $Revision $
 * - Changelog: 
 *    
 *    * 2005-10-04 : Initial version  
 ******************************************************************************
@LICENSE@
 *******************************************************************************/
#include "Pack.hh"
#include "Exception.hh" 
#include "File.hh" 
#include "Dir.hh" 
#include "ByteArray.hh" 
#include <iostream> 
#include <fstream> 

int main(void)
{
    Util::File::remove("test.arc1");
    Util::File::remove("vide.arc1");
    Util::File::remove("test.dat");
    Util::File::remove("const_8");
    Util::Dir::rmdir("test");
    Util::Pack pack("test.arc1");
    Util::PackIndex* index0 = pack.createIndex();
    std::cout << "Pack index: " << std::endl;
    for (size_t i = 0 ; i < index0->size() ; ++i)
    {
        std::cout << i << ": " << (*index0)[i].d_name << ", " << (*index0)[i].d_size << ", " << (*index0)[i].d_offset << std::endl;
    }
    pack.destroyIndex(index0);

    pack.add("const_8", (Util::byte*)"huit", 4);
    pack.add("test_pack.cc", "test_Pack.cc");
    pack.add("const_8", (Util::byte*)"8", 1);

    // Create a huge file 
    std::ofstream out("test.dat");
    for (int i = 0; i < 100000000 ; ++i)
    {
        out << "abcdefgh";
    }
    out.close();
    pack.add("test.dat", "test.dat");

    Util::PackIndex* index = pack.createIndex();
    std::cout << "Pack index: " << std::endl;
    for (size_t i = 0 ; i < index->size() ; ++i)
    {
        std::cout << i << ": " << (*index)[i].d_name << ", " << (*index)[i].d_size << ", " << (*index)[i].d_offset << std::endl;
    }
    pack.destroyIndex(index);
    // Extract single entries to file and memory 
    Util::ByteArray array(0);
    pack.extract("const_8", array);
    std::cout << "Extract const_8 in memory: Size is " << array.size() << std::endl;
    pack.extract("const_8", "const_8");
    std::cout << "Extract const_8 to a file: const_8" << std::endl;

    pack.extract("test_pack.cc", array);
    std::cout << "Extract test_pack.cc in memory: Size is " << array.size() << std::endl;
    std::cout << "File snippet: " << std::endl;
    for (int i = 0 ; i < 100 ; ++i)
    {
      std::cout << array.data()[i];
    }
    std::cout << std::endl;
    pack.extractAll("test");
    Util::Pack pack2("vide.arc1");
    return 0;
}
/*******************************************************************************/
