/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @file
 * @brief Class Logger Test 
 *  
 *
 * 
 * 
 * - Supports: All 
 * - Created: 2005-08-14
 * - Creator: Olivier Delannoy
 * - $Revision $
 * - Changelog: 
 *    
 *    * 2005-08-14 : Initial version  
 ******************************************************************************
@LICENSE@
 *******************************************************************************/
#include "Logger.hh"
#include <iostream>
#include <cstdlib>
int main(int argc, char** argv)
{
    try 
    {
        
        Util::Logger log;
        std::cout << "Log" << std::endl;
    


        log.init("test.log",  Util::UTIL_WARN);
        std::cout << "Init" << std::endl;
        
        UTIL_LOG(&log, Util::UTIL_DEBUG, "toto");
        UTIL_LOG(&log, Util::UTIL_INFO, "toto");
        UTIL_LOG(&log, Util::UTIL_WARN, "toto");
        UTIL_LOG(&log, Util::UTIL_ERROR, "toto");
        //UTIL_LOG(&log, Util::UTIL_FATAL, "toto");
        std::cout << "Test caching features" << std::endl;
        Util::Logger log2;
        std::cout << "test cache" << std::endl;
        UTIL_LOG(&log2, Util::UTIL_INFO, "test cache");
        std::cout << "test cache2" << std::endl;
        UTIL_LOG(&log2, Util::UTIL_DEBUG, "test cache 2");
        std::cout << "test cache3" << std::endl;
        UTIL_LOG(&log2, Util::UTIL_ERROR, "test cache 3");
        std::cout << "Init logger" << std::endl;
        log2.init(&std::cerr);
    }
    catch(Util::Exception e)
    {
        std::cout << "Exception: " <<  e.what() << std::endl;
    }
}

/*******************************************************************************/
