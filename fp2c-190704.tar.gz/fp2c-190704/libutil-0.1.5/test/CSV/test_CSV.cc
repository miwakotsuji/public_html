/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @file
 * @brief Class test_CSV definitions 
 *  
 *
 * 
 * 
 * - Supports: All 
 * - Created: 2006-03-03
 * - Creator: Olivier Delannoy
 * - $Revision $
 * - Changelog: 
 *    
 *    * 2005-03-03 : Initial version  
 ******************************************************************************
@LICENSE@
 *******************************************************************************/
#include "CSVParser.hh"
#include "CSVHandler.hh" 
#include "CSVSerializer.hh"
#include "Dir.hh"
#include "DirHandler.hh" 
#include "RuntimeEnvironment.hh" 
#include <iostream>
#include <cstdlib> 
#include <fstream>

class CSV2HTML : public Util::CSVHandler
{
public:
    CSV2HTML(const Util::String& filename)
    {
        std::cout << "<html>" << std::endl;
        std::cout << "<body>" << std::endl;
        std::cout << "<h1>" << filename << "</h1>" << std::endl;
        std::cout << "<table>" << std::endl;
    }
    ~CSV2HTML()
    {
        std::cout << "</table>" << std::endl;
        std::cout << "</body>" << std::endl;
        std::cout << "</html>" << std::endl;
        std::cout << std::endl << std::endl;
    }
    void rowStart(void)
    {
        std::cout << "<tr>" << std::endl;
    }
    void rowEnd(void)
    {
        std::cout << "</tr>" << std::endl;
    }
    void cell(const Util::String& text)
    {
        std::cout << "<td>" << text << "</td>" << std::endl;
    }
};

class CSV_dirHandler : public Util::DirHandler
{
  void onFile(const Util::String& parentPath, const Util::String& entryName)
  {
    if (entryName.substr(entryName.size() - 3) == "csv")
    {
        CSV2HTML handler(entryName);
        Util::CSVParser parser;
        parser.parse(handler, entryName, ',');
    }
  }
};


int main(int argc, char** argv)
{ 
    std::ofstream out("serialized.csv");
    Util::CSVSerializer csv(out, ',');
    csv.cell("1")
        .cell("2")
        .cell("3")
        .cell("4")
        .newRow()
        .cell(",")
        .cell("\"")
        .cell("c'est la fete, \"\"")
        .cell(",,,,,,")
        .newRow()
        .cell("1")
        .cell("2")
        .cell("3")
        .cell("4");
    out.close();
    CSV_dirHandler handler;
    Util::Dir::visit(handler, Util::RuntimeEnvironment::workingDir(), false);
    return EXIT_SUCCESS;
}



/*******************************************************************************/
