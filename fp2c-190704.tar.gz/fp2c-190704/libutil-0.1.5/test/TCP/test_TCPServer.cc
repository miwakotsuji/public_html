/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @file
 * @brief Test program: test_TCPServer definitions 
 *  
 *
 * 
 * 
 * - Supports: All 
 * - Created: 2006-02-10
 * - Creator: Olivier Delannoy
 * - $Revision $
 * - Changelog: 
 *    
 *    * 2006-02-10 : Initial version  
 ******************************************************************************
@LICENSE@
 *******************************************************************************/
#include <iostream>
#include <string>
#include <TCPServer.hh>
#include <TCPRemoteClient.hh> 
#include <cstdlib>
int main(int argc, char** argv)
{
    Util::TCPServer server(5000);
    Util::TCPRemoteClient* client = server.accept();
    Util::byte buffer[100];
    Util::int32 status;
    
    status = client->recv(buffer, 100);
    std::cout << "Readed: " << status << std::endl;
    client->send(buffer, 100);
    delete client;
    return EXIT_SUCCESS;
}


/*******************************************************************************/
