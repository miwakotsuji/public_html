/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @file
 * @brief Class test_TCPClient definitions 
 *  
 *
 * 
 * 
 * - Supports: All 
 * - Created: 2006-02-10
 * - Creator: Olivier Delannoy
 * - $Revision $
 * - Changelog: 
 *    
 *    * 2006-02-10 : Initial version  
 ******************************************************************************
@LICENSE@
 *******************************************************************************/
#include <cstdlib>
#include <iostream>
#include <string> 
#include <cstring> 
#include <TCPClient.hh>
int main(int argc, char** argv)
{
    Util::TCPClient client(argv[1], 5000);
    if (client.isOk())
    {
        std::cout << "Send: " << "Coucou" << std::endl;
        client.send((Util::byte*)"Coucou", strlen("Coucou") + 1);
        client.shutdown(false, true);
        Util::byte buffer[100];
        client.recv(buffer, 100);
        std::cout << "Recv: " << buffer << std::endl;
        return EXIT_SUCCESS;
    }
    return EXIT_FAILURE;
}

/*******************************************************************************/
