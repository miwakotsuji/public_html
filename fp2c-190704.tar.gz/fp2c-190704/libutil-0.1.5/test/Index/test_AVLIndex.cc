/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @file
 * @brief Class Logger Test 
 *  
 *
 * 
 * 
 * - Supports: All 
 * - Created: 2005-08-14
 * - Creator: Olivier Delannoy
 * - $Revision $
 * - Changelog: 
 *    
 *    * 2005-08-14 : Initial version  
 ******************************************************************************
@LICENSE@
 *******************************************************************************/
#include "AVLIndex.hh"
#include <iostream>
#include <fstream> 
#include <cstdlib>
#include <sstream>
struct ExampleKey;
struct ExampleValue;

struct ExampleKey
{
    Util::uint32 value;
    static int compare(const ExampleKey& obj1, const ExampleKey& obj2)
    {
        if (obj1.value < obj2.value)
            return -1;
        else if (obj1.value == obj2.value)
            return 0;
        else 
            return 1;
    }
};
struct ExampleValue 
{
    Util::uint32 value;  
    static const ExampleValue nil;
}; 
   

const ExampleValue ExampleValue::nil = {0};
const ExampleValue values[] = 
{
    {30}, {63}, {71}, {60}, {89}, {33}, {58}, {19}, {78}, {15}, {10}
};
const ExampleKey keys[] = 
{
    {30}, {63}, {71}, {60}, {89}, {33}, {58}, {19}, {78}, {15}, {10}
};
const int count = 11; 
  
int main(int argc, char** argv)
{ 
    Util::AVLIndex<ExampleKey, ExampleValue> index(10);
    int i;
    for(i = 0 ; i < count ; ++i)
    {
        index.insert(keys[i], values[i]);
        index.dump(std::cout);

        std::ostringstream name;
        
        name << Util::String("graph-") << std::setw(3) << std::setfill('0') << i + 1 << Util::String(".dot");
        std::ofstream out(name.str().c_str());
        index.dumpDot(out);    
        out.close(); 
    }
    
    return EXIT_SUCCESS;
}
 
/*******************************************************************************/
