/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @file
 * @brief Application Framework test 
 *  
 *
 * 
 * 
 * - Supports: All 
 * - Created: 2005-08-14
 * - Creator: Olivier Delannoy
 * - $Revision $
 * - Changelog: 
 *    
 *    * 2005-08-14 : Initial version  
 ******************************************************************************
@LICENSE@
 *******************************************************************************/
#include "Application.hh"
#include "ConsoleApplicationAdaptor.hh"
#include "LoggerFactory.hh"
class TestApplication : public Util::Application
{
    
public:
    TestApplication(Util::ApplicationAdaptor* adaptor, int argc, char** argv)
        : Util::Application(adaptor, argc, argv)
    {
    }
    virtual ~TestApplication(void) 
    {
    }
    
    
    
protected:
    virtual Util::uint32 run(void)
    {
        out() << "Start" << std::endl;
        UTIL_INFO("default", "Start");
        UTIL_INFO("default", "Stop");
        
        out() << "Stop" << std::endl;
        
    }
private:
};




UTIL_APPLICATION(TestApplication, Util::ConsoleApplicationAdaptor)
/*******************************************************************************/
