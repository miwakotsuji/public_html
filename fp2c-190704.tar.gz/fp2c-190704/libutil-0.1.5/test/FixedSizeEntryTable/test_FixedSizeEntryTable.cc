/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @file
* @brief Class FixedSizeEntryTable Test 
*  
*
* 
* 
* - Supports: All 
* - Created: 2005-08-14
* - Creator: Olivier Delannoy
* - $Revision $
* - Changelog: 
*    
*    * 2005-08-14 : Initial version  
******************************************************************************
@LICENSE@
*******************************************************************************/
#include "FixedSizeEntryTable.hh"
#include "LittleEndianStream.hh"
#include <iostream>
#include <cstdlib>
#include <algorithm> 
struct Test 
{
    Util::uint32 a;
    Util::uint32 b;
    Util::uint32 c;
    void write(Util::LittleEndianStream& stream)
    {
        stream.write(a);
        stream.write(b);
        stream.write(c);
    }
    void read(Util::LittleEndianStream& stream) 
    {
        stream.read(a);
        stream.read(b);
        stream.read(c);
    }
    bool operator==(const Test& src) const
    {
        return a == src.a &&
            b == src.b &&
            c == src.c;
    }
    static const Util::uint32 SIZE = sizeof(Util::uint32) + sizeof(Util::uint32) + sizeof(Util::uint32);
}; 
int main(int argc, char** argv)
{
    Test tmp;
    std::cout << "Before creating table" << std::endl;
									
    Util::FixedSizeEntryTable<Test> table("test.ft1");
    std::cout << "After creating table" << std::endl;
    if (! table.open())
        {
            std::cout << "Failed opening table" << std::endl;
            exit(1);
        }
    std::cout << "After opening table" << std::endl;
    for(int i = 0 ;  i < 3 ; ++i)
        for(int j = 0 ; j < 3 ; ++j)
            for(int k = 0 ; k < 3 ; ++k)
                {
                    tmp.a = i; 
                    tmp.b = j;
                    tmp.c = k;
                    table.insertEntry(tmp);
                }
    table.printStats(std::cout);
    tmp.a = 1;
    tmp.b = 1;
    tmp.c = 1;
    
    Util::FixedSizeEntryTable<Test>::iterator fiter = std::find(table.begin(), table.end(), tmp);
    if (fiter != table.end())
    {
        std::cout << "tmp found at index: " << fiter.index() << std::endl;
        fiter = std::find(++fiter, table.end(), tmp);
        if (fiter != table.end())
        {
            std::cout << "tmp found again at index: " << fiter.index() << std::endl;
        }
    }
    else 
        std::cout << "tmp not found" << std::endl;
    tmp.a = 5;
    fiter = std::find(table.begin(), table.end(), tmp);
    if (fiter != table.end())
        std::cout << "tmp found at index: " << fiter.index()  << std::endl;
    else 
        std::cout << "tmp not found" << std::endl;
    
    

    Util::FixedSizeEntryTable<Test>::iterator iter = table.begin();
    int i;
    for(i = 1 ; table.end() != iter ; ++iter, ++i)
    {
        std::cout << i << ": " << (*iter).a << ':' << (*iter).b << ':' << (*iter).c << std::endl;
    }
    Util::FixedSizeEntryTable<Test>::reverse_iterator riter = table.rbegin();
    i = table.lastIndex();
    for (; riter != table.rend() ; ++riter, --i)
    {
            std::cout << i << ": " << (*riter).a << ':' << (*riter).b << ':' << (*riter).c << std::endl;
    }
    
    return EXIT_SUCCESS;
} 
/*******************************************************************************/
