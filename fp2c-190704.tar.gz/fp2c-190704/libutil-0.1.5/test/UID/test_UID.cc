/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @file
 * @brief Class test_Pack definitions 
 *  
 *
 * 
 * 
 * - Supports: All 
 * - Created: 2005-10-04
 * - Creator: Olivier Delannoy
 * - $Revision $
 * - Changelog: 
 *    
 *    * 2005-10-04 : Initial version  
 ******************************************************************************
@LICENSE@
 *******************************************************************************/
#include "UID.hh"
#include "MD5.hh" 
#include <iostream>
int main(void)
{
    std::cout << Util::UID::createUID() << std::endl;
    std::cout << Util::UID::createUID() << std::endl;
    Util::byte buffer[16];
    Util::UID::createUID(buffer);
    std::cout << Util::MD5::MD5ToString(buffer) << std::endl;
    Util::UID::createUID(buffer);
    std::cout << Util::MD5::MD5ToString(buffer) << std::endl;
    return 0;
}
/*******************************************************************************/
