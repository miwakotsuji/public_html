/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @file
 * @brief Class test_Rename definitions 
 *  
 *
 * 
 * 
 * - Supports: All 
 * - Created: 2005-10-27
 * - Creator: Olivier Delannoy
 * - $Revision $
 * - Changelog: 
 *    
 *    * 2005-10-27 : Initial version  
 ******************************************************************************
@LICENSE@
 *******************************************************************************/
#include "File.hh"
int main(int argc, char** argv)
{
    if (argc != 3)
        return -1;
    UTIL_DEBUGUTIL(argv[0]);
    UTIL_DEBUGUTIL(argv[1]);
    UTIL_DEBUGUTIL(argv[2]);
    Util::File::rename(argv[2], argv[1]);
    return 0;
}
/*******************************************************************************/
