/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @file
 * @brief Class test_Process definitions 
 *  
 *
 * 
 * 
 * - Supports: All 
 * - Created: 2005-08-28
 * - Creator: Olivier Delannoy
 * - $Revision $
 * - Changelog: 
 *    
 *    * 2005-08-28 : Initial version  
 ******************************************************************************
@LICENSE@
 *******************************************************************************/
#include "Process.hh"
#include "RuntimeEnvironment.hh" 
#include <unistd.h> 
#include <iostream>

int main(void)
{
    Util::Process p;
    Util::StringList stringList;
    stringList << "-a" << "-u" << "-x"; 
    std::cout << "Spawing a new process: " << std::endl;
    p.start("/usr/bin/ps", stringList);
    std::cout << "Waiting for terminaison: " << std::endl;
    p.wait();
    std::cout << "test_Process exit" << std::endl;
    Util::Process p1;
    std::cout << "Spawning a new process: " << std::endl;
    p1.start("/usr/bin/ls", Util::StringList() << "-als", "..");
    p1.wait();
    std::cout << "pwd: " << Util::RuntimeEnvironment::workingDir() << std::endl;
    std::cout << "Spawning sleep: " << std::endl;
    Util::Process p2;
    p2.start("/usr/bin/sleep", Util::StringList() << "10");
    std::cout << "Process state: " << p2.state() << std::endl;
    while(p2.state() != Util::PROCESS_FINISHED)
    {
     
      std::cout << "sleep not yet finished" << std::endl;
      sleep(1);
    }
    std::cout << "Fin" << std::endl;
}


/*******************************************************************************/
