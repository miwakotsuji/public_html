/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @file
 * @brief Class test_ConfigXCF definitions 
 *  
 *
 * 
 * 
 * - Supports: All 
 * - Created: 2005-08-11
 * - Creator: Olivier Delannoy
 * - $Revision $
 * - Changelog: 
 *    
 *    * 2005-08-11 : Initial version  
 ******************************************************************************
@LICENSE@
 *******************************************************************************/
#include "ConfigXCF.hh"
#include "XMLParserFactory.hh"
#include <iostream> 



int main(int argc, char** argv)
{
    new Util::XMLParserFactory;
    Util::ConfigXCF config;
    std::cerr << "Loading test.xcf" << std::endl;
    config.load("test.xcf");
    std::cerr << config << std::endl;
    config.save("test2.xcf");
    Util::ConfigXCF config2;
    std::cerr << "Loading test2.xcf" << std::endl;
    config2.load("test2.xcf");
    std::cerr << config2 << std::endl;

    delete Util::XMLParserFactory::getSingletonPtr();
    return 0;
}


/*******************************************************************************/
