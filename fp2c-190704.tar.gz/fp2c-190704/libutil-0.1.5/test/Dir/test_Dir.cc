/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @file
 * @brief Class test_Dir definitions 
 *  
 *
 * 
 * 
 * - Supports: All 
 * - Created: 2005-09-13
 * - Creator: Olivier Delannoy
 * - $Revision $
 * - Changelog: 
 *    
 *    * 2005-09-13 : Initial version  
 ******************************************************************************
@LICENSE@
 *******************************************************************************/
#include "Dir.hh"
#include "RuntimeEnvironment.hh"
#include <iostream>

class MyDirHandler : public Util::DirHandler
{
public:
    void onFile(const Util::String& dirName, const Util::String& entryName)
    {
      std::cout << "FILE:       " << dirName << entryName << std::endl;
    }
    void onEnterDir(const Util::String& dirName, const Util::String& entryName)
    {
      std::cout << "ENTER DIR:  " << dirName << entryName << Util::RuntimeEnvironment::PATH_SEPARATOR << std::endl;
    }
    void onExitDir(const Util::String& dirName, const Util::String& entryName)
    {
      std::cout << "EXIT DIR:   " << dirName << entryName << Util::RuntimeEnvironment::PATH_SEPARATOR << std::endl;
    }
};



int main()
{
    Util::Dir::mkdir("toto/titi", true);
    Util::Dir::mkdir("toto/toto", true);
    Util::Dir::rmdir("toto", true);
    std::cout << "Visit and DirHandler demo" << std::endl;
    MyDirHandler handler;
    Util::Dir::visit(handler, Util::RuntimeEnvironment::workingDir(), true);
    std::cout << "Temporary folder creation" << std::endl;
    Util::String tempName = Util::Dir::mktemp() ; 
    std::cout << "Temporary dir name: " << tempName << std::endl;
    Util::Dir::mkdir(tempName + Util::RuntimeEnvironment::PATH_SEPARATOR + Util::String("test"));
    Util::Dir::visit(handler, tempName, true);
    Util::Dir::rmdir(tempName);
    return 0;
}


/*******************************************************************************/
