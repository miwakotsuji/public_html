/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @file
 * @brief Class test_Zip definitions 
 *  
 *
 * 
 * 
 * - Supports: All 
 * - Created: 2005-08-25
 * - Creator: Olivier DELANNOY
 * - $Revision $
 * - Changelog: 
 *    
 *    * 2005-08-25 : Initial version  
 ******************************************************************************
@LICENSE@
 *******************************************************************************/
#include "Zip.hh"
#include <cassert>
int main(int argc, char** argv)
{
    Util::Zip*zip;
		
		zip = new Util::Zip("test.zip", false);
		assert(zip);
    assert(zip->addEntry("test_Zip.cc"));
    assert(zip->addEntry("Makefile.am"));
    delete zip;
    zip = new Util::Zip("test.zip", true);
		assert(zip);
    assert(zip->extractAllEntry("/tmp/"));
		delete zip;
}

/*******************************************************************************/
