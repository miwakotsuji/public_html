/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @ingroup util_system
* @file
* @brief Process Class declaration 
*  
* - Supports:
*   - System 
*       - UNIX (Linux) 
* - Created: 2005-08-06
* - Creator: Olivier Delannoy
* - Changelog: 
*    
*    * 2005-08-06 : Initial version  
*******************************************************************************
Copyright Olivier Delannoy 2005

Olivier Delannoy <Olivier.Delannoy@gmail.com>

This software is a computer program whose purpose is to [describe
functionalities and technical features of your software].

This software is governed by the CeCILL  license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.

*******************************************************************************/
#ifndef UTIL_PROCESS_HH
#define UTIL_PROCESS_HH
#include "util_namespace.hh"
#include "StringList.hh"
#include <iostream>
namespace Util {
    /**
     * Describe the state of child process
     */
    enum ProcessState 
    {
        PROCESS_WAITING,  /** State before launching the child process  */
        PROCESS_STARTING, /** State starting   */
        PROCESS_RUNNING,  /** State running */
        PROCESS_FINISHED, /** State finished */
    };
    /**
     * @ingroup util_system
     * @brief Process Spawning Class. 
     *
     *  This class provide the user code with an abstract of
     * process. It provide the user with a way to spawn
     * subprocess, wait for their teminaison and many more
     * features.
     */
    class Process 
    {
    public:
        /** 
         * Constructor 
         */
        explicit Process(void);
        /** 
         * Destructor
         */
        ~Process(void);
        /**
         * Spawn the process 
         * @param program The name of the program or the full path  
         *
         * @param parameters The list of the command line parameter 
         *
         * @param workingDir the process working dir 
         *
         */
        bool start(const String& program, const StringList& parameters, const String& workingDir = "");
        /**
         * Send data to the child process 
         */
        //std::ostream& stdin(void);
        /**
         * Receive standard output of the child process 
         */
        //std::istream& stdout(void);
        /**
         * Receive standard error of the child process 
         */
        //std::istream& stderr(void); 
        /**
         * Retrieve the current state of the process 
         *
         * @return The state of the process 
         */
        ProcessState state(void);
        /**
         * Wait for child process to finish
         */
        void wait(void);
        /**
         * Retrieve the exit status code of the child process 
         *
         * @note It's an error to ask the exit status before the
         * termination of the child process.
         * 
         * @return the return code  
         */
        int32 exitStatus(void) const throw();                
        /**
         * Retrieve the process ID of te child process 
         *
         * @note It's an error to ask the process id before the
         * termination of the child process.
         * 
         * @return the Process ID   
         */
        uint32 processID(void) const throw();
    protected:
    private:
        /** Store all parameters */
        StringList mParameters;
        /** Store the state of the process */
        ProcessState mState;
        /** Store the process id of the subprocess once spawned */
        int32 mPid;
        /** Store the process exit status */
        int32 mExitStatus;
        /** Store a stream pointer to the child process input stream */
        //std::ostream* mProcessInput;
        /** Store a stream pointer connected to the child process output stream */ 
        //std::istream* mProcessOutput;
        /** Store a stream pointer connected to the child process error stream */ 
        //std::istream* mProcessError; 
        /** Disabled copy constructor */
        Process(Process& src);
        /** Disabled assignment operator */
        Process& operator=(Process& src);
    };
}
#ifdef UTIL_OPT_INLINE
#include "Process.icc"
#endif
#endif
/*******************************************************************************/




