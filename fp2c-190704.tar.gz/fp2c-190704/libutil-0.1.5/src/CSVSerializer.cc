/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @file
 * @brief Class CSVSerializer definitions 
 *  
 *
 * 
 * 
 * - Supports: All 
 * - Created: 2006-11-06
 * - Creator: Olivier Delannoy
 * - $Revision $
 * - Changelog: 
 *    
 *    * 2006-11-06 : Initial version  
 ******************************************************************************
@LICENSE@
 *******************************************************************************/
#ifndef HAVE_CONFIG_H
#include "util_config.hh"
#endif
#include "CSVSerializer.hh"
namespace Util
{
CSVSerializer::CSVSerializer(std::ostream& out, char separator)
    : mStream(out), mSeparator(separator), mStartOfRow(true)
{
}
CSVSerializer::~CSVSerializer(void)
{
}
CSVSerializer& CSVSerializer::newRow()
{
  mStream << std::endl;
  mStartOfRow = true;
  return *this;
}
CSVSerializer& CSVSerializer::cell(const String& text)
{
    if (mStartOfRow)
        mStartOfRow = false;
    else 
        mStream << mSeparator;
    
    mStream << '"';
    const uint32 size = text.size();
    for (uint32 i = 0 ; i < size ; ++i)
    {
        if ( text[i] == '"')
            mStream << "\"\"";
        else
            mStream <<  text[i];
    }
    mStream << '"';
    return *this;
}
}
/*******************************************************************************/
