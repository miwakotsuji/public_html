/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @ingroup util_application 
 * @file
 * @brief Class Application definitions
 *  
 *
 *
 * - Supports: All 
 * - Created: 2005-08-06
 * - Creator: Olivier Delannoy
 * - $Revision $
 * - Changelog: 
 *    
 *    * 2005-08-06 : Initial version  
 *******************************************************************************
@LICENSE@
 *******************************************************************************/
#include "Application.hh" 
#ifndef UTIL_OPT_INLINE 
#  define inline 
#  include "Application.icc"
#  undef inline 
#endif 
#include "CommandLineParser.hh"
#include "RuntimeEnvironment.hh"
#include "XMLParserFactory.hh" 
#include "ConfigXCF.hh" 
#include "ConfigFactory.hh"
#include "LoggerFactory.hh" 
#include "PluginFactory.hh"
#include <cassert> 
#include <cstring>
#include <iostream>

const Util::uint32 Util::Application::SUCCESS = 0;
const Util::uint32 Util::Application::ERROR = 1;
Util::Application::Application(Util::ApplicationAdaptor* adaptor, int argc, char** argv) 
    : mCmdLineParser(new CommandLineParser(argc, argv)),
      mLoggers(new LoggerFactory), 
      mConfigs(new ConfigFactory), 
      mPlugins(new PluginFactory),
      mAdaptor(adaptor)
{
    UTIL_DEBUGUTIL("Start Application Framework");
    char* tmp = strrchr(argv[0], RuntimeEnvironment::PATH_SEPARATOR); 
    if (tmp) 
        mBaseName = tmp + 1;
    else 
        mBaseName = argv[0];
    new XMLParserFactory;
    

    // Create Default Option 
    mCmdLineParser->addOption(new CommandLineOption("usage"));
    mCmdLineParser->addOption(new CommandLineOption("help"));
    mCmdLineParser->addOption(new CommandLineOption("version"));
    mCmdLineParser->addOption(new CommandLineOption("config-dir", "", true));
    mCmdLineParser->addOption(new CommandLineOption("config",     "", true));   
    mCmdLineParser->addOption(new CommandLineOption("log-dir",    "", true));
    mCmdLineParser->addOption(new CommandLineOption("plugin-dir", "", true));

    // Init configuration option 
    mConfigs->registerLoader(ConfigXCF::FILE_EXTENSION, new ConfigXCF);
    mConfigs->setDefaultLoader(ConfigXCF::FILE_EXTENSION);
}


Util::Application::~Application()
{
    delete mPlugins;
    delete mConfigs;
    delete mLoggers;
    delete mCmdLineParser;
    delete XMLParserFactory::getSingletonPtr();
    delete mAdaptor;   
    UTIL_DEBUGUTIL("End Application Framework");
}


Util::CommandLineOption* Util::Application::option(const Util::String& name)
{
    return mCmdLineParser->option(name);
}


const Util::String& Util::Application::parameter(Util::uint32 index) const throw(OutOfBoundException)
{
    return mCmdLineParser->parameter(index);
}

Util::uint32 Util::Application::parameters(void) const
{
    return mCmdLineParser->parameters();
}

void Util::Application::displayUsage(void)
{
    mAdaptor->displayNotification(usage(), Util::UTIL_NOTIFICATION_USAGE);
}

void Util::Application::displayVersion(void)
{
    mAdaptor->displayNotification(version(), Util::UTIL_NOTIFICATION_VERSION);
}

// The main program 
Util::uint32 Util::Application::execute(void) 
{
    UTIL_DEBUGUTIL("Starting application execution");
    uint32 status = SUCCESS;
    // Handling command line stuff 
    configureCommandLine();
    if (! mCmdLineParser->parse()) 
    {
        displayUsage();
        return ERROR;   
    }
    // Detect Command line parameters 
    Util::CommandLineOption *option = mCmdLineParser->option("usage");
    if (option && option->count()) 
    {
        displayUsage();
        return SUCCESS;
    }
    option = mCmdLineParser->option("help");
    if (option && option->count()) 
    {
        displayUsage();
        return SUCCESS;
    }
    option = mCmdLineParser->option("version");
    if (option && option->count())
    {
        displayVersion();
        return SUCCESS;
    }
    UTIL_DEBUGUTIL("Start initializing Configuration services");
    // Init ConfigFactory
    String confName = configName();
    String confDir  = configDir();
    option = mCmdLineParser->option("config");
    if (option && option->count())
        confName = option->value();
    
    option = mCmdLineParser->option("config-dir");
    if (option && option->count())
        confDir = option->value();
    mConfigs->setConfigDir(confDir);
    mConfigs->setDefault(confName);
    UTIL_DEBUGUTIL("End initializing Configuration services");
    
    UTIL_DEBUGUTIL("Start initializing  Logging services");
    // Init logger 
    String loggersConfig = mConfigs->
        create("default")->get("config", "loggers" , loggersConfigName());
    String loggerDir = loggersDir();
    option = mCmdLineParser->option("log-dir");
    if (option && option->count())
        loggerDir =  option->value();
    mLoggers->init(loggersConfig, mBaseName, loggerDir);
    UTIL_DEBUGUTIL("End initializing  Logging services");
    // Init Plugins 
    UTIL_DEBUGUTIL("Start initializing Plugin services");
    String plugDir = pluginDir();
    option = mCmdLineParser->option("plugin-dir");
    if (option && option->count())
        plugDir = option->value();
    mPlugins->addPluginPath(plugDir);
    UTIL_DEBUGUTIL("End initializing Plugin services");
    // Start user code 
    try 
    {
        UTIL_DEBUGUTIL("Entering user code");
        status = run();
        UTIL_DEBUGUTIL("Exiting user code");
    }
    catch(std::exception& e)
    {
        status = ERROR;
        mAdaptor->displayNotification(e.what(), Util::UTIL_NOTIFICATION_EXCEPTION);
    }
    UTIL_DEBUGUTIL("Terminating application execution");
    return status;
}

void Util::Application::configureCommandLine(void) 
{
    
}

Util::String Util::Application::usage(void) const
{
    String res("Usage : ");
    res += mBaseName;
    res += " [options]";
    res += usageQuick();
    res += "\nOptions: "                                                \
        "\n  --usage............: display this message"                 \
        "\n  --help.............: display this message"                 \
        "\n  --version..........: display version information"          \
        "\n  --config=file......: master configuration file"            \
        "\n  --config-dir=dir...: Path to the configuration files"      \
        "\n  --log-dir=dir......: Path to the directory used for logging" \
        "\n  --plugin-dir=dir...: Path to the directory containing plugins";
    res += usageOptions();
    res += "\n\nOptions mark with a * are required\nParameters: ";
    res += usageParameters();
    res += "\n\nParameters mark with a * are required";
    return res;
}

Util::String Util::Application::usageQuick(void) const
{
    return "";
}

Util::String Util::Application::usageOptions(void) const
{
    return "";
}

Util::String Util::Application::usageParameters(void) const
{
    return "";
}
Util::String Util::Application::version(void) const
{
    return "";
}
Util::String Util::Application::configName(void) const
{
    return mBaseName;
}
Util::String Util::Application::configDir(void) const
{
    return ".";
}
Util::String Util::Application::loggersConfigName(void) const
{
    return "loggers";
}
Util::String Util::Application::loggersDir(void) const
{
    return ".";
}
Util::String Util::Application::pluginDir(void) const
{
    return ".";
}
/*******************************************************************************/

