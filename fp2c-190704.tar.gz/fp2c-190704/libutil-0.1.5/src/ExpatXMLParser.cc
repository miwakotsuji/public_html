/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @file
* @brief Class ExpatXMLParser definitions 
*  
*
* 
* 
* - Supports: All 
* - Created: 2005-08-11
* - Creator: Olivier Delannoy
* - $Revision $
* - Changelog: 
*    
*    * 2005-08-11 : Initial version  
******************************************************************************
@LICENSE@
*******************************************************************************/
#include "ExpatXMLParser.hh"
#include "Exception.hh" 
#include "expat.h"

namespace Util
{
    ExpatXMLParser::ExpatXMLParser(void)
        : XMLParserImpl("ExpatXMLParser", false)
    {
    }
    static void startElement(void *data, const char *el, const char **attr) 
    {
        XMLHandler* handler = (XMLHandler*)data;
        Properties props;
        for(int i = 0 ; attr[i] ; i +=2)
            props.add(attr[i], attr[i+1]);
        handler->elementStart(el, props);
    }
    static void endElement(void* data, const char *el)
    {
        XMLHandler* handler = (XMLHandler*)data;
        handler->elementEnd(el);
    }
    static void text(void* data, const XML_Char *s, int len)
    {
        XMLHandler* handler = (XMLHandler*)data;
        handler->text(String(s, len));
    }
    void ExpatXMLParser::parse(XMLHandler& handler, const ByteArray& data, const ByteArray* const xsd) throw(XMLParseException)
    {

        XML_Parser parser = XML_ParserCreate(NULL);
        if (! parser) 
        {
            throw XMLParseException(0, 0, "Unable to allocate Expat Parser");
        }
        XML_SetUserData(parser, (void*)&handler);
        XML_SetElementHandler(parser, startElement, endElement);
        XML_SetCharacterDataHandler(parser, text);
        UTIL_DEBUGUTIL('[' << String(reinterpret_cast<const char*>(data.data()), data.size()) << ']');
        if (! XML_Parse(parser, reinterpret_cast<const char*>(data.data()), data.size(), true))
        {
            
            uint32 row = XML_GetCurrentLineNumber(parser);
            uint32 col = XML_GetCurrentColumnNumber(parser);
            String message(XML_ErrorString(XML_GetErrorCode(parser)));
            XML_ParserFree(parser);
            
            throw XMLParseException(row, col, message);
        }
        XML_ParserFree(parser);
    }
    bool ExpatXMLParser::initializeImpl(void)
    {
        return true;
    }
    void ExpatXMLParser::cleanupImpl(void)
    {
    }
}
/*******************************************************************************/
