/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @ingroup util_application
* @file
* @brief Class CommandLineParser declaration   
*  
* - Supports: All
* - Created: 2005-08-07-02
* - Creator: Olivier Delannoy
* - $Revision $
* - Changelog: 
*    * 2005-08-06 : libutil integration and updates 
*    * 2005-07-02 : 
*       - Removing std::string dependencies
*       - Adding a function to give access to the number of available parameters 
*******************************************************************************
Copyright Olivier Delannoy 2005

Olivier Delannoy <Olivier.Delannoy@gmail.com>

This software is a computer program whose purpose is to [describe
functionalities and technical features of your software].

This software is governed by the CeCILL  license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.

*******************************************************************************/
#ifndef UTIL_COMMANDLINEPARSER_HH
#define UTIL_COMMANDLINEPARSER_HH 1
#include "util_namespace.hh"
#include "CommandLineOption.hh"
#include <vector>
#include <deque>
#include <iostream>
namespace Util {
    /**
     * @ingroup util_application
     * @brief Command Line parser class 
     *
     * This class is a utility class dedicated to the parsing of options
     * on the command line.  A command line parser instance ensure
     * provide long and short option parsing. It also ensure that all
     * option are well formed according to their descriptions. This
     * parser requires that all options are situated before free
     * parameters. All options begin whether with a - or with --. A
     * special option named -- terminate the option parsing. 
     */
    class CommandLineParser
    {
    public:
        /**
         * Constructor 
         * It initialize the object with the command line parameter. 
         * You must then create CommandLineOptions object and register them before parsing. 
         * 
         * @param argc The size of the string array @em argv
         * @param argv a c style string array 
         */
        explicit CommandLineParser(int argc, char **argv);
        /** Destructor */
        ~CommandLineParser(void);
        /**
         * Does the parsing task 
         *
         * @return true if all options and parameters fits the requirement. false on error 
         * @note this function should be called only once. 
         */
        bool parse(void); 
    
        /**
         * Set the number of required parameter 
         * @param count the number of required parameter 
         * @note This function as no meaning once the command line was parsed. 
         */
        void parameterCount(uint32 count);
    
        /**
         * Set a flag that allow a variadic number of parameter 
         * @param variadic true to allow a variadic number of parameter
         * @note This function as no meaning once the command line was parsed. 
         */
        void variadicFlag(bool variadic);
    
        /**
         * Add a new option. 
         * @param option a pointer to an option. 
         * @note This function as no meaning once the command line was parsed. 
         */
        void addOption(CommandLineOption* option);

        /**
         * Retrieve the option with name @em name 
         * @param name the name of the option 
         * @return a pointer to the option if exists 0 otherwise. 
         * @note This function as no meaning before the parsing was done 
         */
        CommandLineOption* option(const String& name);
 
        /**
         * Retrieve parameter at @em index 
         *
         * @param index the index of the expected parameter (begins at 1) 
         * @return a string if the parameter exists (the program is aborted otherwise)
         * @note This function as no meaning before the parsing was done 
         */
        const String& parameter(uint32 index) const;   

        /**
         * Retrieve the number of parameters effectively set 
         * @return the number of parameter available 
         */
        uint32 parameters(void) const;
        /**
         * Printout the object to @em out
         */
        void print(std::ostream& out) const throw();
        
    protected:
    private:
        /** Typename for the container of Option */
        typedef std::vector<CommandLineOption*> OptionList;
        /** typename for a string array */
        typedef std::deque<String> ParameterList;
        /** Parameter List */
        ParameterList mParameters;
        /** Options list */
        OptionList mOptions;
        /** Store the number of required parameter */
        uint32 mCount;
        /** True if there can be more parameter on the command line */
        bool mVariadic;
        /** True if the parsing was previously done */
        bool mParsed;
        /** Disabled copy constructor */
        CommandLineParser(CommandLineParser& src);
        /** Disabled assignment operator */
        CommandLineParser& operator=(CommandLineParser& src);
    };
}
std::ostream& operator<<(std::ostream& out, const Util::CommandLineParser& obj);

#ifdef UTIL_OPT_INLINE 
#  include "CommandLineParser.icc"
#endif
#endif
/*******************************************************************************/      



