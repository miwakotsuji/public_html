/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @ingroup util_tools 
* @file
* @brief Class Pack definition
*  
* @todo Add throw clause to the class to report correcly exception list 
* - Supports: 
*   - UNIX: (linux/POSIX)
* - Created: 2005-08-25
* - Creator: Olivier DELANNOY
* - Last change in revision : $Revision $
* - Changelog: 
*    
*    * 2005-08-25 : Initial version  
******************************************************************************
@LICENSE@
*******************************************************************************/
#ifdef HAVE_CONFIG_H
#include <util_config.hh>
#endif
#include "Pack.hh"
#include "Exception.hh" 
#include "RuntimeEnvironment.hh"
#include "Dir.hh"
#include <cerrno>
#include <cstring>
#include <cstdio>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <iostream>
#include <climits>
/* The format is really simple : 
 * an header of 4 byte 
 * 0x00000000 ARC1
 * 0x00000004 Entry1
 * 0x???????? ...
 * 0x00000000 EntryN 
 * 
 * Entry: 
 * 4  bytes : The size of the entryName 
 * NE bytes : The entry Name 
 * 4  bytes : The size of the data 
 * ND bytes : The data 
 */


namespace Util
{
    
Pack::Pack(const String& fileName)
    : fd(-1), addLast(false)
{
    UTIL_DEBUGUTIL("Opening pack file: '" << fileName << "'");
    fd = ::open(fileName.c_str(), O_RDWR | O_CREAT, 0666);
    if (fd == -1)
    {
        UTIL_DEBUGUTIL("IOException thrown");
        throw IOException(errno, fileName + ": Unable to open file");
    }
    UTIL_DEBUGUTIL("Reading header");
    // Check for header
    char buffer[4];
    int status = ::read(fd, buffer, sizeof(buffer));
    if (status == -1)
    {
        ::close(fd);
        UTIL_DEBUGUTIL("IOException thrown");
        throw IOException(errno, fileName + ": Unable to read header");
    }
    UTIL_DEBUGUTIL("Parse header");
        
    if(status < 4)
    {
        UTIL_DEBUGUTIL("New File");
        //Empty file write the header 
        status = ::write(fd, "ARC1", 4);
        if (status == -1)
        {
            ::close(fd);
            UTIL_DEBUGUTIL("IOException thrown");
            throw IOException(errno, fileName + ": Unable to write the header");
        }
        ::lseek(fd, 0, SEEK_SET);
        status = ::read(fd, buffer, 4);
        if (status == -1)
        {
            ::close(fd);
            throw Exception(fileName + ": Unable to read header");
        }
    }
    String header(buffer, 4);
    if (header.compare("ARC1") != 0)
    {
        ::close(fd);
        UTIL_DEBUGUTIL("IOException thrown");
        throw Exception(fileName + ": Wrong header");
    }
    UTIL_DEBUGUTIL("HEADER Correct");
}

Pack::~Pack(void)
{
    close();
}

void Pack::close(void)
{
    if (fd != -1)
        ::close(fd);   
    fd = -1;
}



bool Pack::add(const String& entryName, const String& fileName)
{
    if (fd == -1)
    {
        return false;
    }
    int fd_in = open(fileName.c_str(), O_RDONLY);
    if (fd_in == -1)
    {
        return false;
    }
    struct stat in_stat;
    if (::fstat(fd_in, &in_stat) == -1)
    {
        ::close(fd_in);
        return false;

    }
    // 4 times the page size under linux 
    const uint32 BUFFER_SIZE = 16384;
    char buffer[BUFFER_SIZE];
    // Go to the end of the arch
    if (!addLast) 
    {
        ::lseek(fd, 0, SEEK_END); // We should check the return value here 
        addLast = true;
    }
    // Prepare file header 
    uint32 nameSize = entryName.size();
    uint32 dataSize = in_stat.st_size;
    uint32 offset = 0;
    ::memcpy(buffer + offset, reinterpret_cast<char*>(&nameSize), sizeof(nameSize));
    offset += sizeof(nameSize);
    ::memcpy(buffer + offset, reinterpret_cast<char*>(&dataSize), sizeof(dataSize));
    offset += sizeof(dataSize);
    ::memcpy(buffer + offset, entryName.c_str(), nameSize); // Hey that's prevent one read call ;) 
    offset += nameSize;
    int status = ::write(fd, buffer, sizeof(nameSize) + nameSize + sizeof(dataSize));
    if (status == -1)
    {
        ::close(fd_in);
        ::close(fd);
        fd = -1;
        UTIL_DEBUGUTIL("IOException thrown");
        throw IOException(errno, "::write() failed");
    }
    int read = 0;
    while(dataSize - read > 0)
    {
        status = ::read(fd_in, buffer, BUFFER_SIZE);
        if (status == -1)
        {
            ::close(fd_in);
            ::close(fd);
            fd =-1;
            UTIL_DEBUGUTIL("IOException thrown");
            throw IOException(errno, "::read() failed");
        }
        if (status == 0)
        {
            // EOF we should never get there  
            break;
        }
            
        read += status;
        uint32 toWrite = status;
        int written = 0;
        while(toWrite - written > 0)
        {
            status = ::write(fd, buffer + written, toWrite - written);
            if (status == -1)
            {
                ::close(fd_in);
                ::close(fd);
                fd = -1;
                UTIL_DEBUGUTIL("IOException thrown");
                throw IOException(errno, "::write() failed");
            }
            written += status;
        }
    }
    ::close(fd_in);
    return true;
}

/*
bool Pack::addpath(char *entryName, const String& dirName)
{
    int len;
    String fullpath;
    byte* data = new byte[256];
    sprintf((char *)data,"%s%s",dirName.c_str(),entryName);
    len=strlen((char *)data); 

    if (fd == -1)
        return false;
    if (!addLast)
    {
        lseek(fd, 0, SEEK_END);
        addLast = true;
    }
    // 4 times the page size under linux 
    const uint32 BUFFER_SIZE = 16384;
    char buffer[BUFFER_SIZE];
    uint32 nameSize = strlen(entryName);
    uint32 offset = 0;
    ::memcpy(buffer + offset, reinterpret_cast<char*>(&nameSize), sizeof(nameSize));
    offset += sizeof(nameSize);
    ::memcpy(buffer + offset, reinterpret_cast<char*>(&len), sizeof(len));
    offset += sizeof(len);
    ::memcpy(buffer + offset, entryName, nameSize);
    offset += nameSize;
    uint32 copy =  BUFFER_SIZE - offset - len > 0 ? len : BUFFER_SIZE - offset;
    uint32 written = 0;
    ::memcpy(buffer + offset, reinterpret_cast<char*>(data), copy);
    int status = ::write(fd, buffer, offset + copy);
    if (status == -1)
    {
        ::close(fd);
        fd = -1;
        UTIL_DEBUGUTIL("IOException thrown");
        throw IOException(errno, "::write() failed");
    }
    written += status - offset;
    while (len - written  > 0)
    {
        status = ::write(fd, data + written, len - written);
        if (status == -1)
        {
            ::close(fd);
            fd = -1;
            UTIL_DEBUGUTIL("IOException thrown");
            throw IOException(errno, "::write() failed");
        }
        written += status;
    }
    delete [] data;
    return true;

}
*/

bool Pack::add(const String& entryName, byte* data, uint32 len)
{
    if (fd == -1)
        return false;
    if (!addLast) 
    {
        lseek(fd, 0, SEEK_END);
        addLast = true;
    }
    // 4 times the page size under linux 
    const uint32 BUFFER_SIZE = 16384;
    char buffer[BUFFER_SIZE];
    uint32 nameSize = entryName.size();
    uint32 offset = 0;
    ::memcpy(buffer + offset, reinterpret_cast<char*>(&nameSize), sizeof(nameSize));
    offset += sizeof(nameSize);
    ::memcpy(buffer + offset, reinterpret_cast<char*>(&len), sizeof(len));        
    offset += sizeof(len);
    ::memcpy(buffer + offset, entryName.c_str(), nameSize);
    offset += nameSize;
    uint32 copy =  BUFFER_SIZE - offset - len > 0 ? len : BUFFER_SIZE - offset;
    uint32 written = 0;
    ::memcpy(buffer + offset, reinterpret_cast<char*>(data), copy);
    int status = ::write(fd, buffer, offset + copy);
    if (status == -1)
    {
        ::close(fd);
        fd = -1;
        UTIL_DEBUGUTIL("IOException thrown");
        throw IOException(errno, "::write() failed");
    }
    written += status - offset;
    while (len - written  > 0)
    {
        status = ::write(fd, data + written, len - written);
        if (status == -1)
        {
            ::close(fd);
            fd = -1;
            UTIL_DEBUGUTIL("IOException thrown");
            throw IOException(errno, "::write() failed");
        }
        written += status;
    }
    return true;
}

bool Pack::extractAll(const String& dirName)
{
    if (fd == -1)
        return false;
    const uint32 BUFFER_SIZE = 16384;
    //Go to the first entry 
    addLast = false;
    lseek(fd, 4, SEEK_SET);
    Dir::mkdir(dirName);
    String dir;
    if (dirName[dirName.size() - 1] != RuntimeEnvironment::PATH_SEPARATOR)
        dir = dirName + RuntimeEnvironment::PATH_SEPARATOR;
    else 
        dir = dirName;        
    char buffer[BUFFER_SIZE];
    int status = 1;
    uint32 nameSize = 0;
    uint32 dataSize = 0;
    uint32 offset = 0;
    uint32 state = 0;
    String name = dir;
    uint32 toRead = 0;
    int fd_out = -1;
    UTIL_DEBUGUTIL("Extract resources");
        
    while(status)
    {
        offset = 0;
        status = ::read(fd, buffer, BUFFER_SIZE);
        if (status == -1)
        {
            ::close(fd);
            fd = -1;
            UTIL_DEBUGUTIL("IOException thrown");
            throw IOException(errno,  "::read() failed");    
        }
        //Vider le buffer courant 
        while( status - offset > 0)
        {
            UTIL_DEBUGUTIL("State: " << state);
            UTIL_DEBUGUTIL("Status: " << status);
            UTIL_DEBUGUTIL("Offset: " << offset);
            // We are in the nameSize chunk
            if (state < sizeof(nameSize))
            {
                toRead = sizeof(nameSize) - state;
                toRead = status - offset  > toRead ? toRead : status - offset;
                ::memcpy(reinterpret_cast<char*>(&nameSize) + sizeof(nameSize) - toRead, buffer + offset,toRead);
                offset += toRead;
                state += toRead;
            }
            // We are in the dataSize chunk
            else if (state < sizeof(nameSize) + sizeof(dataSize))
            {
                toRead = sizeof(dataSize) - state + sizeof(nameSize);
                toRead = status - offset > toRead ? toRead : status - offset;
                ::memcpy(reinterpret_cast<char*>(&dataSize) + sizeof(dataSize) - toRead, buffer + offset, toRead);
                offset += toRead;
                state += toRead;
                UTIL_DEBUGUTIL("Fin de nameSize: " << nameSize);
            }
            // We are in the name chunk
            else if (state < sizeof(nameSize) + sizeof(dataSize) + nameSize)
            {
                UTIL_DEBUGUTIL("Name Size: " << nameSize);
                UTIL_DEBUGUTIL("Data Size: " << dataSize);
                UTIL_DEBUGUTIL("Name: " << name);
                UTIL_DEBUGUTIL("Offset: " << offset);
                UTIL_DEBUGUTIL("Status: " << status);
                UTIL_DEBUGUTIL("State: " << state);
                UTIL_DEBUGUTIL("Buffer: " << (void*)buffer);
                UTIL_DEBUGUTIL("Buffer + offset: " << (void*)(buffer+ offset));
                toRead = nameSize - state + sizeof(nameSize) + sizeof(dataSize);
                toRead = status - offset > toRead  ? toRead : status - offset;
                UTIL_DEBUGUTIL("ToRead: " << toRead);
                String fname((buffer + offset), toRead); 
                UTIL_DEBUGUTIL("Filename: " << fname);
                name += fname;
                UTIL_DEBUGUTIL("Name: " << name);
                offset += toRead;
                state += toRead;
            }
            // We are in the data chunk 
            else 
            {
                if (fd_out == -1)
                {
                    fd_out = open(name.c_str(), O_WRONLY|O_CREAT|O_TRUNC, 0666);
                    if (fd_out == -1)
                    {
                        return false;                            
                    }
                }
                toRead = dataSize - state + sizeof(nameSize) + sizeof(dataSize) + nameSize;
                toRead = status - offset > toRead ? toRead : status - offset;
                int status2 = ::write(fd_out, buffer + offset, toRead);
                if (status2 == -1)
                {
                    ::close(fd_out);
                    ::close(fd);
                    fd = -1;
                    UTIL_DEBUGUTIL("IOException thrown");
                    throw IOException(errno, "::write() failed");     
                }
                offset += status2;
                state += status2;
                if (state >= sizeof(nameSize) + sizeof(dataSize) + nameSize + dataSize)
                {
                    UTIL_DEBUGUTIL("Fin de : " << name);
                    ::close(fd_out);
                    fd_out = -1;
                    state = 0;
                    name = dir;
                    nameSize = 0;
                    dataSize = 0;

                }
            }
        }
    }
    UTIL_DEBUGUTIL("Data extracted successfully");
    return true;
}


/************************** Extract in file*/

bool Pack::extract(const String& entryName, const String& localName)
{
    UTIL_DEBUGUTIL("Trying to extract " << entryName << " to file " << localName);
 
    if (fd == -1)
        return false;
    const uint32 entryNameSize = entryName.size();
    char buffer[PATH_MAX];
    int status;
    uint32 sizeInfo[2];
    uint32 entryInfo[3];
    entryInfo[0] = 0; // Name Size 
    entryInfo[1] = 0; // Data Size 
    entryInfo[2] = 0; // Offset
    // It's not an addition 
    addLast = false;
    //Go to the first entry
    lseek(fd, 4, SEEK_SET);    
    status = 1;
    while(status)
    {
        UTIL_DEBUGUTIL("Offset of the next entry: " << lseek(fd, 0, SEEK_CUR));
        status= ::read(fd, (char*)sizeInfo, sizeof(sizeInfo));
        int nextEntry = lseek(fd, 0, SEEK_CUR) + sizeInfo[0] + sizeInfo[1];
        UTIL_DEBUGUTIL("Status: " << status);
        if (status == -1)
        {
            ::close(fd);
            fd = -1;
            throw IOException(errno, "::read() failed");    
        }   
        else if (status == sizeof(sizeInfo))
        {
            UTIL_DEBUGUTIL("New Entry");
            if (sizeInfo[0] == entryNameSize)
            {
                UTIL_DEBUGUTIL("Entry name size match");
                status = ::read(fd, buffer, entryNameSize);
                if (status == -1)
                {
                    ::close(fd);
                    fd = -1;
                    UTIL_DEBUGUTIL("IOException thrown");
                    throw IOException(errno, "::read() failed");    
                }   
                else if (entryName == String(buffer, entryNameSize))
                {
                    entryInfo[0] = sizeInfo[0];
                    entryInfo[1] = sizeInfo[1];
                    entryInfo[2] = lseek(fd, 0, SEEK_CUR);
                    UTIL_DEBUGUTIL("Entry match with data offset: " << entryInfo[2]);
                }
            }
            else 
            {
                UTIL_DEBUGUTIL("Skeep entry, name size does not match");
            }
            lseek(fd, nextEntry, SEEK_SET);
        }
    }
    // If  entryInfo[0] != 0 -> We find the entry 
    if (entryInfo[0] == 0) 
        return false;
    
    
    lseek(fd, entryInfo[2], SEEK_SET);
    // We get the entry extract it to a folder 
    int fd_out = ::open(localName.c_str(), O_WRONLY | O_CREAT | O_TRUNC, 0666);
    if (fd_out == -1)
    {
        throw IOException(errno, "::open() failed");
    }
    uint32 written = 0;    
    while(written < entryInfo[1])
    {
        uint32 toRead = entryInfo[1] - written;
        if (toRead > PATH_MAX)
            toRead = PATH_MAX;
        status = ::read(fd, buffer, toRead);
        if (status == -1)
        {
            ::close(fd);
            fd = -1;
            UTIL_DEBUGUTIL("IOException thrown");
            throw IOException(errno, "::read() failed");
        }
        int written2 = 0;
        while(written2 < status)
        {
            int status2 = ::write(fd_out, buffer, status);
            if (status2 == -1)
            {
                ::close(fd_out);
                UTIL_DEBUGUTIL("IOException thrown");
                throw IOException(errno, "::write() failed");
            }
            written2 += status2;
        }
        written += written2;
    }                        
    ::close(fd_out);
    return true;
}

/******************************* Extract in memory*/
    
bool Pack::extract(const String& entryName, ByteArray& dest)
{
    UTIL_DEBUGUTIL("Extracting " << entryName << " to memory");
    
    if (fd == -1)
        return false;
    const uint32 entryNameSize = entryName.size();
    char buffer[PATH_MAX];
    int status;
    uint32 sizeInfo[2];
    uint32 entryInfo[3];
    entryInfo[0] = 0; // Name Size 
    entryInfo[1] = 0; // Data Size 
    entryInfo[2] = 0; // Offset
    // It's not an addition 
    addLast = false;
    //Go to the first entry
    lseek(fd, 4, SEEK_SET);    
    status = 1;
    while(status)
    {
        UTIL_DEBUGUTIL("Offset of the next entry: " << lseek(fd, 0, SEEK_CUR));
        status= ::read(fd, (char*)sizeInfo, sizeof(sizeInfo));
        int nextEntry = lseek(fd, 0, SEEK_CUR) + sizeInfo[0] + sizeInfo[1];
        UTIL_DEBUGUTIL("Status: " << status);
        if (status == -1)
        {
            ::close(fd);
            fd = -1;
            throw IOException(errno, "::read() failed");    
        }   
        else if (status == sizeof(sizeInfo))
        {
            UTIL_DEBUGUTIL("New Entry");
            if (sizeInfo[0] == entryNameSize)
            {
                UTIL_DEBUGUTIL("Entry name size match");
                status = ::read(fd, buffer, entryNameSize);
                if (status == -1)
                {
                    ::close(fd);
                    fd = -1;
                    UTIL_DEBUGUTIL("IOException thrown");
                    throw IOException(errno, "::read() failed");    
                }   
                else if (entryName == String(buffer, entryNameSize))
                {
                    entryInfo[0] = sizeInfo[0];
                    entryInfo[1] = sizeInfo[1];
                    entryInfo[2] = lseek(fd, 0, SEEK_CUR);
                    UTIL_DEBUGUTIL("Entry match with data offset: " << entryInfo[2]);
                }
            }
            else 
            {
                UTIL_DEBUGUTIL("Skeep entry, name size does not match");
            }
            lseek(fd, nextEntry, SEEK_SET);
        }
    }
    if (entryInfo[0] == 0)
        return false;
    // Prepare the result 
    dest.resize(entryInfo[1]);
    lseek(fd, entryInfo[2], SEEK_SET);
    status = ::read(fd, dest.data(), entryInfo[1]);
    if (status == -1)
    {
        ::close(fd);
        fd = -1;
        UTIL_DEBUGUTIL("IOException thrown");
        throw IOException(errno, "::read() failed");    
    }   
    return false;
}

// work on index
PackIndex* Pack::createIndex()
{
    UTIL_DEBUGUTIL("Create PackIndex");    
    PackIndex* result = new PackIndex;
    lseek(fd, 4, SEEK_SET);
    
    uint32 sizeInfo[2];
    int status = 1;
    char buffer[PATH_MAX];
    
    while(status)
    {
        UTIL_DEBUGUTIL("Offset: " << lseek(fd, 0, SEEK_CUR));
        
        status = ::read(fd,(char*)sizeInfo, sizeof(sizeInfo));
        if (status == -1)
        {
            delete result;
            ::close(fd);
            fd = -1;
            UTIL_DEBUGUTIL("IOException thrown");
            throw IOException(errno, "::read() failed");    
        }
        else if (status == sizeof(sizeInfo))
        {
            
            // New entry: 
            PackEntry entry;
            
            entry.d_size = sizeInfo[1];
            status = ::read(fd, buffer, sizeInfo[0]);
            if (status == -1)
            {
                delete result;
                ::close(fd);
                fd = -1;
                UTIL_DEBUGUTIL("IOException thrown");
                throw IOException(errno, "::read() failed");
            }
            entry.d_name.assign(buffer, sizeInfo[0]);
            entry.d_offset = lseek(fd, 0, SEEK_CUR);
            UTIL_DEBUGUTIL("Entry: " << entry.d_name << " at offset " << entry.d_offset << " of size " << entry.d_size);
            
            PackIndex::iterator iter = result->begin();
            const PackIndex::iterator end =  result->end();
            for (; iter != end ; ++iter) 
            {
                if ((*iter).d_name == entry.d_name)
                {
                    (*iter).d_offset = entry.d_offset;
                    (*iter).d_size = entry.d_size;
                    break;
                }
            }
            if (iter == end)
            {
                result->push_back(entry);
            }
            lseek(fd, sizeInfo[1], SEEK_CUR);
        }
    }
    return result;
}

void Pack::destroyIndex(PackIndex* index)
{
    delete index;
} 
}

/*******************************************************************************/

