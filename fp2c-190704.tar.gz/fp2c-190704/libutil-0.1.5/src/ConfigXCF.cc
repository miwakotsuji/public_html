/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @file
 * @brief Class ConfigXCF definitions 
 *  
 *
 * 
 * 
 * - Supports: All 
 * - Created: 2005-08-10
 * - Creator: Olivier Delannoy
 * - $Revision $
 * - Changelog: 
 *    
 *    * 2005-08-10 : Initial version  
 ******************************************************************************
@LICENSE@
 *******************************************************************************/
#include "ConfigXCF.hh"
#include "ConfigXCF_xmlHandler.hh" 
#include "XMLParser.hh"
#include "XMLParserFactory.hh" 
#include "FileInfo.hh" 
#include <fstream>
namespace Util
{
    const String ConfigXCF::FILE_EXTENSION = "xcf";
 
    const String ConfigXCF::XSD_NAME = "config.xsd";
     
    ConfigXCF::ConfigXCF(void)
    {    
    }
    ConfigXCF::~ConfigXCF(void)
    {
    }
    void ConfigXCF::loadImpl(const String& fileName) 
    {
        XMLParser parser = XMLParserFactory::getSingleton().create(UTIL_XML_PARSER_DEFAULT);
        ConfigXCF_xmlHandler handler(this);
        try
        {
            parser.parse(handler, fileName, XSD_NAME);
        }
        catch(XMLParseException& ex)
        {
            UTIL_DEBUGUTIL("XMLParseException '" << fileName << "': " << ex.what() << " at (" << ex.row() << ':' << ex.column() << ')');
        }
        
    }
    void ConfigXCF::saveImpl(const String& fileName, bool overwrite)
    {
        if (FileInfo(fileName).isFile() && !overwrite)
        {
            // Error do nothing
        }
        else 
        {
            std::ofstream out(fileName.c_str());
            out << "<?xml version=\"1.0\" ?>" << std::endl << std::endl
                << "<config>" << std::endl;
            // Output entries 
            ConfigData::const_iterator groupIter = mConfigData.begin();
            for(; groupIter != mConfigData.end() ; ++groupIter)
            {
                if (groupIter->first != "")
                {   
                    out << "  <group name=\"" << groupIter->first << "\">" << std::endl;
                    ConfigGroup::const_iterator valueIter = groupIter->second.begin();
                    for(; valueIter != groupIter->second.end() ; ++valueIter)
                    {
                        out << "    <entry name=\"" << valueIter->first << "\" value=\"" 
                            << valueIter->second << "\" />" << std::endl;
                    }
                    out << "  </group>" << std::endl;
                }
                else 
                {
                    ConfigGroup::const_iterator valueIter = groupIter->second.begin();
                    for( ; valueIter != groupIter->second.end() ; ++valueIter)
                    {
                        out << "  <entry name=\"" << valueIter->first << "\" value=\"" 
                            << valueIter->second << "\" />" << std::endl;
                    }
                }
            }
            out << "</config>" << std::endl;
            out.close();
        }
    }
    Util::Config* Util::ConfigXCF::clone(void) const
    {
        return new ConfigXCF;
    }
}
/*******************************************************************************/
