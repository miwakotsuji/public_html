/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @file
* @brief Class LoggerHeader definitions 
*  
*
* 
* 
* - Supports: All 
* - Created: 2006-03-23
* - Creator: Olivier Delannoy
* - $Revision $
* - Changelog: 
*    
*    * 2006-03-23 : Initial version  
******************************************************************************
@LICENSE@
*******************************************************************************/
#include "LoggerHeader.hh"
#ifndef UTIL_OPT_INLINE
#define inline
#include "LoggerHeader.icc"
#undef inline
#endif 
#include "RuntimeEnvironment.hh"
#include <cctype> 
#include <iomanip>
#include <ctime>

static const char* const UTIL_LEVEL_TEXT[] = 
{
    "ALL", 
    "DEBUG", 
    "INFORMATION", 
    "WARNING", 
    "ERROR", 
    "FATAL" 
};
namespace Util
{
    
    LoggerHeader::LoggerHeader(const char* const filename, uint32 line, LoggingLevel level)
        : mFile(filename), mLine(line), mLevel(level)
    {
        mTime = RuntimeEnvironment::unixTime();
    }
    void LoggerHeader::format(std::ostream& out, const String& format) const 
    {
        uint32 iter;
        uint32 size = format.size();
        
        for (iter = 0 ; iter < size ; ++iter)
        {
            if(format[iter] == '%')
            {
                ++iter;
                // Size 
                uint32 fieldSize = 0;
                while (iter < size && isdigit(format[iter]))
                {
                    fieldSize *= 10;
                    fieldSize += format[iter] - '0';
                    ++iter;
                }
                if (iter == size)
                {
                    // It's an invalid format
                    out << "[INVALID HEADER FORMAT]";
                    return;
                }
                switch(format[iter])
                {
                case 'u':
                {
                    char outstr[200];
                    struct tm *tmp;
                    tmp = localtime((time_t*)&mTime);
                    if (tmp)
                    {
                        if (strftime(outstr, sizeof(outstr), "%y-%m-%d/%H:%M:%S", tmp) != 0)
                        {
                            out << outstr;
                        }
                        else 
                        {
                            out << mTime;
                        }
                    }
                    else
                    {
                        out << mTime;
                    }
                }
                break;
                case 'p':
                    out << RuntimeEnvironment::processID();
                    break;
                case 'b':
                    // Basename of the program 
                    // ignored at the moment 
                    break;
                case 't':
                    // Thread id 
                    // ignored at the moment 
                    break;
                case 'f':
                    if (fieldSize)   
                    {
                        uint32 i;
                        for(i = 0 ; i < fieldSize && mFile[i] ; ++i)
                            out << mFile[i];
                        for( ; i < fieldSize ; ++i)    
                            out << ' ';
                    }
                    else
                    {
                        out << mFile;
                    }
                    break;
                case 'l':
                    out << mLine;
                    break;
                case 'd':
                    out << mLevel;
                    break;
                case 'm':
                    if (fieldSize)
                    {
                        uint32 i;
                        for(i = 0; i < fieldSize && UTIL_LEVEL_TEXT[mLevel][i] ; ++i)
                            out << UTIL_LEVEL_TEXT[mLevel][i];
                        for( ; i < fieldSize ; ++i)
                            out << ' ';
                    }
                    else 
                    {
                        out << UTIL_LEVEL_TEXT[mLevel];
                    }
                    break;
                case '%':
                    out << '%';
                    break;
                default:
                    // Invalid format ignore it 
                    break;
                }
            }
                else
            {
                out << format[iter];
            }
        }
    }
}
/*******************************************************************************/
