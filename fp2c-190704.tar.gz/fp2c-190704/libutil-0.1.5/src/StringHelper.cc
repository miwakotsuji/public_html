/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @file
 * @brief Class StringHelper definitions 
 *  
 *
 * 
 * 
 * - Supports: All 
 * - Created: 2006-04-01
 * - Creator: Olivier Delannoy
 * - $Revision $
 * - Changelog: 
 *    
 *    * 2006-04-01 : Initial version  
 ******************************************************************************
@LICENSE@
 *******************************************************************************/
#include "StringHelper.hh"
#include <cctype>
namespace Util
{
    String StringHelper::simplifyWhiteSpace(const String& source)
    {
        String res;
        bool inSpace = false;
        String::const_iterator iter = source.begin();
        // Remove initial whitespace 
        while(iter != source.end() && ::isspace(*iter))
        {
            ++iter;
        }
        for(;iter != source.end() ; ++iter)
        {
            if (::isspace(*iter))
            {
                inSpace = true;
            }
            if (! ::isspace(*iter))
            {
                if (inSpace)
                {
                    res += ' ';
                    inSpace = false;
                }
                res += *iter;
            }
        }
        return res;
    }
    String StringHelper::ltrim(const String& source)
    {
        uint32 start = 0;
        while(start != source.size() && ::isspace(source[start]))
              ++start;
        return source.substr(start);
    }
    String StringHelper::rtrim(const String& source)
    {
        uint32 end = source.size() - 1;
        while(end != 0 && ::isspace(source[end]))
            --end;
        return source.substr(0, end);
    }
    String StringHelper::trim(const String& source)
    {
        uint32 start = 0;
        uint32 end = source.size() - 1;
        while(start != source.size() && ::isspace(source[start]))
              ++start;
        while(end != 0 && ::isspace(source[end]))
            --end;
        if (start > end)
            return "";
        return source.substr(start, end - start + 1);
    }
}
/*******************************************************************************/
