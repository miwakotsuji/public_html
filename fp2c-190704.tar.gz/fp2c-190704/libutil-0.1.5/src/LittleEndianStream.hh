/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @ingroup util_tools 
* @file
* @brief Class LittleEndianStream declaration  
*  
* This class handle binary IO operation on files. 
* - Supports: All 
* 
* - Created: 2005-08-06
* - Creator: Olivier Delannoy
* - Changelog: 
*
*    * 2005-08-06 : Initial version  
*/
/*******************************************************************************
Copyright Olivier Delannoy 2005

Olivier Delannoy <Olivier.Delannoy@gmail.com>

This software is a computer program whose purpose is to [describe
functionalities and technical features of your software].

This software is governed by the CeCILL  license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.

*******************************************************************************/
#ifndef UTIL_LITTLEENDIANSTREAM_H
#define UTIL_LITTLEENDIANSTREAM_H 1
#include "util_namespace.hh"
#include <iostream>   
namespace Util {
    /**
     * @ingroup util_tools
     * @brief This is a filter to hide the differences between processor 
     * endianness. 
     * 
     * This class provide a filter to decode and encode data from
     * a little endian stream of data. This class act as a a
     * decorator arround standard iostream.
     *
     */
    class LittleEndianStream 
    {
    public:
        /**
         * Create a LittleEndianStream from the file named @em fileName. 
         * 
         *
         * @param fileName the name of the file to open in reading
         * and writing mode.
         * 
         * @note the stream create the file if it does not exists already.
         */
        explicit LittleEndianStream(const String& fileName);
        /**
         * Create a LittleEndianStream based on a existing stream 
         * @param stream a pointer to an opened in reading and writing stream.
         */
        explicit  LittleEndianStream(std::iostream* stream);
        /**
         * Destructor 
         */
        ~LittleEndianStream(void);
        
        /**
         *  Read a signed integer of 8 bits. 
         *
         * Read a signed integer of 8 bits.
         *
         * @param result the result of the read operation. 
         *
         * @return the filter instance so that it is possible 
         * to chain action. 
         */
        bool read(int8& result);
    
        /**
         *  Read an unsigned integer of 8 bits. 
         * 
         * Read an unsigned interger of 8 bits. 
         *
         * @param result the result of the read operation. 
         *
         * @return the filter instance so that it is possible 
         * to chain action. 
         */
        bool read(uint8& result);
    
        /**
         *  Read a signed integer of 16 bits. 
         * 
         * Read a signed integer of 16 bits. 
         * 
         * @param result the result of the read operation. 
         *
         * @return the filter instance so that it is possible 
         * to chain action. 
         */
        bool read(int16& result);
    
        /**
         *  Read an unsigned integer of 16 bits. 
         * 
         * Read an unsigned integer of 16 bits. 
         * 
         * @param result the result of the read operation. 
         *
         * @return the filter instance so that it is possible 
         * to chain action. 
         */
        bool read(uint16& result);
    
        /**
         *  Read a signed integer of 32 bits. 
         * 
         * Read a signed integer of 32 bits. 
         * 
         * @param result the result of the read operation. 
         *
         * @return the filter instance so that it is possible 
         * to chain action. 
         */
        bool read(int32& result);
    
        /**
         *  Read an unsigned integer of 32 bits. 
         * 
         * Read a signed integer of 32 bits. 
         * 
         * @param result the result of the read operation. 
         *
         * @return the filter instance so that it is possible 
         * to chain action. 
         */
        bool read(uint32& result);
    
        /**
         *  Read a signed integer of 64 bits. 
         * 
         * Read a signed integer of 64 bits. 
         * 
         * @param result the result of the read operation. 
         *
         * @return the filter instance so that it is possible 
         * to chain action. 
         */
        bool read(int64& result);
    
        /**
         *  Read an unsigned integer of 64 bits. 
         * 
         * Read a signed integer of 64 bits. 
         * 
         * @param result the result of the read operation. 
         *
         * @return the filter instance so that it is possible 
         * to chain action. 
         */
        bool read(uint64& result);
    
        /*
         *  Read a 32 bits floating point value. . 
         * 
         * Read a 32 bits floating point value. 
         * 
         * @param result the result of the read operation. 
         *
         * @return the filter instance so that it is possible 
         * to chain action. 
         */
        bool read(real32& result);
    
        /**
         *  Read a 64 bits floating point value. . 
         * 
         * Read a 64 bits floating point value. 
         * 
         * @param result the result of the read operation. 
         *
         * @return the filter instance so that it is possible 
         * to chain action. 
         */ 
        bool read(real64& result);
            
        /**
         *  Write a signed integer of 8 bits. 
         *
         * Write a signed integer of 8 bits.
         *
         * @param value the value to write. 
         *
         * @return the filter instance so that it is possible 
         * to chain action. 
         */
        bool write(int8 value);

        /**
         *  Write a signed integer of 8 bits. 
         *
         * Write a signed integer of 8 bits.
         *
         * @param value the value to write. 
         *
         * @return the filter instance so that it is possible 
         * to chain action. 
         */
        bool write(uint8 value);

        /**
         *  Write a signed integer of 16 bits. 
         *
         * Write a signed integer of 16 bits.
         *
         * @param value the value to write. 
         *
         * @return the filter instance so that it is possible 
         * to chain action. 
         */
        bool write(int16 value);

        /**
         *  Write an unsigned integer of 16 bits. 
         *
         * Write an unsigned integer of 16 bits.
         *
         * @param value the value to write. 
         *
         * @return the filter instance so that it is possible 
         * to chain action. 
         */
        bool write(uint16 value);

        /**
         *  Write a signed integer of 32 bits. 
         *
         * Write a signed integer of 32 bits.
         *
         * @param value the value to write. 
         *
         * @return the filter instance so that it is possible 
         * to chain action. 
         */
        bool write(int32 value);

        /**
         *  Write an unsigned integer of 32 bits. 
         *
         * Write an unsigned integer of 32 bits.
         *
         * @param value the value to write. 
         *
         * @return the filter instance so that it is possible 
         * to chain action. 
         */
        bool write(uint32 value);

        /**
         *  Write a signed integer of 64 bits. 
         *
         * Write a signed integer of 64 bits.
         *
         * @param value the value to write. 
         *
         * @return the filter instance so that it is possible 
         * to chain action. 
         */
        bool write(int64 value);

        /**
         *  Write an unsigned integer of 64 bits. 
         *
         * Write an unsigned integer of 64 bits.
         *
         * @param value the value to write. 
         *
         * @return the filter instance so that it is possible 
         * to chain action. 
         */
        bool write(uint64 value);
    
        /**
         *  Write a floatting point number of 32 bits. 
         *
         * Write a floatting point number of 32 bits.
         *
         * @param value the value to write. 
         *
         * @return the filter instance so that it is possible 
         * to chain action. 
         */
        bool write(real32 value);

        /**
         *  Write a floatting point number of 64 bits.
         *
         * Write a floatting point number of 64 bits. 
         *
         * @param value the value to write. 
         *
         * @return the filter instance so that it is possible 
         * to chain action. 
         */
        bool write(real64 value);
        /**
         *  Evaluate stream object for use in a condition. 
         * 
         * This function is used to check if the last operation was successfull. 
         * The result is 0 if the last operation failed or is another address 
         * otherwise. This address is not expected to be dereference but only 
         * tested to be different of 0.  
         *
         * @return 0 if an error occured another address otherwise. 
         */
        void* operator()() const;

        /**
         *  Evaluate stream object for use in a condition. 
         *
         * This function return true if an error occured previously. 
         *
         * @return true if an error occured false otherwise.
         */
        bool operator!() const; 

        /**
         *  Update the reader position for next operation. 
         *
         * Update the position of the next operation.  This is an
         * offset from the start of the stream.
         *
         * @param pos The offset from the begining of the file.
         *
         * @return the filter instance so that it is possible 
         * to chain action. 
         */
        bool seek(const std::streampos& pos);

        /**
         *  Update the reader position for next operation.
         * 
         * Update the postion of the next operation. relative to 
         * - std::beg The begining of the file 
         * - std::cur The current position 
         * - std::end The end of the file 
         * 
         * @param offset the offset from the current position  
         * @param dir the direction where to apply the offset
         * 
         * @return the filter instance so that it is possible 
         * to chain action. 
         */
        bool seek(const std::streamoff& offset, std::ios::seekdir dir);
            
        /**
         *  Get the position in bytes of the next operation. 
         * 
         * Return the offset of the next reading operation.
         *
         * @return The offset from the begining of the file. 
         */
        std::streampos tell();

        /**
         *  Flush the stream 
         */
        void flush(void);
    protected:

    private:
        /** Store a pointer to the underlying stream object */
        std::iostream *mStream;
        /** Disabled default constructor */
        LittleEndianStream(void); 
        /** Disabled copy constructor */
        LittleEndianStream(LittleEndianStream& src);
        /** Disabled assignment operator */
        LittleEndianStream& operator=(LittleEndianStream& src);
    };
}

#ifdef UTIL_OPT_INLINE
#  include "LittleEndianStream.icc"
#endif
#endif
/******************************************************************************/
 



