/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @ingroup util_application
* @file
* @brief Class LoggerFactory declaration 
*
*
* - Supports: All
* - Created: 2005-08-06
* - Creator: Olivier Delannoy
* - $Revision $
* - Changelog: 
*    
*    * 2005-08-06 : Initial version  
*******************************************************************************
Copyright Olivier Delannoy 2005

Olivier Delannoy <Olivier.Delannoy@gmail.com>

This software is a computer program whose purpose is to [describe
functionalities and technical features of your software].

This software is governed by the CeCILL  license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.

*******************************************************************************/
#ifndef UTIL_LOGGERFACTORY_HH
#define UTIL_LOGGERFACTORY_HH 1
#include "Factory.hh"
#include "Logger.hh"
namespace Util {
    class Config;
    // Backward Declaration 
    /**
     * @ingroup util_application
     * @brief  Create and share Logger 
     *  
     * This object create, configure and share logger for the whole application. 
     * It's a Factory in the Gang of Four convention 
     */
    class LoggerFactory : public Util::Singleton<LoggerFactory>
    {
    public:
        /** 
         * Default constructor
         */
        LoggerFactory(void);
        /**
         * Destructor
         */
        virtual ~LoggerFactory(void);
        /**
         * Init logger factory parameters and update all logger previously created. 
         * @param configName The name of the configuration file to use 
         * @param appName The name of the running application 
         *
         * @todo 
         * - Create the log dir if it does not exists this relies on the class Dir 
         * 
         */
        void init(const String& configName, const String& appName, const String& logDir);

        /** 
         * Retrieve the logger object based on its name 
         * @name loggerName This parameter is simply ignored 
         * @return the logger object 
         */
        Logger* create(const String& loggerName);

        using Util::Singleton<LoggerFactory>::getSingleton;
        using Util::Singleton<LoggerFactory>::getSingletonPtr;  
    protected:
       
    private:
        /** The single logger supported by the system*/
        Logger* mLogger;
        /** Flag to check for single initialization */
        bool mInit;
    };
}

/**
 * Log a debugging message 
 *
 * @param logger the string identifier of a logger 
 *
 * @param msg the message to send to the logger, it is send to the
 * destination throught operator<<. You do not have to put the initial
 * << and a final line ending is added automatically. message is used
 * the same as if it was in std::cout << message << std::endl. You
 * must terminate the macro with a semi column. 
 */
#define UTIL_DEBUG(logger, msg)                                  \
    UTIL_LOG(Util::LoggerFactory::getSingleton().create(logger), \
             Util::UTIL_DEBUG,                     \
             msg)
/**
 * Log a debugging assertion. if @em cond is false then the message will be displayed 
 *
 * @param logger the string identifier of a logger.
 *
 * @param cond evalute cond in order to check wether to display the
 * message or not. if cond is false the message will be displayed 
 *
 * @param msg the message to send to the logger, it is send to the
 * destination throught operator<<. You do not have to put the initial
 * << and a final line ending is added automatically. message is used
 * the same as if it was in std::cout << message << std::endl. You
 * must terminate the macro with a semi column. 
 *
 */
#define UTIL_DEBUG_ASSERT(logger, cond, msg)                \
    {                                                       \
        if (! (cond))                                       \
            UTIL_DEBUG(logger, #cond << ": " << msg);       \
    }

/**
 * Log an exception with level debug 
 *
 * @param logger the string identifier of a logger.
 * 
 * @param exception the class name of the exception to thrown.
 *
 * @param param the list of parameter of the exception surronded with paranthesis. 
 */
#define UTIL_DEBUG_EXCEPTION(logger, exception, param)                  \
    UTIL_DEBUG(logger, "Exception '" << #exception << "' has been thrown."); \
    throw exception param;

/**
 * Log a debugging message 
 *
 * @param logger the string identifier of a logger 
 *
 * @param msg the message to send to the logger, it is send to the
 * destination throught operator<<. You do not have to put the initial
 * << and a final line ending is added automatically. message is used
 * the same as if it was in std::cout << message << std::endl. You
 * must terminate the macro with a semi column. 
 */
#define UTIL_INFO(logger, msg)                                   \
    UTIL_LOG(Util::LoggerFactory::getSingleton().create(logger), \
             Util::UTIL_INFO,                      \
             msg)

/**
 * Log an information  assertion. if @em cond is false then the message is logged.
 *
 * @param logger the string identifier of a logger.
 *
 * @param cond evalute cond in order to check wether to display the
 * message or not. if cond is false the message will be displayed 
 *
 * @param msg the message to send to the logger, it is send to the
 * destination throught operator<<. You do not have to put the initial
 * << and a final line ending is added automatically. message is used
 * the same as if it was in std::cout << message << std::endl. You
 * must terminate the macro with a semi column. 
 *
 */
#define UTIL_INFO_ASSERT(logger, cond, msg)                \
    {                                                      \
        if (! (cond))                                      \
            UTIL_INFO(logger, #cond << ": " << msg);       \
    }

/** 
 * Log an exception with level information
 *
 * @param logger the string identifier of a logger.
 * 
 * @param exception the class name of the exception to thrown.
 *
 * @param param the list of parameter of the exception surronded with paranthesis. 
 */
#define UTIL_INFO_EXCEPTION(logger, exception, param)                   \
    UTIL_INFO(logger, "Exception '" << #exception << "' has been thrown."); \
    throw exception param;

/**
 * Log a warning message 
 *
 * @param logger the string identifier of a logger 
 *
 * @param msg the message to send to the logger, it is send to the
 * destination throught operator<<. You do not have to put the initial
 * << and a final line ending is added automatically. message is used
 * the same as if it was in std::cout << message << std::endl. You
 * must terminate the macro with a semi column. 
 */
#define UTIL_WARN(logger, msg)                                     \
    UTIL_LOG(Util::LoggerFactory::getSingleton().create(logger),   \
             Util::UTIL_WARN,                                      \
             msg)

/**
 * Log a warning assertion. if @em cond is false then abort the program.
 *
 * @param logger the string identifier of a logger.
 *
 * @param cond evalute cond in order to check wether to display the
 * message or not. if cond is false the message will be displayed 
 *
 * @param msg the message to send to the logger, it is send to the
 * destination throught operator<<. You do not have to put the initial
 * << and a final line ending is added automatically. message is used
 * the same as if it was in std::cout << message << std::endl. You
 * must terminate the macro with a semi column. 
 *
 */
#define UTIL_WARN_ASSERT(logger, cond, msg)                 \
    {                                                       \
        if (! (cond))                                       \
            UTIL_WARN(logger, #cond << ": " << msg);        \
    }

/** 
 * Log an exception with level warning
 *
 * @param logger the string identifier of a logger.
 * 
 * @param exception the class name of the exception to thrown.
 *
 * @param param the list of parameter of the exception surronded with paranthesis. 
 */
#define UTIL_WARN_EXCEPTION(logger, exception, param)                   \
    UTIL_WARN(logger, "Exception '" << #exception << "' has been thrown."); \
    throw exception param;

/**
 * Log an error message 
 *
 * @param logger the string identifier of a logger 
 *
 * @param msg the message to send to the logger, it is send to the
 * destination throught operator<<. You do not have to put the initial
 * << and a final line ending is added automatically. message is used
 * the same as if it was in std::cout << message << std::endl. You
 * must terminate the macro with a semi column. 
 */        
#define UTIL_ERROR(logger, msg)                                    \
    UTIL_LOG(Util::LoggerFactory::getSingleton().create(logger),   \
             Util::UTIL_ERROR,                                     \
             msg)
/**
 * Log a fatal assertion. if @em cond is false then abort the program.
 *
 * @param logger the string identifier of a logger.
 *
 * @param cond evalute cond in order to check wether to display the
 * message or not. if cond is false the message will be displayed 
 *
 * @param msg the message to send to the logger, it is send to the
 * destination throught operator<<. You do not have to put the initial
 * << and a final line ending is added automatically. message is used
 * the same as if it was in std::cout << message << std::endl. You
 * must terminate the macro with a semi column. 
 *
 */
#define UTIL_ERROR_ASSERT(logger, cond, msg)                \
    {                                                       \
        if (! (cond))                                       \
            UTIL_ERROR(logger, #cond << ": " << msg);       \
    }

/** 
 * Log an exception with level error
 *
 * @param logger the string identifier of a logger.
 * 
 * @param exception the class name of the exception to thrown.
 *
 * @param param the list of parameter of the exception surronded with paranthesis. 
 */
#define UTIL_ERROR_EXCEPTION(logger, exception, param)                  \
    UTIL_ERROR(logger, "Exception '" << #exception << "' has been thrown."); \
    throw exception param;

/**
 * Log a fatal error message and abort the execution.
 *
 * @param logger the string identifier of a logger 
 *
 * @param msg the message to send to the logger, it is send to the
 * destination throught operator<<. You do not have to put the initial
 * << and a final line ending is added automatically. message is used
 * the same as if it was in std::cout << message << std::endl. You
 * must terminate the macro with a semi column. 
 */   
#define UTIL_FATAL(logger, msg)                                         \
    UTIL_LOG(Util::LoggerFactory::getSingleton().create(logger),        \
             Util::UTIL_FATAL,                                          \
             msg)
/**
 * Log a fatal assertion. if @em cond is false then abort the program.
 *
 * @param logger the string identifier of a logger.
 *
 * @param cond evalute cond in order to check wether to display the
 * message or not. if cond is false the message will be displayed 
 *
 * @param msg the message to send to the logger, it is send to the
 * destination throught operator<<. You do not have to put the initial
 * << and a final line ending is added automatically. message is used
 * the same as if it was in std::cout << message << std::endl. You
 * must terminate the macro with a semi column. 
 *
 */
#define UTIL_FATAL_ASSERT(logger, cond, msg)                 \
    if (!(cond))                                             \
    {                                                        \
        UTIL_FATAL(logger, #cond << ": " << msg);            \
    }
#endif
/*******************************************************************************/      



