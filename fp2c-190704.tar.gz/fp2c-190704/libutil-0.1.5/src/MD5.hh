/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @file
* @ingroup util_tools
* @brief MD5 Class declaration 
*
* @note This file integrates code from the internet with a special
* license check if we can use this in our application or not.
*
* - Supports: All
* - Created: 2005-08-06
* - Creator: Olivier Delannoy
* - Changelog: 
*    
*    * 2005-08-06 : Initial version  
*******************************************************************************
@LICENSE@ 
*******************************************************************************/
/////////////////////////////////////////////////////////////////////////
// MD5.hh
// Implementation file for MD5 class
//
// This C++ Class implementation of the original RSA Data Security, Inc.
// MD5 Message-Digest Algorithm is copyright (c) 2002, Gary McNickle.
// All rights reserved.  This software is a derivative of the "RSA Data
//  Security, Inc. MD5 Message-Digest Algorithm"
//
// You may use this software free of any charge, but without any
// warranty or implied warranty, provided that you follow the terms
// of the original RSA copyright, listed below.
//
// Original RSA Data Security, Inc. Copyright notice
/////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 1991-2, RSA Data Security, Inc. Created 1991. All
// rights reserved.
//
// License to copy and use this software is granted provided that it
// is identified as the "RSA Data Security, Inc. MD5 Message-Digest
// Algorithm" in all material mentioning or referencing this software
// or this function.
// License is also granted to make and use derivative works provided
// that such works are identified as "derived from the RSA Data
// Security, Inc. MD5 Message-Digest Algorithm" in all material
// mentioning or referencing the derived work.
// RSA Data Security, Inc. makes no representations concerning either
// the merchantability of this software or the suitability of this
// software for any particular purpose. It is provided "as is"
// without express or implied warranty of any kind.
// These notices must be retained in any copies of any part of this
// documentation and/or software.
/////////////////////////////////////////////////////////////////////////
#ifndef UTIL_MD5_HH
#define UTIL_MD5_HH 1
#include "util_namespace.hh"
namespace Util 
{
    /**
     * @ingroup util_tools
     * @brief Computes MD5 Checksum 
     * 
     * This class provide MD5 Digest computation. The resulting digest
     * consists in 16 bytes of data. Multiple static methods are
     * provided in order to simplificate the life of the user to
     * compute file Digest, string digest and to convert digest to
     * string.
     */
    class MD5
    {
    public:
        /** 
         * Default Constructor 
         */
        MD5(void);
        /**
         * Destructor
         */
        ~MD5(void);
        /**
         * Init or reinit the internal state of the MD5 Digest 
         */
        void	init(void);
        /**
         * Update the current MD5 Digest computation 
         */
        void	update(byte* chInput, uint32 nInputLen);
        /**
         * Update the MD5 digest from file content  
         */
        void update(const String& fileName);
    
        /**
         * Finalize the computation of the MD5 Digest 
         */
        void	finalize(void);
        /**
         * Retrieve the MD5 digest byte array  
         * @return a 16 byte long MD5 digest 
         */
        byte*	getDigest(void); 


        /**
         * Convert an MD5 Digest to a printable string.
         * 
         * @param md5Digest an array of byte corresponding to a 16
         * bytes MD5 Digest.
         * 
         * @return the corresponding String object 
         */
        static String MD5ToString(byte md5Diggest[16]);
        /**
         * Get the MD5 Digest of a text.
         *
         * @param a text 
         * @return a visual representation of the MD5 Digest of text. All byte of the
         * Digest is represented in Hexadecimal notation.
         */
        static String stringToString(const String& text);
        /**
         * Compute the MD5 Digest of a file and return a string representation of the Digest 
         * 
         * @param fileName The name of the file 
         * @return a string representation of the Digest 
         */
        static String fileToString(const String& fileName);

    protected:
    private:
        /**
         * @internal 
         * Used to compute the MD5 Digest
         */
        void	Transform(byte* block);
        /**
         * @internal 
         * Used to compute the MD5 Digest
         */
        void	Encode(byte* dest, uint32* src, uint32 nLength);
        /**
         * @internal 
         * Used to compute the MD5 Digest
         */
        void	Decode(uint32* dest, byte* src, uint32 nLength);
        /**
         * @internal 
         * Used to compute the MD5 Digest
         */
        uint32	rotate_left(uint32 x, uint32 n);
        /**
         * @internal 
         * Used to compute the MD5 Digest
         */
        uint32	F(uint32 x, uint32 y, 
                                uint32 z);
        /**
         * @internal 
         * Used to compute the MD5 Digest
         */
        uint32	G(uint32 x, uint32 y, 
                                uint32 z);
        /**
         * @internal 
         * Used to compute the MD5 Digest
         */
        uint32	H(uint32 x, uint32 y, uint32 z);
        /**
         * @internal 
         * Used to compute the MD5 Digest
         */
        uint32	I(uint32 x, uint32 y, uint32 z);
        /**
         * @internal 
         * Used to compute the MD5 Digest
         */
        void FF(uint32& a, uint32 b, uint32 c, 
                uint32 d, uint32 x, uint32 s, 
                uint32 ac);  
        /**
         * @internal 
         * Used to compute the MD5 Digest
         */
        void GG(uint32& a, uint32 b, uint32 c, 
                uint32 d, uint32 x, uint32 s, 
                uint32 ac);
    
        /**
         * @internal 
         * Used to compute the MD5 Digest
         */
        void	HH(uint32& a, uint32 b, uint32 c, 
                 uint32 d, uint32 x, uint32 s, 
                 uint32 ac);
    
        /**
         * @internal 
         * Used to compute the MD5 Digest
         */
        void	II(uint32& a, uint32 b, uint32 c, 
                 uint32 d, uint32 x, uint32 s, 
                 uint32 ac);
    private:
        uint32		m_State[4];
        uint32		m_Count[2];
        byte		m_Buffer[64];
        byte		m_Digest[16];
        byte		m_Finalized;

        /** Disabled copy constructor */
        MD5(MD5& src);
        /** Disabled assignment operator */ 
        MD5& operator=(MD5& src);
    };
}
#ifdef UTIL_OPT_INLINE 
#include "MD5.icc"
#endif
#endif 
/*******************************************************************************/



