/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @ingroup util_application
* @file
* @brief Class CommandLineOption definition  
*  
* - Supports: All
* - Created: 2005-08-06
* - Creator: Olivier Delannoy
* - $Revision $
* - Changelog: 
*    
*    * 2005-08-06 : Initial version  
*******************************************************************************
@LICENSE@
*******************************************************************************/
#ifndef HAVE_CONFIG_H
#include "util_config.hh"
#endif
#include "CommandLineOption.hh"
#ifndef UTIL_OPT_INLINE
#define inline
#include "CommandLineOption.icc"
#undef inline 
#endif 
Util::CommandLineOption::CommandLineOption(void) 
    : mCount(0), mWithValue(false), mRequired(false)
{
  
}
Util::CommandLineOption::CommandLineOption(const Util::String& name, 
                                           const Util::String& defaultValue, 
                                           bool withValue, bool required) 
    : mCount(0), mName(name), mValue(defaultValue), 
      mWithValue(withValue), mRequired(required)
{
  
}
Util::CommandLineOption::~CommandLineOption(void)
{
  
}
bool Util::CommandLineOption::match(const Util::String& parameter)
{
    if (parameter[0] == '-' && parameter[1] == '-') 
    {
        uint32 size = mName.size();
        if (parameter.compare(2, size, mName) == 0)
        {
            // An option if of the form : --[name]=value
            if (mWithValue && parameter[2 + size] == '=')
            {
                mCount++;
                mValue = parameter.substr(3 + size);
                return true;
            }
            // Option is of the form: --[name]    
            else if (!mWithValue && parameter.size() == 2 + size)
            {
                mCount++;
                return true;
            }      
        }
    }
    return false;
}
void Util::CommandLineOption::print(std::ostream& out) const throw()
{
    out << "CommandLineOption<<<" << mName 
        << ',' << mCount 
        << ',' << mValue 
        << ',' << (mWithValue ? 'V' : ' ')
        << ',' << (mRequired ? 'R' : ' ')
        << ">>>";
}
/*******************************************************************************/
