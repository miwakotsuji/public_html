/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @file
 * @ingroup util_tools 
 * @brief Class StringList definitions 
 *  
 *
 * 
 * 
 * - Supports: All 
 * - Created: 2005-08-07
 * - Creator: Olivier Delannoy
 * - $Revision $
 * - Changelog: 
 *    
 *    * 2005-08-07 : Initial version  
 ******************************************************************************
@LICENSE@
 *******************************************************************************/
#include "StringList.hh"
#ifndef UTIL_OPT_INLINE
#define inline
#include "StringList.icc"
#undef inline
#endif 
Util::StringList::StringList(void)
{
}

Util::StringList::StringList(std::list<String >& src)
    : std::list<String>(src)
{
}
Util::StringList::~StringList(void)
{
    
}

Util::int32 Util::StringList::indexOf(const Util::String& string, Util::int32 fromIndex) const
{
    if (fromIndex >= 0) 
    {
        const_iterator iter = begin();
        const_iterator endIter = end();
        int32 i = 0;
        for(; iter != endIter ; ++iter, ++i) 
            if (i > fromIndex && *iter == string)
                return i;
    }
    else 
    {
        const_reverse_iterator iter = rbegin();
        const_reverse_iterator endIter = rend();
        fromIndex = - fromIndex + 1;
        int32 i = 0;
        for( ; iter != endIter ; ++iter, ++i) 
            if (i > fromIndex && *iter == string)
                return i;
    }
    return -1;
}

Util::String Util::StringList::join(const Util::String& separator) const
{
    String result;
    const_iterator iter = begin();
    if (iter != end())
    {    
        result = *iter;
        ++iter;
    }
    for(; iter != end(); ++iter)
    {
        result += separator;
        result += *iter;
    }
    return result;
}

void Util::StringList::print(std::ostream& out) const
{
    out << "StringList<<<";
    std::list<String>::const_iterator iter = begin();
    
    for(; iter != end() ; ++iter)
    {
        out << *iter << ',';
    }
    out << ">>>";
}
/*******************************************************************************/
