/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @file
* @ingroup util_system
* @brief TCPClient class declaration
*
* - Supports: 
*   - system: 
*     - UNIX (Linux)
*     - Win32 (XP)
* - Created: 2005-05-29
* - Creator: Olivier Delannoy
* - $Revision $
* - Changelog: 
*    * 2005-08-06 : Integrated to libutil 
*                   - Moved from Util::Compat namespace to Util
*    * 2005-05-29 : Initial version  
*******************************************************************************
@LICENSE@ 
*******************************************************************************/
#ifndef UTIL_TCPCLIENT_HH
#define UTIL_TCPCLIENT_HH 1
#include "TCPSocket.hh"
namespace Util {
    /**
     * @brief This class is used to connect to a server and sending
     * data to him.
     * 
     * - Supports: 
     *   - system: 
     *     - UNIX (Linux)
     *     - Win32 (XP)
     * - Created: 2005-05-29
     * - Creator: Olivier Delannoy
     * - $Revision $
     * - Changelog: 
     *    * 2005-08-06 : Integrated to libutil 
     *                   - Moved from Util::Compat namespace to Util
     *    * 2005-05-29 : Initial version  
     *
     * @todo Long documentation for this class 
     */
    class TCPClient : public Util::TCPSocket
    {
     public:
         /**
          * Default Constructor
          */
        TCPClient(const Util::String& host, Util::uint16 port);
         /**
          * Destructor 
          */
        virtual ~TCPClient(void);

        using Util::TCPSocket::send;
        using Util::TCPSocket::read;
        using Util::TCPSocket::recv;
        using Util::TCPSocket::write;
        using Util::TCPSocket::shutdown;
        
    protected:
    private:
    };
}
#endif
/*******************************************************************************/



