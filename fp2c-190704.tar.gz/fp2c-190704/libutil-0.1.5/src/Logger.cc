/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @ingroup util_application
* @file
* @brief Class CommandLineParser declaration   
*  
* - Supports: All
* - Created: 2005-08-07-02
* - Creator: Olivier Delannoy
* - $Revision $
* - Changelog: 
*    * 2005-08-07 : Moved to libutil 
*    * 2005-05-29 : Initial version 
*******************************************************************************
@LICENSE@
*******************************************************************************/
#include "Logger.hh"
#include <fstream>
#include <utility>
#include <cassert>
namespace Util
{
    
    const String Logger::DEFAULT_FORMAT = "%u-[%5m]-(%p)-<%10f:%l> ";
    NullStreambuf<char> Logger::mNullBuffer;
    std::ostream Logger::mIgnore(&mNullBuffer);
    
    Logger::Message::Message(const char* const file, 
                             int line, LoggingLevel level)
        : mHeader(file, line, level) 
    {
    }
    
    Logger::Logger() 
        : mLevel(DEFAULT_LEVEL), 
          mFormat(DEFAULT_FORMAT),
          mCacheMessage(true),
          mOut(0)
    {
    }

    Logger::~Logger(void)
    {
        if (mOut != &std::cout && mOut != &std::cerr)
            delete mOut;
    }
    void Logger::init(const String& fileName, LoggingLevel level, const String& format)
    {
        mLevel = level;
        mFormat = format;
        mOut = new std::ofstream(fileName.c_str());
        if (*mOut)
        {
            clearCache();
            mCacheMessage = false;
        }
        else 
        {
            delete mOut;
        }
    }
    void Logger::init(std::ostream* stream, LoggingLevel level, const String& format)
    {
        mLevel = level;
        mFormat = format;
        mOut = stream;
        clearCache();
        mCacheMessage = false;
    }
    std::ostream& Logger::message(const char * const file, int line, LoggingLevel level)
    {
        if (mCacheMessage)
        {
            mCache.push_back(Message(file, line, level));
            mOut = new std::ostringstream;
            return *mOut;
        }
        else 
        {
            std::ostream *res = &mIgnore;
            if (level >= mLevel)
            {
                res = mOut;
                LoggerHeader header(file, line, level);
                header.format(*res, mFormat);
            }
            return *res;
        }
    }
    void Logger::messageFinalize(LoggingLevel level) throw(Exception)
    {
        if (mCacheMessage)
        {
            *mOut << std::endl;
            mCache.back().mText = reinterpret_cast<std::ostringstream*>(mOut)->str();
            delete mOut;
            mOut = 0;
        }
        else if (level >= mLevel)
        {
            *mOut << std::endl;
        }

        if (level == UTIL_FATAL)
            throw Exception("Fatal event occured");
    }
    void Logger::clearCache(void)
    {
        std::vector<Message>::iterator iter = mCache.begin();
        for (; iter != mCache.end() ; ++iter)
        {
            if (iter->mHeader.level() >= mLevel)
            {
                iter->mHeader.format(*mOut, mFormat);
                *mOut << iter->mText;
            }
        }
        mCache.clear();
    }
}
