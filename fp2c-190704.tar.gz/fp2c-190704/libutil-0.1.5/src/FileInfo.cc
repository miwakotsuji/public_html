/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @file
* @ingroup util_system 
* @brief Class FileInfo definitions 
*  
*
* 
* 
* - Supports: 
*    - System 
*      - UNIX (Linux) 
*      - Win32 (XP)
* - Created: 2005-08-07
* - Creator: Olivier Delannoy
* - $Revision $
* - Changelog: 
*    
*    * 2005-08-07 : Integrated to libutil 
*          - Moved to Util namespace instead of Util::Compat 
*    * 2005-07-15 : Initial version 
******************************************************************************
@LICENSE@
*******************************************************************************/
#include "FileInfo.hh"
#ifndef UTIL_OPT_INLINE
#define inline
#include "FileInfo.icc"
#undef inline
#endif
#if defined(__WIN32__) || defined(_WIN32)
#  include <time.h>
#  include <sys/types.h>
#  include <sys/stat.h>
#  include <io.h>
#  define UTIL_STAT_STRUCT struct _stat
#  define UTIL_STAT(path, res) _stat(path, &res)
#  define UTIL_ACCESS(path, mode) _access(path, mode)
#  define UTIL_ACCESS_MODE_WRITE 2
#  define UTIL_ACCESS_MODE_READ 4
#  define UTIL_ACCESS_MODE_EXEC 0
#else 
#  include <sys/types.h>
#  include <sys/stat.h>
#  include <unistd.h>
#  define UTIL_STAT_STRUCT struct stat
#  define UTIL_STAT(path, res) stat(path, &res)
#  define UTIL_ACCESS(path, mode) access(path, mode)
#  define UTIL_ACCESS_MODE_WRITE W_OK
#  define UTIL_ACCESS_MODE_READ R_OK
#  define UTIL_ACCESS_MODE_EXEC X_OK
#endif 

Util::FileInfo::FileInfo(const Util::String& path)
    : mValid(false), mPath(path)
{
    update();
}
Util::FileInfo::~FileInfo(void)
{
    
}
void Util::FileInfo::update(void)
{

    UTIL_STAT_STRUCT fileStat;
    if (UTIL_STAT(mPath.c_str(), fileStat) == -1)
    {
        mValid = false;
    }
    else 
    {
        mValid = true;
        mSize = fileStat.st_size;
        mDir = S_ISDIR(fileStat.st_mode);
        mFile =  S_ISREG(fileStat.st_mode);
        mReadable = UTIL_ACCESS(mPath.c_str(), UTIL_ACCESS_MODE_READ) == 0;
        mWriteable = UTIL_ACCESS(mPath.c_str(), UTIL_ACCESS_MODE_WRITE) == 0;
        mExecutable = UTIL_ACCESS(mPath.c_str(), UTIL_ACCESS_MODE_EXEC) == 0;
    }
}
void Util::FileInfo::print(std::ostream& out) const
{
    out << "FileInfo<<<"
        << mPath 
        << ',' << (mDir ? 'd' : (mFile ? 'f' : '?')) 
        << ',' << (mReadable ? 'r' : ' ')
        << ',' << (mWriteable ? 'w' : ' ')
        << ',' << (mExecutable ? 'x' : 'w')
        << ',' << (mValid ? mSize : 0)
        << ">>>";
    
}
/*******************************************************************************/





