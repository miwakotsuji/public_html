/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @ingroup util_application 
 * @file
 * @brief Class Plugin Facotry definitions 
 *  
 * - Supports: All 
 * - Created: 2005-08-06
 * - Creator: Olivier Delannoy
 * - $Revision $
 * - Changelog: 
 *    
 *    * 2005-08-06 : Initial version  
 *******************************************************************************
@LICENSE@
 *******************************************************************************/
#include "PluginFactory.hh"
#include <cassert>
#include "RuntimeEnvironment.hh"
#include "Config.hh"
#include "ConfigFactory.hh" 
#include "LoggerFactory.hh"
#include "Application.hh"

Util::PluginFactory::PluginFactory(void) 
{
    UTIL_DEBUGUTIL("Start Plugin services");
}
Util::PluginFactory::~PluginFactory(void)
{
    UTIL_DEBUGUTIL("End Plugin services");
}
void Util::PluginFactory::addPluginPath(const Util::String& path)
{
    UTIL_DEBUG("default", "Adding '" << path << "' to the plugin search path");
    Plugin::addSearchPath(path);
    
}
/**
 * Create plugin object 
 */
Util::Plugin* Util::PluginFactory::createObject(const Util::String& name)
{
    
    Plugin* plug =  new Plugin();
    if (plug->open(name) == -1)
    {
        UTIL_ERROR("default", "Loading plugin '" << name << "' failed: " << plug->lastError());
        delete plug;
        return 0;
    }
    else
    {
        UTIL_DEBUG("default", "Loading plugin '" << name << "' successfull");
    }
    return plug;
}
/*******************************************************************************/      

