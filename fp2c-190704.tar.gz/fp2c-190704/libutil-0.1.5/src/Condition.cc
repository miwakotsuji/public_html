/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @ingroup util_system
 * @file
 * @brief Class Condition definitions 
 *  
 *
 * 
 * 
 * - Supports: 
 *   - System:
 *     - UNIX (Linux)
 * - Created: 2005-11-18
 * - Creator: Olivier Delannoy
 * - $Revision $
 * - Changelog: 
 *    
 *    * 2005-11-18 : Initial version  
 ******************************************************************************
@LICENSE@
 *******************************************************************************/
#include "Condition.hh"
#ifndef UTIL_OPT_INLINE
#define inline
#include "Condition.icc"
#undef inline
#endif 
#ifdef UTIL_OPT_SDL
#error "SDL Based ports not yet available" 
#elif defined(__WIN32__) || defined(_WIN32)
#error "Win32 ports not yet available" 
#else 
// UNIX Pthread 
#   include <pthread.h>
#endif 
#include <cassert> 


Util::Condition::Condition(void)
    : mImpl(0)
{
#if defined(UTIL_OPT_SDL)
#elif defined(__WIN32__) || defined(_WIN32)
#else 
    class LocalImpl : public ConditionImpl 
    {
    public:
        LocalImpl(void)
        {
            assert(pthread_mutex_init(&mMutex, 0) == 0);
            assert(pthread_cond_init(&mCond, 0) == 0);
            
        };
        virtual ~LocalImpl(void)
        {
            pthread_cond_destroy(&mCond);
            pthread_mutex_destroy(&mMutex);
        }
        virtual void lock(void)
        {
            assert(pthread_mutex_lock(&mMutex) == 0);
        }
        virtual void unlock(void)
        {
            assert(pthread_mutex_unlock(&mMutex) == 0);
        }
        virtual void wait(void)
        {
            assert(pthread_cond_wait(&mCond, &mMutex) == 0);
        }
        virtual void notify(void)
        {
            assert(pthread_cond_signal(&mCond) == 0);
            
        }
        virtual void notifyAll(void)
        {
            assert(pthread_cond_broadcast(&mCond) == 0);   
        }
    private:
        pthread_mutex_t mMutex;
        pthread_cond_t mCond;
    };
#endif
    mImpl = new LocalImpl;
    assert(mImpl);
}

Util::Condition::~Condition(void)
{
    delete mImpl;
}

/*******************************************************************************/
