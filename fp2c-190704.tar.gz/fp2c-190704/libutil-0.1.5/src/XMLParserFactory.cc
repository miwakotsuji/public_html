/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @file
 * @brief Class XMLParserFactory definitions 
 *  
 *
 * 
 * 
 * - Supports: All 
 * - Created: 2006-03-24
 * - Creator: Olivier Delannoy
 * - $Revision $
 * - Changelog: 
 *    
 *    * 2006-03-24 : Initial version  
 ******************************************************************************
@LICENSE@
 *******************************************************************************/
#ifdef HAVE_CONFIG_H
#include <util_config.hh>
#endif 
#include "XMLParserFactory.hh"
#include "XMLParserImpl.hh" 

// TinyXML 
#ifdef UTIL_OPT_HAVE_XML_TINY
#include "TinyXMLParser.hh"
#endif 

//Expat
#ifdef UTIL_OPT_HAVE_XML_EXPAT
#include "ExpatXMLParser.hh"
#endif 

//Xerces 
#ifdef UTIL_OPT_HAVE_XML_XERCES
#include "XercesXMLParser.hh"
#endif 
namespace Util
{
    XMLParserFactory::XMLParserFactory(void)
        : mDefault(0)
    {
#ifdef UTIL_OPT_HAVE_XML_XERCES 
        mParsers.push_back(new XercesXMLParser);
#endif
#ifdef UTIL_OPT_HAVE_XML_EXPAT
        mParsers.push_back(new ExpatXMLParser);
#endif
#ifdef UTIL_OPT_HAVE_XML_TINY
        mParsers.push_back(new TinyXMLParser);
#endif 
        // Default parser 
        XMLParserImplList::iterator iter;
        const String defaultParser(UTIL_OPT_XML_DEFAULT_PARSER);
        for(iter = mParsers.begin() ; iter != mParsers.end() ; ++iter) 
        {
            if ((*iter)->name() == defaultParser)
            {
                mDefault = *iter;
            }
        }
        if (!mDefault)
            mDefault = mParsers.front();
        assert(mDefault != 0);
    }
    XMLParserFactory::~XMLParserFactory(void)
    {
        XMLParserImplList::iterator iter;
        for(iter = mParsers.begin() ; iter != mParsers.end() ; ++iter)
        {
            (*iter)->cleanup();
            delete *iter;
        }
    }
    XMLParser XMLParserFactory::createByName(const String& parser)
    {
        UTIL_DEBUGUTIL("Create by name");
        XMLParserImplList::iterator iter;
        for(iter = mParsers.begin() ; iter != mParsers.end() ; ++iter)
        {
            if ((*iter)->name() == parser)
            {
                (*iter)->initialize();
                return XMLParser(*iter);
            }
        }
        mDefault->initialize();
        return XMLParser(mDefault);
    }
    XMLParser XMLParserFactory::create(XMLParserFlag flag)
    {
        if (flag != UTIL_XML_PARSER_DEFAULT)
        {
            XMLParserImplList::iterator iter;
            for(iter = mParsers.begin() ; iter != mParsers.end() ; ++iter)
            {
                // Look after a validating parser 
                if (flag & UTIL_XML_PARSER_VALIDATE && (*iter)->isValidating())
                {
                    (*iter)->initialize();
                    return XMLParser(*iter);
                }
            }
        }
        mDefault->initialize();
        return XMLParser(mDefault);
    }
}
/*******************************************************************************/
