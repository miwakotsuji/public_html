/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @ingroup util_system
 * @file
 * @brief Class Condition declaration
 *  
 * 
 * - Supports: 
 *   - System:
 *     - UNIX 
 * - Created: 2005-11-18
 * - Creator: Olivier Delannoy
 * - Last change in revision : $Revision $
 * - Changelog: 
 *    
 *    * 2005-11-18 : Initial version  
 ******************************************************************************
Copyright Olivier Delannoy 2005

Olivier Delannoy <Olivier.Delannoy@gmail.com>

This software is a computer program whose purpose is to [describe
functionalities and technical features of your software].

This software is governed by the CeCILL  license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.

 *******************************************************************************/
#ifndef UTIL_CONDITION_HH
#define UTIL_CONDITION_HH 1
#include "util_namespace.hh"
namespace Util 
{
    /**
     * @ingroup util_system
     * @brief Condition are used to contact a group of Thread and to lock 
     * them until an event occured. 
     *
     * Condition are the companion mecanism of mutexes. All synchornization
     * mecanisms can be implemented in terme of Mutex and Condition. 
     * 
     * - Supports: All
     * - Author: Olivier Delannoy
     * - Creator: 2005-11-18
     * - $Revision $
     */
    class UTIL_EXPORT Condition
    {
    public:
        /**
         * Constructor 
         */
        Condition(void);
        /**
         * Destructor 
         */
        ~Condition(void);
        /** 
         * lock the mutex associated to the condition 
         * @note wait/notify and notifyAll have to be enclosed in a lock/unlock block. 
         */
        void lock(void);
        /** 
         * unlock the mutex associated to the conditon 
         * @note wait/notify and notifyAll have to be enclosed in a lock/unlock block. 
         */ 
        /** 
         * Wait for the notification of the condition
         * @note wait/notify and notifyAll have to be enclosed in a lock/unlock block. 
         */
        void wait(void);
        /**
         * Notify the condition to one waiting thread 
         * @note wait/notify and notifyAll have to be enclosed in a lock/unlock block. 
         */
        void notify(void);
        /**
         * Notify the condition to all waiting thread 
         * @note wait/notify and notifyAll have to be enclosed in a lock/unlock block. 
         */
        void notifyAll(void);
    protected:
    private:
        /** 
         * @ingroup util_system
         * @brief Encapsulate implementation system wide implementation
         * 
         * This class provide all basic operation for system wide
         * Condition class implementation. The interface is similar to
         * the one available for condition. 
         */
        class ConditionImpl
        {
        public:
            
            virtual ~ConditionImpl(void) {}
            virtual void lock(void) = 0;
            virtual void unlock(void) = 0;
            
            virtual void wait(void) = 0;
            virtual void notify(void) = 0;
            virtual void notifyAll(void) = 0;
        protected:
            ConditionImpl(void) {}
            
                
        private:
            ConditionImpl(ConditionImpl&);
            ConditionImpl& operator=(ConditionImpl&);
        };    
        /** Store a pointer to the implementation */
        ConditionImpl* mImpl;
        /* disabled operation */
        Condition& operator=(Condition&);
        Condition(Condition&);
    };
}

#ifdef UTIL_OPT_INLINE
#include "Condition.icc"
#endif
#endif // UTIL_CONDITION_HH
/*******************************************************************************/



