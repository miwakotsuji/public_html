/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @file
* @ingroup util_system
* @brief TCPServer class declaration 
*
* - Supports: 
*   - system: 
*     - UNIX (Linux)
*     - Win32 (XP)
* - Created: 2005-05-29
* - Creator: Olivier Delannoy
* - $Revision $
* - Changelog: 
*    * 2005-08-06 : Integrated to libutil 
*    * 2005-05-29 : Initial version  
*******************************************************************************
@LICENSE@ 
*******************************************************************************/
#ifndef UTIL_TCPSERVER_HH
# define UTIL_TCPSERVER_HH 1
# include "TCPSocket.hh"
namespace Util {
    class TCPRemoteClient;
    /**
     * @brief TCP Server Socket 
     *
     * This class implements a TCP Server. It create an incomming
     * socket and provides the user application with a way to
     * handle incomming connexion. 
     *
     *
     * - Supports: 
     *   - system: 
     *     - UNIX (Linux)
     *     - Win32 (XP)
     * - Created: 2005-05-29
     * - Creator: Olivier Delannoy
     * - $Revision $
     * - Changelog: 
     *    * 2005-08-06 : Integrated to libutil 
     *    * 2005-05-29 : Initial version  
     */
    class TCPServer : public Util::TCPSocket
    {
    public:
        /**
         * Create a new TCPServer 
         */
        TCPServer(Util::uint16 port);
        /**
         * Destructor
         */
        virtual ~TCPServer(void);
        /** 
         * This call is blocking until a new client connect to the
         * socket. Once connected, it create a communication
         * socket between the client and the server. 
         */
        TCPRemoteClient* accept(void);
    protected:
        
    private:
        
    };
}
#endif
/*******************************************************************************/



