/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @file
* @brief Class XMLSerializer definitions 
*  
*
* 
* 
* - Supports: All 
* - Created: 2006-10-29
* - Creator: Olivier Delannoy
* - $Revision $
* - Changelog: 
*    
*    * 2006-10-29 : Initial version  
******************************************************************************
@LICENSE@
*******************************************************************************/
#ifndef HAVE_CONFIG_H
#include "util_config.hh"
#endif
#include "XMLSerializer.hh"
#ifndef UTIL_OPT_INLINE
#define inline
#include "XMLSerializer.icc"
#undef inline 
#endif 

namespace Util
{
    XMLSerializer::XMLSerializer(OutputStream& out, uint32 indentSpace)
        : mError(false), mDepth(0), mIndentSpace(indentSpace), 
          mNeedClose(false), mLastIsText(false), mStream(out)
    {
        mStream << String("<?xml version=\"1.0\" encoding=\"UTF-8\"?>") << std::endl;
        mError = ! mStream;
    }
    XMLSerializer::~XMLSerializer(void)
    {
        if (!mError)
        {
            mStream << std::endl;
        }
    }
    XMLSerializer& XMLSerializer::openTag(const String& name)
    {
        if (! mError)
        {
            if (mNeedClose)
            {
                mStream << '>';	  
            }
            if (!mLastIsText)
            {
                mStream << std::endl;
                indentLine();
            }
            mStream << '<' << name << ' ';
            mTagStack.push_back(name);
            ++mDepth;
            mNeedClose = true;
            mLastIsText = false;
            mError = !mStream;
        }
        return *this;
    }




    XMLSerializer& XMLSerializer::closeTag(void)
    {
        String back(mTagStack.back());
        if (! mError)
        {
            --mDepth;
            if (mNeedClose)
            {
                mStream << "/>" << std::endl;
            }
            else if (! mLastIsText)
            {
                mStream << std::endl;
                indentLine();
                mStream << "</" << back << '>';
            }
            else 
            {
                mStream << "</" << back << '>';
            }
            mLastIsText = false;
            mNeedClose = false;
            mTagStack.pop_back();
            mError = !mStream;
        }
        return *this;
    }


    XMLSerializer& XMLSerializer::attribute(const String& name, const String& value)
    {
        if (!mNeedClose)
        {
            mError = true;
      
        }
        if (!mError)
        {
            mStream << name << "=\"";
            exportData(value);
            mStream << "\" ";
            mLastIsText = false;
            mError = !mStream;
        }
        return *this;
    }


    XMLSerializer& XMLSerializer::text(const String& text)
    {
        if (! mError)
        {
            if (mNeedClose)
            {
                mStream << '>';
                mNeedClose = false;
            }
            exportData(text);
            mLastIsText = true;
            mError = !mStream;
        }
        return *this;
    }


    void XMLSerializer::indentLine(void)
    {
        size_t spaceCount = mDepth * mIndentSpace;
        for (size_t i = 0 ; i < spaceCount ; ++i)
        {
            mStream << ' ';
        }  
    }


    void XMLSerializer::exportData(const String& text)
    {
        String::const_iterator iter = text.begin();
        String::const_iterator iterEnd = text.end();
        for(;! mError && iter != iterEnd ; ++iter)
        {
            convertEntity(*iter);
        }
    }


    void XMLSerializer::convertEntity(String::value_type codePoint)
    {
        // Note: if the codePoint is greater than 127 we are not creating valid UTF-8 document... 
        switch(codePoint)
        {  
        case '<':
            mStream << "&lt;";
            break;
      
        case '>':
            mStream << "&gt;";
            break;
      
        case '&':
            mStream << "&amp;";
            break;

        case '\'':
            mStream << "&apos;";
            break;

        case '"':
            mStream << "&quot;";
            break;

        default:
            mStream << codePoint;
        }
        mError = !mStream;
    }
}
/*******************************************************************************/
