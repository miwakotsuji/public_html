/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @file
* @ingroup util_system
* @brief RuntimeEnvironement Class definition 
*
* - Supports: All
* - Created: 2005-05-29
* - Creator: Olivier Delannoy
* - Changelog: 
*    * 2005-08-06 : Integrated to libutil 
*                   - Moved from Util::Compat namespace to Util
*                   - Removed common directories static dirs 
*    * 2005-05-29 : Initial version  
*******************************************************************************
@LICENSE@ 
*******************************************************************************/
#include "RuntimeEnvironment.hh"
#include <cassert>
#include <cstdlib>

#include <time.h> //Linux, Win32 OK 
#include <sys/types.h> //Linux, Win32 OK 
#if defined(__WIN32__) || defined(_WIN32)
#  include<process.h>
#  include<direct.h>
#  define UTIL_GETENV(key) getenv(key.c_str())
#  define UTIL_PUTENV(key, value) _putenv((key + '=' + value).c_str())
#  define UTIL_GETPID() _getpid()
#  define UTIL_GETCWD(buffer, maxlen) _getcwd(buffer, maxlen)
#  define UTIL_CHDIR(path) _chdir(path.c_str())
#  define UTIL_PATH_SEPARATOR '\\'
#else
#  include <unistd.h> 
#  define UTIL_GETENV(key) getenv(key.c_str())
#  define UTIL_PUTENV(key, value) setenv(key.c_str(), value.c_str(), 1)
#  define UTIL_GETPID() getpid()
#  define UTIL_GETCWD(buffer, maxlen) getcwd(buffer, maxlen)
#  define UTIL_CHDIR(path) chdir(path.c_str())
#  define UTIL_PATH_SEPARATOR '/'
#endif  
Util::String Util::RuntimeEnvironment::env(const Util::String& name, 
                                           const Util::String& defValue)
{
    char *tmp = UTIL_GETENV(name);
    if (tmp)
        return tmp;
    return defValue;
}

void Util::RuntimeEnvironment::updateEnv(const Util::String& name, 
                                         const Util::String& value)
{
    UTIL_PUTENV(name, value);
}



Util::String Util::RuntimeEnvironment::workingDir(void)
{
    char  PWD_BUFFER[2048];
    assert(UTIL_GETCWD(PWD_BUFFER, 2048));
    return PWD_BUFFER;
}


void Util::RuntimeEnvironment::workingDir(const Util::String& dir)
{
    assert(UTIL_CHDIR(dir) == 0);
}

Util::uint32 Util::RuntimeEnvironment::processID(void)
{
    return UTIL_GETPID();
}

Util::int32 Util::RuntimeEnvironment::unixTime(void)
{
    return ::time(0);
}

const char Util::RuntimeEnvironment::PATH_SEPARATOR = UTIL_PATH_SEPARATOR;
/*******************************************************************************/

