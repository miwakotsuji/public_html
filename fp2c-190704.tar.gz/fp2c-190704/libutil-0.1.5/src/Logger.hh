/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @ingroup util_application
* @file
* @brief Class CommandLineParser declaration   
*  
* - Supports: All
* - Created: 2005-08-07-02
* - Creator: Olivier Delannoy
* - $Revision $
* - Changelog: 
*    * 2005-08-07 : Moved to libutil 
*    * 2005-05-29 : Initial version 
*******************************************************************************
Copyright Olivier Delannoy 2005

Olivier Delannoy <Olivier.Delannoy@gmail.com>

This software is a computer program whose purpose is to [describe
functionalities and technical features of your software].

This software is governed by the CeCILL  license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.

*******************************************************************************/
#ifndef UTIL_LOGGER_HH
#define UTIL_LOGGER_HH 1
#include "util_namespace.hh"
#include "NullStreambuf.hh" 
#include "Exception.hh" 
#include "LoggerHeader.hh" 
#include <iostream>
#include <vector> 
#include <sstream>
namespace Util {
    /**
     * @ingroup util_application
     * @brief A Logger is a runtime configurable message manager 
     * 
     * It's goal consists in determining according to the
     * configuration of the program which message must be displayed
     * and which one must'nt be displayed. It's a good tool to prevent
     * a lot of editing of the source code and to enable different
     * level of message according to the audience of a program. 
     * 
     *
     * Defining an efficient logger is quite difficult. And it's
     * always difficult to choose between functionnalities and
     * performance. We are really interested in having both. Ideally
     * we should do nothing when the message must not be
     * displayed. It's only possible at compile time. While this
     * behaviour is interesting we will try to allow both compile time
     * and runtime logger configuration. The problem of compile time
     * configuration is that it's permanent. There's no more option
     * without compiling again the whole application. We will so allow
     * both compile time and runtime configuration of the
     * Logger. Compile time option will cost nothing and will provides
     * the developer to disable at compile time a set of level. The
     * user can still configure it's logger for level that where not
     * disabled by developers. 
     * 
     * @see LoggerHeader, LoggerFactory
     */
    class Logger 
    {
    public:
        /**
         * Default constructor
         */
        Logger(void);        
        /**
         * Destructor 
         */
        ~Logger(void);
        /**
         * Init the logger and empty all cached message
         * All message are now directed to @em fileName  
         */
        void init(const String& fileName, LoggingLevel level = DEFAULT_LEVEL, const String& format = DEFAULT_FORMAT);
        /**
         * Init the logger and empy all cached message 
         * All message are now directed to @em stream 
         */
        void init(std::ostream* stream, LoggingLevel level = DEFAULT_LEVEL, const String& format = DEFAULT_FORMAT);
        /**
         * Log a message
         * 
         * @param file The file from which the message comes 
         * @param line The line from which the message comes 
         * @param level The level of the message 
         *   - DEBUG: for debugging messages 
         *   - INFO: for information messages 
         *   - WARN: for warning messages 
         *   - ERROR: for error messages 
         *   - FATAL: for fatal messages.  
         * @return a stream for outputing the message 
         */
        std::ostream& message(const char * const file, int line, LoggingLevel level);
        /**
         * Terminate the log message 
         */ 
        void messageFinalize(LoggingLevel level) throw(Exception);
        /** Default logging level */
        static const LoggingLevel DEFAULT_LEVEL = UTIL_INFO;
        /** Default Message format */
        static const String DEFAULT_FORMAT;
    protected:
    private:
        /** Clear cache */ 
        void clearCache(void);
        /** 
         * This struct store message cached 
         */ 
        struct Message 
        {
            /** 
             * Constructor 
             */
            Message(const char* const file, int line, LoggingLevel level);
            LoggerHeader mHeader; /**< The header information */ 
            String mText; /** Text of the message  */   
        };
        
        /** The level of accepted messages */
        LoggingLevel mLevel;
        /** The format of a messages */
        String mFormat;
        /** Store whether to cache message or not */ 
        bool mCacheMessage;
        /** Store cached message */
        std::vector<Message > mCache;
        /** A pointer to a dummy stream */
        static std::ostream mIgnore;
        /** The streambuffer used for mIgnore */ 
        static Util::NullStreambuf<char> mNullBuffer;
        /**  A pointer to the stream to log to */
        std::ostream* mOut;
        /* Disabled Copy Constructor */
        Logger(Logger& src);
        /* Disabled assignment operator */
        Logger& operator=(Logger& src);
    };
}
/**
 * This macro is used to hide the complexity of logging a message You
 * should always use this macro to log a message.  LoggerFactory
 * provide advance logging features prefer macro of the form
 * UTIL_DEBUG...., UTIL_INFO..., etc. 
 */
#define UTIL_LOG(loggerPtr, level, data)                                \
    {                                                                   \
        (loggerPtr)->message(__FILE__, __LINE__, level)                 \
            << data;                                                    \
        (loggerPtr)->messageFinalize((level));                          \
    }
#endif 
/*******************************************************************************/      



