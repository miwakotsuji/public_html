/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @ingroup util_application
* @file
* @brief Abstract Class ConsoleApplicationAdaptor declaration
*  
* - Supports: 
*   - system
*     - UNIX (Linux) 
*
* - Created: 2005-08-06
* - Creator: Olivier Delannoy
* - Changelog: 
*    * 2005-08-06: Moved to Util  
*    * 2005-07-08: Initial version  
*******************************************************************************
@LICENSE@
*******************************************************************************/
#include "ConsoleApplicationAdaptor.hh"
#ifndef UTIL_HAVE_INLINE
#define inline
#include "ConsoleApplicationAdaptor.icc"
#undef inline
#endif 

Util::ConsoleApplicationAdaptor::ConsoleApplicationAdaptor(bool mergeOutErr) 
    : mIn(&std::cin), mOut(&std::cout), mErr(&std::cerr)
{
    if (mergeOutErr)
    {
        //std::cerr.close();
        mErr = mOut;
    }
}

Util::ConsoleApplicationAdaptor::~ConsoleApplicationAdaptor(void)
{
    
}

void Util::ConsoleApplicationAdaptor::displayNotification(const Util::String& message, Util::NotificationType notificationType)
{
    String prefix;
    
    switch(notificationType)
    {
    case UTIL_NOTIFICATION_ERROR:
        prefix="Error";
        break;

    case UTIL_NOTIFICATION_EXCEPTION:
        prefix="Exception";
        break;

    case UTIL_NOTIFICATION_USAGE:
        prefix="Usage";
        break;
            
    case UTIL_NOTIFICATION_VERSION:
        prefix="Version Information" ;
        break;
        
    default:
        prefix="Message";
    }
    out() << "------------------------------------------" << std::endl;
    out() << "--" << prefix << std::endl;
    out() << "------------------------------------------" << std::endl;
    out() << message  << std::endl;
    out() << "------------------------------------------" << std::endl;
}
/******************************************************************************/
