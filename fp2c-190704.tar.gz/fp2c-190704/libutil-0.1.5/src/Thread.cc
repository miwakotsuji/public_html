/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @ingroup util_system
 * @file
 * @brief Class Thread definition 
 *  
 * Provide a Thread class implementation  
 * - Supports:
 *   - System 
 *       - UNIX/Pthread 
 *       - Win32 
 *   - SDL 
 * 
 * - Created: 2005-08-06
 * - Creator: Olivier Delannoy
 * - Changelog: 
 *
 *    * 2005-08-06 : Initial version  
 */
/*******************************************************************************
@LICENSE@
 *******************************************************************************/
#include "Thread.hh" 
#include <cassert>
#ifndef UTIL_OPT_INLINE 
#define inline
#include "Thread.icc"
#undef inline
#endif 
#include <sstream>
#if defined(UTIL_OPT_SDL)
#  include <SDL.h>
#  include <SDL_thread.h>
#elif defined(__WIN32__) || defined(_WIN32)
#  include <windows.h>
#  include <process.h>
#else
#  include <pthread.h>
#endif

Util::Thread::Thread(void) 
    : mIdentifier(),
      mState(THREAD_WAITING), 
      mImpl(0)     
{
#if defined(UTIL_OPT_SDL)
    // SDL Based Thread 
    Thread * tmp = this;
    class LocalImpl : public ThreadImpl
    {
    public:
        static int runImpl(Thread* obj)
        {
            obj->mState = THREAD_RUNNING;
            obj->mIdentifier = obj->mImpl->identifier();
            obj->run();
            obj->mState = THREAD_FINISHED;
            return 0;
        }
        
        virtual void start(Thread* obj)
        {
            mThread = SDL_CreateThread((int(*)(void*))runImpl, obj);
        }
        
        virtual void interrupt(void)
        {
            SDL_KillThread(mThread);
            SDL_WaitThread(mThread, 0); // Free all memory
        }
        
        virtual void join(void)
        {
            SDL_WaitThread(mThread, 0);
        }
        
        virtual String identifier(void)
        {
            std::ostringstream out;
            out << SDL_GetThreadID(mThread);
            return out.str();
        }
    private:
        SDL_Thread* mThread;
    };
#elif defined(__WIN32__) || defined(_WIN32) 
    // Win32 Thread 
    class LocalImpl : public ThreadImpl
    {
    public:
        static void runImpl(Thread* obj)
        {
            obj->mState = THREAD_RUNNING;
            obj->mIdentifier = obj->mImpl->identifier();
            obj->run();
            obj->mState = THREAD_FINISHED;
       	    //_endThread(); 
	}
        
        virtual void start(Thread* obj)
        {
            mThread = (HANDLE)_beginthread((void(*)(void*))runImpl, 0, obj);
        }
        
        virtual void interrupt(void) 
        {
            CloseHandle(mThread);
            WaitForSingleObject( mThread, INFINITE );
        }
        
        virtual void join(void) 
        {
            WaitForSingleObject( mThread, INFINITE );
        }
        
        virtual String identifier(void) 
        {
            std::ostringstream out;
            out << mThread; // Might be something quite strange ... to be checked. 
            return out.str();
        }
        
    private:
        HANDLE mThread;
    };
#else 
    // Pthread 
    class LocalImpl : public ThreadImpl
    {
    public:
        static void* runImpl(Thread *obj)
        {
            obj->run();
            return 0;
        }
        virtual void start(Thread* obj)
        {
            obj->mState = THREAD_RUNNING;
            obj->mIdentifier = obj->mImpl->identifier();
            // We should do some error reporting 
            pthread_create(&mThread, 0, (void*(*)(void*))runImpl, obj);
            obj->mState = THREAD_FINISHED;
        }
        virtual void interrupt(void)
        {
            pthread_cancel(mThread);
            pthread_join(mThread, 0);
        }
        virtual void join(void)
        {
            pthread_join(mThread, 0);
        }
        virtual String identifier(void)
        {
            return "";
            
            std::ostringstream out;
            out << mThread;
            return out.str();
        }
    private:
        pthread_t mThread;
    };
#endif
    mImpl = new LocalImpl();
}

Util::Thread::~Thread(void)
{
    mImpl->join();
    delete mImpl;
}

void Util::Thread::print(std::ostream& out) const
{
    out << "THREAD<<<" << mIdentifier << ">>>";
}
/******************************************************************************/


