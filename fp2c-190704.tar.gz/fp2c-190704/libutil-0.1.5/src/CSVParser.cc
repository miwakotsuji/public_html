/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @file
* @brief Class CSVParser definitions 
*  
*
* 
* 
* - Supports: All 
* - Created: 2006-03-03
* - Creator: Olivier Delannoy
* - $Revision $
* - Changelog: 
*    
*    * 2006-03-03 : Initial version  
******************************************************************************
@LICENSE@
*******************************************************************************/
#include "CSVParser.hh"
#include <cstdio>
#include <cctype>
namespace Util 
{
CSVParser::CSVParser(void)
{
}
CSVParser::~CSVParser(void)
{
}
void CSVParser::parse(CSVHandler& handler, const String& filename, char separator)
{    
    FILE* data = fopen(filename.c_str(), "rb");
    if (! data)
    {
        // ERROR File do not exists or cannot be read 
        return;
    }
    if (fseek(data, 0, SEEK_END) == -1)
    {
        // ERROR while reading the file 
        fclose(data);
        return;
    }
    long size = ftell(data);
    if (size == -1)
    {
        // ERROR getting the size of the file 
        fclose(data);
        return;
    }
    if (size == 0)
    {
        // File empty (not an error) 
        fclose(data);
        return;
    }
    rewind(data);
    // Allocate memory 
    byte* array = new byte[size];
    if (! array)
    {
        // Error memory allocation failed 
        fclose(data);
        return;
    }
    ssize_t status = fread(reinterpret_cast<char*>(array), 1, size, data);
    if (status == -1)
    {
        // Error reading the file 
        delete [] array;
        fclose(data);
        return;
    }
    if (status != size)
    {
        // Error reading the file 
        delete [] array;
        fclose(data);
        return;
    }
    parse(handler, array, size, separator);
    delete [] array;
    fclose(data);
}


void CSVParser::parse(CSVHandler& handler, const byte* data, uint32 size, char separator)
{
    // This function need to be updated to support the result produce by CSVSerializer : 
    // Each cell start with " and finished with a " cells are separated by a separator 
    // if a cell contains a " it is encoded "" 
    
    
    CSVHandler* pHandler = &handler;
    uint32 row = 1;
    uint32 col = 1;
    String value;
    int inquote = 0;
    int eol = 1;
    bool empty = 1;
    for(uint32 i = 0 ; i < size ; ++i)
    {
        switch(data[i])
        {
        case '"':
            if (inquote && data[i+1] == '"')
            {
                ++i;
                value += '"';    
            }
            else 
            {   
                inquote = 1 - inquote;
                if (eol && !empty)
                {
                    pHandler->rowStart();
                    //value.clear();
                    eol = 0;
                    empty = 0;
                }
            }
            break;

        case '\n':
            if (! empty)
            {
                if (! value.empty())
                    pHandler->cell(value);
                pHandler->rowEnd();
            }
            value.clear();
            col = 1;
            ++row;
            eol = 1;
            empty = 1;
            break;

        default:
            if (eol && !empty)
            {
                pHandler->rowStart();
                //value.clear();
                eol = 0;
                empty = 0;
            }
            if (data[i] == separator)
            {
                empty = 0;
                if (! inquote)
                {
                    pHandler->cell(value);
                    value.clear();
                    ++col;
                }
                else
                {
                    value += data[i];
                }
            }
            else 
            {
                if (! isspace(data[i]))
                    empty = 0;
                value += data[i];
            }
        }
    }
    if (!eol && !empty)
    {
        pHandler->cell(value);
        pHandler->rowEnd();
    }
}
}
/*******************************************************************************/
