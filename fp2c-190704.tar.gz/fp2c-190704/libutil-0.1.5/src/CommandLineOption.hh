/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @ingroup util_application
* @file
* @brief Class CommandLineOption declaration  
*  
* - Supports: All
* - Created: 2005-08-06
* - Creator: Olivier Delannoy
* - $Revision $
* - Changelog: 
*    
*    * 2005-08-06 : Initial version  
*******************************************************************************
Copyright Olivier Delannoy 2005

Olivier Delannoy <Olivier.Delannoy@gmail.com>

This software is a computer program whose purpose is to [describe
functionalities and technical features of your software].

This software is governed by the CeCILL  license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.

*******************************************************************************/
#ifndef UTIL_COMMANDLINEOPTION_HH
#define UTIL_COMMANDLINEOPTION_HH 1
#include "util_namespace.hh"
#include <iostream>
namespace Util {
    /**
     * @ingroup util_application
     * @brief Command Line Option class 
     * 
     * A Command line option defines an allowed option on the command
     * line It provide the user with a way to interact with the
     * application An option is of the form --[option-name](=value). All
     * option should be set before a special option '--' which denotes
     * the end of the option list. Options are all presents before the
     * parameter list.
     * @see CommandLineParser
     */
    class CommandLineOption
    {  
    public:
        /**
         * Default Constructor
         */
        CommandLineOption(void);    
        /**
         * Constructor
         * @param name The name of the option 
         * @param defaultValue The default value associated to the option 
         * @param withValue True if the option expects a value 
         * @param required True if the option is requiered
         */
        CommandLineOption(const String& name, const String& defaultValue = "", 
                          bool withValue = false, bool required = false);
        /**
         * Destructor
         */
        ~CommandLineOption(void);
        /**
         * Check if the option correspond to this object and if it's the case handle it. 
         * @param option the parameter string from the command line
         * @return true if the @em option match this instance. 
         */
        bool match(const String& parameter);
        /**
         * Set the name of the option.
         * @param name The new name of the option.
         */
        void name(const String& name);
        /**
         * Get the name of the option.
         * @return a string with the name of the option.
         */
        const String& name(void) const;
        /**
         * Set the value of the option. 
         * @param value The new value.
         */
        void value(const String& value);
        /**
         * Get the value of the option.
         * @return a string containing the value 
         */
        const String& value(void) const;
        /**
         * Tell whether the option should have a value or not 
         * @param withValue true if the option require a parameter
         */
        void valueFlag(bool withValue);
        /**
         * Retrieve the withValue flag 
         * @return true if the option expect a parameter.
         */
        bool hasValue(void) const;
        /**
         * Tell whether the option is required or not 
         * @param required true if the option is required 
         */
        void requiredFlag(bool required);
        /**
         * Retrieve the required state of the option 
         * @return true if the option is required 
         */
        bool isRequired(void) const;
        /**
         * Retrieve the number of time this option has been seen 
         * @return The number of time this option was present on the command line 
         */
        uint32 count(void) const;
        /**
         * Printout the current object to @em out 
         */
        void print(std::ostream& out) const throw();
    protected:
    private:
        /** Store the number of time this option has match */
        uint32 mCount;
        /** Store the name of this option */
        String mName;
        /** Store the value associated to an option */
        String mValue;
        /** True if a value is required for this option */
        bool mWithValue;
        /** True if this is a required option */
        bool mRequired;
    };
}
std::ostream& operator<<(std::ostream& out, const Util::CommandLineOption& obj);
#ifdef UTIL_OPT_INLINE
#include "CommandLineOption.icc"
#endif
#endif 
/*******************************************************************************/



