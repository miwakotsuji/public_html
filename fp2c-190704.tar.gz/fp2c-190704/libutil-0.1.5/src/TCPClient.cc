/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @file
* @ingroup util_system
* @brief TCPClient class definition 
*
* - Supports: 
*   - system: 
*     - UNIX (Linux)
*     - Win32 (XP)
* - Created: 2005-05-29
* - Creator: Olivier Delannoy
* - $Revision $
* - Changelog: 
*    * 2005-08-06 : Integrated to libutil 
*                   - Moved from Util::Compat namespace to Util
*    * 2005-05-29 : Initial version  
*******************************************************************************
@LICENSE@ 
*******************************************************************************/
#include "TCPClient.hh"
Util::TCPClient::TCPClient(const Util::String& host, Util::uint16 port)
    : TCPSocket(host, port)
{
    connect();
}

Util::TCPClient::~TCPClient(void)
{
    
}
/*******************************************************************************/
