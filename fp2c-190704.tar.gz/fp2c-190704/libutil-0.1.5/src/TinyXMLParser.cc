/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @file
* @brief Class TinyXMLParser definitions 
*  
* 
* - Supports: All 
* - Created: 2005-08-10
* - Creator: Olivier Delannoy
* - $Revision $
* - Changelog: 
*    
*    * 2005-08-10 : Initial version  
******************************************************************************
@LICENSE@
*******************************************************************************/
#include "TinyXMLParser.hh"
namespace Util
{    
    TinyXMLParser::TinyXMLParser(void)
        : XMLParserImpl("TinyXMLParser", false), mHandler(0)
    {   
    }
    TinyXMLParser::~TinyXMLParser(void)
    {
    }
    void TinyXMLParser::parse(XMLHandler& handler, const ByteArray& data, const ByteArray* const xsd) throw (XMLParseException)
    {
        mHandler = &handler;
        Tiny::TiXmlDocument doc;
        doc.Parse(reinterpret_cast<const char*>(data.data())); // Check this
        if (doc.Error())
        {
            throw XMLParseException(doc.ErrorRow(), doc.ErrorCol(), doc.ErrorDesc());
        }
        const Tiny::TiXmlElement* currElement = doc.RootElement();
        if (currElement)
        {
            processElement(currElement);
        }
    }


    void TinyXMLParser::processElement(const Tiny::TiXmlElement* element)
    {
        Properties props;
        const Tiny::TiXmlAttribute* currAttr = element->FirstAttribute();
    
        while(currAttr)
        {
            props.add(currAttr->Name(), currAttr->Value());
            currAttr = currAttr->Next();
        }
        
        mHandler->elementStart(element->Value(), props);
        const Tiny::TiXmlNode* node = element->FirstChild();
        while(node)
        {
            switch(node->Type())
            {
            case Tiny::TiXmlNode::ELEMENT:
                processElement(node->ToElement());
                break;
            case Tiny::TiXmlNode::TEXT:
                processText(node->ToText());
                break;
            }
            node = node->NextSibling();
        }
        mHandler->elementEnd(element->Value());
    }
    void TinyXMLParser::processText(const Tiny::TiXmlText* text)
    {
        //Ajouter des options au handler pour la gestion du text 
        mHandler->text(text->Value());
    }
    bool TinyXMLParser::initializeImpl(void)
    {
        Tiny::TiXmlDocument::SetCondenseWhiteSpace(false);
        return true;
    }
    void TinyXMLParser::cleanupImpl(void)
    {
    }
}
/*******************************************************************************/
