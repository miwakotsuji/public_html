/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @ingroup util_application 
 * @file
 * @brief Class Application declarations 
 *  
 * This file defines the core set of features of the application
 * framework.
 *
 * - Supports: All 
 * - Created: 2005-08-06
 * - Creator: Olivier Delannoy
 * - $Revision $
 * - Changelog: 
 *    
 *    * 2005-08-06 : Initial version  
 *******************************************************************************
Copyright Olivier Delannoy 2005

Olivier Delannoy <Olivier.Delannoy@gmail.com>

This software is a computer program whose purpose is to [describe
functionalities and technical features of your software].

This software is governed by the CeCILL  license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.

 *******************************************************************************/
#ifndef UTIL_APPLICATION_HH
#define UTIL_APPLICATION_HH 1
#include "util_namespace.hh"
#include "ApplicationAdaptor.hh"
#include "Singleton.hh" 
#include "Exception.hh"
#include <cassert>
#include <cstdlib>

namespace Util {
    class ConfigFactory;
    class LoggerFactory;
    class PluginFactory;
    class CommandLineParser;
    class CommandLineOption;
    
    /**
     * @brief Application Abstract Class 
     * 
     * The Application class provide us with a common environment for
     * defining applications based on the Application Framework. 
     * 
     * This framework integrates mecanisms to deals with command line parameters, 
     * Loggers, and many more services.
     *
     */
    class Application : public Singleton<Application>
    {
    public:
        /**
         * Default Constructor 
         *
         * @param adaptor Adaptor class used to hide platforms specific
         * behaviour concerning output streams 
         * 
         * @param argc The number of command line parameters available 
         * @param argv An array of c string describing the command line. 
         */
        explicit Application(ApplicationAdaptor* adaptor, int argc, char **argv);
        /** 
         * Destructor 
         */
        virtual ~Application(void);
        /**
         * Retrieve the base name of the application 
         * @return the clean name of the application. 
         */
        const String& baseName(void) const throw(); 

        /**
         * Execute the application and way for its termination 
         *
         * @return The return code of the application 
         */
        uint32 execute(void);


        /**
         * Retrieve command Line option 
         * 
         * @param name The name of the option 
         *
         * @return A pointer to the option object or 0 if the option
         * was not found.
         */
        CommandLineOption* option(const String &name);
        
        /**
         * Retrieve Command Line parameter at @em index
         * @param index the rank of the parameter 
         * @return a string corresponding to the @em index parameter
         */
        const String& parameter (uint32 index) const throw(OutOfBoundException);
        
        /** 
         * Retrieve the number of parameters available 
         * @return the number of parameters 
         */
        uint32 parameters(void) const;
        /**
         * Give access to the standard input stream
         */
        std::istream& in(void);
        /**
         * Give access to the standard output stream
         */
        std::ostream& out(void);
        
        /** 
         * Give access to the standard error stream
         */
        std::ostream& err(void);
        
        /** Use this return value if the application terminate successfully */
        static const uint32 SUCCESS;
        /** Use this return value if the application terminate with an error */
        static const uint32 ERROR;

        
        using Singleton<Application>::getSingleton;
        using Singleton<Application>::getSingletonPtr;
    protected:
        /**
         * Put the code of your application here.
         * 
         * @return The return value should be one of : 
         * - Util::Application::SUCCESS corresponding to a successfull computation.
         * - Util::Application::ERROR corresponding to a computation with error.
         *
         * @note Subclass must provide this method.
         */
        virtual uint32 run(void) = 0;
        /**
         * Define the command line options and parameter requirement
         * for your application. 
         * 
         * @note to accept parameter you should redefine this methods
         * as well as the usage(void) method in derived class 
         */
        virtual void configureCommandLine(void);    
        /**
         * Return a string containing a formated usage string for this
         * program.  The default message print common option
         * 
         * @return A string describing the command line paramter of this program 
         */
        String usage(void) const;
        /**
         * Return a string describing options added by the
         * configureCommandLine() function. This message is composed
         * of the result of the three function : usageQuick(),
         * usageOptions(), usageParameters(). 
         * It display something like : 
         * <pre>
         * usage: [basename] <options> usageQuick()
         *   --usage.........: print this message 
         *   --help..........: print this message 
         *   --version.......: display the program version 
         *   --config=file...: the name of the default configuration file 
         *   --config-dir=dir: the name of the configuration folder 
         *   --log-dir=dir...: directory containing the log files
         * usageOptions()
         *  
         * Options marks with a * are required options 
         *
         * usageParameters()
         * </pre>  
         * @return a string containings all options 
         */
        virtual String usageOptions(void) const;
        /**
         * Return the program call command line pattern 
         * 
         * @return a string containing the command line pattern 
         */
        virtual String usageQuick(void) const;
        /**
         * Return a parameter list description 
         *
         * @return a string describing all command line parameters. 
         */
        virtual String usageParameters(void) const;
        /**
         * Return a string containing a formated version string for this program. 
         *
         * @todo Implement version information collecting
         * 
         * @return A string describing the version of the program 
         */
        String version(void) const;
        /**
         * Display the program usage 
         * 
         * @note this function must be
         * overloaded in the derived classes.
         * The message is obtained throught a call to usage(void)
         */
        virtual void displayUsage(void);
        /**
         * Display the program version 
         * 
         * @note this function must be overloaded in the derived classes. 
         * The message is obtained throught a call to version(void)
         */
        virtual void displayVersion(void);
        /**
         * This method return the name of the master configuration file baseName
         */
        virtual String configName(void) const;
        /**
         * This method return the path of configuration files 
         */
        virtual String configDir(void) const ;
        /** 
         * This method return the name of the loggers configuration file
         */
        virtual String loggersConfigName(void) const ;
        /** 
         * This method return the path to the logging files 
         */
        virtual String loggersDir(void) const ;
        /**
         * This method return the path to the plugins 
         */
        virtual String pluginDir(void) const ;
        

        /** Command Line Parser */
        CommandLineParser *mCmdLineParser;
   private:              
        /** Store the basename of the application */
        String mBaseName;
        /** Loggers factory */ 
        LoggerFactory *mLoggers;
        /** Configuration file factory */
        ConfigFactory *mConfigs;
        /** Plugins factory */
        PluginFactory *mPlugins;
        /** Application Adaptator Pointer */
        ApplicationAdaptor* mAdaptor;
    };
}
/**
 * This macro give a direct access to the input stream of the application
 */
#define UTIL_IN() Util::Application::getSingleton().err()
/**
 * This macro give a direct access to the output stream of the application 
 */
#define UTIL_OUT() Util::Application::getSingleton().out() 
/**
 * This macro give a direct access to the error stream of the application 
 */
#define UTIL_ERR() Util::Application::getSingleton().err()
// This macro is the only exception to the rules of the Utility library codings.
/**
 * Define the entry point of the program in a portable way both on
 * linux and windows. At not the current macro start a console
 * application. both on linux and Windows 
 */
#if defined(__WIN32__) || defined(_WIN32)
#  define UTIL_APPLICATION(ApplicationClass, adaptor)               \
    int main(int argc, char** argv)                                 \
    {                                                               \
        Util::ApplicationAdaptor* appAdaptor = new adaptor;         \
        if (! appAdaptor)                                           \
        {                                                           \
            std::cerr << "Unable to create ApplicationAdaptor: "    \
                      << #adaptor << std::endl;                     \
            return EXIT_FAILURE;                                    \
        }                                                           \
        Util::Application* application;                             \
        application = new ApplicationClass(appAdaptor, argc, argv); \
        if (! application)                                          \
        {                                                           \
            std::cerr << "Unable to create Application object: "    \
                      << #ApplicationClass << std::endl;            \
            return EXIT_FAILURE;                                    \
        }                                                           \
        Util::uint32 status = application->execute();               \
        delete application;                                         \
        if (status == Util::Application::SUCCESS)                   \
            return EXIT_SUCCESS;                                    \
        else                                                        \
            return EXIT_FAILURE;                                    \
    }
#else
#  define UTIL_APPLICATION(ApplicationClass, adaptor)               \
    int main(int argc, char** argv)                                 \
    {                                                               \
        Util::ApplicationAdaptor* appAdaptor = new adaptor;         \
        if (! appAdaptor)                                           \
        {                                                           \
            std::cerr << "Unable to create ApplicationAdaptor:"     \
                      << #adaptor << std::endl;                     \
            return EXIT_FAILURE;                                    \
        }                                                           \
        Util::Application* application;                             \
        application = new ApplicationClass(appAdaptor, argc, argv); \
        if (! application)                                          \
        {                                                           \
            std::cerr << "Unable to create Application object: "    \
                      << #ApplicationClass << std::endl;            \
            return EXIT_FAILURE;                                    \
        }                                                           \
        Util::uint32 status = application->execute();               \
        delete application;                                         \
        if (status == Util::Application::SUCCESS)                   \
            return EXIT_SUCCESS;                                    \
        else                                                        \
            return EXIT_FAILURE;                                    \
    }
#endif
#ifdef UTIL_OPT_INLINE 
#  include "Application.icc"
#endif
#endif
/*******************************************************************************/      



