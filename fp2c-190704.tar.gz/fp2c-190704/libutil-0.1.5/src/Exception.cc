/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @file
* @ingroup util_base
* @brief Exception Class definition
*  
* - Supports: All
* - Created: 2005-08-06
* - Creator: Olivier Delannoy
* - $Revision $
* - Changelog: 
*    * 2005-08-10 : Adding OutOfBoundException class 
*    * 2005-08-06 : Moved to the Utility Library 
*    * 2005-05-29 : Initial version
*******************************************************************************
@LICENSE@
*******************************************************************************/
#include "Exception.hh"
#ifndef UTIL_OPT_INLINE
#  define inline
#  include "Exception.icc"
#  undef inline
#endif
#include <sstream> 
namespace Util
{
Exception::Exception(const String& message) throw()
    : mMessage(message)
{
}
void Exception::append(const String& message) 
{
    mMessage += message;
}

Exception::~Exception(void) throw()
{
}
OutOfBoundException::OutOfBoundException(const String& message) throw()
    : Exception(message) 
{
}
SystemException::SystemException(int32 err, const String& message) throw()
    : Exception(message), mError(err)
{
    append(" ");
    append(errorString());        
}
IOException::IOException(int32 err, const String& message) throw()
        : SystemException(err, message)
    {
    }
    XMLParseException::XMLParseException(uint32 row, uint32 column, const String& message) throw()
        : Exception(message), mRow(row), mColumn(column)
    {   
    }
    
}
/*******************************************************************************/
