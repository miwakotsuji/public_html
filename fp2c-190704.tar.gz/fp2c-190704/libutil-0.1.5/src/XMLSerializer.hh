/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @file
 * @brief Class XMLSerializer declaration
 *  
 * 
 * - Supports: All  
 * - Created: 2006-10-29
 * - Creator: Olivier Delannoy
 * - Last change in revision : $Revision $
 * - Changelog: 
 *    
 *    * 2006-10-29 : Initial version  
 ******************************************************************************
Copyright Olivier Delannoy 2005

Olivier Delannoy <Olivier.Delannoy@gmail.com>

This software is a computer program whose purpose is to [describe
functionalities and technical features of your software].

This software is governed by the CeCILL  license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.

 *******************************************************************************/
#ifndef UTIL_XMLSERIALIZER_HH
#define UTIL_XMLSERIALIZER_HH 1
#include "util_namespace.hh"
#include <iostream>
#include <vector> 
namespace Util 
{
    typedef std::ostream OutputStream;
    
    /**
     * @brief Create syntaxly correct XML document 
     * 
     * This class allow the creation of valid XML document enforcing syntax and 
     * conversion of special characters to the corresponding entity. 
     * 
     * @note Currently there is only support for the ASCII charset because of the 
     * string class used by the current libutil 
     *
     * - Supports: All
     * - Author: Olivier Delannoy
     * - Creator: 2006-10-29
     * - $Revision $
     */
    class UTIL_EXPORT XMLSerializer
    {
    public:
        /**
         * Constructor 
         * @param out the stream used to produce the resultat 
         */
        XMLSerializer(OutputStream& out, uint32 indentSpace = 4);
        /**
         * Destructor 
         */
        ~XMLSerializer(void);
        /**
         * @brief 
         * Open a new tag 
         * 
         * Open a  new tag element named @em name. 
         *
         * @param name the name of the tag 
         *
         * @return a reference to the
         * current serialization object 
         *
         * @note the closeTag method does
         * not need to know the name of the tag to close it's manage
         * automatically within the class.
         */
        XMLSerializer& openTag(const String& name);
        /**
         * @brief 
         * Close the latest opended tag 
         * 
         * Close the latest opended tag if no tag remains to close the
         * serializer is put in an error state
         *
         * @return a reference to the current serialization object 
         */ 
        XMLSerializer& closeTag(void);
        /** 
         * @brief 
         * Add an attribute to an open tag. 
         * 
         * This method create a new attribute for a tag. Take care to
         * create all attributes before dealing with element text or
         * you will put the serializer object in an error status.
         *
         * @param name the name of the attribute 
         *
         * @param value the value of the attribute 
         *
         * @return a reference to the current serialization object 
         */
        XMLSerializer& attribute(const String& name, const String& value);
        /**
         * @brief 
         * Create a text node in the document 
         * 
         * Create a text node based on the content of @em text. You
         * don't need to take care of the content of text, special
         * characters will be automatically converted to their
         * corresponding entity.
         * 
         * @param text the content of the text node 
         * 
         * @return a reference to the current serialization object 
         */
        XMLSerializer& text(const String& text);
        
        /** 
         * @brief 
         * Check wether the Serializer is in a valid state or not 
         * 
         * This method return true if the order of the call to
         * openTag, closeTag, attribute and text is valid. It will return false if an error occured 
         * it is safe to neglect error until the end cause no operation are really done if an error 
         * as been detected before 
         * 
         * @return true if no  error occured previously 
         */
        operator bool () const;
        /** 
         * @brief 
         * Check wether the Serializer is in a valid state or not 
         * 
         * This method return false if the order of the call to
         * openTag, closeTag, attribute and text is valid. It will return false if an error occured 
         * it is safe to neglect error until the end cause no operation are really done if an error 
         * as been detected before 
         * 
         * @return true if an  error occured previously 
         */
        bool operator!() const;
                
    protected:
    private:
        bool mError;            //!< Store whether an error occured or not 
        uint32 mDepth;          //!< Store the current depth of the xml document  
        uint32 mIndentSpace;    //!< Store the number of space used for identation  
        bool mNeedClose;        //!< True if a tag need to be closed 
        bool mLastIsText;       //!< True if the last operation has been a text node creation 
        OutputStream& mStream;  //!< A reference to the target stream 
        std::vector<String> mTagStack; //!< The stack of openTag (mDepth should be deduce from this object) 
        /**
         * @brief 
         * Initialize a new line with the needed indentation 
         */
        void indentLine();
        /**        
         * @brief 
         * Encode a bunch of text taking in account the special characters 
         */
        void exportData(const String& data);
        /**
         * @brief 
         * Convert if needed a single character
         */
        void convertEntity(String::value_type codePoint);
        
        
        /* Disable both operation */ 
        XMLSerializer(const XMLSerializer& obj);
        XMLSerializer& operator=(const XMLSerializer& obj);
    };
}
#ifdef UTIL_OPT_INLINE
#include "XMLSerializer.icc" 
#endif 
#endif // UTIL_XMLSERIALIZER_HH
/*******************************************************************************/



