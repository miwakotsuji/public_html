/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 * @file
 * @brief Class LoggerFactory function definition 
 *
 *
 */
#include "LoggerFactory.hh"
#include "Config.hh"
#include "ConfigFactory.hh"
#include "Logger.hh"
#include "Dir.hh" 
#include "RuntimeEnvironment.hh" 
#include <sstream>

Util::LoggerFactory::LoggerFactory(void) 
    : mLogger(0), mInit(false)
{
    UTIL_DEBUGUTIL("Start Logging services");
}

Util::LoggerFactory::~LoggerFactory(void) 
{
    delete mLogger;
    UTIL_DEBUGUTIL("Stop Logging services");
}
void Util::LoggerFactory::init(const Util::String& configName, const Util::String& appName, const Util::String& logDir)
{
    if (mInit)
    {
        UTIL_DEBUGUTIL("LoggerFactory already initialize");
        return;
    }
    mInit = true;
    if (!mLogger)
        mLogger = new Logger;
    

    UTIL_DEBUGUTIL("Init LoggerFactory: " << configName << ", " << appName << ", " << logDir);
    Config* config = Util::ConfigFactory::getSingleton().create(configName);

    UTIL_DEBUGUTIL("Init path logging dir");
    String destDir(logDir);
    if (logDir[logDir.size() -1] != RuntimeEnvironment::PATH_SEPARATOR)
        destDir += RuntimeEnvironment::PATH_SEPARATOR;
    UTIL_DEBUGUTIL("Creating Dir " << destDir << " if it does not exists");
    Dir::mkdir(destDir);
    String type = config->get(appName, "type", "stream");
    String format = config->get(appName, "format", Logger::DEFAULT_FORMAT);
    String level = config->get(appName, "level", "default");
    LoggingLevel logLevel = Logger::DEFAULT_LEVEL;
    if (level == "debug")
        logLevel = UTIL_DEBUG;
    else if (level == "info")
        logLevel = UTIL_INFO;
    else if (level == "warn")
        logLevel = UTIL_WARN;
    else if (level == "error")
        logLevel = UTIL_ERROR;
    else if (level == "fatal")
        logLevel= UTIL_FATAL;



    if (type == "file")    
    {
        std::ostringstream dest;
        dest << destDir;
        dest << appName;
        dest << '-' <<  RuntimeEnvironment::processID() << ".log";
        UTIL_DEBUGUTIL("Logger send output to " << dest.str());
        mLogger->init(dest.str(), logLevel, format);
    }
    else 
    {
        String dest = config->get(appName, "stream", "stderr");
        std::ostream* out = &std::cerr;
        if (dest == "stdout")
            out = &std::cout;
        else 
            dest = "stderr";
        UTIL_DEBUGUTIL("Logger send output to " << dest);
        mLogger->init(out, logLevel, format);
    }
}
Util::Logger* Util::LoggerFactory::create(const Util::String& loggerName)
{
    if (! mLogger)
    {
        mLogger = new Logger;
    }
    return mLogger;
}
/*******************************************************************************/      



