/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @file
 * @brief Class XMLHandler definitions 
 *  
 *
 * 
 * 
 * - Supports: All 
 * - Created: 2005-08-09
 * - Creator: Olivier Delannoy
 * - $Revision $
 * - Changelog: 
 *    
 *    * 2005-08-09 : Initial version  
 ******************************************************************************
@LICENSE@
 *******************************************************************************/
#include "XMLHandler.hh"
#include <cassert>
Util::XMLHandler::XMLHandler(void)
{
    
}
Util::XMLHandler::XMLHandler(Util::XMLHandler& src)
{
    assert(0);
}
Util::XMLHandler::~XMLHandler(void)
{

}
Util::XMLHandler& Util::XMLHandler::operator=(Util::XMLHandler& src)
{
    assert(0);
    return *this;
}
void Util::XMLHandler::elementStart(const Util::String& elementName, const Util::Properties& attributes)
{
    
}
void Util::XMLHandler::elementEnd(const Util::String& elementName)
{
    
}
void Util::XMLHandler::text(const Util::String& text)
{

}
/*******************************************************************************/
