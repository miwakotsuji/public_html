/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @file
 * @brief Class DirHandler definitions 
 *  
 *
 * 
 * 
 * - Supports: All 
 * - Created: 2006-10-29
 * - Creator: Olivier Delannoy
 * - $Revision $
 * - Changelog: 
 *    
 *    * 2006-10-29 : Initial version  
 ******************************************************************************
@LICENSE@
 *******************************************************************************/
#ifndef HAVE_CONFIG_H
#include "util_config.hh"
#endif
#include "DirHandler.hh"
namespace Util
{
    
DirHandler::DirHandler(void)
{   
}
DirHandler::~DirHandler(void)
{
}
void DirHandler::onFile(const String& parentPath, const String& filename)
{
}
void DirHandler::onEnterDir(const String& parentPath, const String& dirame)
{
}
void DirHandler::onExitDir(const String& parentPath, const String& dirame)
{
}
}
/*******************************************************************************/
