/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @file
 * @brief Class Dir declaration
 *  
 * 
 * - Supports: 
 *   - Native: 
 *     - UNIX (Linux)
 *  
 * - Created: 2005-09-13
 * - Creator: Olivier Delannoy
 * - Last change in revision : $Revision $
 * - Changelog: 
 *    
 *    * 2005-09-13 : Initial version  
 ******************************************************************************
Copyright Olivier Delannoy 2005

Olivier Delannoy <Olivier.Delannoy@gmail.com>

This software is a computer program whose purpose is to [describe
functionalities and technical features of your software].

This software is governed by the CeCILL  license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.

 *******************************************************************************/
#ifndef UTIL_DIR_HH
#define UTIL_DIR_HH 1
#include "util_namespace.hh"
#include "DirHandler.hh" 
namespace Util 
{
    /**
     * @brief This class is specialized in directory manipulation. 
     *
     * This class provide a static operation for handling common directory operation such as 
     * - creating 
     * - testing existance 
     * - removing 
     *
     * - Supports: 
     *   - Native:
     *     - UNIX (linux)
     *
     * - Author: Olivier Delannoy
     * - Creator: 2005-09-13
     * - $Revision $
     */
    class UTIL_EXPORT Dir
    {
    public:
        /**
         * Test whether a directory exists or not 
         */
        static bool exists(const String& name);
        /** 
         * Create a new directory 
         */
        static bool mkdir(const String& name, bool createParents=true);
        /** 
         * Remove a directory 
         */
        static bool rmdir(const String& name, bool recurse=true);
        /**
         * @brief 
         * Create a directory with a unique name in the temporary folder 
         *
         * Create a temporary directory with a unique name in the temporary folder of the system 
         * and return the name of this folder
         *
         * @return the name of directory created 
         */
        static String mktemp();
        
        /**
         * @brief 
         * Browse a directory 
         * 
         * This function activate events on a handler given to the function. The events are of two kinds: 
         * - file is encounter 
         * - folder is encounter 
         * This visit of the directory tree can be made recursiv 
         */
        static void visit(DirHandler& handler, const String& dirName, bool recurs = true); 
    protected:
    
    private:
        
    };
}
#endif // UTIL_DIR_HH
/*******************************************************************************/



