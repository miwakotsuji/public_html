/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @file
 * @brief Class Dir definitions 
 *  
 *
 * 
 * 
 * - Supports: 
 *   - Native: 
 *      - UNIX (linux)
 *
 * - Created: 2005-09-13
 * - Creator: Olivier Delannoy
 * - $Revision $
 * - Changelog: 
 *    
 *    * 2005-09-13 : Initial version  
 ******************************************************************************
@LICENSE@
 *******************************************************************************/
#ifndef HAVE_CONFIG_H
#include "util_config.hh"
#endif
#include "Dir.hh"
#include "FileInfo.hh"
#include "File.hh"
#include "StringList.hh" 
#include "RuntimeEnvironment.hh" 
#include "Exception.hh" 

// add some checking here  
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>
#include <unistd.h> 
#include <cerrno>
#include <cstdlib>
bool Util::Dir::exists(const Util::String& dirName)
{
    return FileInfo(dirName).isDir();
}
bool Util::Dir::mkdir(const Util::String& dirName, bool createParents)
{
    UTIL_DEBUGUTIL("Creating Dir: " << dirName);
    if (dirName.empty())
        return false;
    if (FileInfo(dirName).isDir())
        return true;
    bool res = ::mkdir(dirName.c_str(), 0777) == 0;
    if (!res)
    {
        if (createParents)
        {
            uint32 last = dirName.size() - 1;
            for (; last >= 0 ; --last)
            {
                if (dirName[last] == Util::RuntimeEnvironment::PATH_SEPARATOR)
                {
                    break;
                }
            }
            if (dirName[last] == Util::RuntimeEnvironment::PATH_SEPARATOR)
            {
                res = Dir::mkdir(dirName.substr(0, last), true);
                if (res)
                    res = ::mkdir(dirName.c_str(), 0777) == 0;
            }
        }
    }
    return res;
}
bool Util::Dir::rmdir(const Util::String& dirName, bool recurse)
{
    if (recurse)
    {
        UTIL_DEBUGUTIL("Visit :" << dirName);
        // Descend the tree 
        DIR* parent = opendir(dirName.c_str());
        if (parent)
        {
            struct dirent* entry;
            while ((entry = readdir(parent)) != 0)
            {
                if ((strcmp(".", entry->d_name) != 0) &&
                    (strcmp("..", entry->d_name) != 0))
                {
                    String entryName(entry->d_name);
                    UTIL_DEBUGUTIL("Removing: " << entryName);
                    if (entryName != "." && entryName != "..")
                    {                                        
                        if (FileInfo(dirName + Util::RuntimeEnvironment::PATH_SEPARATOR + entryName).isDir())
                            Dir::rmdir(dirName + Util::RuntimeEnvironment::PATH_SEPARATOR + entryName, true);
                        else 
                            File::remove(dirName + Util::RuntimeEnvironment::PATH_SEPARATOR + entryName);
                    }    
                }
            }
            closedir(parent);
            UTIL_DEBUGUTIL("Finished in dir " << dirName);
        }
    }
    UTIL_DEBUGUTIL("Removing Dir: " << dirName);    
    return ::rmdir(dirName.c_str()) == 0;
}
Util::String Util::Dir::mktemp()
{
    char buffer[PATH_MAX];
    ::strcpy(buffer, "/tmp/util_XXXXXX");
    char* res = ::mkdtemp(buffer);
    if (res)
    {
        return res;
    }
    throw IOException(errno, "mkdtemp failed");
}



void Util::Dir::visit(DirHandler& handler, const String& dirName, bool recurse)
{
    DIR* parent = ::opendir(dirName.c_str());
    if (parent)
    {
        String curDir(dirName);
        
        if (dirName[dirName.size() -1] != Util::RuntimeEnvironment::PATH_SEPARATOR)
            curDir += Util::RuntimeEnvironment::PATH_SEPARATOR;
        struct dirent* entry;
        while((entry = ::readdir(parent)) != 0)
        {
            if ((strcmp(".", entry->d_name) != 0) && 
                (strcmp("..", entry->d_name) != 0))
            {
                String entryName(entry->d_name);
                if (FileInfo(curDir + entryName).isDir())
                {
                    (&handler)->onEnterDir( curDir, entryName);
                    if (recurse)
                    {
                        Dir::visit(handler, curDir + entryName, recurse);
                    }
                    (&handler)->onExitDir( curDir, entryName);
                }
                else
                {
                    (&handler)->onFile(curDir, entryName);
                }
            }
        }
        closedir(parent);
    }
}


/*******************************************************************************/
