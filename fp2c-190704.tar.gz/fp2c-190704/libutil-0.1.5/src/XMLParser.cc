/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @file
 * @ingroup util_xml 
 * @brief Class XMLParser definitions 
 *  
 *
 * 
 * 
 * - Supports: All 
 * - Created: 2005-08-09
 * - Creator: Olivier Delannoy
 * - $Revision $
 * - Changelog: 
 *    
 *    * 2005-08-09 : Initial version  
 ******************************************************************************
@LICENSE@
 *******************************************************************************/
#include "XMLParser.hh"
#include "XMLParserImpl.hh"
#include <cassert>
namespace Util
{
    XMLParser::XMLParser(XMLParserImpl* impl)
        : mParser(impl)
    {   
        assert(impl != 0); // Invariant 
    }
    const String& XMLParser::name(void) const
    {
        return mParser->name();
    }
    void XMLParser::parse(XMLHandler& handler, const ByteArray& data, const ByteArray* const xsd)
    {
        mParser->parse(handler, data, xsd);
    }
    void XMLParser::parse(XMLHandler& handler, const String& dataFilename, const ByteArray* const xsd)
    {
        ByteArray data(dataFilename);
        mParser->parse(handler, data, xsd);
    }
    void XMLParser::parse(XMLHandler& handler, const ByteArray& data, const String& xsdFilename)
    {
        if (mParser->isValidating())
        {
            ByteArray xsd(xsdFilename);
            mParser->parse(handler, data, &xsd);
        }
        else
        {
            mParser->parse(handler, data, 0);
        }
    }
    void XMLParser::parse(XMLHandler& handler, const String& dataFilename, const String& xsdFilename)
    {
        ByteArray data(dataFilename);
        if (mParser->isValidating())
        {
            ByteArray xsd(xsdFilename);
            mParser->parse(handler, data, &xsd);
        }
        else
        {
            mParser->parse(handler, data, 0);
        }
    }
}
/*******************************************************************************/
