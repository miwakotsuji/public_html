/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @file
 * @brief Class Zip definitions 
 *  
 *
 * 
 * 
 * - Supports: All 
 * - Created: 2005-08-25
 * - Creator: Olivier DELANNOY
 * - $Revision $
 * - Changelog: 
 *    
 *    * 2005-08-25 : Initial version  
 ******************************************************************************
@LICENSE@
 *******************************************************************************/
#include "Zip.hh"
#include "RuntimeEnvironment.hh"
#include "Exception.hh"
#include "FileInfo.hh"
#include "File.hh"
#include "unzip.h"
#include "zip.h"

#include <cassert>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <cstdio>
/** Sizeof the buffer used during communication from the source file to the dest file */
const Util::uint32 BUFSIZE =  4092;

Util::Zip::Zip(void)
{
    assert(0);
}

Util::Zip::Zip(const Util::String& fileName, bool openRead)
    : mOpenForReading(openRead)
{
    
    if (openRead)
    {
        mZipHandle = unzOpen(fileName.c_str());
    }
    else 
    {
        if (FileInfo(fileName).exists())
            File::remove(fileName);
        mZipHandle = zipOpen(fileName.c_str(), 0);
    }
}

Util::Zip::Zip(Util::Zip& src)
{
    assert(0);
}

Util::Zip::~Zip(void)
{
    if (mOpenForReading)
        unzClose(mZipHandle);
    else
        zipClose(mZipHandle, 0);
}

Util::Zip& Util::Zip::operator=(Util::Zip& src)
{
    assert(0);
    return *this;
}

bool Util::Zip::extractAllEntry(const Util::String& dirName)
{
    // Rhoooo trying to extract entries from a zip in writing mode ... bad 
    if (! mOpenForReading)
        return false;
    // Update path to provide direct copy 
    String myPath(dirName);
    if (dirName[dirName.size() -1] != RuntimeEnvironment::PATH_SEPARATOR)
        myPath += RuntimeEnvironment::PATH_SEPARATOR;
    
    // Dest folder does not exists it's ... bad 
    if (! FileInfo(myPath).isDir())
        return false;
    
    int status = unzGoToFirstFile(mZipHandle);
    if (status == UNZ_END_OF_LIST_OF_FILE)
    {
        return true;
    }
    else if (status == UNZ_OK)
    {        
        while(status == UNZ_OK)
        {
            char inZipName[1024];
            status = unzGetCurrentFileInfo(
                mZipHandle, 0, 
                inZipName, 1024, 
                0, 0, 0, 0);
            status = unzOpenCurrentFile(mZipHandle);
            if (status != UNZ_OK)
                return false;
            
            FILE * f = fopen((myPath + inZipName).c_str(), "wb");
            if (!f)
                return false;
            char buffer[BUFSIZE];
            uint32 size_read;
            do 
            {
                size_read = unzReadCurrentFile(mZipHandle, buffer, BUFSIZE);
                if (size_read < BUFSIZE)
                {
                    if (unzeof(mZipHandle) == 0)
                    {
                        fclose(f);
                        return false;
                    }
                }
                if (size_read > 0)
                    fwrite(buffer, 1, size_read, f); // Should check this 
            }
            while(size_read);
            status = unzCloseCurrentFile(mZipHandle);
            if (status == UNZ_OK)
                status = unzGoToNextFile(mZipHandle);
        }
        return true;
    }
    else     
        return false;
}

bool  Util::Zip::addEntry(const Util::String& fileName)
{
    // Rhooo trying to add entry during the reading of a zip ... bad 
    if (mOpenForReading)
        return false;
    uint8 buffer[BUFSIZE];
    uint32 size_read = 0;
    FILE* tmp = fopen(fileName.c_str(), "rb");
    // Compute name in file 
    int lastSeparator;
    for(lastSeparator = fileName.size() - 1 ; lastSeparator >= 0 ; --lastSeparator)
    {
        if (fileName[lastSeparator] == RuntimeEnvironment::PATH_SEPARATOR)
            break;
    }
    String inZipName(fileName.substr(lastSeparator < 0 ? 0 : lastSeparator));
    
    //Prepare zip entry header 
    zip_fileinfo zi;
    zi.dosDate = 0;
    zi.internal_fa = 0;
    zi.external_fa = 0;
    // Requesting real information SOME cleaning is needed 
    struct stat s;
    struct tm* filedate;
    time_t tm_t = 0;
    if (stat(fileName.c_str(), &s) != 0)
    {
        fclose(tmp);
        return false;
    }
    tm_t = s.st_mtime;
    filedate = localtime(&tm_t);
    zi.tmz_date.tm_sec = filedate->tm_sec;
    zi.tmz_date.tm_min = filedate->tm_min;
    zi.tmz_date.tm_hour = filedate->tm_hour;
    zi.tmz_date.tm_mday = filedate->tm_mday;
    zi.tmz_date.tm_mon = filedate->tm_mon;
    zi.tmz_date.tm_year = filedate->tm_year;
    assert(mZipHandle);
    
    if (ZIP_OK != zipOpenNewFileInZip(
            mZipHandle, 
            inZipName.c_str(), &zi, 
            /* local extra field */ 0, 0, 
            /* global extra field*/ 0, 0, 
            /* comment */ 0, 
            Z_DEFLATED, Z_DEFAULT_COMPRESSION))
    {
        // Bad 
        fclose(tmp);
        return false;
        
    }
    do 
    {
        size_read = fread(buffer, 1, BUFSIZE, tmp);
        if (size_read < BUFSIZE)
        {
            if (feof(tmp) ==0)
            {
                fclose(tmp);
                return false;
            }
        }
        std::cout << "Adding " << size_read << " bytes" << std::endl;
        
        if (size_read > 0)
        {
            if (zipWriteInFileInZip(mZipHandle, buffer, size_read) != ZIP_OK)
            {
                fclose(tmp);
                return false;
            }
        }
    }
    while(size_read);
    return zipCloseFileInZip(mZipHandle) == ZIP_OK;
}
/*******************************************************************************/
