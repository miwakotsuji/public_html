/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @file
 * @ingroup util_tools
 * @brief Class Properties definitions 
 *  
 *
 * 
 * 
 * - Supports: All 
 * - Created: 2005-08-10
 * - Creator: Olivier Delannoy
 * - $Revision $
 * - Changelog: 
 *    
 *    * 2005-08-10 : Initial version  
 ******************************************************************************
@LICENSE@
 *******************************************************************************/
#include "Properties.hh"
#ifndef UTIL_OPT_INLINE
#define inline
#include "Properties.icc"
#undef inline
#endif 
#include <sstream> 
Util::Properties::Properties(void)
{
    
}
Util::Properties::~Properties(void)
{
}

Util::Properties::Properties(std::map<Util::String, Util::String>& src)
    : std::map<Util::String, Util::String>(src)
{
}

Util::Properties& Util::Properties::operator=(std::map<Util::String, Util::String>& src)
{
    clear();
    insert(src.begin(), src.end());
    return *this;
}
const Util::String& Util::Properties::key(Util::uint32 index) const throw(Util::OutOfBoundException)
{
    const_iterator iter = begin();
    for( ; iter != end() && index ; --index , ++iter);
    if (iter == end())
        throw OutOfBoundException("Properties::key() - Invalid index");
    return iter->first;
}
const Util::String& Util::Properties::stringValue(Util::uint32 index) const throw(Util::OutOfBoundException)
{
    const_iterator iter = begin();
    for( ; iter != end() && index ; --index , ++iter);
    if (iter == end())
        throw OutOfBoundException("Properties:stringValue() - Invalid index");
    return iter->second;
}
const Util::String& Util::Properties::stringValue(const Util::String& key, const Util::String& defValue) const throw()
{
    const_iterator iter = find(key);
    if (iter != end())
        return iter->second;
    return defValue;
}
Util::int32 Util::Properties::intValue(Util::uint32 index) const throw(Util::OutOfBoundException)
{
    const_iterator iter = begin();
    for( ; iter != end() && index ; --index , ++iter);
    if (iter == end())
        throw OutOfBoundException("Properties:stringValue() - Invalid index");
    std::istringstream buf(iter->second);
    int32 res;
    buf >> res;
    return res;
}
Util::int32 Util::Properties::intValue(const Util::String& key, Util::int32 defValue) const throw()
{
    const_iterator iter = find(key);
    if (iter != end())
    {
        std::istringstream buf(iter->second);
        int32 res;
        buf >> res;
        return res;
    }
    return defValue;
}
bool Util::Properties::booleanValue(Util::uint32 index) const throw(Util::OutOfBoundException)
{
    const_iterator iter = begin();
    for( ; iter != end() && index ; --index , ++iter);
    if (iter == end())
        throw OutOfBoundException("Properties:booleanValue() - Invalid index");
    if (iter->second == "yes"  || 
        iter->second == "on"   || 
        iter->second == "1"    || 
        iter->second == "true")
        return true;
    return false;
}
bool Util::Properties::booleanValue(const Util::String& key, bool defValue) const throw()
{
    const_iterator iter = find(key);
    if (iter != end())
    {
        if (iter->second == "yes"  || iter->second == "on"   || 
            iter->second == "1"    || iter->second == "true")
            return true;
        return false;
    }
    return defValue;
}

Util::real32 Util::Properties::realValue(Util::uint32 index) const throw(Util::OutOfBoundException)
{
    const_iterator iter = begin();
    for( ; iter != end() && index ; --index , ++iter);
    if (iter == end())
        throw OutOfBoundException("Properties:realValue() - Invalid index");
    std::istringstream buf(iter->second);
    real32 res;
    buf >> res;
    return res;
}
Util::real32 Util::Properties::realValue(const Util::String& key, Util::real32 defValue) const throw()
{
    const_iterator iter = find(key);
    if (iter != end())
    {
        std::istringstream buf(iter->second);
        real32 res;
        buf >> res;
        return res;
    }
    return defValue;
}
void Util::Properties::print(std::ostream& out) const throw()
{
    out << "Properties<<<" << std::endl;
    const_iterator iter = begin();
    for(; iter != end() ; ++iter)
    {
        out << "\t<<<" << iter->first << ">>> -> <<<" << iter->second << ">>>" << std::endl;
    }
    out << ">>>";
}
/*******************************************************************************/
