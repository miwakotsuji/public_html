/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @file
* @ingroup util_system
* @brief TCPRemoteClient class definition 
*
* - Supports: 
*   - system: 
*     - UNIX (Linux)
*     - Win32 (XP)
* - Created: 2005-05-29
* - Creator: Olivier Delannoy
* - $Revision $
* - Changelog: 
*    * 2005-08-06 : Integrated to libutil 
*    * 2005-05-29 : Initial version  
*******************************************************************************
@LICENSE@ 
*******************************************************************************/
#include "TCPRemoteClient.hh"
Util::TCPRemoteClient::TCPRemoteClient(Util::int32 socket)
    : Util::TCPSocket(socket)
{
    
}

Util::TCPRemoteClient::~TCPRemoteClient(void)
{
    
}
/*******************************************************************************/



