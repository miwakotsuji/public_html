/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @file
 * @brief Class URL definitions 
 *  
 *
 * 
 * 
 * - Supports: All 
 * - Created: 2006-03-27
 * - Creator: Olivier Delannoy
 * - $Revision $
 * - Changelog: 
 *    
 *    * 2006-03-27 : Initial version  
 ******************************************************************************
@LICENSE@
 *******************************************************************************/
#ifdef HAVE_CONFIG_H
#include <util_config.hh>
#endif
#include "URL.hh"
#include "Exception.hh" 
namespace Util
{
    URL::URL(const String& url)
    {
        uint32 i;
        uint32 size = url.size();
        for (i = 0 ; i < size && url[i] != ':'; ++i)
        {
            if (url[i] >= 'a' && url[i] <= 'z')
                mProtocol += url[i];
            else if (url[i] >= 'A' && url[i] <= 'Z')
                mProtocol += url[i] - 'A' + 'a';
            else if (url[i] == '.')
                mProtocol += '.';
            else if (url[i] == '-')
                mProtocol += '-';
            else if (url[i] == '+')
                mProtocol += '+';
            else 
                throw Exception(url + ": Invalid url, protocol contains invalid char");
        }
        mRest = url.substr(i+1);
        //Parse the rest according to the scheme 
        if (mProtocol.compare("file") == 0)
        {
            if (mRest[0] != '/' || mRest[1] != '/')
            {
                throw Exception(url + ": Invalid file url");
            }     
        }
    }
    const String& URL::protocol(void) const
    {
        return mProtocol;
    }
    const String& URL::rest(void) const
    {
        return mRest;
    }
    
    String URL::field(URLFieldName field) const
    {
        if (mProtocol.compare("file") == 0)
        {
            if (field == UTIL_URL_PATH)
            {
                return mRest.substr(2);
            }
        }
        /** @todo Not yet implemented */
        return "";
    }
    
    
    
    
}
/*******************************************************************************/
