/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @ingroup util_application
* @file
* @brief Class Config defintion 
*  
* - Supports: All
* - Created: 2005-08-06
* - Creator: Olivier Delannoy
* - $Revision $
* - Changelog: 
*    
*    * 2005-08-06 : Initial version  
*******************************************************************************
@LICENSE@
*******************************************************************************/
#include "Config.hh"
#ifndef UTIL_OPT_INLINE
#  define inline 
#  include "Config.icc"
#  undef inline 
#endif 
#include <cassert>
Util::Config::Config(void)
{
    
}

Util::Config::Config(Util::Config& src)
{
    assert(0);
}

Util::Config& Util::Config::operator=(Util::Config& src)
{
    assert(0);
    return *this;
}
Util::Config::~Config(void) 
{
}
Util::String Util::Config::get(const Util::String& group, 
                                      const Util::String& key, 
                                      const Util::String& fallback) const
{
    // Do it better than this 
    ConfigData::const_iterator iter = mConfigData.find(group);
    if (iter != mConfigData.end())
    {
        
        ConfigGroup::const_iterator iterKey = iter->second.find(key);
        if (iterKey != iter->second.end())
            return iterKey->second;
    }
    return fallback;
}


void Util::Config::set(const Util::String& group, const Util::String& key, const Util::String& value)
{
    if (!exists(group))
        mConfigData.insert(make_pair(group, ConfigGroup()));
    mConfigData[group][key] = value;
}

void Util::Config::unset(const Util::String& group, const Util::String& key)
{
    if (exists(group))
    {
        mConfigData[group].erase(key);
        if (mConfigData[group].empty())
            mConfigData.erase(group);
    }
}

void Util::Config::print(std::ostream& out) const
{
    out << "Config<<<" << std::endl;
    ConfigData::const_iterator groupIter = mConfigData.begin();
    for(; groupIter != mConfigData.end() ; ++groupIter)
    {
        out << "  <<<" << groupIter->first << ">>>" << std::endl;
        ConfigGroup::const_iterator valueIter = groupIter->second.begin();
        for(; valueIter != groupIter->second.end() ; ++valueIter)
        {
            out << "    <<<" << valueIter->first << ">>>=<<<" << valueIter->second << ">>>" << std::endl;
        }
    }
    out << ">>>";
}
/*******************************************************************************/      
