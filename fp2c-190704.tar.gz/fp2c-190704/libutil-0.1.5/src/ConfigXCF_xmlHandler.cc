/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @file
 * @brief Class ConfigXCF_xmlHandler definitions 
 *  
 *
 * 
 * 
 * - Supports: All 
 * - Created: 2006-03-25
 * - Creator: Olivier Delannoy
 * - $Revision $
 * - Changelog: 
 *    
 *    * 2006-03-25 : Initial version  
 ******************************************************************************
@LICENSE@
 *******************************************************************************/
#include "ConfigXCF_xmlHandler.hh"
namespace Util
{
    ConfigXCF_xmlHandler::ConfigXCF_xmlHandler(Config* target)
        : mTarget(target)
    {
    }
    
    void ConfigXCF_xmlHandler::elementStart(const String& name, const Properties& attributes)
    {
        if (name == "group")
        {
            mGroup = attributes.stringValue("name");
        }
        else if (name == "entry")
        {
            String key = attributes.stringValue("name");
            String value = attributes.stringValue("value");
            mTarget->set(mGroup, key, value);
        }
    }
    void ConfigXCF_xmlHandler::elementEnd(const String& name)
    {
        if (name == "group")
        {
            mGroup = "";
        }
    }
}
/*******************************************************************************/
