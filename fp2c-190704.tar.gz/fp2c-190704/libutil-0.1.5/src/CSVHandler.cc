/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @file
 * @brief Class CSVHandler definitions 
 *  
 *
 * 
 * 
 * - Supports: All 
 * - Created: 2006-03-03
 * - Creator: Olivier Delannoy
 * - $Revision $
 * - Changelog: 
 *    
 *    * 2006-03-03 : Initial version  
 ******************************************************************************
@LICENSE@
 *******************************************************************************/
#include "CSVHandler.hh"
namespace Util
{
    CSVHandler::CSVHandler(void)
    {    
    }
    CSVHandler::~CSVHandler(void)
    {
    }
    void CSVHandler::rowStart(void)
    {
    }
    void CSVHandler::rowEnd(void)
    {    
    }
    void CSVHandler::cell(const String& text)
    {    
    }
}
/*******************************************************************************/
