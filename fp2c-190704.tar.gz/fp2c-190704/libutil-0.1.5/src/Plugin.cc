/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @ingroup util_application 
 * @file
 * @brief Class Plugin definitions 
 *  
 * - Supports: All (Throught libLTDL)
 * - Created: 2005-08-06
 * - Creator: Olivier Delannoy
 * - $Revision $
 * - Changelog: 
 *    
 *    * 2005-08-06 : Initial version  
 *******************************************************************************
@LICENSE@
 *******************************************************************************/
#ifdef HAVE_CONFIG_H 
#include <util_config.hh>
#endif 
#include "Plugin.hh"
#include "RuntimeEnvironment.hh" 
#include <cassert> 
#ifdef HAVE_DLFCN_H 
# include <dlfcn.h>
namespace Util
{
class DLImpl
{
public:
    static void addSearchPath(const String& path)
    {
        // Setenv or something like that LD_LIBRARY_PATH 
        String curEnv = RuntimeEnvironment::env("LD_LIBRARY_PATH");
        String newEnv;
        newEnv.reserve(path.size() + 1 + curEnv.size());
        newEnv.append(path);
        newEnv.append(":");
        newEnv.append(curEnv);
        RuntimeEnvironment::updateEnv("LD_LIBRARY_PATH", newEnv);
    }
    
    DLImpl()
        : mDSO(0)
    {   
    }
    
    ~DLImpl()
    {
        close();
    }
    
    int open(const String& name)
    {
        if (mDSO)
            return -1;
        // Try the simple approach first 
        mDSOName = name + ".so";
        mDSO = dlopen(mDSOName.c_str(), RTLD_GLOBAL | RTLD_LAZY);
        if (mDSO == 0)
        {
            // std::cout << "ERROR? loading " << mDSOName <<" "<< dlerror() << std::endl; 
            // Simple approach failed iterate through all value in 
            // LD_LIBRARY_PATH env 
             const String curEnv = RuntimeEnvironment::env("LD_LIBRARY_PATH");
             const size_t max = curEnv.size();
             int j = 0;
             for(int i = 0 ; mDSO == 0 && i < max ; ++i)
             {
                    if (curEnv[i] == ':')
                    {
                        String path = curEnv.substr(j, i - j);
                        path += '/';
                        path += mDSOName;
                        mDSO = dlopen(path.c_str(), RTLD_GLOBAL | RTLD_LAZY);   
                        j = i+1;
                        if (mDSO)
                        {
                            mDSOName = path;
                        }else{
                            // std::cout << "ERROR? loading " << path <<" "<< dlerror() << std::endl;
                        }
                    }
             }
        }
        return (mDSO == 0) ? -1 : 0;
    }
    
    bool  isOpened()
    {
        return mDSO != 0;
    }
    
    int close()
    {
        if (mDSO)
            return dlclose(mDSO);
        return 0;
    }
    
    void* symbol(const String& symbol)
    {
        if (mDSO == 0)
            return 0;
        return dlsym(mDSO, symbol.c_str());
    }
    
    void makeResident()
    {
        // USE RTLD_NODELETE | RTLD_NOLOAD
        if (mDSO)
            dlopen(mDSOName.c_str(), RTLD_NOLOAD | RTLD_NODELETE);
    }
    bool isResident()
    {
        return dlopen(mDSOName.c_str(), RTLD_NOLOAD) == mDSO;
    }
    
    String lastError() 
    {
        return dlerror();
    }
private:
    void* mDSO;                 //!< Store the handle of the DSO 
    String mDSOName;
};

}
#else
#error "Dynamic Shared Object implementation not found" 
#endif   

namespace Util
{
int Plugin::open(const String& filename)
{
    mImpl = new DLImpl;
    if (mImpl)
        return mImpl->open(filename);
    return -1;
}
bool Plugin::isOpened(void) const
{
    assert(mImpl);
    return mImpl->isOpened();
}
const String& Plugin::lastError(void)
{
    assert(mImpl);
    mLastError = mImpl->lastError();
    return mLastError;
}
void* Plugin::loadSymbol(const String& symbol)
{
    assert(mImpl);
    return mImpl->symbol(symbol);
}
uint32 Plugin::close(void)
{
    delete mImpl;
    return 0;
}
void Plugin::makeResident(void)
{
    assert(mImpl);
    mImpl->makeResident();
}
bool Plugin::isResident(void)
{
    assert(mImpl);
    return mImpl->isResident();
}

Plugin::Plugin(void) 
    : mImpl(0)
{
}

Plugin::~Plugin(void)
{
    delete mImpl;
}
void Plugin::addSearchPath(const String& path)
{
    DLImpl::addSearchPath(path);
}

}
/*******************************************************************************/      
