/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @file
 * @brief Class XMLParserImpl definitions 
 *  
 *
 * 
 * 
 * - Supports: All 
 * - Created: 2005-08-09
 * - Creator: Olivier Delannoy
 * - $Revision $
 * - Changelog: 
 *    
 *    * 2005-08-09 : Initial version  
 ******************************************************************************
@LICENSE@
 *******************************************************************************/
#include "XMLParserImpl.hh"
namespace Util 
{
    XMLParserImpl::XMLParserImpl(const String& name, bool isValidating)
        : mName(name), mValidating(isValidating), mInitialized(false)
    {
    }
    XMLParserImpl::~XMLParserImpl(void)
    {
    }
    const String& XMLParserImpl::name(void) const
    {
        return mName;
    }
    bool XMLParserImpl::isValidating(void) const
    {
        return mValidating;
    }
    bool XMLParserImpl::initialize(void)
    {
        if (! mInitialized)
            mInitialized = initializeImpl();
        return mInitialized;
    }
    void XMLParserImpl::cleanup(void)
    {
        if (mInitialized)
        {
            cleanupImpl();
            mInitialized = false;
        }
    }
}
/*******************************************************************************/
