/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @file
* @ingroup util_system
* @brief TCPServer class definition
*
* - Supports: 
*   - system: 
*     - UNIX (Linux)
*     - Win32 (XP)
* - Created: 2005-05-29
* - Creator: Olivier Delannoy
* - $Revision $
* - Changelog: 
*    * 2005-08-06 : Integrated to libutil 
*    * 2005-05-29 : Initial version  
*******************************************************************************
@LICENSE@ 
*******************************************************************************/
#include "TCPServer.hh"
#include "TCPRemoteClient.hh"
Util::TCPServer::TCPServer(Util::uint16 port)
    : Util::TCPSocket("", port)
{
    listen();
}

Util::TCPServer::~TCPServer(void)
{
    
}


Util::TCPRemoteClient* Util::TCPServer::accept(void)
{
    return new TCPRemoteClient(Util::TCPSocket::accept());
}
/*******************************************************************************/



