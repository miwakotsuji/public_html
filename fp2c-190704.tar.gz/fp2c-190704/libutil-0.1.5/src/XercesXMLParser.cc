/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @file
 * @brief Class XercesXMLParser definitions 
 *  
 *
 * 
 * 
 * - Supports: All 
 * - Created: 2006-03-11
 * - Creator: Olivier Delannoy
 * - $Revision $
 * - Changelog: 
 *    
 *    * 2006-03-11 : Initial version  
 ******************************************************************************
@LICENSE@
 *******************************************************************************/
#include "XercesXMLParser.hh"
namespace Util
{
    /** 
     * This class is used internally by the Xerces Parser 
     */ 
    class XercesHandler : public XERCES_CPP_NAMESPACE::DefaultHandler
    {
    public:
        XercesHandler(XMLHandler& handler)
            mHandler(&handler)
        {
        }
        
        ~XercesHandler(void)
        {    
        }
        // Implementation of methods in Xerces DefaultHandler.
        void startElement(const XMLCh* const uri, const XMLCh* const localname, const XMLCh* const qname, const XERCES_CPP_NAMESPACE::Attributes& attrs)
        {
            XERCES_CPP_NAMESPACE_USE;
            Properties attributes;
            // Populate Attributes blocks
            XercesXMLParser::populateAttributesBlock(attrs, attributes);
            String element(XercesParser::transcodeXmlCharToString(localname, XMLString::stringLen(localname)));
            mHandler->elementStart(element, attributes);
        }
        void endElement(const XMLCh* const uri, const XMLCh* const localname, const XMLCh* const qname)
        {
            XERCES_CPP_NAMESPACE_USE;
            String element(XercesParser::transcodeXmlCharToString(localname,XMLString::stringLen(localname)));
            mHandler->elementEnd(element);
        }
        void characters (const XMLCh *const chars, const unsigned int length)
        {
            mHandler->text(XercesParser::transcodeXmlCharToString(chars, length));
        }
        /*
        void warning (const XERCES_CPP_NAMESPACE::SAXParseException &exc)
        {
            
        }
        void error (const XERCES_CPP_NAMESPACE::SAXParseException &exc)
        {
        }
        void fatalError (const XERCES_CPP_NAMESPACE::SAXParseException &exc)
        {
        }
        */
    protected:
        XMLHandler* mHandler;      
    };


    XercesXMLParser::XercesXMLParser(void)
    {   
    }
    XercesXMLParser::~XercesXMLParser(void)
    {
    }
    void XercesXMLParser::parse(XMLHandler& handler, const String& fileName, const String& schemaName)
    {
        XERCES_CPP_NAMESPACE_USE;
        XercesHandler xercesHandler(handler);
        // create parser
        SAX2XMLReader* reader = createReader(xercesHandler);
        try
        {
            // set up schema
            initialiseSchema(reader, schemaName, filename);
            // do parse
            doParse(reader, filename, resourceGroup);
        }
        catch(const XMLException& exc)
        {
            
            /*
            if (exc.getCode() != XMLExcepts::NoError)
            {
            */
            delete reader;  
            /*
                char* excmsg = XMLString::transcode(exc.getMessage());
                String message("XercesParser::parseXMLFile - An error occurred at line nr. " + PropertyHelper::uintToString((uint)exc.getSrcLine()) + " while parsing XML file '" + filename + "'.  Additional information: ");
                message += excmsg;
                XMLString::release(&excmsg);
                throw Exception(message);
            }
            */
        }
        catch(const SAXParseException& exc)
        {
            delete reader;
            /*
            char* excmsg = XMLString::transcode(exc.getMessage());
            String message("XercesParser::parseXMLFile - An error occurred at line nr. " + PropertyHelper::uintToString((uint)exc.getLineNumber()) + " while parsing XML file '" + filename + "'.  Additional information: ");
            message += excmsg;
            XMLString::release(&excmsg);
            throw FileIOException(message);
            */
        }
        catch(...)
        {
            delete reader;
            /*
            Logger::getSingleton().logEvent("XercesParser::parseXMLFile - An unexpected error occurred while parsing XML file '" + filename + "'.", Errors);
            throw;
            */
        }
        // cleanup
        delete reader;
    }
    bool XercesXMLParser::initializeImpl(void)
    {
        XERCES_CPP_NAMESPACE_USE;

        // initialise Xerces-C XML system
        try
        {
            XMLPlatformUtils::Initialize();
            return true;
        }
        catch(XMLException& exc)
        {
            return false;
            /*
            // prepare a message about the failure
            char* excmsg = XMLString::transcode(exc.getMessage());
            String message("An exception occurred while initialising the Xerces-C XML system.  Additional information: ");
            message += excmsg;
            XMLString::release(&excmsg);

            // throw a C string (because it won't try and use logger, which may not be available)
            throw message.c_str();
            */
        }
    }
    void XercesXMLParser::cleanupImpl(void)
    {
        // cleanup XML stuff
        XERCES_CPP_NAMESPACE_USE;
        XMLPlatformUtils::Terminate(); 
    }
    void XercesXMLParser::populateAttributesBlock(const XERCES_CPP_NAMESPACE::Attributes& xerces_attr, Properties& attr)
    {
        XERCES_CPP_NAMESPACE_USE;
        String attributeName;
        String attributeValue;
        for (uint32 i = 0; i < xerces_attr.getLength(); ++i)
        {
            XMLCh* name  = src.getLocalName(i);
            XMLCh* value = src.getValue(i);
            attributeName = transcodeXmlCharToString(name, XMLString::stringLen(name));
            attributeValue = transcodeXmlCharToString(value, XMLString::stringLen(value));
            attr.add(attributeName, attributeValue);
        }
    }
    String XercesXMLParser::transcodeXmlCharToString(const XERCES_CPP_NAMESPACE::XMLCh* const xmlch_str, unsigned int inputLength)
    {
        String out;
        XERCES_CPP_NAMESPACE_USE;
        XMLTransService::Codes  res;
        XMLTranscoder* transcoder = XMLPlatformUtils::fgTransService->
            makeNewTranscoderFor(XMLRecognizer::US_ASCII, res, 4096, XMLPlatformUtils::fgMemoryManager);

        if (res == XMLTransService::Ok)
        {
            char* outBuff[128];
            unsigned int outputLength;
            unsigned int eaten = 0;
            unsigned int offset = 0;
//            unsigned int inputLength = XMLString::stringLen(xmlch_str); // dalfy caracters node need to transcode but give the size 

            while (inputLength)
            {
                outputLength = transcoder->transcodeTo(xmlch_str + offset, inputLength, outBuff, 128, 
                                                       eaten, XMLTranscoder::UnRep_RepChar);
                out.append(outBuff, outputLength);
                offset += eaten;
                inputLength -= eaten;
            }
            delete transcoder;
        }
        // Handling of error 
        return out;
    }
    void XercesXMLParser::initialiseSchema(XERCES_CPP_NAMESPACE::SAX2XMLReader* reader, const String& schemaName, const String& xmlFilename)
    {
/*
        XERCES_CPP_NAMESPACE_USE;
        // enable schema use and set validation options
        reader->setFeature(XMLUni::fgXercesSchema, true);
        reader->setFeature(XMLUni::fgSAX2CoreValidation, true);
        reader->setFeature(XMLUni::fgXercesValidationErrorAsFatal, true);

        // load in the raw schema data
        // RawDataContainer rawSchemaData;
        // try base filename first, from default resource group

        try
        {
            Logger::getSingleton().logEvent("XercesParser::initialiseSchema - Attempting to load schema from file '" + schemaName + "'.");
            System::getSingleton().getResourceProvider()->loadRawDataContainer(schemaName, rawSchemaData, d_defaultSchemaResourceGroup);
        }
        // oops, no file.  Try an alternative instead, using base path and
        // resource group from the XML file we're going to be processing.
        catch(InvalidRequestException)
        {
            // get path from filename
            String schemaFilename;
            size_t pos = xmlFilename.rfind("/");
            if (pos == String::npos) pos = xmlFilename.rfind("\\");
            if (pos != String::npos) schemaFilename.assign(xmlFilename, 0, pos + 1);
            // append schema filename
            schemaFilename += schemaName;
            // re-try the load operation.
            Logger::getSingleton().logEvent("XercesParser::initialiseSchema - Attempting to load schema from file '" + schemaFilename + "'.");
            System::getSingleton().getResourceProvider()->loadRawDataContainer(schemaFilename, rawSchemaData, resourceGroup);
        }
        // wrap schema data in a xerces MemBufInputSource object
        MemBufInputSource  schemaData(
            rawSchemaData.getDataPtr(),
            static_cast<const unsigned int>(rawSchemaData.getSize()),
            schemaName.c_str(),
            false);
        reader->loadGrammar(schemaData, Grammar::SchemaGrammarType, true);
        // enable grammar reuse
        reader->setFeature(XMLUni::fgXercesUseCachedGrammarInParse, true);

        // set schema for usage
        XMLCh* pval = XMLString::transcode(schemaName.c_str());
        reader->setProperty(XMLUni::fgXercesSchemaExternalNoNameSpaceSchemaLocation, pval);
        XMLString::release(&pval);
        Logger::getSingleton().logEvent("XercesParser::initialiseSchema - XML schema file '" + schemaName + "' has been initialised.");

        // use resource provider to release loaded schema data (if it supports this)
        System::getSingleton().getResourceProvider()->unloadRawDataContainer(rawSchemaData);
*/
    }

    XERCES_CPP_NAMESPACE::SAX2XMLReader* XercesXMLParser::createReader(XERCES_CPP_NAMESPACE::DefaultHandler& handler)
    {
  
      XERCES_CPP_NAMESPACE_USE;

        SAX2XMLReader* reader = XMLReaderFactory::createXMLReader();

        // set basic settings we want from parser
        reader->setFeature(XMLUni::fgSAX2CoreNameSpaces, true);

        // set handlers
        reader->setContentHandler(&handler);
        reader->setErrorHandler(&handler);

        return reader;
    }

    void XercesXMLParser::doParse(XERCES_CPP_NAMESPACE::SAX2XMLReader* parser, const String& xmlFilename, const String& resourceGroup)
    {
/*
        XERCES_CPP_NAMESPACE_USE;

        // use resource provider to load file data
        //RawDataContainer rawXMLData;
        //System::getSingleton().getResourceProvider()->loadRawDataContainer(xmlFilename, rawXMLData, resourceGroup);
        LocalFileInputSource fileData(
            
        MemBufInputSource  fileData(
            rawXMLData.getDataPtr(),
            static_cast<const unsigned int>(rawXMLData.getSize()),
            xmlFilename.c_str(),
            false);

         // perform parse
         try
         {
             parser->parse(fileData);
         }
         catch(...)
         {
             // use resource provider to release loaded XML source (if it supports this)
             //System::getSingleton().getResourceProvider()->unloadRawDataContainer(rawXMLData);

             throw;
         }
         // use resource provider to release loaded XML source (if it supports this)
         //System::getSingleton().getResourceProvider()->unloadRawDataContainer(rawXMLData);
         */
    }
}
/*******************************************************************************/
