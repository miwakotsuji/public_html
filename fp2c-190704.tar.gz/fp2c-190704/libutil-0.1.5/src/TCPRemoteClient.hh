/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @file
* @ingroup util_system
* @brief TCPRemoteClient class declaration 
*
* - Supports: 
*   - system: 
*     - UNIX (Linux)
*     - Win32 (XP)
* - Created: 2005-05-29
* - Creator: Olivier Delannoy
* - $Revision $
* - Changelog: 
*    * 2005-08-06 : Integrated to libutil 
*    * 2005-05-29 : Initial version  
*******************************************************************************
@LICENSE@ 
*******************************************************************************/
#ifndef UTIL_TCPREMOTECLIENT_HH
#define UTIL_TCPREMOTECLIENT_HH 1
# include "TCPSocket.hh"
# include "TCPServer.hh" 
namespace Util {
    /**
     * @brief Remote client are server side communication with client
     * end point.
     * 
     * - Supports: 
     *   - system: 
     *     - UNIX (Linux)
     *     - Win32 (XP)
     * - Created: 2005-05-29
     * - Creator: Olivier Delannoy
     * - $Revision $
     * - Changelog: 
     *    * 2005-08-06 : Integrated to libutil 
     *    * 2005-05-29 : Initial version  
     */
    class TCPRemoteClient : public Util::TCPSocket
    {   
    public:
        /**
         * Destructor 
         */
        virtual ~TCPRemoteClient(void);
         
        using Util::TCPSocket::send;
        using Util::TCPSocket::read;
        using Util::TCPSocket::recv;
        using Util::TCPSocket::write;
        using Util::TCPSocket::shutdown;
        
    protected:
        TCPRemoteClient(int32 socket);
         
    private:
        friend class TCPServer;
    };
}
#endif
/*******************************************************************************/



