/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @ingroup util_system
 * @file
 * @brief Process Class definition 
 *  
 * - Supports:
 *   - System 
 *       - UNIX (Linux)
 * - Last change in revision : $Revision $
 * - Created: 2005-08-06
 * - Creator: Olivier Delannoy
 * - Changelog: 
 *    
 *    * 2005-08-06 : Initial version  
 *******************************************************************************
@LICENSE@
 *******************************************************************************/
#include "Process.hh"
#ifndef UTIL_OPT_INLINE
#  define inline
#  include "Process.icc"
#  undef inline
#endif
#ifndef __GNUC__
#include <libgen.h>
#endif
#if defined(__WIN32__) || defined(_WIN32)
#  include <process.hh> 
#else
#  include <unistd.h>
#  include <sys/types.h>
#  include <sys/wait.h>
#endif 

#include "RuntimeEnvironment.hh" 
#include <cassert> 
#include <cstring>

Util::Process::Process(void)
    : mState(PROCESS_WAITING)
{
}
Util::Process::~Process(void)
{
}
Util::Process::Process(Util::Process& src)
{
    assert(0);
}
Util::Process& Util::Process::operator=(Util::Process& src)
{
    assert(0);
    return *this;
}
bool Util::Process::start(const Util::String& program, const Util::StringList& parameters, const Util::String& workingDir)
{
    UTIL_DEBUGUTIL("parameters count: " << parameters.size());
    mState = PROCESS_STARTING;
    // Common operation 
    mParameters = parameters;
    // Prepare command line parameters 
    const char** args = new const char*[2 + parameters.size()];
    StringList::const_iterator iter = mParameters.begin();
    uint32 i = 1;
    args[0] = basename((char *)program.c_str());
    UTIL_DEBUGUTIL("  program: " << program);
    UTIL_DEBUGUTIL("  basename: " << args[0]);
    
    for ( ; iter != mParameters.end() ; ++iter, ++i)
    {
        UTIL_DEBUGUTIL(" param " << i <<": " << *iter);
        args[i] = iter->c_str();
    }
    args[i] = 0;
    String currentDir = RuntimeEnvironment::workingDir();
    if (workingDir != "")
    {
        RuntimeEnvironment::workingDir(workingDir);
        if (RuntimeEnvironment::workingDir() == currentDir)
        {
            //It's an error 
            delete [] args;
            return false;
        }
    }
    // Does the spawning job 
#if defined(__WIN32__) || defined(_WIN32)
    // A call to spawn 
    // Change dir before 
    mPid = _spawnv(PNOWAIT0, program.c_str(), args);
    if (mPid == -1)
    {
        delete [] args;
        if (RuntimeEnvironment::workingDir() != currentDir)
        {
            RuntimeEnvironment::workingDir(currentDir);
        }
        // Spawn failed 
        return false;
    }
#else 
    // A call to fork 
    mPid = fork();
    if (mPid == -1)
    {
        delete [] args;
        if (RuntimeEnvironment::workingDir() != currentDir)
        {
            RuntimeEnvironment::workingDir(currentDir);
        }
        // Fork failed 
        return false;
    }
    else if (mPid == 0)
    {
        execv(program.c_str(), (char* const*)args);
        exit(1);
    }
#endif 
    mState = PROCESS_RUNNING;
    if (RuntimeEnvironment::workingDir() != currentDir)
    {
        RuntimeEnvironment::workingDir(currentDir);    
    }
    delete [] args;
    return true;
}

void Util::Process::wait(void)
{
#if defined(__WIN32__) || defined(_WIN32)
#else         
    if (mState != PROCESS_RUNNING)
        return;
    int eStatus;
    int status = waitpid(mPid, &eStatus, 0);
    if (status == mPid)
    {
        if (WIFEXITED(eStatus))
            mExitStatus = WEXITSTATUS(eStatus);
        mState = PROCESS_FINISHED;
    }
#endif
}

Util::ProcessState Util::Process::state(void)
{
    UTIL_DEBUGUTIL("Process state: " << mState);
    if (mState == PROCESS_RUNNING)
    {
#if defined(__WIN32__) || defined(_WIN32)
#else         
        UTIL_DEBUGUTIL("Checking whether the process is finished or not");
        // Check if the process is finished or not 
        int eStatus;
        int status = waitpid(mPid, &eStatus, WNOHANG);
        UTIL_DEBUGUTIL("Status: " << status << " PID:" << mPid);
        if (status == mPid)
        {
            if (WIFEXITED(eStatus))
                mExitStatus = WEXITSTATUS(eStatus);    
            mState = PROCESS_FINISHED;
        }
#endif
    }
    return mState;
}
/*******************************************************************************/



