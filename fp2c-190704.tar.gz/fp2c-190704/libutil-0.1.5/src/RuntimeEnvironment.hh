/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @file
* @ingroup util_system
* @brief RuntimeEnvironement Class declaration
*
* - Supports: 
*   - system: 
*     - UNIX (Linux)
*     - Win32 (XP)
* - Created: 2005-05-29
* - Creator: Olivier Delannoy
* - $Revision $
* - Changelog: 
*    * 2005-08-06 : Integrated to libutil 
*                   - Moved from Util::Compat namespace to Util
*                   - Removed common directories static dirs 
*    * 2005-05-29 : Initial version  
*******************************************************************************
@LICENSE@ 
*******************************************************************************/
#ifndef UTIL_RUNTIME_ENVIRONMENT_HH
#define UTIL_RUNTIME_ENVIRONMENT_HH 1
#include "util_namespace.hh"
namespace Util {
    /**
     * @ingroup util_system 
     * @brief Give access to the environment of the application
     * 
     * This class encapsulate all operation related to the 
     * execution in which the application is executed. 
     * This class provide an access to : 
     * - Environment variable 
     * - Current Working Directory 
     * - Current time 
     *
     * - Supports: 
     *   - system: 
     *     - UNIX (Linux)
     *     - Win32 (XP)
     * - Created: 2005-05-29
     * - Creator: Olivier Delannoy
     * - $Revision $
     * - Changelog: 
     *    * 2005-08-06 : Integrated to libutil 
     *                   - Moved from Util::Compat namespace to Util
     *                   - Removed common directories static dirs 
     *    * 2005-05-29 : Initial version  
     */
    class UTIL_EXPORT RuntimeEnvironment 
    {
    public:
        /**
         * Get the value of an environment var
         * 
         * @param name The name of the var 
         * @param defValue The value to return if the var is not set 
         * @return The value of this var or the default value. 
         */
        static String env(const String& name, const String& defValue = "");
        /**
         * Set the environment variable 
         * @param name The name of the var
         * @param value The new value of the var 
         */
        static void updateEnv(const String& name, const String& value);
        /**
         * Retrieve current working directory
         */
        static String workingDir(void);
        /** 
         * Change current working dir 
         */
        static void workingDir(const String& dir);

        /**
         * Get the process ID 
         */
        static uint32 processID(void);

        /** 
         * Get the current unix time 
         */
        static int32 unixTime(void);
        /**
         * Get the path separator 
         */
        static const char PATH_SEPARATOR; 
    protected:
    private: 
    };    
}
#endif
/*******************************************************************************/



