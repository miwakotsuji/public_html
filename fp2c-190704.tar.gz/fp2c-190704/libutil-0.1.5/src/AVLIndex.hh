/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @file
 * @brief Class AVLIndex declaration
 *  
 * 
 * - Supports: All  
 * - Created: 2006-03-17
 * - Creator: Olivier Delannoy
 * - Last change in revision : $Revision $
 * - Changelog: 
 *    
 *    * 2006-03-17 : Initial version  
 ******************************************************************************
Copyright Olivier Delannoy 2005

Olivier Delannoy <Olivier.Delannoy@gmail.com>

This software is a computer program whose purpose is to [describe
functionalities and technical features of your software].

This software is governed by the CeCILL  license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.

 *******************************************************************************/
#ifndef UTIL_AVLINDEX_HH
#define UTIL_AVLINDEX_HH 1
#include "util_namespace.hh"
#include "Index.hh" 
#include <iostream> 
#include <iomanip> 
#include <cstring>
namespace Util 
{
    /**
     * @brief  Index implementation made with an AVL Tree. 
     *
     * This is an implementation of the Index template to provide 
     * based on an AVLTree. The implementation provides the following complexities : 
     *   - find: O(log n)
     *   - insert: O(log n)
     *   - remove: Not implemented  
     * 
     * - Supports: All
     * - Author: Olivier Delannoy
     * - Creator: 2006-03-17
     * - $Revision $
     */
    template <typename Key, typename Value>
    class UTIL_EXPORT AVLIndex : public Index<Key, Value> 
    {
    public:    
        typedef Key key_type;
        typedef Value value_type;
        struct Node
        {
            /** Left child index */
            uint32 mLeft;
            /** Right child index */ 
            uint32 mRight;
            /** parent node */
            uint32 mParent;
            /** Key */
            key_type mKey;
            /** Value */
            value_type mValue;
        };
        /**
         * Constructor 
         * @param capacity initial size for the AVLIndex 
         */
        AVLIndex(uint32 capacity)
            : mCapacity(capacity), mSize(0), mRootIndex(0), mNodes(0)
        {
            mNodes = new Node[1 + capacity];
            // We left out the first node (0)     
        }
        
        
        /**
         * Destructor 
         */
        virtual ~AVLIndex(void)
        {
            delete[] mNodes;
        }
        /* Inherited doc */
        virtual void insert(const key_type& key, const value_type& newValue)
        {
            ++mSize;
            UTIL_DEBUGUTIL("Insert(" << mSize << "): " << key.value );
            // check capacity
            if (mSize == mCapacity)
            {
                Node* tmp = new Node[2*mCapacity + 1];
                memcpy(reinterpret_cast<char*>(tmp), reinterpret_cast<char*>(mNodes), sizeof(Node)*(mCapacity+1));
                delete [] mNodes;
                mNodes = tmp;
                mCapacity *= 2;
            }
            mNodes[mSize].mLeft = 0;
            mNodes[mSize].mRight = 0;
            mNodes[mSize].mParent = 0;
            mNodes[mSize].mValue = newValue;
            mNodes[mSize].mKey = key;
            if (mRootIndex == 0)
            {
                mRootIndex = mSize;
            }
            else
            {
                //////////////////////
                // Node:= rootIndex;//
                //////////////////////
                uint32 node = mRootIndex;
                uint32 parent = mRootIndex;
                int32 comp = 0;
                while(node)
                {
                    parent = node;
                    if (comp = key_type::compare(mNodes[mSize].mKey, mNodes[node].mKey))
                    {
                        switch (comp)
                        {
                        case -1:
                            node = mNodes[node].mLeft;
                            break;
    
                        case 0:
                            // It's already in skipping 
                            --mSize;
                            break;

                        case 1:
                            node = mNodes[node].mRight;
                            break;
                        }
                        
                    }
                }
                switch(comp)
                {
                case -1:
                    mNodes[parent].mLeft = mSize;
                    break;
                    
                case 1:
                    mNodes[parent].mRight = mSize;
                    break;
                }
                mNodes[mSize].mParent = parent;
                balance(mSize);
            }
        }
        /* Inherited doc */
        const value_type& find(const key_type& key)
        {
            uint32 node = mRootIndex;
            int32 comp = 0;
            
            while(node)
            {
                comp = key_type::compare(key, mNodes[node].mKey);
                switch(comp)
                {
                case 0:
                    return mNodes[node].mValue;
                case 1:
                    node = mNodes[node].mLeft;
                    break;
                case -1:
                    node = mNodes[node].mRight;
                    break;
                }
            }
            return value_type::nil;
        }
        uint32 size(void) const
        {
            return mSize; 
        }
        /**
         * This method is used for debugging purpose and so does some assumption 
         *  - The Key.value field exists and can be displayed using the << operator on iostream 
         *  - The Value.value field exists and can be displayed using the << operator on iostream 
         * @param out the stream used for dumping the tree 
         */
        void dump(std::ostream& out) const
        {
            out << "|Root    : " << std::setw(43) << mRootIndex << '|' << std::endl
                << "|Capacity: " << std::setw(43)<< mCapacity << '|' << std::endl 
                << "|Size    : " << std::setw(43) << mSize << '|' << std::endl;
            
            out << "|   Index|    Left|   Right|  Parent|     Key|   Value|" << std::endl
                << "|-----------------------------------------------------|" << std::endl;
            for(uint32 i = 1 ; i <= mSize ; ++i)
            {
                out << '|' << std::setw(8) << i 
                    << '|' << std::setw(8) << mNodes[i].mLeft
                    << '|' << std::setw(8) << mNodes[i].mRight
                    << '|' << std::setw(8) << mNodes[i].mParent
                    << '|' << std::setw(8) << mNodes[i].mKey.value
                    << '|' << std::setw(8) << mNodes[i].mValue.value
                    << '|' << std::endl;
            }
            out << "|-----------------------------------------------------|" << std::endl;
        }
        void dumpDot(std::ostream& out) const
        {
            out << "digraph debug" << std::endl
                << "{" << std::endl;
            out << "\troot -> node" << mRootIndex << std::endl;
            out << "\troot [shape=box];" << std::endl;
            for (uint32 i = 1 ; i <= mSize ; ++i)
            {
                if (mNodes[i].mLeft)
                    out << "\tnode" << i << " -> node" << mNodes[i].mLeft << ";" << std::endl;
                if (mNodes[i].mRight)
                out << "\tnode" << i << " -> node" << mNodes[i].mRight << ";" << std::endl;
                if (mNodes[i].mParent)
                    out << "\tnode" << i << " -> node" << mNodes[i].mParent << "[color=red];" << std::endl;
                else 
                    out << "\tnode" << i << " -> root [color=red];" << std::endl;
                
                out << "\tnode" << i << "[label=\"" << i << "/" << mNodes[i].mKey.value /* << "/" << mNodes[i].mValue.value */ << "\"];" << std::endl;
            }
            out << "}" << std::endl;    
        }
    protected:
    private:
        uint32 findNodeIndex(const key_type& key)
        {
            uint32 node = mRootIndex;
            int32 comp = 0;
            while (node)
            {
                comp = key_type::compare(key, mNodes[node].mKey);
                switch(comp)
                {
                case 0:
                    return node;
                case 1:
                    node = mNodes[node].mLeft;
                    break;
                case -1:
                    node = mNodes[node].mRight;
                    break;
                }
            }
            return node;
        }
        uint32 findParentNodeIndex(const key_type& key)
        {
            uint32 node = findNodeIndex(key);
            return mNodes[node].mParent;
        }
        void rotateLeft2(uint32 nodeIndex)
        {
            UTIL_DEBUGUTIL("RotateLeft2: " << nodeIndex);
            uint32 b = mNodes[nodeIndex].mParent;
            uint32 a = mNodes[b].mParent;
            uint32 d = mNodes[nodeIndex].mLeft;
            if (a)
            {
                if (mNodes[a].mLeft == b)
                    mNodes[a].mLeft = nodeIndex;
                else 
                    mNodes[a].mRight = nodeIndex;
                mNodes[nodeIndex].mParent = a;
            }
            else
            {
                mRootIndex = nodeIndex;
                mNodes[nodeIndex].mParent = 0;
            }
            mNodes[d].mParent = b;
            mNodes[b].mRight = d;
            mNodes[b].mParent = nodeIndex;
            mNodes[nodeIndex].mLeft = b;
        }
        void rotateLeft3(uint32 nodeIndex)
        {
            rotateRight2(mNodes[mNodes[nodeIndex].mRight].mLeft);
            rotateLeft2(mNodes[nodeIndex].mRight);
        }
        void rotateRight2(uint32 nodeIndex)
        {
            UTIL_DEBUGUTIL("RotateRight2: " << nodeIndex);
            uint32 b = mNodes[nodeIndex].mParent;
            uint32 a = mNodes[b].mParent;
            uint32 d = mNodes[nodeIndex].mRight;
            
            if (a)
            {
                if(mNodes[a].mLeft == b)
                    mNodes[a].mLeft = nodeIndex;
                else
                    mNodes[a].mRight = nodeIndex;
                mNodes[nodeIndex].mParent = a;                
            }
            else
            {
                mRootIndex = nodeIndex;
                mNodes[mRootIndex].mParent = 0;
            }
            mNodes[b].mParent = nodeIndex;
            mNodes[b].mLeft = d;
            mNodes[d].mParent = b;
            mNodes[nodeIndex].mRight = b;
        }
        void rotateRight3(uint32 nodeIndex)
        {
            rotateLeft2(mNodes[mNodes[nodeIndex].mLeft].mRight);
            rotateRight2(mNodes[nodeIndex].mLeft);
            
        }        
        void balance(uint32 nodeIndex)
        {
            
            uint32 left_height;
            uint32 right_height;
            uint32 node;
            node = mNodes[nodeIndex].mParent;
            while(node)
            {
                UTIL_DEBUGUTIL("Balance: " << node);
                left_height  = height(mNodes[node].mLeft);
                right_height = height(mNodes[node].mRight);   
                UTIL_DEBUGUTIL("Height (" << node << ") left(" << left_height << ") right(" << right_height << ")");
                if (right_height - left_height == 2)
                {
                    uint32 right = mNodes[node].mRight;
                    if (height(mNodes[right].mRight) > height(mNodes[right].mLeft))
                        rotateLeft2(right);
                    else
                        rotateLeft3(node);
                }
                else if (left_height - right_height == 2)
                {
                    uint32 left = mNodes[node].mLeft;
                    if (height(mNodes[left].mLeft) > height(mNodes[left].mRight))
                        rotateRight2(left);
                    else
                        rotateRight3(node);
                    
                }
                node = mNodes[node].mParent;
            }
        }
        /** 
         * Computes the height of the tree starting at a certain node 
         * @param nodeIndex The node to start the computation of the height
         * @return the height of the (sub)tree. 
         */
        uint32 height(uint32 nodeIndex)
        {
            uint32 left_height = 0;
            uint32 right_height = 0;
            if (nodeIndex ==0)
                return 0;
            if (mNodes[nodeIndex].mLeft == 0 && mNodes[nodeIndex].mRight == 0)
                return 1;
            if (mNodes[nodeIndex].mLeft)
                left_height = 1 + height(mNodes[nodeIndex].mLeft);

            if (mNodes[nodeIndex].mRight)
                right_height = 1 + height(mNodes[nodeIndex].mRight);

            return  left_height < right_height ? right_height : left_height;
        }
        


        /**  Store the current capacity */
        uint32 mCapacity;
        /** Store the current number of node used */
        uint32 mSize;
        /** Store the index of the current root in the tree */
        uint32 mRootIndex;
        /** Array of nodes */
        Node* mNodes;
    };

}
#endif // UTIL_AVLINDEX_HH
/*******************************************************************************/



