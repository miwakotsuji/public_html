/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @ingroup util_application 
 * @file
 * @brief Class Plugin declaration
 *  
 * - Supports: All (Throught libLTDL)
 * - Created: 2005-08-06
 * - Creator: Olivier Delannoy
 * - $Revision $
 * - Changelog: 
 *    
 *    * 2005-08-06 : Initial version  
 *******************************************************************************
Copyright Olivier Delannoy 2005

Olivier Delannoy <Olivier.Delannoy@gmail.com>

This software is a computer program whose purpose is to [describe
functionalities and technical features of your software].

This software is governed by the CeCILL  license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.

 *******************************************************************************/
#ifndef UTIL_PLUGIN_HH
#define UTIL_PLUGIN_HH 1
#include "util_namespace.hh" 


namespace Util {

/**
 * @ingroup util_application 
 * @brief Dynamic libraries loading implementation helper 
 * 
 * This class provides functions to load dynamic libraries on a specific 
 * operating system 
 */ 
class DLImpl;

    /**
     * @ingroup util_application 
     * @brief Dynamic libraries loading class
     *
     * This class provides functions to load dynamic libraries at
     * runtime. The exported symbol in the dynamic library should
     * match C naming standard. The Library writer must add a extern
     * "C" prefix to all exported function or class.
     */
    class Plugin
    {
    public:
        /**
         * Default Constructor
         */
        Plugin(void);
        /**
         * Destructor
         */
        ~Plugin(void);

        /**
         * Load a dynamic library.
         * @return 0 on success, and -1 on error
         */
        int open(const String& filename);
      
        /**
         * Test whether or not the plugin is loaded 
         * @return true if the plugin is loaded false otherwise. 
         *
         * @note this function is usefull when using the constructor that open the library. 
         * It prevent the use of exception within the Util::Compat namespace 
         */
        bool isOpened(void) const;
      
        /**
         * Get last plugin error.
         * @return a human readable string describing the most
         * recent error that occurred from any of the dl routines
         * (dlopen, dlsym or dlclose) since the last call to
         * dlerror().
         * It returns NULL if no errors have occurred since
         * initialization or since it was last called.
         */
        const String& lastError(void);

        /**
         * Get the handle on a function of the plugin.
         * @remarks Since this function may actually return NULL (which
         * does not necessarily mean that an error occured),
         * the correct way to test for an error is to call lastError()
         * to clear any old error conditions.
         * @remarks The plugin must respect the naming conventions
         * of the C language (extern "C") so that the plugin
         * can be loaded.
         */
        void* loadSymbol(const String& symbol);
        /**
         * Make this plugin resident. It will be impossible to
         * close this module afterwards.
         */
        void makeResident(void);
            
        /**
         * Check Whether a module is resident or not 
         */
        bool isResident(void);
        /** 
         * Add a path to the plugin search path 
         */
        static void addSearchPath(const String& path);
            
    protected:

    private:
        /**
         * Unload a dynamic library.
         * @return 0 on success, and non-zero on error
         */
        uint32 close();
        /**
         * Store the dynamic library implementation
         */
        DLImpl* mImpl;
        
        /**
         * Store the last error 
         */
        String mLastError;
    };
}
#endif
/*******************************************************************************/      



