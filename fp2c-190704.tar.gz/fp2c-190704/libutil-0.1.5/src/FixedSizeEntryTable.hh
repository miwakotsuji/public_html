/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @ingroup util_template
* @file
* @brief Template FixedSizeEntryTable definition   
*  
* This class provide binary data storage of fixed size entry in an efficent way.  
* - Supports: All 
* 
* - Created: 2005-08-06
* - Creator: Olivier Delannoy
* - Changelog: 
*
*    * 2005-08-06 : Initial version  
*/
/*******************************************************************************
Copyright Olivier Delannoy 2005

Olivier Delannoy <Olivier.Delannoy@gmail.com>

This software is a computer program whose purpose is to [describe
functionalities and technical features of your software].

This software is governed by the CeCILL  license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.

*******************************************************************************/
#ifndef UTIL_FIXEDSIZEENTRYTABLE_HH
#define UTIL_FIXEDSIZEENTRYTABLE_HH 1
#include "util_namespace.hh"
#include "LittleEndianStream.hh" 
#include <cassert>
#include <iterator>
#include <fstream>
namespace Util {
    /**
     * @ingroup util_template 
     * @brief Tables of fixed size lines.
     * 
     * This template defines a fixed size line table of binary
     * data. It relies on a binary representation in little
     * endian.  The file is composed of two parts. An header and a
     * lines list.  Each line are represented throught the TEntry
     * class. The table ensure constant time access, updates and
     * addition of new entries. There is no supports for removing
     * entries. The table data are encoded in little endian. This
     * fixed byte order ensure that file defines in this class are 
     * exactly the same on all architectures. 
     * 
     * Example: 
     * @code
     * #include "FixedSizeEntryTable.hh"
     * #include <fstream>
     *
     * struct StringInfo 
     * {
     *     Util::uint32 mOffset;
     *
     *     Util::uint32 mSize;
     *
     *     void write(Util::LittleEndianStream& stream)
     *     {
     *         stream.writeUint32(mOffset);
     *         stream.writeUint32(mSize);
     *     }
     *
     *     void read(Util::LittleEndianStream& stream)
     *     {
     *         stream.readUint32(mOffset);
     *         stream.readUint32(mSize);
     *     }
     *     static const Util::uint32 SIZE = 2*sizeof(Util::uint32);
     * };
     *
     *
     * typedef Util::TL::Table<StringInfo> StringInfoTable;
     *
     *  
     *
     * int main(int argc, char **argv) 
     * {
     *     StringInfoTable table("test.ft1");
     *
     *     StringInfo info;
     *     Util::uint32 index;
     *     if (! table.open())
     *         {
     *             std::cout << "Failed opening table" << std::endl;
     *             exit(1);
     *         }
     *     table.printStats(std::cout);
     *     if (argc >= 2) 
     *         {
     *             switch(argv[1][0]) 
     *                 {
     *                 case 'u':
     *                     assert(argc == 5);
     *                     index = atoi(argv[2]);
     *                     info.mOffset = atoi(argv[3]);
     *                     info.mSize = atoi(argv[4]);
     *                     table.updateEntry(index, &info);
     *                     std::cout << "Updating entry " << index << std::endl;
     *                     break;
     *                 case 'i':
     *                     assert(argc == 4);
     *                     info.mOffset = atoi(argv[2]);
     *                     info.mSize = atoi(argv[3]);
     *                     index = table.insertEntry(&info);
     *                     std::cout << "Adding entry " << index << std::endl;
     *                     break;
     *                 default:
     *                     assert(0);
     *                 }
     *             table.printStats(std::cout);
     *         }
     *     std::cout << "Table data:" << std::endl;
     *
     *     for(Util::uint32 i = 1 ; i <= table.lastIndex() ; ++i) 
     *         {
     *             table.getEntry(i, &info);
     *             std::cout << i << ";" << info.mOffset << ";" << info.mSize << std::endl;
     *         }
     *     return 0;
     * }
     * @endcode
     * @todo Update example to match the new interface 
     */
    template <class TEntry> class FixedSizeEntryTable
    {
    public:
        class iterator 
        {
        public:
            typedef iterator  _Self;
            typedef int32 difference_type;
            typedef std::random_access_iterator_tag iterator_category;
            typedef TEntry value_type;
            typedef TEntry* pointer;
            typedef TEntry& reference;
            iterator(FixedSizeEntryTable* source, uint32 index) 
                : mIndex(index),  mSource(source)
            {
                mSource->getEntry(index, mEntry);
            }
            reference operator*(void) 
            {
                return mEntry;
            }
            pointer operator->(void) 
            {
                return &mEntry;
            }
            _Self& operator++(void)
            {
                ++mIndex;
                mSource->getEntry(mIndex, mEntry);
                return *this;
            }
            _Self& operator++(int) 
            {
                _Self __tmp = *this;
                ++mIndex;
                mSource->getEntry(mIndex, mEntry);
                return __tmp;
            }
            _Self& operator--(void)
            {
                --mIndex;
                mSource->getEntry(mIndex, mEntry);
                return *this;
            }
            _Self& operator--(int)
            {
                _Self __tmp = *this;
                --mIndex;
                mSource->getEntry(mIndex, mEntry);
                return __tmp;
            }
            _Self& operator+=(difference_type __n)
            {
                if (mIndex - __n < 0)
                    mIndex = 0;
                else 
                    mIndex += __n;  
                mSource->getEntry(mIndex, mEntry);
                return *this;
            }
            _Self operator+(difference_type __n)
            {
                _Self __tmp = *this;
                return __tmp += __n;
            }
            _Self& operator-=(difference_type __n)
            {
                return *this += -__n;
            }
            _Self& operator-(difference_type __n)
            {
                _Self __tmp = *this;
                return __tmp += - __n;
            }
            reference operator[](difference_type __n)
            {
                return *(*this + __n);
            }

            bool operator==(const _Self& __x) const
            {
                return mIndex == __x.mIndex;
            }
            bool operator!=(const _Self& __x) const 
            {
                return mIndex != __x.mIndex;
            }
            uint32 index(void) const 
            {
                return mIndex;
            }
            difference_type operator-(const _Self& __iter) const 
            {
                return mIndex - __iter.mIndex;
            }
            

        protected:
        private:
            uint32 mIndex;
            TEntry mEntry;
            FixedSizeEntryTable<TEntry>* mSource;
        };
        class const_iterator 
        {
        public:
            typedef const_iterator _Self;
            typedef int32 difference_type;
            typedef std::random_access_iterator_tag iterator_category;
            typedef TEntry value_type;
            typedef const TEntry* pointer;
            typedef const TEntry& reference;
            const_iterator(FixedSizeEntryTable* source, uint32 index) 
                :  mIndex(index), mSource(source)
            {
                mSource->getEntry(index, mEntry);
            }             
            reference operator*(void) const
            {
                return mEntry;
            }
            pointer operator->(void) const
            {
                return &mEntry;
            }
            _Self& operator++(void)
            {
                ++mIndex;
                mSource->getEntry(mIndex, mEntry);
                return *this;
            }
            _Self& operator++(int) 
            {
                _Self __tmp = *this;
                ++mIndex;
                mSource->getEntry(mIndex, mEntry);
                return __tmp;
            }
            _Self& operator--(void)
            {
                --mIndex;
                mSource->getEntry(mIndex, mEntry);
                return *this;
            }
            _Self& operator--(int)
            {
                _Self __tmp = *this;
                --mIndex;
                mSource->getEntry(mIndex, mEntry);
                return __tmp;
            }
            _Self& operator+=(difference_type __n)
            {
                if (mIndex - __n < 0)
                    mIndex = 0;
                else 
                    mIndex += __n;  
                mSource->getEntry(mIndex, mEntry);
                return *this;
            }
            _Self operator+(difference_type __n)
            {
                _Self __tmp = *this;
                return __tmp += __n;
            }
            _Self& operator-=(difference_type __n)
            {
                return *this += -__n;
            }
            difference_type operator-(const _Self& __iter) const 
            {
                return mIndex - __iter.mIndex;
            }
            _Self& operator-(difference_type __n) 
            {
                _Self __tmp = *this;
                return __tmp += - __n;
            }
            reference operator[](difference_type __n)
            {
                return *(*this + __n);
            }
            bool operator==(const _Self& __x) const
            {
                return mIndex == __x.mIndex;
            }
            bool operator!=(const _Self& __x) const 
            {
                return mIndex != __x.mIndex;
            } 
            uint32 index(void) const 
            {
                return mIndex;
            }
        protected:
        private:
            uint32 mIndex;
            TEntry mEntry;
            FixedSizeEntryTable<TEntry>* mSource;    
        };        
        typedef TEntry value_type;
        typedef TEntry* pointer;
        typedef const TEntry* const_pointer;
        typedef TEntry& reference;
        typedef const TEntry& const_reference;
        typedef std::reverse_iterator<iterator> reverse_iterator;
        typedef std::reverse_iterator<const_iterator> const_reverse_iterator;
        typedef uint32 size_type;
        typedef int32 difference_type;
        typedef FixedSizeEntryTable<TEntry> Self;
        /** 
         * Constructor 
         * @param fileName the name of the file containing the Table. 
         */
        explicit FixedSizeEntryTable(const String& fileName) 
            : mStream(0), 
              mFileName(fileName), 
              mEntriesCount(0),               
              mEntriesSize(0),
              mOpen(false)
        {
        }
        /** 
         * Destructor 
         */
        virtual ~FixedSizeEntryTable(void)
        {
            delete mStream;   
        }
        /** 
         * Open the table. It's required before any operation 
         * 
         * @return false if the header does not respect the file
         * format or if the file is of the wrong size
         */
        bool open(void)
        {
            UTIL_DEBUGUTIL("Opening table" << mFileName);
            
            mStream = new LittleEndianStream(mFileName);
            if (mStream->seek(0, std::ios_base::end) && ! mStream->tell())
            {
                UTIL_DEBUGUTIL("Creating header");
                createHeader();
            }
            delete mStream;
            mStream = new LittleEndianStream(mFileName);
            if (decodeHeader())
                mOpen = true;
            
            UTIL_DEBUGUTIL(mOpen);
            
            return mOpen;                
        }
        /** 
         * Clear the content of the table 
         */
        bool clear(void)
        {
            UTIL_DEBUGUTIL("Erase all table data");
            delete mStream;
            std::ofstream out;
            out.open(mFileName.c_str(), std::ios_base::out | std::ios_base::trunc);
            out.close();
            return open();		
        }
				
        iterator begin(void)
        {
            return iterator(this, 1);
        }
        const_iterator begin(void) const 
        {
            return const_iterator(this, 1);
        }
        iterator end(void)
        {
            return iterator(this, mEntriesCount + 1);
        }
        const_iterator end(void) const
        {
            return const_iterator(this, mEntriesCount + 1);
        }
        reverse_iterator rbegin(void)
        {
            return reverse_iterator(end());
            
        }
        const_reverse_iterator rbegin(void) const
        {
            return const_reverse_iterator(end());
        }
        reverse_iterator rend(void)
        {
            return reverse_iterator(begin());
        }
        const_reverse_iterator rend(void) const
        {
            return const_reverse_iterator(begin());
        }
        /**
         * Get the entry associated to @em index 
         *
         * @param index The index of the entry begining at 1.
         *
         *  @param entry A pointer to the resulting entry. It's up
         * to the caller to provide a pointer to an existing entry
         * object.
         * 
         * @return true if the entry exists false otherwise. 
         */
        bool getEntry(uint32 index,  TEntry& entry)
        {
            if (index > 0 && index <= mEntriesCount) 
            {
                mStream->seek(ENTRIES_OFFSET + mEntriesSize * index);
                entry.read(*mStream);
                return true;
            }
            return false;
        }            
        /**
         * Update the entry associated to @em index 
         * 
         * @param index The index of the entry (greater than 1).
         *
         * @param entry A pointer to the entry data used for the
         * update.
         * 
         * @return true if the entry exists false otherwise. 
         */
        bool updateEntry(Util::uint32 index, TEntry& entry)
        {
            if (index > 0 && index <= mEntriesCount)
            {
                mStream->seek(ENTRIES_OFFSET + mEntriesSize * index);
                entry.write(*mStream);
                mStream->flush();
                return true;
            }
            return false;    
        }
        /**
         * Insert a new entry to the table 
         * 
         * @param entry A pointer to the entry data. 
         * 
         * @return the index of the new entry. 
         */
        virtual uint32 insertEntry(TEntry& entry)
        {
            mStream->seek(0, std::ios_base::end);
            entry.write(*mStream);
            mStream->seek(ENTRIES_COUNT_OFFSET);
            ++mEntriesCount;
            mStream->write(mEntriesCount);
            mStream->flush();
            return mEntriesCount;
        }
        /**
         * Retrieve the index of the next available entry
         * 
         * @return the index of the next insert operation 
         */
        uint32 lastIndex(void) const throw()
        {
            return mEntriesCount;
        }
        /**
         * print  statistical information on the tables 
         * @param out the output stream used for printing 
         */
        void printStats(std::ostream& out) const throw()
        {
            out << "Table.......................: " << mFileName << std::endl
                << " - Format...................: Fixed Size Entry Table 1.0" << std::endl
                << " - Size of entries..........: " << mEntriesSize << std::endl
                << " - Number of entries........: " << mEntriesCount << std::endl
                << " - Offset of the first entry: " 
                << ENTRIES_OFFSET + mEntriesSize << std::endl
                << " - Size of table............: " 
                << ENTRIES_OFFSET + mEntriesSize * ( 1 +  mEntriesCount) 
                << std::endl;
        }
        /** This value is used whenever an operation which return an index failed */
        static const uint32 BAD_INDEX = 0;
    protected:
        /** 
         * Decode the content of the header or create one if the file is empty. 
         * 
         */ 
        virtual  bool decodeHeader(void)
        {
            UTIL_DEBUGUTIL("Decoding header");
            mStream->seek(0, std::ios_base::beg);
            int8 magicChar[4];
            // decode the existing header
            UTIL_DEBUGUTIL("Parsing file type");
            mStream->read(magicChar[0]);
            mStream->read(magicChar[1]);
            mStream->read(magicChar[2]);
            mStream->read(magicChar[3]);
            if ((magicChar[0] != 'F') || (magicChar[1] != 'T') || 
                (magicChar[2] != '1') || (magicChar[3] != '0'))
            {
                UTIL_DEBUGUTIL("Wrong File Type");
                return false;
            }
            
            
                
            mStream->read(mEntriesSize);
            if ((mEntriesSize != TEntry::SIZE))
            {
                UTIL_DEBUGUTIL("Wrong entry size");
                return false;
            }
            
            mStream->read(mEntriesCount);
            // check the size of the file 
            mStream->seek(0, std::ios_base::end);
            uint32 fsize = mStream->tell();
            if ( fsize != ENTRIES_OFFSET + mEntriesSize * (1 + mEntriesCount))
            {
                UTIL_DEBUGUTIL("Wrong file size");
                return false;
            }
            return true;
        }
        /**
         * Create a new header for newly created empty files
         */
        virtual void createHeader(void)
        {
            std::fstream * tmp = new std::fstream(mFileName.c_str(), std::ios_base::out);
            mStream = new Util::LittleEndianStream(tmp);
            // It's a new file lets create it 
            // magic number
            mStream->write('F');
            mStream->write('T');
            mStream->write('1');
            mStream->write('0');
            // size of an entry
            mStream->write(TEntry::SIZE);
            // count of an entry

            mStream->write(mEntriesCount);
            // padding 
            uint32  headerPadding = 0x0f0f0f0f;
            mStream->write(headerPadding);
            mStream->write(headerPadding);
            mStream->write(headerPadding);
            mStream->write(headerPadding);
            mStream->write(headerPadding);
                        
            // The first null entry filled with 1 
            uint8 padding = 0xff;
            for(uint8 i = 0 ; i < TEntry::SIZE ; ++i) 
            {
                mStream->write(padding);
            }        
            mStream->flush();
        }
        /**  The stream to use for communication */
        Util::LittleEndianStream *mStream;
    private:
        /** The name of the file containing the table */
        String mFileName;    
        /** The number of entry currently available */
        Util::uint32 mEntriesCount;
        /** The size of all entries */
        Util::uint32 mEntriesSize;
        /** True if the table is open and ready for reading and writing */
        bool mOpen;
        /** The offset of the size of entries */
        static const Util::uint32 ENTRIES_SIZE_OFFSET = 4;
        /** The offset of the count of entries */
        static const Util::uint32 ENTRIES_COUNT_OFFSET = 8;
        /** The offset for the null entry 0 */
        static const Util::uint32 ENTRIES_OFFSET = 32;
      
        /** Disabled default constructor */
        FixedSizeEntryTable(void) {}
        /** Disabled copy constructor */
        FixedSizeEntryTable(FixedSizeEntryTable& src) {assert(0);}
        /** Disabled assignment operator */
        FixedSizeEntryTable& operator=(FixedSizeEntryTable& src)
        {
            assert(0);
            return *this;
        }   
    };
template <typename T> 
std::ostream& operator<<(std::ostream& out, const FixedSizeEntryTable<T>& obj)
{
    obj.printStats(out);
    return out;
}
}

/*
  template <class TEntry> 
  typename Util::FixedSizeEntryTable<TEntry>::iterator::difference_type operator-(
  const typename Util::FixedSizeEntryTable<TEntry>::iterator& __lhs, 
  const typename Util::FixedSizeEntryTable<TEntry>::iterator& __rhs)
  {
  return __lhs.index() - __rhs.index();
  }

  template <class TEntry> 
  typename Util::FixedSizeEntryTable<TEntry>::iterator::difference_type operator-(
  const typename Util::FixedSizeEntryTable<TEntry>::iterator& __lhs, 
  const typename Util::FixedSizeEntryTable<TEntry>::const_iterator& __rhs)
  {
  return __lhs.index() - __rhs.index(); 
  }

  inline template <class TEntry> 
  Util::FixedSizeEntryTable<TEntry>::iterator::difference_type operator-(
  const Util::FixedSizeEntryTable<TEntry>::const_iterator& __lhs, 
  const Util::FixedSizeEntryTable<TEntry>::const_iterator& __rhs)
  {
  return __lhs.index() - __rhs.index(); 
  }
  inline template <class TEntry> 
  Util::FixedSizeEntryTable<TEntry>::iterator::difference_type operator-(
  const Util::FixedSizeEntryTable<TEntry>::const_iterator& __lhs, 
  const Util::FixedSizeEntryTable<TEntry>::iterator& __rhs)
  {
  return __lhs.index() - __rhs.index(); 
  }
*/


#endif
/******************************************************************************/



