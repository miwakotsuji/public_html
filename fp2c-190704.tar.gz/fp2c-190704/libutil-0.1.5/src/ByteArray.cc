/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @file
* @ingroup util_base
* @brief Class ByteArray definitions 
*  
*
* 
* 
* - Supports: 
*   - Unix: linux (POSIX) 
* - Created: 2006-03-24
* - Creator: Olivier Delannoy
* - $Revision $
* - Changelog: 
*    
*    * 2006-03-24 : Initial version  
******************************************************************************
@LICENSE@
*******************************************************************************/
#ifdef HAVE_CONFIG_H
#include "util_config.hh"
#endif
#include "ByteArray.hh"
#ifndef UTIL_OPT_INLINE
#define inline
#include "ByteArray.icc"
#undef inline
#endif
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h> 
#include <unistd.h> 
#include <exception> 
#include <cerrno> 
#include <cassert> 
#include <iostream>
namespace Util
{
    ByteArray::ByteArray(uint32 size) throw(std::bad_alloc)
        : mData(0), mSize(size)
    {
        if (size)
            mData = new byte[size];
    }
    ByteArray::ByteArray(const String& filename) throw(std::bad_alloc, IOException)
    {
        // It's a little bit more complex 
        int fd = 0;                 // File descriptor
        int status = 0;             // Sys call status 
        uint32 read = 0;            // Number of bytes read
        struct stat fd_stat;    // Store statistical information of the file 
        UTIL_DEBUGUTIL("ByteArray: Loading content from " << filename);
        
        // Open the file 
        fd = open(filename.c_str(), O_RDONLY);
        if (fd == -1)
        {
            throw IOException(errno, filename + ": Unable to open file");
        }
        // Get it's size 
        status = fstat(fd, &fd_stat);
        if (status == -1)
        {
            close(fd);
            throw IOException(errno, filename + ": Failed to get the size of the file");
        }
        mSize = fd_stat.st_size;
        // We should use RAII here 
        try 
        {
            mData = new byte[fd_stat.st_size]; 
        }
        catch(std::bad_alloc& ex)
        {
            close(fd);
            throw; // rethrow the same exception 
        }
        while(read < mSize)
        {
            status = ::read(fd,reinterpret_cast<char*>(mData + read), mSize - read);
            if (status == -1)
            {
                if (errno == EINTR)
                    continue;
                else 
                    throw IOException(errno, filename + ": reading failed");
            }
            if (status == 0)
            {
                break;
            }
            read += status;
        }
        close(fd);
    }
    void ByteArray::resize(uint32 newSize)
    {
        if (mSize == 0)
        {
            if (newSize)
            {
                mData = new byte[newSize];
            }
        }
        else
        {
            if (newSize)
            {
                byte* tmp = new byte[newSize];
                ::memcpy(reinterpret_cast<char*>(tmp), reinterpret_cast<char*>(mData), (mSize > newSize ) ? newSize : mSize);
                delete [] mData;
                mData = tmp;
            }
            else
            {
                delete mData;
                mData = 0;
            }    
        }
        mSize = newSize;
    }
    
    ByteArray::~ByteArray(void)
    {
        delete [] mData;
    }
}
/*******************************************************************************/
