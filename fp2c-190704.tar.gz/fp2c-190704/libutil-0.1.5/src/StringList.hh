/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @ingroup util_tools
 * @file
 * @brief Class StringList declaration
 *  
 * 
 * - Supports: All  
 * - Created: 2005-08-07
 * - Creator: Olivier Delannoy
 * - Last change in revision : $Revision $
 * - Changelog: 
 *    
 *    * 2005-08-07 : Initial version  
 ******************************************************************************
Copyright Olivier Delannoy 2005

Olivier Delannoy <Olivier.Delannoy@gmail.com>

This software is a computer program whose purpose is to [describe
functionalities and technical features of your software].

This software is governed by the CeCILL  license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.

 *******************************************************************************/
#ifndef UTIL_STRINGLIST_HH
#define UTIL_STRINGLIST_HH 1
#include "util_namespace.hh"
#include <iostream>
#include <list>
namespace Util 
{
    /**
     * @ingroup util_tools 
     * @brief String list template specialization with additionnal functionnalities. 
     * 
     * This class provides an augmented interface to
     * std::list<String>. Some common templates are specialize in
     * order to decrease the number of instantiation. Most of them are
     * based on a standard container from the STL and the String class. 
     * 
     * - Author: Olivier Delannoy
     * - Creator: 2005-08-07
     * - Last change in revision : $Revision $
     */
    class UTIL_EXPORT StringList : public std::list<String > 
    {
    public:
        /** 
         * Default constructor
         */
        StringList(void);
        /**
         * Constructor 
         * Create a StringList object from the basic corresponding type. 
         */
        StringList(std::list<String >& src);
        /** Destructor */ 
        virtual ~StringList(void);
        
        /**
         * Test whether a string is contains within the list 
         * @param string the string to search for 
         * @return true if the string is contains in it 
         */
        bool contains(const String& string) const;
        /**
         * Index of a string 
         * @param string the string to search for 
         * @param fromIndex Start the search from this index 
         * @return the index of the first string find 
         */
        int32 indexOf(const String& string, int32 fromIndex = 0) const;
        /**
         * Index of the last matching string of the list 
         * 
         * @param string the string to search for
         * 
         * @param fromIndex Start the search from this index
         * 
         * @return the index of the first string find begining at the
         * end of the list.
         */
        int32 lastIndexOf(const String& string, int32 fromIndex= 0) const;
        /**
         * Return a string composed of the join of all string in the list 
         * @param separator The separator used between strings 
         * @return the resulting string. 
         */
        String join(const String& separator = " ") const ;
        /**
         * Insert a string in the list 
         */
        StringList& operator+(const String& newElement);
        /**
         * Insert a string in the list 
         */
        StringList& operator<<(const String& newElement);
        /**
         * Insert a string list in the list 
         */
        StringList& operator<<(const StringList& list);
        /**
         * Printout the object to a stream 
         * 
         * @param out the stream object 
         */
        virtual void print(std::ostream& out) const;
    protected:
    private:    
    };
}
std::ostream& operator<<(std::ostream&, const Util::StringList& obj);
#ifdef UTIL_OPT_INLINE
#include "StringList.icc"
#endif
#endif // UTIL_STRINGLIST_HH
/*******************************************************************************/



