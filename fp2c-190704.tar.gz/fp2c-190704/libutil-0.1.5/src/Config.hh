/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @ingroup util_application
* @file
* @brief Class Config Declaration 
*  
* - Supports: All
* - Created: 2005-08-06
* - Creator: Olivier Delannoy
* - $Revision $
* - Changelog: 
*    
*    * 2005-08-06 : Initial version  
*******************************************************************************
Copyright Olivier Delannoy 2005

Olivier Delannoy <Olivier.Delannoy@gmail.com>

This software is a computer program whose purpose is to [describe
functionalities and technical features of your software].

This software is governed by the CeCILL  license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.

*******************************************************************************/
#ifndef UTIL_CONFIG_HH
#define UTIL_CONFIG_HH 1
#include "util_namespace.hh"
#include <map>
#include <iostream> 
namespace Util {
    /**
     * @ingroup util_application
     * @brief Abstract Configuration class  
     *
     * Config class define configuration information organised in two
     * level.  All configuration value is stored in a group and have a
     * key. The same key might exists in multiple groups but only once
     * in a group. The last appearance of the key is used if the same
     * key appear twice.
     *
     * Configuration informations are stored in files each file might
     * have a different format. 
     */
    class Config
    {
    public:
        /** 
         * Destructor 
         */
        virtual ~Config(void);
        /**
         * Retrieve the configuration value 
         * @param group the name of the group 
         * @param key the name of the key in @em group 
         * @param fallback the value if the key does not exists 
         * @return A string containing the key value 
         */
        String get(const String& group, const String& key, const String& fallback = "") const;
        /**
         * Set a key in a group. If the group does not exists it is automatically created 
         * @param group The name of the group 
         * @param key the name of the key 
         * @param value The value associated with the key 
         */
        void set(const String& group, const String& key, const String& value);
        /**
         * Delete a key in a group empty groups are automaticaly removed 
         * @param group The name of a group 
         * @param key The name of the key in the group 
         *
         */
        void unset(const String& group, const String& key);
        /**
         * Test if the group exists 
         * @param group The name of the group 
         * @return true if the group exists 
         */
        bool exists(const String& group) const;
        /**
         * Test if the key exists in @em group 
         * @param group The name of the group 
         * @param key The name of the key 
         * @return true if the key exists
         */
        bool exists(const String& group, const String& key) const;
        /**
         * load from a file configuration informations. 
         */
        void load(const String& fileName);
        /**
         * save to a file configuration informations.
         */
        void save(const String& fileName, bool overwrite = true);
        /** 
         * save change to the file previously used 
         */
        void save(void);
        /**
         * Output configuration information to stream out 
         */
        virtual void print(std::ostream& out) const;
        /** 
         * Clone current object 
         */
        virtual Config* clone(void) const = 0;
    protected:
        /**
         *  Default Constructor 
         */
        Config(void);
        /**
         * Load configuration file from a file 
         */
        virtual void loadImpl(const String& fileName) = 0;
        /**
         * Save configuration file to a file 
         */
        virtual void saveImpl(const String& fileName, bool overwrite) = 0;
        /**
         * Typename for configuration key value pair
         */
        typedef std::map<String, String> ConfigGroup;
        /**
         * Typename for configuration group list 
         */
        typedef std::map<String, ConfigGroup> ConfigData;
        /**
         * Store configuration entries 
         */
        ConfigData mConfigData;        
    private:     
        /** 
         * Store the name of the file used for the previous loading operation 
         */
        String mLoadedFrom;
        /**
         * Copy Constructor
         */
        Config(Config& src);
        /**
         * Affectation operator 
         */
        Config& operator=(Config&);
    };    
}
std::ostream& operator<<(std::ostream& out, const Util::Config& obj);
#ifdef UTIL_OPT_INLINE
#  include "Config.icc"
#endif 
#endif
/*******************************************************************************/      



