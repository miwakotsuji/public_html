/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @ingroup util_system 
 * @file
 * @brief Class File definitions 
 *  
 *
 * 
 * 
 * - Supports: All 
 * - Created: 2005-08-24
 * - Creator: Olivier DELANNOY
 * - $Revision $
 * - Changelog: 
 *    
 *    * 2005-08-24 : Initial version  
 ******************************************************************************
@LICENSE@
 *******************************************************************************/
#include "File.hh"
#include "UID.hh"
#include <cstdio>
#if defined (__WIN32__) || defined(_WIN32)
#  include <windows.h>
#else
#  include <unistd.h>
#  define UTIL_REMOVE(path) unlink(path.c_str())
#endif 
bool Util::File::remove(const Util::String& fileName)
{
    return UTIL_REMOVE(fileName) == 0;
}

bool Util::File::rename(const Util::String& destName, 
                        const Util::String& srcName)
{
    UTIL_DEBUGUTIL("Move");
    UTIL_DEBUGUTIL("Destination: " << destName);
    UTIL_DEBUGUTIL("Source: " << srcName);
    return ::rename(srcName.c_str(), destName.c_str()) == 0;
}


bool Util::File::copy(const Util::String& destName, 
                      const Util::String& srcName)
{
   UTIL_DEBUGUTIL("Copy");
   UTIL_DEBUGUTIL("Destination: " << destName);
   UTIL_DEBUGUTIL("Source: " << srcName);
   FILE* dst = fopen(destName.c_str(), "wb");
   if (dst == 0)
       return false;
   FILE* src = fopen(srcName.c_str(), "rb");
   if (src == 0)
   {
       fclose(dst);
       Util::File::remove(destName);
       return false;
   }
   char buffer[0xffff];
   while(! feof(src))
   {
       ssize_t readed = fread(buffer, 1, 0xffff, src);
       if (readed == -1)
       {
           fclose(src);
           fclose(dst);
           Util::File::remove(destName);
           return false;
       }
       if (readed > 0)
       {
           ssize_t written = fwrite(buffer, 1, readed, dst);
           if ((written == -1) || (written != readed))
           {
               fclose(src);
               fclose(dst);
               Util::File::remove(destName);
               return false;
           }
       }
   }
   fclose(src);
   fclose(dst);
   return true;
}


Util::String Util::File::tempName()
{
    String res("util_temp_");
    res += UID::createUID();
    return res;
}


/*******************************************************************************/
