/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @file
* @brief Class util_namespace declaration
*  
* 
* 
* - Created: 2005-08-05
* - Creator: Olivier Delannoy
* - Changelog: 
*    
*    * 2005-08-05 : Initial version  
*/
/*******************************************************************************
Copyright Olivier Delannoy 2005

Olivier Delannoy <Olivier.Delannoy@gmail.com>

This software is a computer program whose purpose is to [describe
functionalities and technical features of your software].

This software is governed by the CeCILL  license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.

*******************************************************************************/
#ifndef UTIL_UTIL_NAMESPACE_HH
#define UTIL_UTIL_NAMESPACE_HH 1
#include "util_base.hh" 
// Documentation sections 
/** 
 * @defgroup util_base libutil kernel 
 * @brief Foundation class use in all other groups 
 * 
 * This group is composed of all class that are used everywhere and are 
 * essential for the foundation of the library. 
 */ 
/** 
 * @defgroup util_application Application Framework Module
 * @brief Application Framework features overview 
 * 
 * This module groups all features directly linked to the Application
 * Framework available within the utility library 
 */
/**
 * @defgroup util_system System Classes Module
 * @brief System related class 
 * 
 * Those class deals with the system interaction. 
 */ 
/**
 * @defgroup util_tools Tool Classes Module
 * @brief All unclassified class of common usage
 *
 * All class in this module does not fit any other. They come with the
 * utility library in order to fits some common needs in the design of
 * an application. 
 */
/**
 * @defgroup util_xml XML document parsing Module
 * 
 * This module provides all features related to XML parsing. It
 * consists of two main API. The first API is similar to what can be
 * found in SAX and the second one is similar to what can be found in
 * DOM.
 */
/**
 * @brief The utility library namespace. 
 * 
 * Most of the features of the library are directly available throught
 * the namespace util. Some subsystem are avaible in subnamespace of Util. 
 * 
 */
namespace Util 
{
    // Integral types  
    /** 8 bits unsigned integer */
    typedef unsigned UTIL_INT8 uint8;
    /** 16 bits unsigned integer */
    typedef unsigned UTIL_INT16 uint16;
    /** 32 bits unsigned integer */
    typedef unsigned UTIL_INT32 uint32;
    /** 64 bits unsigned integer */
    typedef unsigned UTIL_INT64 uint64;
    /** 8 bit signed integer */
    typedef UTIL_INT8 int8;
    /** 16 bits signed integer */
    typedef UTIL_INT16 int16;
    /** 32 bits signed integer */
    typedef UTIL_INT32 int32;
    /** 64 bits signed integer */
    typedef UTIL_INT64 int64;

    // Reals 
    /** 32 bits floatting point value */
    typedef UTIL_REAL32 real32;
    /** 64 bits floatting point value */
    typedef UTIL_REAL64 real64;

    // Alias of integral types 
    /** byte type  8 bits value */
    typedef uint8 byte;
    /** word type 16 bits value */
    typedef uint16 word;
    /** dword type 32 bits value */
    typedef uint32 dword;
    /** qword type 64 bits value */
    typedef uint64 qword;
    // Strings 
    /** string type */
    typedef UTIL_STRING String;

    // Enumerations 
    /** 
     * @ingroup util_application 
     * Notification type enumeration 
     */
    enum NotificationType 
    {
        UTIL_NOTIFICATION_ERROR,     /**< Display error notification */
        UTIL_NOTIFICATION_EXCEPTION, /**< Display Exception notification */
        UTIL_NOTIFICATION_USAGE,     /**< Display usage notification message */
        UTIL_NOTIFICATION_VERSION,   /**< Display version information */
        UTIL_NOTIFICATION_DEFAULT,   /**< Display Default notification */
    };
    /**
     * @ingroup util_application  
     * Logging level 
     */ 
    enum LoggingLevel 
    {
        UTIL_ALL,   /**< All message */
        UTIL_DEBUG, /**< It's a debugging message */
        UTIL_INFO,  /**< It's a normal message */
        UTIL_WARN,  /**< It might have been bad */
        UTIL_ERROR, /**< It's bad some error occured */
        UTIL_FATAL, /**< It's critical... All must be aborted */
    };
    /**
     * @ingroup util_xml
     * XML Parser configuration flag
     */
    enum XMLParserFlag 
    {
        /** Use the best match parser */
        UTIL_XML_PARSER_BEST = 0,
        /** Use the default parser as specified during the build process */ 
        UTIL_XML_PARSER_DEFAULT = 1,
        /** Try to get a validating parser */ 
        UTIL_XML_PARSER_VALIDATE= 2,
    };    
    /** 
     * @ingroup util_base 
     * XML List the various field that can be queryed for an URL 
     */
    enum URLFieldName 
    {
        UTIL_URL_LOGIN,         /**< Login used */
        UTIL_URL_PASSWORD,      /**< Passord used */
        UTIL_URL_HOSTNAME,      /**< Server hostname */
        UTIL_URL_PORT,          /**< Server port */
        UTIL_URL_PATH,          /**< Path of the query */
        UTIL_URL_QUERY_STRING   /**< Query String */ 
    };
    
}
#endif // UTIL_UTIL_NAMESPACE_HH



