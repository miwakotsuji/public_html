/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @file
* @ingroup util_system
* @brief TCPSocket class inline definitions 
*
* - Supports: 
*   - system: 
*     - UNIX (Linux)
*     - Win32 (XP)
* - Created: 2005-05-29
* - Creator: Olivier Delannoy
* - $Revision $
* - Changelog: 
*    * 2005-08-06 : Integrated to libutil 
*                   - Moved from Util::Compat namespace to Util
*    * 2005-05-29 : Initial version  
*******************************************************************************
@LICENSE@ 
*******************************************************************************/
#include "TCPSocket.hh"
#include "util_config.hh" 
#ifndef UTIL_OPT_INLINE
#define inline
#include "TCPSocket.icc"
#undef inline
#endif 
#if defined(__WIN32__) || defined(_WIN32)
#  include <windows.h>
#  include <Winsock2.h>
#  define UTIL_CLOSE_SOCKET(socket) closesocket(socket)
#else
#  include <sys/types.h>
#  include <sys/socket.h>
#  include <netinet/in.h>
#  include <arpa/inet.h>
#  include <netdb.h>
#  include <unistd.h> 
#  define UTIL_CLOSE_SOCKET(socket) close(socket)
#endif

#if defined(UTIL_OPT_DNS_ADNS)
#  include <adns.h>
#elif defined(UTIL_OPT_DNS_UDNS)
#  include <udns.hh>
#elif defined(UTIL_OPT_DNS_GETHOSTBYNAME)
#  include <netdb.h>
#else
#  include <sys/socket.h>
#  include <netinet/in.h>
#  include <arpa/inet.h>
#endif 

#include <cassert>
#include <cerrno>
#include <cstring>
#include <iostream>
Util::TCPSocket::TCPSocket(const Util::String& host, Util::uint16 port)
    : mAddress(0), mSocket(0), mError(false)
{
    UTIL_DEBUGUTIL("Creating socket: " << host << ':' << port);
    mSocket = ::socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (mSocket == -1)
    {
        mError = true;
        mErrorMsg = ::strerror(errno);
    }
    else 
    {
        mAddress = new struct sockaddr_in;
        
        ::memset(mAddress, 0, sizeof(mAddress));
        mAddress->sin_family = AF_INET;
        mAddress->sin_port = htons(port);
        mAddress->sin_addr.s_addr = htonl(INADDR_ANY);
        if (host != "")
        {
#ifdef UTIL_OPT_DNS_ADNS
            //DNS = adns 
            adns_state state;
            adns_answer* answer;
            if (adns_init(&state, adns_if_noenv, 0) != 0)
            {
                mError = true;
                mErrorMsg = "Unable to init adns";
            }
            else 
            {
                if (adns_synchronous(state, host.c_str(), adns_r_a, adns_qf_quoteok_cname, &answer) != 0)
                {
                  mError = true;
                  mErrorMsg = "ADNS name resolution failed";
                }
                else 
                {
                    mAddress->sin_addr.s_addr = answer->rss.inaddr->s_addr;
                }
                adns_finish(state);
            }
#elif UTIL_OPT_DNS_UDNS
            UTIL_DEBUGUTIL("Using UDNS DNS resolver for host: " << host );
            //DNS = udns (default) 
            struct hostent* hostent;
            
            if ((hostent = Util::UDNS::dns_gethostbyname(host.c_str())) == 0)
            {
                UTIL_DEBUGUTIL("dns_gethostbyname(" << host << ") return an error");
                mError = true;
                mErrorMsg = Util::UDNS::dns_strerror(errno);
            }
            else 
            {
                UTIL_DEBUGUTIL("dns_gethostbyname("  << host << ") return successfully");
                UTIL_DEBUGUTIL("inet_ntoa: " << inet_ntoa(*((struct in_addr*)hostent->h_addr_list[0])));
                
                mAddress->sin_addr.s_addr = ((struct in_addr *)(hostent->h_addr))->s_addr;
            }
#elif UTIL_OPT_DNS_GETHOSTBYNAME
            //DNS = glibc
            struct hostent* hostent;
            if ((hostent = ::gethostbyname(host.c_str())) == 0)
            {
                mError = true;
                mErrorMsg = ::strerror(errno);
            }
            else 
            {
                mAddress->sin_addr.s_addr = ((struct in_addr *)(hostent->h_addr))->s_addr;
            }
#else
            // DNS=none
            if (inet_aton(host.c_str(), &(mAddress->sin_addr)) == 0)
            {
                mError = true;
                mErrorMsg = ::strerror(errno);
            }
#endif 
        }
    }
}

Util::TCPSocket::TCPSocket(Util::int32 socket)
    : mAddress(0), mSocket(socket), mError(false)
{
    
}

Util::TCPSocket::~TCPSocket(void)
{
    UTIL_CLOSE_SOCKET(mSocket);
    delete mAddress;
    
}


void Util::TCPSocket::connect(void)
{
    if (!mError)
    {
        if (::connect(mSocket, (struct sockaddr*) mAddress, sizeof(*mAddress)) != 0)
        {
            // Get the error status 
            mError = true;
            mErrorMsg = ::strerror(errno);
        }    
    }
}


void Util::TCPSocket::listen(void)
{
    if (!mError)
    {
        int opt = 1;
        if (::setsockopt(mSocket, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) != 0)
        {
          mError = true;
          mErrorMsg = ::strerror(errno);
        }
        if (::bind(mSocket, (struct sockaddr*) mAddress, sizeof(*mAddress)) != 0)
        {
            mError = true;
            mErrorMsg = ::strerror(errno);
        }
        else if (::listen(mSocket, 20) != 0)
        {
            mError = true;
            mErrorMsg = ::strerror(errno);
        }
    }
    
}

void Util::TCPSocket::shutdown(bool input, bool output)
{
    if (!mError)
    {
        
        int mode = 0;
        if (input) 
            ++mode;
        if (output)
            ++mode;
        if (::shutdown(mSocket, mode) != 0)
        {
            mError = true;
            mErrorMsg = ::strerror(errno);
        }
    }
}

Util::int32 Util::TCPSocket::accept(void)
{
    return ::accept(mSocket, 0, 0);
}


Util::int32 Util::TCPSocket::send(Util::byte* data, Util::uint32 length)
{       
    Util::int32 result = 0;
    Util::int32 len = 0;
    while( length - len > 0  && !mError)
    {
        result = ::send(mSocket, (char*)data + len, length - len, 0);
        if (result == -1)
        {
            mError = true;
            mErrorMsg = strerror(errno);    
        }
        else 
        {
            len += result;
        }
    }
    return (result == -1) ? result : length;
}

Util::int32 Util::TCPSocket::read(Util::byte* data, Util::uint32 length)
{ 
    int32 result =  ::read(mSocket, (char*)data, length);  
    if (result == -1)
    {
      mError = true;
      mErrorMsg = strerror(errno);
    }
    return result;
}

Util::int32 Util::TCPSocket::recv(Util::byte* data, Util::uint32 length)
{
    Util::int32 result = 0;
    Util::int32 len = 0;
    while( length - len > 0 && !mError)
    {
        
        result = ::recv(mSocket, (char*)data + len, length - len, 0);
        if (result == -1)
        {
            mError = true;
            mErrorMsg = strerror(errno);
        }
        else if (result == 0)
        {
            return len;
        }
        else 
        {
            len += result;
        }
    }
    return (result == -1) ? result : length;
}

Util::int32 Util::TCPSocket::write(Util::byte* data, Util::uint32 length)
{
    int32 result = ::write(mSocket, (char*)data, length);
    if (result == -1)
    {
        mError = true;
        mErrorMsg = strerror(errno);
    }
    return result;
}


// Disabled operation 

Util::TCPSocket::TCPSocket(void) 
{
    assert(0);
}

Util::TCPSocket::TCPSocket(Util::TCPSocket&)
{
    assert(0);
}

Util::TCPSocket& Util::TCPSocket::operator=(Util::TCPSocket&)
{
    assert(0);
    return *this;
}
/*******************************************************************************/

