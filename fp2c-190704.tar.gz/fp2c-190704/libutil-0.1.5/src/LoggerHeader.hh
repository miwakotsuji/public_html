/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @file
 * @brief Class LoggerHeader declaration
 *  
 * 
 * - Supports: All  
 * - Created: 2006-03-23
 * - Creator: Olivier Delannoy
 * - Last change in revision : $Revision $
 * - Changelog: 
 *    
 *    * 2006-03-23 : Initial version  
 ******************************************************************************
Copyright Olivier Delannoy 2005

Olivier Delannoy <Olivier.Delannoy@gmail.com>

This software is a computer program whose purpose is to [describe
functionalities and technical features of your software].

This software is governed by the CeCILL  license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.

 *******************************************************************************/
#ifndef UTIL_LOGGERHEADER_HH
#define UTIL_LOGGERHEADER_HH 1
#include "util_namespace.hh"
#include <iostream>
namespace Util 
{
    /**
     * @brief 
     *
     * 
     * - Supports: All
     * - Author: Olivier Delannoy
     * - Creator: 2006-03-23
     * - $Revision $
     */
    class UTIL_EXPORT LoggerHeader
    {
    public:
        /**
         * Constructor 
         * @param filename the name of the file where the LoggerHeader was created 
         * @param line the line number 
         * @param level the level of the message 
         */
        LoggerHeader(const char* const filename, uint32 line, LoggingLevel level);
        /** 
         * Get the level of the message 
         */
        LoggingLevel level(void) const;
        
        /**
         * Printout the object to a stream 
         * 
         * @param out the stream object
         *
         * @param format the format of the header is a string
         * containing a combinaison of the following markers
         * - %u: Timestamp formatted this way: yy-mm--dd hh:mm::ss
         * - %p: Process identifier
         * - %b*: Process name (ignored at the moment)
         * - %t: Thread id (ignored at the moment)
         * - %f*: File name
         * - %l: Line
         * - %m*: log level (as text) 
         * - %d: log level (as an integer)   
         * - %%: a %
         * Format information with a star can be limited placing a number between the format and the tag caracter. 
         */
        void format(std::ostream& out, const String& format) const;
    protected:
    
    private:
        /** file name of the file */
        const char* mFile;
        /** line number */
        uint32 mLine;
        /** Level of the message */
        LoggingLevel mLevel;
        /** time of the message */ 
        int32 mTime;
        /* Disabled constructor */ 
        LoggerHeader(void);
        
    };
}
#ifdef UTIL_OPT_INLINE
#include "LoggerHeader.icc"
#endif 
#endif // UTIL_LOGGERHEADER_HH
/*******************************************************************************/



