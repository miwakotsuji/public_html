/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @file
* @ingroup util_system 
* @brief Class FileInfo declaration 
*  
*
* 
* 
* - Supports: 
*    - System 
*      - UNIX (Linux) 
*      - Win32 (XP)
* - Created: 2005-07-15
* - Creator: Olivier Delannoy
* - $Revision $
* - Changelog: 
*    
*    * 2005-08-07 : Integrated to libutil 
*          - Moved to Util namespace instead of Util::Compat 
*    * 2005-07-15 : Initial version 
******************************************************************************
Copyright Olivier Delannoy 2005

Olivier Delannoy <Olivier.Delannoy@gmail.com>

This software is a computer program whose purpose is to [describe
functionalities and technical features of your software].

This software is governed by the CeCILL  license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.

*******************************************************************************/
#ifndef UTIL_FILEINFO_HH
#define UTIL_FILEINFO_HH 1
#include "util_namespace.hh"
#include <iostream> 
namespace Util {
    /**
     * @ingroup util_system 
     * @brief Retreives information concerning files 
     *
     * Retrieves some information concerning a file
     * name. Information contains : 
     *   - file exists
     *   - Check if it's a file 
     *   - Check if it's a directory 
     *   - Get the size of the file 
     *   - Check if it is possible to read a file or a directory
     *   - Check if it is possible to write to a file or a directory
     *   - Check if it is possible to execute to a file or a directory 
     *
     * - Supports: 
     *    - System 
     *      - UNIX (Linux) 
     *      - Win32 (XP)
     * - Created: 2005-07-15
     * - Creator: Olivier Delannoy
     * - $Revision $
     * @todo Deal with special file and modification times 
     */
    class FileInfo
    {
    public:
            
        /**
         * Load information about a path.
         * @param path The name of the file or the current folder.  
         */
        FileInfo(const String& path = ".");

        /**
         * Destructor
         */
        ~FileInfo(void);
            
        /**
         * Update all information
         */
        void update(void);
        /**
         * Test whether the file exists or not 
         * 
         * @return true if the file exists and if we can access to
         * it's information. 
         */
        bool exists(void) const;
            
        /**
         * Test whether it is a directory or not 
         * 
         * @return true if it is a directory
         */
        bool isDir(void) const;
            
        /**
         * Test whether it is a file or not 
         * 
         * @return true if it is a file 
         */
        bool isFile(void) const ;
            
        /**
         * Retrieve the size of a file.
         * 
         * @return the number of bytes of the file. 
         */
        uint64 size(void) const;

        /**
         * Test whether the file is readable 
         *
         * @return true if it is possible to read from the file or  directory 
         */
        bool isReadable(void) const;
            
        /**
         * Test whether the file is writable 
         *
         * @return true if it is possible to write to the file or  directory 
         */
        bool isWriteable(void) const;
            
        /**
         * Test whether the file is executable 
         *
         * @return true if it is possible to execute the file or directory 
         */
        bool isExecutable(void) const;
        /**
         * Get the path corresponding to the object 
         * @return a String corresponding to the path 
         */
        const String& path(void) const;
        /**
         * Printout some information concerning the FileInfo object
         * @param out the stream object 
         */
        void print(std::ostream& out) const;
    protected:
    private:  
        /** Store whether it's a file */
        bool mFile;
        /** Store whether it's a directory */
        bool mDir;
        /** True if the information are valid false otherwise */
        bool mValid;
        /** True if the file is readable */
        bool mReadable;
        /** True if the file is writeable */
        bool mWriteable;
        /** True if the file is executable */ 
        bool mExecutable;
        /** Store the size of the file */
        uint64 mSize;
        /** Store the path of the file */
        String mPath;  
    };
}
/**
 * Stream operator << for a Util::FileInfo object 
 */
std::ostream& operator<<(std::ostream& out, const Util::FileInfo& obj);
# ifdef UTIL_OPT_INLINE
#  include "FileInfo.icc"
# endif
#endif
/*******************************************************************************/




