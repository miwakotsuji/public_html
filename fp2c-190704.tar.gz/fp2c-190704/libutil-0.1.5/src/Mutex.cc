/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @ingroup util_system
 * @file
 * @brief Class Mutex definition 
 *  
 * - Supports:
 *   - System 
 *       - UNIX/Pthread 
 *       - Win32 
 *   - SDL  
 * - Created: 2005-08-06
 * - Creator: Olivier Delannoy
 * - Changelog: 
 *    
 *    * 2005-08-06 : Initial version  
 *******************************************************************************
@LICENSE@
 *******************************************************************************/
#include "Mutex.hh"
#ifndef UTIL_OPT_INLINE 
#define inline
#include "Mutex.icc"
#undef inline
#endif

#ifdef UTIL_OPT_SDL
// SDL 
#  include<SDL/SDL.h>
#  include<SDL/SDL_thread.h>
#elif defined(__WIN32__) || defined(_WIN32)
// Win32 
#  include <windows.h>
#else 
// UNIX Pthread 
#  include <pthread.h>
#endif
#include <cassert> 
Util::Mutex::Mutex(void)
{
#if defined(UTIL_OPT_SDL)
    class LocalImpl : public MutexImpl 
    {
    public:
        LocalImpl(void) : mMutex(SDL_CreateMutex()) {}
        virtual ~LocalImpl(void)
        {
            SDL_DestroyMutex(mMutex);
        }
        virtual void lock(void)
        {
            assert(SDL_mutexP(mMutex) == 0);    
        }
        virtual void unlock(void)
        {
            assert(SDL_mutexV(mMutex) == 0);
        }
    private:
        SDL_mutex * mMutex;  
    };
#elif defined(__WIN32__) || defined(_WIN32)
    class LocalImpl : public MutexImpl 
    {
    public:
        LocalImpl(void)
        {
            InitializeCriticalSection(&mMutex);  
        }
        virtual ~LocalImpl(void) 
        {
            DeleteCriticalSection(&mMutex);
        }
        virtual void lock(void)
        {
            EnterCriticalSection(&mMutex);
        }
        virtual void unlock(void)
        {
            LeaveCriticalSection(&mMutex);
        }
    private:
        CRITICAL_SECTION mMutex;
    };
    
#else 
    // Pthread 
    class LocalImpl : public MutexImpl
    {
    public:
        LocalImpl(void)
        {
            assert(pthread_mutex_init(&mMutex, 0) == 0);
        }
        virtual ~LocalImpl(void)
        {
            pthread_mutex_destroy(&mMutex);
        }
        virtual void lock(void) 
        {
            assert(pthread_mutex_lock(&mMutex) == 0);
        }
        virtual void unlock(void)
        {
            assert(pthread_mutex_unlock(&mMutex) == 0);
        }        
    private:
        pthread_mutex_t mMutex;
    };
#endif    
    mImpl = new LocalImpl;
    assert(mImpl);
}
//Destructor
Util::Mutex::~Mutex(void)
{
    delete mImpl;
}
/*******************************************************************************/      
