/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @ingroup util_tools 
* @file
* @brief Class LittleEndianStream definitions 
*  
* This class handle binary IO operation on files. 
* - Supports: All 
* 
* - Created: 2005-08-06
* - Creator: Olivier Delannoy
* - Changelog: 
*
*    * 2005-08-06 : Initial version  
*/
/*******************************************************************************
@LICENSE@
*******************************************************************************/
#include "LittleEndianStream.hh"
#ifndef UTIL_OPT_INLINE
#  define inline
#  include "LittleEndianStream.icc"
#  undef inline
#endif
#include <cassert> 
#include <algorithm>
#ifndef __GNUC__
#include <stdint.h>
#endif 
#include <fstream> 
#if __BYTE_ORDER == __BIG_ENDIAN
#define BYTE_SWAP(data) byteSwap(reinterpret_cast<uint8_t*>(&data), sizeof(data))
/**
 * @internal 
 * Private function used to swap bytes of a data 
 * It works for both LE to BE and BE to LE 
 */
static void byteSwap(Util::uint8* value, Util::uint32 length)
{
    register Util::uint32 i = 0;
    register Util::uint32 j = length-1;
    while (i < j)
    {
        std::swap(value[i], value[j]);
        ++i; 
        --j;
    }
}
#else
#define BYTE_SWAP(data)
#endif 


Util::LittleEndianStream::LittleEndianStream(void)
{
    assert(0);
}
Util::LittleEndianStream::LittleEndianStream(Util::LittleEndianStream& src)
{
    assert(0);
}
Util::LittleEndianStream& Util::LittleEndianStream::operator=(Util::LittleEndianStream& src)
{
    assert(0);
    return *this;
}
Util::LittleEndianStream::LittleEndianStream(const Util::String& fileName)
{
    std::ifstream in(fileName.c_str());
    if (!in)
    {
        //Create the file
        std::ofstream out(fileName.c_str());
        out.close();
    }
    in.close();
    mStream = new std::fstream(fileName.c_str());
    
}

Util::LittleEndianStream::LittleEndianStream(std::iostream* stream) 
{
    mStream = stream;
}


Util::LittleEndianStream::~LittleEndianStream() 
{
    delete mStream;
}
bool Util::LittleEndianStream::read(Util::int8& result) 
{
    mStream->read(reinterpret_cast<char*>(&result), sizeof(int8));
    return *mStream;
}
bool Util::LittleEndianStream::read(Util::uint8& result) 
{

    mStream->read(reinterpret_cast<char*>(&result), sizeof(uint8));
    return *mStream;
}
bool Util::LittleEndianStream::read(Util::int16& result) 
{
    mStream->read(reinterpret_cast<char*>(&result), sizeof(int16));
    BYTE_SWAP(result);
    return *mStream;
}
bool Util::LittleEndianStream::read(Util::uint16& result) 
{
    mStream->read(reinterpret_cast<char*>(&result), sizeof(uint16));
    BYTE_SWAP(result);
    return *mStream;
}
bool Util::LittleEndianStream::read(Util::int32& result) 
{
    mStream->read(reinterpret_cast<char*>(&result), sizeof(int32));
    BYTE_SWAP(result);
    return *mStream;
}
bool Util::LittleEndianStream::read(Util::uint32& result) 
{
    mStream->read(reinterpret_cast<char*>(&result), sizeof(uint32));
    BYTE_SWAP(result);
    return *mStream;
}
bool Util::LittleEndianStream::read(Util::int64& result) 
{
    mStream->read(reinterpret_cast<char*>(&result), sizeof(int64));
    BYTE_SWAP(result);
    return *mStream;
}
bool Util::LittleEndianStream::read(Util::uint64& result) 
{
    mStream->read(reinterpret_cast<char*>(&result), sizeof(uint64));
    BYTE_SWAP(result);
    return *mStream;
}
bool Util::LittleEndianStream::read(Util::real32& result) 
{
    mStream->read(reinterpret_cast<char*>(&result), sizeof(real32));
    BYTE_SWAP(result);
    return *mStream;
}
bool Util::LittleEndianStream::read(Util::real64& result) 
{
    mStream->read(reinterpret_cast<char*>(&result), sizeof(real64));
    BYTE_SWAP(result);
    return *mStream;
}
bool Util::LittleEndianStream::write(Util::int8 value) 
{
    mStream->write(reinterpret_cast<char*>(&value), sizeof(int8));
    return *mStream;
}
bool Util::LittleEndianStream::write(Util::uint8 value) 
{
    mStream->write(reinterpret_cast<char*>(&value), sizeof(uint8));
    return *mStream;
}
bool Util::LittleEndianStream::write(Util::int16 value) 
{

    BYTE_SWAP(value);
    mStream->write(reinterpret_cast<char*>(&value), sizeof(int16));
    return *mStream;
}
bool Util::LittleEndianStream::write(Util::uint16 value) 
{
    BYTE_SWAP(value);
    mStream->write(reinterpret_cast<char*>(&value), sizeof(uint16));
    return *mStream;
}
bool Util::LittleEndianStream::write(Util::int32 value) 
{
    BYTE_SWAP(value);
    mStream->write(reinterpret_cast<char*>(&value), sizeof(int32));
    return *mStream;
}
bool Util::LittleEndianStream::write(Util::uint32 value) 
{
    BYTE_SWAP(value);
    mStream->write(reinterpret_cast<char*>(&value), sizeof(uint32));
    return *mStream;
}
bool Util::LittleEndianStream::write(Util::int64 value) 
{
    BYTE_SWAP(value);
    mStream->write(reinterpret_cast<char*>(&value), sizeof(int64));
    return *mStream;
}
bool Util::LittleEndianStream::write(Util::uint64 value) 
{
    BYTE_SWAP(value);
    mStream->write(reinterpret_cast<char*>(&value), sizeof(uint64));
    return *mStream;
}
bool Util::LittleEndianStream::write(Util::real32 value) 
{
    BYTE_SWAP(value);
    mStream->write(reinterpret_cast<char*>(&value), sizeof(real32));
    return *mStream;
}
bool Util::LittleEndianStream::write(Util::real64 value) 
{
    BYTE_SWAP(value);
    mStream->write(reinterpret_cast<char*>(&value), sizeof(real64));
    return *mStream;
}
/******************************************************************************/
