/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @ingroup util_application
* @file
* @brief Class ConfigFactory declaration  
*  
* - Supports: All
* - Created: 2005-08-06
* - Creator: Olivier Delannoy
* - $Revision $
* - Changelog: 
*    
*    * 2005-08-06 : Initial version  
*******************************************************************************
Copyright Olivier Delannoy 2005

Olivier Delannoy <Olivier.Delannoy@gmail.com>

This software is a computer program whose purpose is to [describe
functionalities and technical features of your software].

This software is governed by the CeCILL  license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.

*******************************************************************************/
#ifndef UTIL_CONFIGFACTORY_HH
#define UTIL_CONFIGFACTORY_HH 1
#include "Factory.hh"
#include "Config.hh"
namespace Util {
    /**
     * @ingroup util_application
     * @brief Config object provider. This class manage a pool of Config
     * object.
     * 
     * This class provide Config objects on demand. It instantiate the
     * well adapted loader dependending on the hints given by the
     * programmer or on the file extension. Multiple loading of the same
     * config file leads to one load from the disk.
     *
     */
    class ConfigFactory : public Util::Factory<Config>
    {
    public:
        /**
         * Default Constructor
         */ 
        ConfigFactory(void);
        /**
         * Default Destructor
         */
        virtual ~ConfigFactory(void);
        /**
         * Set the default path to configuration files 
         * @param path the configuration file search path 
         */
        void setConfigDir(const String& path);
        /**
         * Set the default configuration file 
         * @param baseName the baseName of the master configuration file 
         */
        void setDefault(const String& baseName);
        /**
         * Set the extension corresponding of the fallback loader to
         * use.  If the file to load come without any extension the factory 
         * will try the loader corresponding to @em fileExtension 
         */
        void setDefaultLoader(const String& fileExtension);
        /**
         * Register a new config loaded 
         */
        void registerLoader(const String& fileExtension, Config* object);
    protected:
        /** Create new Config object on demands */
        virtual Config* createObject(const String& baseName);

    private:
        /** Configuration Directory */
        String mConfigDir;
        /** Default configuration file */
        String mDefault;
        /** Default config format extension */
        String mDefaultExt;
        /** Store loaders */
        std::map<String, Config*> mLoaders;
    };  
}
#ifdef UTIL_OPT_INLINE 
#  include "ConfigFactory.icc"
#endif
#endif
/*******************************************************************************/      



