/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
 *******************************************************************************
 * Utility Library 
 *******************************************************************************
 * @file
 * @brief Class UID function definition 
 *  
 * - Supports: All
 * - Created: 2005-08-06
 * - Creator: Olivier Delannoy
 * - Changelog: 
 *    
 *    * 2005-08-06 : Initial version  
 *******************************************************************************
@LICENSE@
 *******************************************************************************/
#include "UID.hh"
#include "MD5.hh"
#include "RuntimeEnvironment.hh"
#include <sstream>
#include <cstring>
#include <cstdlib> 
Util::String Util::UID::createUID(void)
{
    std::ostringstream out;
    out << RuntimeEnvironment::processID();
    out << RuntimeEnvironment::unixTime();
    out << rand();
    return MD5::stringToString(out.str());
}

void Util::UID::createUID(Util::byte* result)
{
    std::ostringstream out;
    out << RuntimeEnvironment::processID();
    out << RuntimeEnvironment::unixTime();
    out << rand();       
    Util::MD5 digest;
    digest.init();
    digest.update(reinterpret_cast<byte*>(const_cast<char*>(out.str().c_str())), out.str().size());
    digest.finalize();
    memcpy(result, digest.getDigest(), 16);
}
/*******************************************************************************/      
