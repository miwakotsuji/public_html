/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @ingroup util_application
* @file
* @brief Class ConfigFactory definition  
*  
* - Supports: All
* - Created: 2005-08-06
* - Creator: Olivier Delannoy
* - $Revision $
* - Changelog: 
*    
*    * 2005-08-06 : Initial version  
*******************************************************************************
@LICENSE@
*******************************************************************************/
#include "ConfigFactory.hh"
#ifndef UTIL_OPT_INLINE
#define inline 
#include "ConfigFactory.icc"
#undef inline
#endif
#include "FileInfo.hh"
#include "RuntimeEnvironment.hh"
#include "LoggerFactory.hh"

Util::ConfigFactory::ConfigFactory(void)
    : mConfigDir("."), mDefault(""), mDefaultExt("")
{
    UTIL_DEBUGUTIL("Start Configuration services");
    
}
Util::ConfigFactory::~ConfigFactory(void)
{   
    // Unload loaders object 
    std::map<String, Config*>::iterator iter = mLoaders.begin();
    for (; iter != mLoaders.end() ; ++iter)
    {
        delete iter->second;
    }
    UTIL_DEBUGUTIL("End Configuration services");
}
Util::Config* Util::ConfigFactory::createObject(const Util::String& baseName)
{
    
    Config *result = 0;
    String path = mConfigDir;
    path += RuntimeEnvironment::PATH_SEPARATOR;
    if (baseName == "default")
        path += mDefault;
    else
        path += baseName;
    UTIL_DEBUGUTIL("Load configuration named '" << baseName << "': " << path);
    // Test the default loader if it exists
    if (FileInfo(path + '.' + mDefaultExt).isFile() && mLoaders.find(mDefaultExt) != mLoaders.end())
    {
        //Use the default loader 
        result = mLoaders[mDefaultExt]->clone();
        //Load the configuration
        UTIL_DEBUGUTIL("Loading: " << path << '.' << mDefaultExt);
        UTIL_DEBUG("default", "Loading '" << baseName << "' : " << path + '.' + mDefaultExt);
        result->load(path + '.' + mDefaultExt);
    }
    else 
    {
        //Iterate throught all loader
        std::map<String, Config*>::const_iterator iter = mLoaders.begin();
        for(; iter != mLoaders.end() ; ++iter)
        {
            if (FileInfo(path + iter->first).isFile())
            {
        
                // Use this loader 
                result = iter->second->clone();
                // Load the configuration 
                UTIL_DEBUGUTIL("Loading: " << path << '.' << iter->first);
                UTIL_DEBUG("default", "Loading '" << baseName << "' : " << path << '.' << iter->first);
                result->load(path + '.' + iter->first);
                break;
            }
        }
    }
    
    // Try our best ... to be really accomodating  
    if (! result && (mLoaders.find(mDefaultExt) != mLoaders.end()))
    {
        UTIL_DEBUGUTIL("Fallback loader: " << mDefaultExt);
        // Create the Default Configuration object and load nothing
        result = mLoaders[mDefaultExt]->clone();
    }
    return result;
}
/*******************************************************************************/      
