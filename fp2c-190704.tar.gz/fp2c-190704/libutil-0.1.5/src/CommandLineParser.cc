/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @ingroup util_application
* @file
* @brief Class CommandLineParser declaration   
*  
* - Supports: All
* - Created: 2005-08-07-02
* - Creator: Olivier Delannoy
* - $Revision $
* - Changelog: 
*    * 2005-08-06 : libutil integration and updates 
*    * 2005-07-02 : 
*       - Removing std::string dependencies
*       - Adding a function to give access to the number of available parameters 
*******************************************************************************
@LICENSE@
*******************************************************************************/
#include "CommandLineParser.hh"
#ifndef UTIL_OPT_INLINE 
#define inline
#include "CommandLineParser.icc"
#undef inline 
#endif 
Util::CommandLineParser::CommandLineParser(int argc, char **argv) : mCount(0), mVariadic(false), mParsed(false)
{
    for(uint32 i = 1; i - argc > 0; ++i)
    {
        mParameters.push_back(argv[i]);
    }
}
Util::CommandLineParser::CommandLineParser(Util::CommandLineParser& src)
{
    assert(0);
}
Util::CommandLineParser& Util::CommandLineParser::operator=(Util::CommandLineParser& src)
{
    assert(0);
    return *this;
}
Util::CommandLineParser::~CommandLineParser(void)
{
    for (OptionList::iterator iter = mOptions.begin(); iter != mOptions.end() ; ++iter)
    {
        delete  *iter;
    }
}
bool  Util::CommandLineParser::parse()
{
    assert(!mParsed); 
    mParsed = true;
    //Parse option list
    while(mParameters.size())
    {
        const String front = mParameters.front();
        if (front.size() < 2 || front == "--" || front[0] != '-' || front[1] != '-') 
        {
            if (front == "--") 
                mParameters.pop_front();
            break;
        }
        else  
        {
            OptionList::iterator iter = mOptions.begin();
            for(; iter != mOptions.end(); ++iter) 
            {
                if ((*iter)->match(front))
                    break;
            }
            if (iter == mOptions.end()) 
                return false;
        }
        mParameters.pop_front();
    }
    // Check if all options required are presents 
    for(OptionList::const_iterator iter = mOptions.begin() ; iter != mOptions.end() ; ++iter)
    {
        if ((*iter)->isRequired() && (*iter)->count() == 0)
        {
            return false;
        }
          
    }

    // Parameter only now detect all things begining with -- and return an error 
    for(ParameterList::const_iterator iter = mParameters.begin() ; iter != mParameters.end() ; ++iter)
    {
        if ((*iter)[0] == '-' && (*iter)[1] == '-')
            return false;
    }

    // Okay we are in the case of parameters... Lets check their number 
    UTIL_DEBUGUTIL(mParameters.size() << "<" << mCount);
    if (mParameters.size() < mCount)
        return false;
    if (mVariadic == false && mParameters.size() != mCount)
        return false;
    return true;
}

Util::CommandLineOption*  Util::CommandLineParser::option(const Util::String& name)
{
  
    assert(mParsed);
    for(OptionList::iterator iter = mOptions.begin(); iter != mOptions.end() ; ++iter)
    {
        if ((*iter)->name() == name)
            return *iter;
    }
    return 0;
}
void Util::CommandLineParser::print(std::ostream& out) const throw()
{
    out << "CommandLineParser<<<" << std::endl
        << "\tOptions: " << std::endl;
    OptionList::const_iterator iter = mOptions.begin();
    for ( ; iter != mOptions.end() ; ++iter)
    {
        out << "\t\t-" << *iter << std::endl;
    }
    out << "\tParameters: " << std::endl;
    ParameterList::const_iterator iter2 = mParameters.begin();
    for ( ; iter2 != mParameters.end() ; ++iter2)
    {
        out << "\t\t-<<<" << *iter << ">>>" << std::endl;
    }
    out << ">>>";
}
/*******************************************************************************/      

