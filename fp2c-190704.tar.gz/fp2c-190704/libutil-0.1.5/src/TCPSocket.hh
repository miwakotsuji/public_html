/* -*- mode: c++; c-file-style: "engine"; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/**
*******************************************************************************
* Utility Library 
*******************************************************************************
* @file
* @ingroup util_system
* @brief TCPSocket class declaration
*
* - Supports: 
*   - system: 
*     - UNIX (Linux)
*     - Win32 (XP)
* - Created: 2005-05-29
* - Creator: Olivier Delannoy
* - $Revision $
* - Changelog: 
*    * 2005-08-06 : Integrated to libutil 
*                   - Moved from Util::Compat namespace to Util
*    * 2005-05-29 : Initial version  
*******************************************************************************
@LICENSE@ 
*******************************************************************************/
#ifndef UTIL_TCPSOCKET_HH
# define UTIL_TCPSOCKET_HH 1
#include "util_namespace.hh"
struct sockaddr_in;
namespace Util {
    /**
     * @brief TCP Socket abstract class 
     *
     * 
     * - Supports: 
     *   - system: 
     *     - UNIX (Linux)
     *     - Win32 (XP)
     * - Created: 2005-05-29
     * - Creator: Olivier Delannoy
     * - $Revision $
     * - Changelog: 
     *    * 2005-08-06 : Integrated to libutil 
     *                   - Moved from Util::Compat namespace to Util
     *    * 2005-05-29 : Initial version  
     */
    class TCPSocket
    {
    public:
        virtual ~TCPSocket(void);
        /**
         * return true if the socket is in a good state 
         */
        bool isOk(void) const;
        /**
         * Get the last error message or an empty string 
         */
        const String& lastError(void) const;
            
    protected:
        /**
         * Create a new communication end point and bind it to an
         * address and a port. A server socket can pass a blank
         * string as host. 
         * 
         * @param host the name of distant communication end
         * point. It can be a dotted ip notation or a host name. 
         *
         * @param port the port number of the distant
         * communication end point or the port to use for
         * listening operation. 
         */
        TCPSocket(const String& host, uint16 port);
            
        TCPSocket(int32 socket);
            
        void connect(void);
        void listen(void);

        void shutdown(bool input = true, bool output = true);

        int32 accept(void);
            
        int32 send(byte* data, uint32 length);
        int32 recv(byte* data, uint32 length);

        int32 read(byte* data, uint32 length);
        int32 write(byte* data, uint32 length);
    private:
        struct sockaddr_in* mAddress;
        /** 
         * Store Socket Handler
         */
        int32 mSocket;
        /**
         * True if an error occured 
         */
        bool mError;
        /**
         * Store the last error string
         */
        String mErrorMsg;
            
            
        /**
         * Disabled operation 
         */
        TCPSocket(void);
        /**
         * Disabled operation 
         */
        TCPSocket(TCPSocket&);
        /**
         * Disabled operation 
         */
        TCPSocket& operator=(TCPSocket&);
    };
}
#ifdef UTIL_OPT_INLINE
#  include "TCPSocket.icc"
#endif
#endif
/*******************************************************************************/




