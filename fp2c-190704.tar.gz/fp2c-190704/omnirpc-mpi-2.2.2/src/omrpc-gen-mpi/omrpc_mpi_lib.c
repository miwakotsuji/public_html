
void mpi_start_rex(int argc, char **argv)
{
  // dummy
} /* mpi_start_rex */

void mpi_finish_rex()
{
  // dummy
} /* mpi_finish_rex */

