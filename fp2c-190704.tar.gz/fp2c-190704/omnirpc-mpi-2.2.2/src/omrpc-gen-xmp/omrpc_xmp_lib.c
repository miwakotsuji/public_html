
void xmp_start_rex(int argc, char **argv)
{
  // dummy
} /* xmp_start_rex */

void xmp_finish_rex()
{
  // dummy
} /* xmp_finish_rex */

